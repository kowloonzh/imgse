#!/usr/bin/env bash
set -euo pipefail

# Offline smoke suite for zgpt-run-worker.sh's sliding inactivity marker
# deadline. Never launches a real pane and never requires a live herdr session:
#   - The pure deadline arithmetic (zgpt_sliding_deadline in zgpt-common.sh) is
#     exercised directly.
#   - The real run-worker.sh is run against a stubbed zgpt-worker-pane.sh
#     launcher and a herdr stub whose `pane read` content is env-driven, so the
#     completion loop is exercised end to end:
#       * active mode  -> transcript grows every read -> deadline slides, the
#         run must NOT time out even with a tiny --timeout
#       * static mode  -> transcript never changes -> marker_timeout after the
#         --timeout inactivity window
#       * cap mode     -> active transcript but --max-timeout 2 -> marker_timeout
#         at the absolute ceiling despite continued output
#       * marker mode  -> the stub prints WORKER_DONE after N reads -> status=ok
#       * underscore marker -> one-character separator typo is accepted with a
#         warning so --close still runs

scripts="$(cd "$(dirname "${BASH_SOURCE[0]}")/../scripts" && pwd)"
# shellcheck source=/dev/null
source "$scripts/zgpt-common.sh"

passed=0
failed=0
pass() { printf 'PASS: %s\n' "$1"; passed=$((passed + 1)); }
fail() { printf 'FAIL: %s\n' "$1" >&2; failed=$((failed + 1)); }
assert_eq() { if [[ "$1" == "$2" ]]; then pass "$3"; else fail "$3 (got=$1 expected=$2)"; fi; }
assert_contains() { if grep -q -- "$2" <<<"$1"; then pass "$3"; else fail "$3 (output did not contain: $2)"; fi; }
assert_fail() { local label="$1"; shift; if ! "$@" >/dev/null 2>&1; then pass "$label"; else fail "$label (expected failure)"; fi; }

tmp="$(mktemp -d "${TMPDIR:-/tmp}/zgpt-deadline-smoke.XXXXXX")"
trap 'rm -rf "$tmp"' EXIT

# ── Pure deadline arithmetic ─────────────────────────────────────────────────
assert_eq "$(zgpt_sliding_deadline 1000 900 0 0)" '1900' 'no cap: deadline = last_activity + inactivity'
assert_eq "$(zgpt_sliding_deadline 1000 900 100 5000)" '1900' 'far below ceiling: deadline = last_activity + inactivity'
assert_eq "$(zgpt_sliding_deadline 1000 900 100 1000)" '1100' 'absolute ceiling caps the sliding deadline'
assert_eq "$(zgpt_sliding_deadline 1000 900 100 5)" '105' 'tiny --max-timeout caps immediately'

# ── Stub harness ─────────────────────────────────────────────────────────────
# Real run-worker.sh + common.sh + cli-adapter.sh (symlinked so `source
# "$script_dir/..."` resolves), a fake zgpt-worker-pane.sh launcher that
# reports a fake pane_id, and a herdr stub whose transcript content is driven
# by env so the completion loop sees realistic activity patterns.
stub_dir="$tmp/scripts"
mkdir -p "$stub_dir" "$tmp/bin"
ln -s "$scripts/zgpt-run-worker.sh" "$stub_dir/zgpt-run-worker.sh"
ln -s "$scripts/zgpt-common.sh" "$stub_dir/zgpt-common.sh"
ln -s "$scripts/zgpt-cli-adapter.sh" "$stub_dir/zgpt-cli-adapter.sh"
run_worker="$stub_dir/zgpt-run-worker.sh"

cat >"$stub_dir/zgpt-worker-pane.sh" <<'STUB'
#!/usr/bin/env bash
printf 'pane_id=fake:p1\n'
printf 'family=generic\n'
STUB
chmod +x "$stub_dir/zgpt-worker-pane.sh"

cat >"$tmp/bin/herdr" <<'STUB'
#!/usr/bin/env bash
set -euo pipefail
if [[ "${1:-}" == --session ]]; then shift 2; fi
cmd="${1:-} ${2:-}"
case "$cmd" in
  "pane read")
    source_name=""
    for ((i=3; i<=$#; i++)); do
      if [[ "${!i:-}" == "--source" ]]; then
        j=$((i + 1)); source_name="${!j:-}"; break
      fi
    done
    if [[ "$source_name" == "visible" ]]; then
      # Readiness glyph + absence of the not-logged-in phrase.
      printf '❯\n'
      exit 0
    fi
    # recent-unwrapped: the completion-loop transcript source.
    n="$(cat "${ZGPT_RECENT_COUNT:?}" 2>/dev/null)"; n=$((n + 1)); printf '%s\n' "$n" >"${ZGPT_RECENT_COUNT:?}"
    if [[ -n "${ZGPT_MARKER_AFTER:-}" && "$n" -ge "$ZGPT_MARKER_AFTER" ]]; then
      if [[ "${ZGPT_MARKER_STYLE:-canonical}" == "underscore" ]]; then
        printf 'WORKER_DONE_testtoken\n'
      else
        printf 'WORKER_DONE:testtoken\n'
      fi
    elif [[ "${ZGPT_ACTIVE_MODE:-false}" == true ]]; then
      printf 'tick %s: e2e progress ...\n' "$n"
    else
      printf 'static line\n'
    fi
    exit 0
    ;;
  "agent prompt")
    if [[ "${3:-}" != "--help" && -n "${ZGPT_CAPTURE_PROMPT:-}" ]]; then
      printf '%s' "${4:-}" >"$ZGPT_CAPTURE_PROMPT"
    fi
    exit 0
    ;;
  "pane get"|"pane send-text"|"pane send-keys"|"pane close"|"agent wait"|"agent get")
    exit 0
    ;;
  "pane wait-output")
    # Unsupported waits return immediately; the loop then falls back to reads.
    exit 1
    ;;
  *) exit 0 ;;
esac
STUB
chmod +x "$tmp/bin/herdr"

# Runs the real script against the stub harness in a background subshell so the
# test can bound a hang. Env-prefix vars (ZGPT_ACTIVE_MODE, ZGPT_MARKER_AFTER)
# set on the caller's run_case call are inherited by the worker. Returns the
# worker's exit code, or 124 if it had to be killed at the 15s guard.
run_case() {
    local out_file="$1"; shift
    printf '0\n' >"$tmp/recent.count"
    PATH="$tmp/bin:$PATH" HERDR_SESSION=test-session ZFLOW_LEDGER=off \
        ZGPT_RECENT_COUNT="$tmp/recent.count" \
        "$run_worker" --name t --command fakecli --token testtoken \
        --ready-timeout 5 --poll 1 --task 'benign' "$@" >"$out_file" 2>&1 &
    local pid=$! waited=0
    while kill -0 "$pid" 2>/dev/null && (( waited < 15 )); do
        sleep 1; waited=$((waited + 1))
    done
    if kill -0 "$pid" 2>/dev/null; then
        kill "$pid" 2>/dev/null || true
        wait "$pid" 2>/dev/null || true
        return 124
    fi
    wait "$pid"
    return $?
}

# ── 1. Active transcript slides the deadline: a tiny --timeout must NOT reap ──
# A healthy long task keeps producing output; with --timeout 1 but --max-timeout
# effectively unlimited the run must stay alive (no terminal status), not hit
# marker_timeout at the 1s inactivity mark.
printf '0\n' >"$tmp/recent.count"
out="$tmp/active.out"
PATH="$tmp/bin:$PATH" HERDR_SESSION=test-session ZFLOW_LEDGER=off \
    ZGPT_RECENT_COUNT="$tmp/recent.count" ZGPT_ACTIVE_MODE=true \
    "$run_worker" --name t --command fakecli --token testtoken \
    --ready-timeout 5 --poll 1 --timeout 1 --max-timeout 100000 --task 'benign' \
    >"$out" 2>&1 &
run_pid=$!
sleep 4
if kill -0 "$run_pid" 2>/dev/null; then
    pass 'active transcript: run still alive after --timeout elapsed'
else
    wait "$run_pid" 2>/dev/null || true
    fail 'active transcript: run died unexpectedly (output below)'
    sed 's/^/  /' "$out"
fi
kill "$run_pid" 2>/dev/null || true
wait "$run_pid" 2>/dev/null || true
if grep -q 'status=marker_timeout' "$out"; then
    fail 'active transcript: must not reach marker_timeout while producing output'
else
    pass 'active transcript: no marker_timeout emitted'
fi

# ── 2. Static transcript -> marker_timeout after the inactivity window ────────
out="$tmp/static.out"
set +e
run_case "$out" --timeout 2 --max-timeout 100000
rc=$?
set -e
if [[ "$rc" != 0 ]] && grep -q 'status=marker_timeout' "$out"; then
    pass 'static transcript: marker_timeout after the inactivity window'
else
    fail "static transcript: expected marker_timeout (rc=$rc, output below)"
    sed 's/^/  /' "$out"
fi

# ── 3. Active transcript but --max-timeout cap -> marker_timeout at ceiling ───
# Continued output cannot extend past the absolute ceiling from launch.
out="$tmp/cap.out"
set +e
ZGPT_ACTIVE_MODE=true run_case "$out" --timeout 30 --max-timeout 2
rc=$?
set -e
if [[ "$rc" != 0 ]] && grep -q 'status=marker_timeout' "$out"; then
    pass 'active transcript + --max-timeout 2: capped at the absolute ceiling'
else
    fail "active transcript + --max-timeout 2: expected marker_timeout at cap (rc=$rc, output below)"
    sed 's/^/  /' "$out"
fi

# ── 4. Marker appears -> status=ok ───────────────────────────────────────────
out="$tmp/marker.out"
set +e
ZGPT_MARKER_AFTER=2 run_case "$out" --timeout 30 --max-timeout 30
rc=$?
set -e
if [[ "$rc" == 0 ]] && grep -q '^status=ok$' "$out"; then
    pass 'marker after 2 reads: status=ok'
else
    fail "marker after 2 reads: expected status=ok (rc=$rc, output below)"
    sed 's/^/  /' "$out"
fi

# ── 5. Underscore separator typo -> accepted with warning ───────────────────
out="$tmp/underscore-marker.out"
set +e
ZGPT_MARKER_AFTER=2 ZGPT_MARKER_STYLE=underscore run_case "$out" --timeout 30 --max-timeout 30
rc=$?
set -e
if [[ "$rc" == 0 ]] && grep -q '^status=ok$' "$out" \
    && grep -q 'non-canonical completion marker' "$out"; then
    pass 'underscore marker separator: status=ok with warning'
else
    fail "underscore marker separator: expected status=ok with warning (rc=$rc, output below)"
    sed 's/^/  /' "$out"
fi

# ── 6. Injected prompt names the colon explicitly and stays split ───────────
out="$tmp/prompt.out"
prompt_file="$tmp/injected-prompt.txt"
set +e
ZGPT_MARKER_AFTER=2 ZGPT_CAPTURE_PROMPT="$prompt_file" run_case "$out" --timeout 30 --max-timeout 30
rc=$?
set -e
prompt_text="$(cat "$prompt_file" 2>/dev/null || true)"
if [[ "$rc" == 0 && "$prompt_text" == *"U+003A"* \
    && "$prompt_text" == *"never underscore"* \
    && "$prompt_text" != *"WORKER_DONE:testtoken"* ]]; then
    pass 'prompt specifies the ASCII colon without echoing the assembled marker'
else
    fail "prompt marker instruction: incomplete or echoed assembled marker (rc=$rc)"
    printf '%s\n' "$prompt_text" | sed 's/^/  prompt: /'
fi

# ── 7. Help + validation ─────────────────────────────────────────────────────
help_out="$(ZFLOW_LEDGER=off "$run_worker" --help 2>&1)"
assert_contains "$help_out" '--max-timeout' '--help documents --max-timeout'
if grep -qi 'inactivity' <<<"$help_out"; then
    pass '--help explains the inactivity semantics'
else
    fail '--help explains the inactivity semantics (output did not contain: inactivity)'
fi
assert_fail 'invalid --max-timeout is rejected' ZFLOW_LEDGER=off \
    "$run_worker" --name t --task x --max-timeout abc

printf '\n== Summary ==\n'
printf '%d passed, %d failed\n' "$passed" "$failed"
((failed == 0))
