#!/usr/bin/env bash
set -euo pipefail

# Offline suite for the manager-launch auto-register glue (P0/P1): artifact
# resolution precedence and the exact register + ensure-watch call sequence
# zgpt-run-worker.sh emits for a --role manager|supermanager launch, plus syntax
# and help checks. The heavy register/unregister/discover/ensure-watch logic
# itself is covered by zgpt-watch-managers-smoke.sh with the same herdr mock.

script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")/../scripts" && pwd)"
common="$script_dir/zgpt-common.sh"
run_worker="$script_dir/zgpt-run-worker.sh"
watch_script="$script_dir/zgpt-watch-managers.sh"
tmp="$(mktemp -d "${TMPDIR:-/tmp}/zgpt-auto-register.XXXXXX")"
trap 'rm -rf "$tmp"' EXIT

passed=0; failed=0
pass() { printf 'PASS: %s\n' "$1"; passed=$((passed + 1)); }
fail() { printf 'FAIL: %s\n' "$1" >&2; failed=$((failed + 1)); }

printf '\n== syntax ==\n'
for f in "$common" "$run_worker" "$watch_script"; do
  if bash -n "$f"; then pass "$(basename "$f") parses"; else fail "$(basename "$f") syntax"; fi
done

printf '\n== run-worker --help documents the auto-register flags ==\n'
help_out="$( "$run_worker" --help )"
for flag in --assignment-dir --no-auto-register 'registered=<pane_id>'; do
  grep -q -- "$flag" <<<"$help_out" && pass "help documents $flag" || fail "help missing $flag"
done
wm_help="$( "$watch_script" --help )"
grep -q -- 'ensure-watch' <<<"$wm_help" && pass "watch-managers help documents ensure-watch" || fail "watch-managers help missing ensure-watch"

printf '\n== artifact resolution precedence (--artifact > env > --assignment-dir/result.md) ==\n'
source "$common"
[ "$(zgpt_resolve_assignment_artifact /a/x.md /b)" = "/a/x.md" ] \
  && pass "--artifact wins" || fail "--artifact precedence"
[ "$(ZGPT_ASSIGNMENT_ARTIFACT=/env/y.md zgpt_resolve_assignment_artifact "" /b)" = "/env/y.md" ] \
  && pass "ZGPT_ASSIGNMENT_ARTIFACT wins over --assignment-dir" || fail "env precedence"
[ "$(ZGPT_ASSIGNMENT_ARTIFACT= zgpt_resolve_assignment_artifact "" /run/2026)" = "/run/2026/result.md" ] \
  && pass "--assignment-dir maps to <dir>/result.md" || fail "--assignment-dir mapping"
[ -z "$(ZGPT_ASSIGNMENT_ARTIFACT= zgpt_resolve_assignment_artifact "" "")" ] \
  && pass "no artifact configured => empty" || fail "empty case"

printf '\n== composition: the exact register + ensure-watch sequence run-worker emits ==\n'
bin="$tmp/bin"
status_dir="$tmp/status"
registry="$tmp/registry.tsv"
mkdir -p "$bin" "$status_dir"
cat >"$bin/herdr" <<'STUB'
#!/usr/bin/env bash
set -euo pipefail
if [[ "${1:-}" == --session ]]; then shift 2; fi
cmd="${1:-}"; shift || true
case "$cmd" in
  agent)
    sub="${1:-}"; shift || true
    case "$sub" in
      get)
        pane="${1:-}"
        st="unknown"
        if [[ -f "$ZGPT_FAKE_STATUS_DIR/$pane.status" ]]; then
          st="$(cat "$ZGPT_FAKE_STATUS_DIR/$pane.status")"
        fi
        printf '{"result":{"agent":{"agent_status":"%s"}}}\n' "$st"
        ;;
    esac
    ;;
  pane)
    sub="${1:-}"; shift || true
    case "$sub" in
      get)
        pane="${1:-}"
        if [[ -f "$ZGPT_FAKE_STATUS_DIR/$pane.missing" ]]; then
          printf 'error: no such pane\n' >&2
          exit 1
        fi
        printf '{"result":{"pane":{"pane_id":"%s"}}}\n' "$pane"
        ;;
    esac
    ;;
esac
STUB
chmod +x "$bin/herdr"
export PATH="$bin:$PATH"
export ZGPT_FAKE_STATUS_DIR="$status_dir"
export ZGPT_MANAGER_REGISTRY="$registry"
export ZGPT_SUPER_PANE_ID="w9:super"

# Mirror zgpt-run-worker.sh's auto_register_manager calls verbatim:
#   register <pane> --registry <reg> --workstream <repo> --artifact <path>
#   ensure-watch --registry <reg>
reg_out="$( "$watch_script" register w4N:p2 --registry "$registry" --workstream zflow --artifact "$tmp/result.md" )"
grep -q 'registered=w4N:p2' <<<"$reg_out" && pass "register (run-worker call shape) registers the manager pane" || fail "register shape: $reg_out"
grep -qP 'w4N:p2\tzflow\t' "$registry" && pass "registry row carries workstream + artifact" || fail "registry row: $(cat "$registry" 2>/dev/null)"
watch_out="$( "$watch_script" ensure-watch --registry "$registry" )"
grep -q 'watch=started deliver_to=w9:super' <<<"$watch_out" && pass "ensure-watch (run-worker call shape) starts and targets the super" || fail "ensure-watch shape: $watch_out"
pidfile="$tmp/manager-watch.pid"
live_pid="$(head -n1 "$pidfile" 2>/dev/null | tr -d '[:space:]')"
[[ -n "$live_pid" ]] && kill -0 "$live_pid" 2>/dev/null && pass "durable watcher is alive" || fail "durable watcher dead: $live_pid"
[[ -n "$live_pid" ]] && kill "$live_pid" 2>/dev/null || true
unset ZGPT_SUPER_PANE_ID ZGPT_MANAGER_REGISTRY ZGPT_FAKE_STATUS_DIR

printf '\nSummary: %d/%d passed\n' "$passed" "$((passed + failed))"
((failed == 0))
