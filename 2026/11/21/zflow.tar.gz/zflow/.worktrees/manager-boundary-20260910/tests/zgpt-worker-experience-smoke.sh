#!/usr/bin/env bash
set -euo pipefail

script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")/../scripts" && pwd)"
tmp="$(mktemp -d "${TMPDIR:-/tmp}/zgpt-worker-experience.XXXXXX")"
trap 'rm -rf "$tmp"' EXIT

ledger_out="$($script_dir/zgpt-worker-ledger.sh \
    --run-dir "$tmp/run" \
    --time 2026-07-04T00:00:00Z \
    --worker worker-a \
    --command startcccodex \
    --pane-id terminal_7 \
    --artifact "$tmp/run/review.md" \
    --outcome context_overflow \
    --reason $'resume was too large\tfor context' \
    --next 'restart fresh from worktree')"
printf '%s\n' "$ledger_out" | grep -q '^status=recorded$'
ledger="$tmp/run/worker-ledger.tsv"
[[ -s "$ledger" ]]
[[ "$(wc -l <"$ledger" | tr -d ' ')" == 2 ]]
grep -q $'time\tworker\tcommand\tpane_id\tartifact\toutcome\treason\tnext_action' "$ledger"
grep -q $'2026-07-04T00:00:00Z\tworker-a\tstartcccodex\tterminal_7\t' "$ledger"
grep -q $'\tcontext_overflow\tresume was too large for context\trestart fresh from worktree$' "$ledger"

prompt="$($script_dir/zgpt-review-prompt.sh \
    --artifact "$tmp/review.md" \
    --subject 'Review worker patch' \
    --target 'git diff main...HEAD' \
    --max-commands 5 \
    --minutes 10 \
    --worker worker-review-smoke)"
printf '%s\n' "$prompt" | grep -q 'Correctness only'
printf '%s\n' "$prompt" | grep -q 'Run at most 5 shell commands total'
printf '%s\n' "$prompt" | grep -q 'If the initial sweep reveals no high-confidence correctness issue, approve and stop'
printf '%s\n' "$prompt" | grep -q "Write $tmp/review.md with exactly"

printf 'worker experience smoke ok\n'
