#!/usr/bin/env bash
set -euo pipefail

scripts="$(cd "$(dirname "${BASH_SOURCE[0]}")/../scripts" && pwd)"
gh_pr="$scripts/zgpt-gh-pr.sh"
tmp="$(mktemp -d "${TMPDIR:-/tmp}/zgpt-gh-pr-smoke.XXXXXX")"
trap '[[ -n "${KEEP_ZGPT_SMOKE_TMP:-}" ]] || rm -rf "$tmp"' EXIT

passed=0
failed=0
pass() { printf 'PASS: %s\n' "$1"; passed=$((passed + 1)); }
fail() { printf 'FAIL: %s\n' "$1" >&2; failed=$((failed + 1)); }
assert_contains() { if grep -q -- "$2" <<< "$1"; then pass "$3"; else fail "$3"; fi; }
assert_eq() { if [[ "$1" == "$2" ]]; then pass "$3"; else fail "$3 (got=$1 expected=$2)"; fi; }

bin="$tmp/bin"
mkdir -p "$bin"
worker_log="$tmp/worker.log"
prompt_log="$tmp/prompts.log"

fake_worker="$bin/fake-run-worker"
cat > "$fake_worker" <<'WORKER'
#!/usr/bin/env bash
set -euo pipefail
artifact=''
task=''
cwd=''
printf '%q ' "$@" >> "${FAKE_WORKER_LOG:?}"
printf '\n' >> "${FAKE_WORKER_LOG:?}"
while (($#)); do
    case "$1" in
        --artifact) artifact="${2:?}"; shift 2 ;;
        --task) task="${2:?}"; shift 2 ;;
        --cwd) cwd="${2:?}"; shift 2 ;;
        *) shift ;;
    esac
done
[[ -n "$artifact" ]] || { printf 'missing --artifact\n' >&2; exit 2; }
printf '%s\n---TASK---\n%s\n' "$artifact" "$task" >> "${FAKE_PROMPT_LOG:?}"
case "${FAKE_WORKER_ACTION:-none}" in
    none) ;;
    single-commit|single-commit-pushed)
        [[ -n "$cwd" ]] || exit 2
        printf 'change %s\n' "$(date +%s%N)" >> "$cwd/file.txt"
        git -C "$cwd" add file.txt
        git -C "$cwd" commit -qm 'worker fix'
        if [[ "${FAKE_WORKER_ACTION:-}" == single-commit-pushed ]]; then
            git -C "$cwd" update-ref refs/remotes/origin/feature-x HEAD
            git -C "$cwd" branch --set-upstream-to=origin/feature-x feature-x >/dev/null
        fi
        ;;
    multi-commit)
        [[ -n "$cwd" ]] || exit 2
        printf 'change one\n' >> "$cwd/file.txt"
        git -C "$cwd" add file.txt
        git -C "$cwd" commit -qm 'worker fix one'
        printf 'change two\n' >> "$cwd/file.txt"
        git -C "$cwd" add file.txt
        git -C "$cwd" commit -qm 'worker fix two'
        ;;
    dirty)
        [[ -n "$cwd" ]] || exit 2
        printf 'dirty\n' >> "$cwd/file.txt"
        ;;
    *) printf 'unknown FAKE_WORKER_ACTION=%s\n' "${FAKE_WORKER_ACTION:-}" >&2; exit 2 ;;
esac
body="${FAKE_WORKER_ARTIFACT_BODY:?}"
if [[ "$body" == *__HEAD__* ]]; then
    head="$(git -C "$cwd" rev-parse HEAD)"
    body="${body//__HEAD__/$head}"
fi
printf '%b' "$body" > "$artifact"
printf 'status=ok\nartifact=%s\n' "$artifact"
WORKER
chmod +x "$fake_worker"

fake_gh="$bin/gh"
cat > "$fake_gh" <<'GH'
#!/usr/bin/env bash
set -euo pipefail
printf '%q ' "$@" >> "${FAKE_GH_LOG:?}"
printf '\n' >> "${FAKE_GH_LOG:?}"
if [[ "${1:-}" == pr && "${2:-}" == create ]]; then
    printf 'created %s\n' "${FAKE_GH_CREATE_URL:-https://github.com/owner/repo/pull/7}"
    exit 0
fi
if [[ "${1:-}" == pr && "${2:-}" == view ]]; then
    printf '%s\n' "${FAKE_GH_VIEW_JSON:?}"
    exit 0
fi
printf 'unexpected gh call: %s\n' "$*" >&2
exit 64
GH
chmod +x "$fake_gh"

export ZGPT_RUN_WORKER_CMD="$fake_worker"
export FAKE_WORKER_LOG="$worker_log"
export FAKE_PROMPT_LOG="$prompt_log"
export ZGPT_GH_CMD="$fake_gh"
export FAKE_GH_LOG="$tmp/gh.log"
export ZGPT_STATE_DIR_OVERRIDE="$tmp/state"

pr_url='https://github.com/owner/repo/pull/7'
view_json='{"url":"https://github.com/owner/repo/pull/7","number":7,"state":"OPEN","headRefName":"feature-x","baseRefName":"main","headRepositoryOwner":{"login":"owner"},"headRepository":{"name":"repo"}}'
export ZGPT_GH_PR_FAKE_VIEW_JSON="$view_json"
export FAKE_GH_VIEW_JSON="$view_json"

printf '\n== URL parsing ==\n'
parsed="$($gh_pr parse-url 'https://github.com/owner/repo/pull/7?tab=files#discussion')"
assert_contains "$parsed" '^owner=owner$' 'parses GitHub owner'
assert_contains "$parsed" '^repo=repo$' 'parses GitHub repo'
assert_contains "$parsed" '^pr_number=7$' 'parses GitHub PR number before query/fragment'
if ! "$gh_pr" parse-url 'https://gitlab.com/owner/repo/-/merge_requests/7' >/dev/null 2>&1; then pass 'rejects GitLab MR URL'; else fail 'rejects GitLab MR URL'; fi
if ! "$gh_pr" parse-url 'https://github.com/owner/repo/issues/7' >/dev/null 2>&1; then pass 'rejects non-PR GitHub URL'; else fail 'rejects non-PR GitHub URL'; fi
if ! "$gh_pr" parse-url 'https://user@github.com/owner/repo/pull/7' >/dev/null 2>&1; then pass 'rejects URL userinfo'; else fail 'rejects URL userinfo'; fi

printf '\n== Create is manager-reviewed by default ==\n'
: > "$worker_log"
create_out="$(ZGPT_GH_PR_FAKE_URL="$pr_url" "$gh_pr" create --title hello --body world --cwd "$tmp")"
assert_contains "$create_out" '^pr_url=https://github.com/owner/repo/pull/7$' 'create prints PR URL'
assert_contains "$create_out" '^review_worker_started=false$' 'normal create reports no review worker'
assert_eq "$(wc -l < "$worker_log" | tr -d ' ')" 0 'normal create launches no worker'

printf '\n== Fix target setup ==\n'
repo="$tmp/repo"
git init -q -b feature-x "$repo"
git -C "$repo" config user.name smoke
git -C "$repo" config user.email smoke@example.invalid
git -C "$repo" remote add origin 'git@github.com:owner/repo.git'
printf 'base\n' > "$repo/file.txt"
git -C "$repo" add file.txt
git -C "$repo" commit -qm init
base_head="$(git -C "$repo" rev-parse HEAD)"
git -C "$repo" update-ref refs/remotes/origin/feature-x HEAD
git -C "$repo" branch --set-upstream-to=origin/feature-x feature-x >/dev/null
pass 'created feature worktree fixture'

printf '\n== One-shot correction and feedback ==\n'
: > "$worker_log"; : > "$prompt_log"
export FAKE_WORKER_ARTIFACT_BODY='schema=zflow.github_pr.fix_result.v1\nstatus=not_actionable\npushed=false\n'
fix_out="$($gh_pr fix "$pr_url" --cwd "$repo" --feedback 'please fix the edge case')"
assert_contains "$fix_out" '^worker_launches=1$' 'fix reports one worker launch'
assert_eq "$(wc -l < "$worker_log" | tr -d ' ')" 1 'fix calls zgpt-run-worker exactly once'
assert_contains "$(cat "$prompt_log")" 'please fix the edge case' 'inline feedback reaches worker prompt'
assert_contains "$(cat "$prompt_log")" 'Do not push' 'default correction prompt forbids push'
assert_contains "$fix_out" '^allow_push=false$' 'push gate defaults to false'

feedback_file="$tmp/feedback.md"
printf 'file feedback line\nsecond line\n' > "$feedback_file"
$gh_pr fix "$pr_url" --cwd "$repo" --feedback-file "$feedback_file" >/dev/null
assert_eq "$(wc -l < "$worker_log" | tr -d ' ')" 2 'feedback-file fix is another single worker launch'
assert_contains "$(cat "$prompt_log")" 'file feedback line' 'feedback file content reaches prompt'

printf '
== Push authorization gate ==
'
export FAKE_WORKER_ACTION=single-commit-pushed
export FAKE_WORKER_ARTIFACT_BODY='schema=zflow.github_pr.fix_result.v1
status=fixed
pushed=true
commit_sha=__HEAD__
'
push_out="$($gh_pr fix "$pr_url" --cwd "$repo" --feedback 'push this fix' --allow-push)"
assert_contains "$push_out" '^allow_push=true$' 'explicit allow-push is surfaced'
assert_contains "$push_out" '^pushed=true$' 'authorized normal push artifact is accepted'
assert_contains "$(cat "$prompt_log")" 'authorized one normal push' 'allow-push prompt grants only normal branch push'
git -C "$repo" reset --hard -q "$base_head"
git -C "$repo" update-ref refs/remotes/origin/feature-x "$base_head"
git -C "$repo" checkout -q feature-x
export FAKE_WORKER_ACTION=none

printf '
== Branch/state safety ==
'
export FAKE_WORKER_ARTIFACT_BODY='schema=zflow.github_pr.fix_result.v1
status=not_actionable
pushed=false
'
before_count="$(wc -l < "$worker_log" | tr -d ' ')"
closed_view='{"url":"https://github.com/owner/repo/pull/7","number":7,"state":"CLOSED","headRefName":"feature-x","baseRefName":"main","headRepositoryOwner":{"login":"owner"},"headRepository":{"name":"repo"}}'
if ! ZGPT_GH_PR_FAKE_VIEW_JSON="$closed_view" "$gh_pr" fix "$pr_url" --cwd "$repo" --feedback 'closed' >/dev/null 2>&1; then pass 'rejects closed PR before worker'; else fail 'rejects closed PR before worker'; fi
merged_view='{"url":"https://github.com/owner/repo/pull/7","number":7,"state":"MERGED","headRefName":"feature-x","baseRefName":"main","headRepositoryOwner":{"login":"owner"},"headRepository":{"name":"repo"}}'
if ! ZGPT_GH_PR_FAKE_VIEW_JSON="$merged_view" "$gh_pr" fix "$pr_url" --cwd "$repo" --feedback 'merged' >/dev/null 2>&1; then pass 'rejects merged PR before worker'; else fail 'rejects merged PR before worker'; fi
assert_eq "$(wc -l < "$worker_log" | tr -d ' ')" "$before_count" 'closed/merged PR launches no worker'

bad_view='{"url":"https://github.com/owner/repo/pull/7","number":7,"state":"OPEN","headRefName":"other-branch","baseRefName":"main","headRepositoryOwner":{"login":"owner"},"headRepository":{"name":"repo"}}'
if ! ZGPT_GH_PR_FAKE_VIEW_JSON="$bad_view" "$gh_pr" fix "$pr_url" --cwd "$repo" --feedback 'mismatch' >/dev/null 2>&1; then pass 'rejects branch mismatch before worker'; else fail 'rejects branch mismatch before worker'; fi
after_count="$(wc -l < "$worker_log" | tr -d ' ')"
assert_eq "$after_count" "$before_count" 'branch mismatch launches no worker'

git -C "$repo" checkout -qb main
protected_view='{"url":"https://github.com/owner/repo/pull/7","number":7,"state":"OPEN","headRefName":"main","baseRefName":"develop","headRepositoryOwner":{"login":"owner"},"headRepository":{"name":"repo"}}'
if ! ZGPT_GH_PR_FAKE_VIEW_JSON="$protected_view" "$gh_pr" fix "$pr_url" --cwd "$repo" --feedback 'protected' >/dev/null 2>&1; then pass 'rejects protected PR branch before worker'; else fail 'rejects protected PR branch before worker'; fi
after_protected="$(wc -l < "$worker_log" | tr -d ' ')"
assert_eq "$after_protected" "$before_count" 'protected branch launches no worker'
git -C "$repo" checkout -q feature-x
export ZGPT_GH_PR_FAKE_VIEW_JSON="$view_json"

printf '\n== Worktree and commit audit ==\n'
printf 'dirty start\n' > "$repo/dirty.txt"
before_audit="$(wc -l < "$worker_log" | tr -d ' ')"
if ! "$gh_pr" fix "$pr_url" --cwd "$repo" --feedback 'dirty start' >/dev/null 2>&1; then pass 'rejects dirty worktree before worker'; else fail 'rejects dirty worktree before worker'; fi
rm -f "$repo/dirty.txt"
assert_eq "$(wc -l < "$worker_log" | tr -d ' ')" "$before_audit" 'dirty start launches no worker'

export FAKE_WORKER_ACTION=none
export FAKE_WORKER_ARTIFACT_BODY='schema=zflow.github_pr.fix_result.v1
status=fixed
pushed=false
commit_sha=__HEAD__
'
if ! "$gh_pr" fix "$pr_url" --cwd "$repo" --feedback 'unchanged fixed' >/dev/null 2>&1; then pass 'rejects unchanged fixed artifact'; else fail 'rejects unchanged fixed artifact'; fi
export FAKE_WORKER_ACTION=multi-commit
export FAKE_WORKER_ARTIFACT_BODY='schema=zflow.github_pr.fix_result.v1
status=fixed
pushed=false
commit_sha=__HEAD__
'
if ! "$gh_pr" fix "$pr_url" --cwd "$repo" --feedback 'multi commit' >/dev/null 2>&1; then pass 'rejects multi-commit fixed artifact'; else fail 'rejects multi-commit fixed artifact'; fi
git -C "$repo" reset --hard -q "$base_head"
export FAKE_WORKER_ACTION=none
export FAKE_WORKER_ARTIFACT_BODY='schema=zflow.github_pr.fix_result.v1
status=failed
pushed=false
'
if ! "$gh_pr" fix "$pr_url" --cwd "$repo" --feedback 'valid failed' >/dev/null 2>&1; then pass 'valid failed fix artifact returns nonzero'; else fail 'valid failed fix artifact returns nonzero'; fi

printf '\n== Artifact validation ==\n'
before_artifact="$(wc -l < "$worker_log" | tr -d ' ')"
export FAKE_WORKER_ARTIFACT_BODY='status=fixed\npushed=false\ncommit_sha=000000000000000000000000000000000000000a\n'
if ! "$gh_pr" fix "$pr_url" --cwd "$repo" --feedback 'bad artifact' >/dev/null 2>&1; then pass 'rejects missing schema artifact'; else fail 'rejects missing schema artifact'; fi
assert_eq "$(wc -l < "$worker_log" | tr -d ' ')" $((before_artifact + 1)) 'artifact failure still used one bounded worker launch'

printf '\n== Explicit review opt-in ==\n'
before_review="$(wc -l < "$worker_log" | tr -d ' ')"
if ! "$gh_pr" review "$pr_url" --cwd "$repo" >/dev/null 2>&1; then pass 'review command requires large/high-risk opt-in'; else fail 'review command requires large/high-risk opt-in'; fi
assert_eq "$(wc -l < "$worker_log" | tr -d ' ')" "$before_review" 'review without opt-in launches no worker'
export FAKE_WORKER_ARTIFACT_BODY='schema=zflow.github_pr.review_result.v1\nstatus=reviewed\nfindings=None\n'
review_out="$($gh_pr review "$pr_url" --cwd "$repo" --large-change)"
assert_contains "$review_out" '^review_opt_in=large-change$' 'review surfaces explicit opt-in reason'
assert_contains "$review_out" '^worker_launches=1$' 'review opt-in launches one worker'
assert_eq "$(wc -l < "$worker_log" | tr -d ' ')" $((before_review + 1)) 'review opt-in calls worker exactly once'
assert_contains "$(tail -n 1 "$worker_log")" '--difficulty hard' 'review opt-in uses advisor difficulty by default'
assert_contains "$(cat "$prompt_log")" 'Read-only review only' 'review worker prompt is read-only'
export FAKE_WORKER_ARTIFACT_BODY='schema=zflow.github_pr.review_result.v1
status=failed
findings=blocked
'
if ! "$gh_pr" review "$pr_url" --cwd "$repo" --high-risk >/dev/null 2>&1; then pass 'valid failed review artifact returns nonzero'; else fail 'valid failed review artifact returns nonzero'; fi

printf '\n== Summary ==\n'
printf '%d passed, %d failed\n' "$passed" "$failed"
((failed == 0))
