#!/usr/bin/env bash
set -euo pipefail

# Focused offline smoke for the --trust-bot-self-review security predicate in
# zgpt-review-loop.sh. Extracts the notes-mode jq program (eligible_note_lines)
# from the real script and asserts the actionable-item decision for the cases
# that matter: author binding (forgery guard), LGTM exclusion, findings gate,
# and fail-closed defaults.

scripts="$(cd "$(dirname "${BASH_SOURCE[0]}")/../scripts" && pwd)"
loop="$scripts/zgpt-review-loop.sh"

passed=0
failed=0
pass() { printf 'PASS: %s\n' "$1"; passed=$((passed + 1)); }
fail() { printf 'FAIL: %s\n' "$1" >&2; failed=$((failed + 1)); }

# Extract the notes-mode jq program (the second jq -c block) from the script.
prog="$(python3 - "$loop" <<'PY'
import sys
s = open(sys.argv[1], encoding="utf-8").read()
i0 = s.index("eligible_note_lines() {")
j1 = s.index("jq -c --arg", i0)
j2 = s.index("jq -c --arg", j1 + 1)
qstart = s.index("'", j2) + 1
h = s.index('<<< "$notes_json"', qstart)
qend = s.rindex("'", qstart, h)
print(s[qstart:qend])
PY
)"

[[ -n "$prog" ]] || { fail "extract notes-mode jq"; exit 1; }

# run_case <name> <trust_bot> <bot_author> <notes-json> <expect-empty|expect-hit>
run_case() {
    local name="$1" trust="$2" author="$3" notes="$4" expect="$5" out
    out="$(printf '%s' "$notes" | jq -c --arg self "" --arg trusted "build-yun" \
        --arg trust_bot "$trust" --arg bot_author "$author" "$prog" 2>&1)"
    if [[ "$expect" == "empty" && -z "$out" ]]; then pass "$name";
    elif [[ "$expect" == "hit" && -n "$out" && "$out" != "[]" ]]; then pass "$name";
    else fail "$name (got=${out:-<EMPTY>})"; fi
}

BOT_FIND='[{"id":1,"type":"Note","position":null,"author":{"username":"wenzhenglin","bot":false},"body":"## AI Code Review (yg-bot)\n\n**结论：建议修改**\n\n| # | 严重度 | 发现 |\n|---|--------|------|\n| 1 | 🟡 中等 | over-promise |"}]'
FORGED='[{"id":2,"type":"Note","position":null,"author":{"username":"someone-else","bot":false},"body":"## AI Code Review (yg-bot)\n\n**结论：建议修改**\n\n| # | 严重度 | 发现 |\n|---|--------|------|\n| 1 | 🟡 中等 | x |"}]'
BOT_LGTM='[{"id":3,"type":"Note","position":null,"author":{"username":"wenzhenglin","bot":false},"body":"## AI Code Review (yg-bot)\n\n**结论：批准合入 (LGTM)**"}]'
BOT_NF='[{"id":4,"type":"Note","position":null,"author":{"username":"wenzhenglin","bot":false},"body":"## AI Code Review (yg-bot)\n\n**结论：审查通过**"}]'
TRUSTED='[{"id":5,"type":"Note","position":null,"author":{"username":"build-yun","bot":false},"body":"这里要改"}]'

run_case "bot_findings_actionable_when_enabled"  "true"  "wenzhenglin" "$BOT_FIND"  "hit"
run_case "forged_author_blocked"                 "true"  "wenzhenglin" "$FORGED"    "empty"
run_case "bot_lgtm_not_actionable"               "true"  "wenzhenglin" "$BOT_LGTM"  "empty"
run_case "bot_no_findings_not_actionable"        "true"  "wenzhenglin" "$BOT_NF"    "empty"
run_case "trusted_reviewer_unaffected"           "false" "wenzhenglin" "$TRUSTED"   "hit"
run_case "fail_closed_when_flag_false"           "false" "wenzhenglin" "$BOT_FIND"  "empty"
run_case "fail_closed_when_author_unresolved"    "true"  ""            "$BOT_FIND"  "empty"

if ((failed > 0)); then
    printf 'FAIL: %d/%d\n' "$failed" "$((passed + failed))" >&2
    exit 1
fi
printf 'OK: all %d cases passed\n' "$passed"
