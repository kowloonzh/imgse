#!/usr/bin/env bash
set -euo pipefail

# Offline smoke suite for zgpt-manager-notify.sh. Uses --dry-run for most cases;
# the real `herdr notification show` path is exercised with a herdr stub on PATH.
# Exits non-zero on any failure.

script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")/../scripts" && pwd)"
notify_script="$script_dir/zgpt-manager-notify.sh"
tmp="$(mktemp -d "${TMPDIR:-/tmp}/zgpt-manager-notify.XXXXXX")"
trap 'rm -rf "$tmp"' EXIT

passed=0; failed=0
pass() { printf 'PASS: %s\n' "$1"; passed=$((passed + 1)); }
fail() { printf 'FAIL: %s\n' "$1" >&2; failed=$((failed + 1)); }

st="$tmp/notify.tsv"

printf '\n== --dry-run: first call fires, same pair is a quiet no-op ==\n'
out="$( "$notify_script" --status blocked --workstream zflow --state-file "$st" --dry-run )"
grep -q 'notify: MANAGER_STATUS: blocked (zflow)' <<<"$out" && pass "first notify fires with MANAGER_STATUS title" || fail "first: $out"
out="$( "$notify_script" --status blocked --workstream zflow --state-file "$st" --dry-run )"
[[ -z "$out" ]] && pass "same (workstream,status) is a quiet no-op" || fail "expected silence, got: $out"
out="$( "$notify_script" --status idle_for_steer --workstream zflow --state-file "$st" --dry-run )"
grep -q 'idle_for_steer' <<<"$out" && pass "new status fires again" || fail "new status: $out"

printf '\n== --body is carried ==\n'
out="$( "$notify_script" --status blocked --workstream gamma --state-file "$st" --body 'needs a decision' --dry-run )"
grep -q 'needs a decision' <<<"$out" && pass "--body carried into the notification" || fail "--body: $out"

printf '\n== --state-file /dev/null disables dedup (always fires) ==\n'
out1="$( "$notify_script" --status blocked --workstream beta --state-file /dev/null --dry-run )"
out2="$( "$notify_script" --status blocked --workstream beta --state-file /dev/null --dry-run )"
grep -q 'notify:' <<<"$out1" && grep -q 'notify:' <<<"$out2" && pass "both calls fired with dedup disabled" || fail "dedup disabled: [$out1]/[$out2]"

printf '\n== invalid invocations rejected ==\n'
if "$notify_script" --status working --workstream zflow --state-file "$st" --dry-run >/dev/null 2>&1; then
    fail "unsupported --status accepted"
else
    pass "unsupported --status rejected (rc=$?)"
fi
if "$notify_script" --workstream zflow --state-file "$st" --dry-run >/dev/null 2>&1; then
    fail "missing --status accepted"
else
    pass "missing --status rejected"
fi

printf '\n== real path: herdr notification show invoked with title/body ==\n'
bin="$tmp/bin"
mkdir -p "$bin"
cat >"$bin/herdr" <<'STUB'
#!/usr/bin/env bash
set -euo pipefail
cmd="${1:-}"; shift || true
case "$cmd" in
  notification)
    sub="${1:-}"; shift || true
    case "$sub" in
      show)
        printf 'HERDR_NOTIFY: %s\n' "$*" >>"${ZGPT_FAKE_NOTIFY_LOG:?}"
        printf '{"result":{"ok":true}}\n'
        ;;
      *) ;;
    esac
    ;;
  session)
    printf '{"sessions":[]}\n'
    ;;
esac
STUB
chmod +x "$bin/herdr"
export PATH="$bin:$PATH"
export ZGPT_FAKE_NOTIFY_LOG="$tmp/notify.log"
out="$( "$notify_script" --status blocked --workstream alpha --state-file "$tmp/real.tsv" )"
grep -q 'notified=MANAGER_STATUS: blocked (alpha)' <<<"$out" && pass "real path prints notified=" || fail "real notify: $out"
grep -q 'HERDR_NOTIFY: MANAGER_STATUS: blocked (alpha)' "$ZGPT_FAKE_NOTIFY_LOG" && pass "herdr notification show called with title" || fail "herdr args: $(cat "$ZGPT_FAKE_NOTIFY_LOG" 2>/dev/null || true)"

printf '\n== --help documents the interface ==\n'
out="$( "$notify_script" --help )"
grep -q -- '--status' <<<"$out" && grep -q -- '--dry-run' <<<"$out" && pass "--help documents --status and --dry-run" || fail "--help: $out"

printf '\nSummary: %d/%d passed\n' "$passed" "$((passed + failed))"
((failed == 0))
