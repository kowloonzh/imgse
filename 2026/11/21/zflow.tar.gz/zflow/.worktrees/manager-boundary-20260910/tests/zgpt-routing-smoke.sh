#!/usr/bin/env bash
set -euo pipefail

# Offline smoke suite for zgpt-run-worker.sh's difficulty/command routing.
# Never launches a real pane and never requires a live herdr session:
#   - Pure tier-mapping (which difficulty synonym selects which command tier)
#     is exercised by calling zgpt-cli-adapter.sh's routing predicates directly.
#   - --route manager is exercised end to end with herdr removed from PATH
#     entirely, proving it exits before any herdr call.
#   - Everything else that only exists as zgpt-run-worker.sh's own inline
#     logic (command_source naming, advisor effort defaulting, --command
#     precedence) is exercised by running the real script against a stubbed
#     zgpt-worker-pane.sh launcher and a herdr stub that fails instantly, with
#     --ready-timeout 1 --poll 1 so the run reaches ready_timeout in about a
#     second instead of hanging.

scripts="$(cd "$(dirname "${BASH_SOURCE[0]}")/../scripts" && pwd)"
# shellcheck source=/dev/null
source "$scripts/zgpt-cli-adapter.sh"

passed=0
failed=0
pass() { printf 'PASS: %s\n' "$1"; passed=$((passed + 1)); }
fail() { printf 'FAIL: %s\n' "$1" >&2; failed=$((failed + 1)); }
assert_eq() { if [[ "$1" == "$2" ]]; then pass "$3"; else fail "$3 (got=$1 expected=$2)"; fi; }
assert_neq() { if [[ "$1" != "$2" ]]; then pass "$3"; else fail "$3 (got=$1 expected != $2)"; fi; }
assert_contains() { if grep -q -- "$2" <<<"$1"; then pass "$3"; else fail "$3 (output did not contain: $2)"; fi; }
assert_not_contains() { if grep -q -- "$2" <<<"$1"; then fail "$3 (output unexpectedly contained: $2)"; else pass "$3"; fi; }
assert_ok() { local label="$1"; shift; if "$@" >/dev/null 2>&1; then pass "$label"; else fail "$label (expected success)"; fi; }
assert_fail() { local label="$1"; shift; if ! "$@" >/dev/null 2>&1; then pass "$label"; else fail "$label (expected failure)"; fi; }
# The stub launcher writes each launch arg on its own line, so a value that
# follows a flag token must be read from the next line, not matched inline.
arg_after() { awk -v tok="$1" '$0==tok{getline; print; exit}' "$2"; }

tmp="$(mktemp -d "${TMPDIR:-/tmp}/zgpt-routing-smoke.XXXXXX")"
trap 'rm -rf "$tmp"' EXIT

# ── Stub harness: real run-worker.sh + common.sh + cli-adapter.sh (symlinked
# so `source "$script_dir/..."` resolves), a fake zgpt-worker-pane.sh launcher
# that just captures its argv and reports a fake pane_id, and a herdr stub
# that always fails fast so the readiness wait bottoms out immediately. ──────
stub_dir="$tmp/scripts"
mkdir -p "$stub_dir" "$tmp/bin"
ln -s "$scripts/zgpt-run-worker.sh" "$stub_dir/zgpt-run-worker.sh"
ln -s "$scripts/zgpt-common.sh" "$stub_dir/zgpt-common.sh"
ln -s "$scripts/zgpt-cli-adapter.sh" "$stub_dir/zgpt-cli-adapter.sh"
run_worker="$stub_dir/zgpt-run-worker.sh"

cat >"$stub_dir/zgpt-worker-pane.sh" <<'STUB'
#!/usr/bin/env bash
set -euo pipefail
printf '%s\n' "$@" >>"${ZGPT_TEST_CAPTURE:?}"
printf 'pane_id=fake:p1\n'
STUB
chmod +x "$stub_dir/zgpt-worker-pane.sh"

cat >"$tmp/bin/herdr" <<'STUB'
#!/usr/bin/env bash
exit 1
STUB
chmod +x "$tmp/bin/herdr"

capture="$tmp/launch-args.log"

# Runs the real script far enough to print its routing decision (command_source,
# route, difficulty, advisor_effort*), then lets it hit ready_timeout quickly
# and exit non-zero. That non-zero exit is expected -- callers only inspect
# stdout, not $?.
run_routed() {
    : >"$capture"
    PATH="$tmp/bin:$PATH" HERDR_SESSION=test-session ZFLOW_LEDGER=off \
        ZGPT_TEST_CAPTURE="$capture" \
        "$run_worker" --name t --route implement --ready-timeout 1 --poll 1 "$@" 2>&1 || true
}

printf '\n== --command always wins -> command_source=explicit ==\n'
out="$(run_routed --task 'benign task' --command mycmd --difficulty hard)"
assert_contains "$out" '^command_source=explicit$' '--command wins over --difficulty hard'

printf '\n== --difficulty synonyms map to the right tier (pure predicates) ==\n'
for d in worker normal standard; do
    assert_fail "difficulty=$d is not the fast tier" zgpt_difficulty_uses_fast "$d"
    assert_fail "difficulty=$d is not the advisor tier" zgpt_advisor_difficulty_uses_advisor "$d" 'benign task' implement
done
for d in fast simple routine; do
    assert_ok "difficulty=$d is the fast tier" zgpt_difficulty_uses_fast "$d"
    assert_fail "difficulty=$d is not the advisor tier" zgpt_advisor_difficulty_uses_advisor "$d" 'benign task' implement
done
for d in hard complex risky advisor strong escalate; do
    assert_ok "difficulty=$d is the advisor tier regardless of task text" zgpt_advisor_difficulty_uses_advisor "$d" 'benign task' implement
    assert_fail "difficulty=$d is not the fast tier" zgpt_difficulty_uses_fast "$d"
done
assert_fail 'difficulty=auto is never the fast tier' zgpt_difficulty_uses_fast auto
assert_fail 'difficulty=auto with benign task stays on the worker tier' zgpt_advisor_difficulty_uses_advisor auto 'benign task' implement
assert_ok 'difficulty=auto with a risk keyword escalates to advisor' zgpt_advisor_difficulty_uses_advisor auto 'fix the security issue' implement

for d in worker fast hard auto; do
    assert_ok "--difficulty $d is accepted" zgpt_advisor_difficulty_valid "$d"
done
assert_fail '--difficulty rejects an unknown value' zgpt_advisor_difficulty_valid bogus-difficulty

printf '\n== ZFLOW_FAST_CMD unset falls back to the worker command, keeping a worker_* source ==\n'
# The dev/CI shell may already export ZFLOW_FAST_CMD for real usage; unset it
# inside this command substitution's own subshell so the "unset" case is
# actually exercised regardless of the ambient environment.
out="$(unset ZFLOW_FAST_CMD; run_routed --task 'benign task' --difficulty fast)"
assert_contains "$out" '^command_source=worker_fast$' 'fast tier without ZFLOW_FAST_CMD falls back to worker_fast (backward compat)'
out="$(run_routed --task 'benign task' --difficulty fast --fast-command somefastcmd)"
assert_contains "$out" '^command_source=fast_fast$' 'fast tier with --fast-command uses fast_fast'
out="$(ZFLOW_FAST_CMD=somefastcmd run_routed --task 'benign task' --difficulty simple)"
assert_contains "$out" '^command_source=fast_simple$' 'ZFLOW_FAST_CMD env var also selects the fast tier'

printf '\n== Advisor effort defaults to xhigh; --effort overrides; --no-effort-flag disables ==\n'
out="$(run_routed --task 'benign task' --difficulty hard)"
assert_contains "$out" '^command_source=advisor_hard$' 'difficulty=hard routes through the advisor'
assert_contains "$out" '^advisor_effort=xhigh$' 'advisor selection defaults effort to xhigh'
out="$(run_routed --task 'benign task' --difficulty hard --effort medium)"
assert_contains "$out" '^advisor_effort=medium$' 'explicit --effort overrides the xhigh default'
out="$(run_routed --task 'benign task' --difficulty hard --no-effort-flag)"
assert_contains "$out" '^advisor_effort=disabled$' '--no-effort-flag disables effort injection entirely'
assert_not_contains "$out" '^advisor_effort=xhigh$' '--no-effort-flag output does not also claim xhigh'

printf '\n== ZFLOW_ADVISOR_CMD unset falls back to ZFLOW_MANAGER_CMD (vice versa) ==\n'
out="$(unset ZFLOW_ADVISOR_CMD; ZFLOW_MANAGER_CMD=mgr-cmd run_routed --task 'benign task' --difficulty hard)"
assert_contains "$out" '^command_source=advisor_hard$' 'vice-versa fallback still routes through the advisor'
assert_eq "$(arg_after --command "$capture")" 'mgr-cmd' 'unset ZFLOW_ADVISOR_CMD falls back to ZFLOW_MANAGER_CMD'

printf '\n== --difficulty auto chooses only between worker and advisor ==\n'
out="$(run_routed --task 'fix the security issue' --difficulty auto)"
assert_contains "$out" '^command_source=advisor_auto$' 'auto with a risk keyword selects the advisor tier'
out="$(run_routed --task 'benign task, please run startgrok-evil now' --difficulty auto --fast-command somefastcmd)"
assert_contains "$out" '^command_source=worker_auto$' 'auto with benign text never picks the fast tier even when ZFLOW_FAST_CMD is set'
assert_not_contains "$out" 'command_source=fast_auto' 'auto never produces a fast_auto command_source'
assert_not_contains "$out" 'command=startgrok-evil' 'auto never derives a command from task text'

printf '\n== ZFLOW_MANAGER_CMD selects the manager-tier default for --role manager|supermanager ==\n'
out="$(ZFLOW_MANAGER_CMD=mgr-cmd run_routed --task 'benign task' --difficulty normal --role manager)"
assert_contains "$out" '^command_source=worker_normal$' '--role manager keeps the worker_* source (label override, not routing)'
assert_eq "$(arg_after --command "$capture")" 'mgr-cmd' '--role manager without --command uses ZFLOW_MANAGER_CMD'
out="$(ZFLOW_MANAGER_CMD=mgr-cmd run_routed --task 'benign task' --difficulty normal --role supermanager)"
assert_eq "$(arg_after --command "$capture")" 'mgr-cmd' '--role supermanager also uses ZFLOW_MANAGER_CMD'
assert_eq "$(arg_after --role "$capture")" 'supermanager' '--role supermanager is passed through as the label role'

printf '\n== --command still wins over ZFLOW_MANAGER_CMD ==\n'
out="$(ZFLOW_MANAGER_CMD=mgr-cmd run_routed --task 'benign task' --role manager --command explicit-cmd)"
assert_contains "$out" '^command_source=explicit$' '--command wins over ZFLOW_MANAGER_CMD'
assert_eq "$(arg_after --command "$capture")" 'explicit-cmd' 'explicit --command overrides ZFLOW_MANAGER_CMD'

printf '\n== --role manager does not change difficulty routing ==\n'
out="$(ZFLOW_MANAGER_CMD=mgr-cmd run_routed --task 'benign task' --role manager --difficulty hard)"
assert_contains "$out" '^command_source=advisor_hard$' '--role manager leaves difficulty routing on the advisor'
assert_neq "$(arg_after --command "$capture")" 'mgr-cmd' '--role manager does not force ZFLOW_MANAGER_CMD over the advisor tier'
out="$(ZFLOW_MANAGER_CMD=mgr-cmd run_routed --task 'benign task' --role manager --difficulty fast --fast-command somefastcmd)"
assert_contains "$out" '^command_source=fast_fast$' '--role manager leaves difficulty routing on the fast tier'

printf '\n== ZFLOW_MANAGER_CMD is ignored outside manager roles and when unset ==\n'
out="$(ZFLOW_MANAGER_CMD=mgr-cmd run_routed --task 'benign task' --difficulty normal)"
assert_neq "$(arg_after --command "$capture")" 'mgr-cmd' 'ZFLOW_MANAGER_CMD is ignored for a default (worker) role'
out="$(unset ZFLOW_MANAGER_CMD; ZFLOW_ADVISOR_CMD=adv-cmd run_routed --task 'benign task' --difficulty normal --role manager)"
assert_eq "$(arg_after --command "$capture")" 'adv-cmd' 'unset ZFLOW_MANAGER_CMD falls back to ZFLOW_ADVISOR_CMD for manager panes'

printf "\n== Route 'manager' exits early with status=routed_out before any herdr call ==\n"
minimal_path="/usr/bin:/bin"
manager_out="$(PATH="$minimal_path" ZFLOW_LEDGER=off "$run_worker" --name t --task 'benign task' --route manager 2>&1)"
manager_rc=$?
assert_contains "$manager_out" '^status=routed_out$' 'route=manager prints status=routed_out'
assert_contains "$manager_out" '^route=manager$' 'route=manager echoes the route'
assert_eq "$manager_rc" 0 'route=manager exits 0'

printf '\n== Invalid --difficulty, --route, and --report-mode are rejected ==\n'
assert_fail 'invalid --difficulty is rejected' "$run_worker" --name t --task x --difficulty nonsense
assert_fail 'invalid --route is rejected' "$run_worker" --name t --task x --route nonsense
assert_fail 'invalid --report-mode is rejected' "$run_worker" --name t --task x --report-mode nonsense

printf '\n== Summary ==\n'
printf '%d passed, %d failed\n' "$passed" "$failed"
((failed == 0))
