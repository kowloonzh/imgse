#!/usr/bin/env bash
set -euo pipefail

script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")/../scripts" && pwd)"
watcher="$script_dir/zgpt-watch-pane.sh"
tmp="$(mktemp -d "${TMPDIR:-/tmp}/zgpt-watch-rebind.XXXXXX")"
trap 'rm -rf "$tmp"' EXIT
bin="$tmp/bin"
mkdir -p "$bin"
printf '0\n' >"$tmp/read.count"
printf '0\n' >"$tmp/agent.count"
printf '0\n' >"$tmp/visible.count"
cat >"$bin/herdr" <<'STUB'
#!/usr/bin/env bash
set -euo pipefail
if [[ "${1:-}" == --session ]]; then shift 2; fi
case "${1:-} ${2:-}" in
  "session list") printf '{"sessions":[{"name":"test-session","running":true}]}\n' ;;
  "pane get") exit 1 ;;
  "pane read")
    [[ "${3:-}" == w1:p2 ]] || exit 1
    source=""
    for ((i=1; i<=$#; i++)); do
      if [[ "${!i:-}" == "--source" ]]; then
        j=$((i + 1)); source="${!j:-}"; break
      fi
    done
    n="$(cat "$ZGPT_READ_COUNT")"; n=$((n + 1)); printf '%s\n' "$n" >"$ZGPT_READ_COUNT"
    if [[ "$source" == "visible" ]]; then
      v="$(cat "${ZGPT_VISIBLE_READ_COUNT:?}")"; v=$((v + 1)); printf '%s\n' "$v" >"$ZGPT_VISIBLE_READ_COUNT"
    else
      v=0
    fi
    if [[ "$source" == "recent-unwrapped" && "${ZGPT_FAKE_STALE_SHELL_HISTORY:-false}" == true ]]; then
      printf 'Baked for 2m 52s · 1 shell still running\n'
    fi
    if [[ "$source" == "visible" && ( "${ZGPT_FAKE_ACTIVE_SHELL:-false}" == true || ( -n "${ZGPT_FAKE_ACTIVE_SHELL_READS:-}" && "$v" -le "${ZGPT_FAKE_ACTIVE_SHELL_READS:-0}" ) ) ]]; then
      printf 'Baked for 2m 52s · 1 shell still running\n'
    fi
    if [[ "$source" == "visible" && "${ZGPT_FAKE_SHELL_PROSE:-false}" == true ]]; then
      printf 'note: no shell still running now\n'
    fi
    if (( n > 2 )) && [[ "${ZGPT_NO_MARKER:-false}" != true ]]; then
      printf 'WORKER_DONE:rebind\n'
    fi
    :
    ;;
  "agent get")
    [[ "${3:-}" == w1:p2 || "${3:-}" == worker-rebind ]] || exit 1
    [[ "${ZGPT_REBIND_FAIL:-false}" == true ]] && exit 1
    if [[ "${3:-}" == w1:p2 && "${ZGPT_STATUS_SEQUENCE:-}" == working-idle ]]; then
      a="$(cat "${ZGPT_AGENT_GET_COUNT:?}")"; a=$((a + 1)); printf '%s\n' "$a" >"$ZGPT_AGENT_GET_COUNT"
      if (( a <= 1 )); then status=working; else status=idle; fi
    else
      status=done
    fi
    printf '{"result":{"agent":{"pane_id":"w1:p2","agent_status":"%s"}}}\n' "$status"
    ;;
  *) exit 1 ;;
esac
STUB
chmod +x "$bin/herdr"
log="$tmp/transcript.ndjson"
out="$(PATH="$bin:$PATH" ZGPT_READ_COUNT="$tmp/read.count" ZGPT_VISIBLE_READ_COUNT="$tmp/visible.count" \
  "$watcher" --session test-session --pane-id w1:p1 --agent-name worker-rebind --log "$log" --scrollback 0)"
printf '%s\n' "$out" | grep -q '^state=done reason=WORKER_DONE:$'
grep -q '"pane_id":"w1:p2"' "$log"
grep -q '"agent_name":"worker-rebind"' "$log"

# A pane read failure with no identity rebind is a terminal worker_gone state,
# not a generic read error.
set +e
gone_out="$(PATH="$bin:$PATH" ZGPT_REBIND_FAIL=true ZGPT_READ_COUNT="$tmp/read.count" \
  ZGPT_VISIBLE_READ_COUNT="$tmp/visible.count" "$watcher" --session test-session \
  --pane-id w1:p1 --agent-name worker-rebind --log "$tmp/gone.ndjson" --scrollback 0 2>&1)"
gone_rc=$?
set -e
[[ "$gone_rc" == 1 ]]
printf '%s\n' "$gone_out" | grep -q '^state=worker_gone reason=agent-not-found$'

# Native working -> idle normally completes, but not while Claude reports a
# background shell is still running.
printf '0\n' >"$tmp/read.count"
printf '0\n' >"$tmp/agent.count"
printf '0\n' >"$tmp/visible.count"
active_shell_out_file="$tmp/active-shell.out"
PATH="$bin:$PATH" ZGPT_READ_COUNT="$tmp/read.count" ZGPT_AGENT_GET_COUNT="$tmp/agent.count" \
  ZGPT_VISIBLE_READ_COUNT="$tmp/visible.count" ZGPT_STATUS_SEQUENCE=working-idle ZGPT_NO_MARKER=true \
  ZGPT_FAKE_ACTIVE_SHELL=true "$watcher" --session test-session --pane-id w1:p1 \
  --agent-name worker-rebind --log "$tmp/active-shell.ndjson" --scrollback 0 --keep-watching \
  >"$active_shell_out_file" 2>&1 &
watch_pid=$!
sleep 5
kill "$watch_pid" 2>/dev/null || true
wait "$watch_pid" 2>/dev/null || true
active_shell_out="$(<"$active_shell_out_file")"
printf '%s\n' "$active_shell_out" | grep -q '^state=running reason=working$'
! printf '%s\n' "$active_shell_out" | grep -q '^state=done reason=native:idle$'

run_native_done_case() {
  local label="$1"
  local out_file="$tmp/$label.out"
  printf '0\n' >"$tmp/read.count"
  printf '0\n' >"$tmp/agent.count"
  printf '0\n' >"$tmp/visible.count"
  PATH="$bin:$PATH" ZGPT_READ_COUNT="$tmp/read.count" ZGPT_AGENT_GET_COUNT="$tmp/agent.count" \
    ZGPT_VISIBLE_READ_COUNT="$tmp/visible.count" ZGPT_STATUS_SEQUENCE=working-idle ZGPT_NO_MARKER=true \
    ZGPT_FAKE_ACTIVE_SHELL_READS="${ZGPT_FAKE_ACTIVE_SHELL_READS:-}" \
    ZGPT_FAKE_STALE_SHELL_HISTORY="${ZGPT_FAKE_STALE_SHELL_HISTORY:-false}" \
    ZGPT_FAKE_SHELL_PROSE="${ZGPT_FAKE_SHELL_PROSE:-false}" \
    "$watcher" --session test-session --pane-id w1:p1 --agent-name worker-rebind \
    --log "$tmp/$label.ndjson" --scrollback 0 >"$out_file" 2>&1
  cat "$out_file"
}

# Shell-running status clears from the live visible region; native idle may then complete.
cleared_out="$(ZGPT_FAKE_ACTIVE_SHELL_READS=1 run_native_done_case active-shell-cleared)"
printf '%s\n' "$cleared_out" | grep -q '^state=running reason=working$'
printf '%s\n' "$cleared_out" | grep -q '^state=done reason=native:idle$'

# A stale shell-running line in recent-unwrapped history must not suppress done
# when the live visible tail is clean.
stale_out="$(ZGPT_FAKE_STALE_SHELL_HISTORY=true run_native_done_case stale-history-clean-visible)"
printf '%s\n' "$stale_out" | grep -q '^state=done reason=native:idle$'

# Count-less prose in the visible tail must not match the active-shell detector.
prose_out="$(ZGPT_FAKE_SHELL_PROSE=true run_native_done_case prose-not-shell-status)"
printf '%s\n' "$prose_out" | grep -q '^state=done reason=native:idle$'

printf 'watch rebind smoke ok\n'
