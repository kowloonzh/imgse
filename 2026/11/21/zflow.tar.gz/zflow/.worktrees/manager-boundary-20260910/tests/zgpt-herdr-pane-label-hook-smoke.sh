#!/usr/bin/env bash
set -euo pipefail

# Offline smoke suite for the herdr pane-label hook
# (hooks/herdr-pane-label.sh) and its installer
# (scripts/install-herdr-pane-label-hook.sh).
#
# No live herdr server: `herdr` is stubbed with a fake binary on PATH that
# records every invocation and answers `pane get` with canned JSON. The
# installer is exercised against a temp HOME with an explicit --settings
# override; the machine's real ~/.claude/settings.json is never touched.

skill_root="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
repo_root="$(cd "$skill_root/../../.." && pwd)"
hook_script="$skill_root/hooks/herdr-pane-label.sh"
installer="$repo_root/scripts/install-herdr-pane-label-hook.sh"

[[ -f "$hook_script" ]] || { echo "FAIL: hook not found at $hook_script" >&2; exit 1; }
[[ -f "$installer" ]] || { echo "FAIL: installer not found at $installer" >&2; exit 1; }

passed=0
failed=0
pass() { printf 'PASS: %s\n' "$1"; passed=$((passed + 1)); }
fail() { printf 'FAIL: %s\n' "$1" >&2; failed=$((failed + 1)); }
assert_eq() { if [[ "$1" == "$2" ]]; then pass "$3"; else fail "$3 (got=$1 expected=$2)"; fi; }
assert_contains() { if grep -qF -- "$2" <<<"$1"; then pass "$3"; else fail "$3 (output did not contain: $2)"; fi; }
assert_not_contains() { if grep -qF -- "$2" <<<"$1"; then fail "$3 (output unexpectedly contained: $2)"; else pass "$3"; fi; }

tmp="$(mktemp -d "${TMPDIR:-/tmp}/zgpt-herdr-hook-smoke.XXXXXX")"
trap 'rm -rf "$tmp"' EXIT
export HERDR_FAKE_LOG="$tmp/herdr.log"

# --- fake herdr ------------------------------------------------------------------
fakebin="$tmp/bin"
mkdir -p "$fakebin"
cat >"$fakebin/herdr" <<'FAKE'
#!/usr/bin/env bash
printf '%s\n' "$*" >>"$HERDR_FAKE_LOG"
if [[ "${1:-}" == "pane" && "${2:-}" == "get" ]]; then
  printf '%s\n' "${HERDR_FAKE_PANE_JSON}"
fi
FAKE
chmod +x "$fakebin/herdr"

# --- git repo fixture ------------------------------------------------------------
repo="$tmp/repo"
mkdir -p "$repo"
git init -q "$repo"
git -C "$repo" config user.name smoke
git -C "$repo" config user.email smoke@example.invalid
printf 'base\n' >"$repo/file.txt"
git -C "$repo" add file.txt
git -C "$repo" commit -qm init
git -C "$repo" branch -M main
plain_dir="$tmp/not-a-repo"
mkdir -p "$plain_dir"

json_title='{"result":{"pane":{"label":"","terminal_title_stripped":"Fix the login bug"}}}'
json_blank='{"result":{"pane":{"label":"","terminal_title_stripped":""}}}'
json_placeholder='{"result":{"pane":{"label":"","terminal_title_stripped":"Claude Code"}}}'
json_worker='{"result":{"pane":{"label":"worker:collector","terminal_title_stripped":"anything"}}}'
json_fleet='{"result":{"pane":{"label":"fleet:fanout","terminal_title_stripped":"anything"}}}'
json_advisor='{"result":{"pane":{"label":"advisor:review","terminal_title_stripped":"anything"}}}'
json_manager='{"result":{"pane":{"label":"manager:keepalive","terminal_title_stripped":"anything"}}}'
json_supermanager='{"result":{"pane":{"label":"supermanager:ring0","terminal_title_stripped":"anything"}}}'

FAKE_PANE_JSON="$json_title"
run_hook() {
  # usage: run_hook <cwd> [extra env assignments...] -> prints the fake herdr log.
  # ZFLOW_WORKER_DEPTH is unset by default (the suite itself may run inside a
  # zflow worker, which would trip the hook's guard); pass ZFLOW_WORKER_DEPTH=1
  # explicitly to exercise that guard.
  local dir="$1"; shift
  : >"$HERDR_FAKE_LOG"
  ( cd "$dir" && env -u ZFLOW_WORKER_DEPTH -u ZFLOW_MAX_WORKER_DEPTH \
      PATH="$fakebin:$PATH" \
      HERDR_PANE_ID=pane-1 \
      HERDR_FAKE_PANE_JSON="$FAKE_PANE_JSON" \
      "$@" bash "$hook_script" ) >/dev/null 2>&1 || return 1
  cat "$HERDR_FAKE_LOG"
}

printf '\n== Hook: label format with and without a session title ==\n'
log="$(run_hook "$repo")"
assert_contains "$log" 'pane rename pane-1 human:repo · Fix the login bug' \
  'real title produces human:<repo> · <title>'
FAKE_PANE_JSON="$json_blank"
log="$(run_hook "$repo")"
assert_contains "$log" 'pane rename pane-1 human:repo' \
  'empty title falls back to human:<repo>'
assert_not_contains "$log" ' · ' \
  'empty-title label has no separator'
FAKE_PANE_JSON="$json_placeholder"
log="$(run_hook "$repo")"
assert_eq "$(tail -n1 <<<"$log")" 'pane rename pane-1 human:repo' \
  'the "Claude Code" placeholder title is treated as no title'
FAKE_PANE_JSON="$json_title"
log="$(run_hook "$plain_dir")"
assert_contains "$log" 'pane rename pane-1 human:not-a-repo · Fix the login bug' \
  'non-repo cwd falls back to the directory basename'
assert_contains "$log" 'pane rename pane-1' \
  'hook always calls herdr pane rename with HERDR_PANE_ID (never pane current)'

printf '\n== Hook: worker guards prevent relabelling a zflow pane ==\n'
log="$(run_hook "$repo" ZFLOW_WORKER_DEPTH=1)"
assert_not_contains "$log" 'pane rename' \
  'ZFLOW_WORKER_DEPTH set => hook exits 0 without touching the pane'
assert_not_contains "$log" 'pane get' \
  'ZFLOW_WORKER_DEPTH guard exits before even querying herdr'
for prefix in worker fleet advisor manager supermanager; do
  case "$prefix" in
    worker)       FAKE_PANE_JSON="$json_worker" ;;
    fleet)        FAKE_PANE_JSON="$json_fleet" ;;
    advisor)      FAKE_PANE_JSON="$json_advisor" ;;
    manager)      FAKE_PANE_JSON="$json_manager" ;;
    supermanager) FAKE_PANE_JSON="$json_supermanager" ;;
  esac
  log="$(run_hook "$repo")"
  assert_not_contains "$log" 'pane rename' \
    "$prefix: existing pane label guard skips the rename"
done
FAKE_PANE_JSON="$json_title"

printf '\n== Hook: ring-0 supermanager labelling ==\n'
log="$(run_hook "$repo" ZFLOW_SUPERMANAGER=1)"
assert_contains "$log" 'pane rename pane-1 supermanager:fleet · multi-project' \
  'ZFLOW_SUPERMANAGER=1 labels supermanager:fleet · multi-project (title ignored)'
FAKE_PANE_JSON="$json_blank"
log="$(run_hook "$repo" ZFLOW_SUPERMANAGER=1)"
assert_contains "$log" 'pane rename pane-1 supermanager:fleet · multi-project' \
  'ZFLOW_SUPERMANAGER=1 with empty title keeps the fleet label'
FAKE_PANE_JSON="$json_title"

printf '\n== Hook: never breaks the session (exit 0 on every path) ==\n'
# No HERDR_PANE_ID: nothing to label, must still exit 0.
if ( cd "$repo" && env -u ZFLOW_WORKER_DEPTH -u ZFLOW_MAX_WORKER_DEPTH PATH="$fakebin:$PATH" bash "$hook_script" ) >/dev/null 2>&1; then
  pass 'no HERDR_PANE_ID => exit 0'
else
  fail 'no HERDR_PANE_ID => exit 0'
fi

# --- installer --------------------------------------------------------------------
printf '\n== Installer: temp HOME + --settings override, never the real file ==\n'
home="$tmp/home"
mkdir -p "$home/.claude/skills"
ln -s "$skill_root" "$home/.claude/skills/zflow-workers"
settings_override="$tmp/settings-outside.json"   # deliberately outside $home
printf '%s\n' '{' \
  '  "attribution": {},' \
  '  "permissions": {"allow": ["WebFetch(*)"]},' \
  '  "hooks": {' \
  '    "SessionStart": [{"hooks":[{"type":"command","command":"sh /home/x/.guild/hooks/guild-session-start.sh"}]}]' \
  '  },' \
  '  "statusLine": {"type":"command","command":"~/.claude/statusline.sh","padding":0}' \
  '}' >"$settings_override"

out="$(HOME="$home" bash "$installer" --settings "$settings_override")"
assert_contains "$out" 'install: ' 'installer reports it wired the hook'

hook_cmd="bash '$home/.claude/skills/zflow-workers/hooks/herdr-pane-label.sh'"
count_session() { jq --arg c "$hook_cmd" '[.hooks.SessionStart[]?.hooks[]? | select(.command == $c)] | length' "$1"; }
count_stop() { jq --arg c "$hook_cmd" '[.hooks.Stop[]?.hooks[]? | select(.command == $c)] | length' "$1"; }
assert_eq "$(count_session "$settings_override")" 1 'SessionStart registers exactly one hook entry'
assert_eq "$(count_stop "$settings_override")" 1 'Stop registers exactly one hook entry'
assert_eq "$(jq -r '.hooks.SessionStart[]?.hooks[]? | select(.command == "'"$hook_cmd"'") | .timeout' "$settings_override")" 10 'SessionStart entry carries a timeout'
assert_eq "$(jq -r '.hooks.Stop[]?.hooks[]? | select(.command == "'"$hook_cmd"'") | .async' "$settings_override")" true 'Stop entry is async'
assert_eq "$(jq -r '.permissions.allow[0]' "$settings_override")" 'WebFetch(*)' 'pre-existing permissions key survives untouched'
assert_eq "$(jq -r '.statusLine.command' "$settings_override")" '~'"/.claude/statusline.sh" 'pre-existing statusLine key survives untouched'
assert_contains "$(jq -c '.hooks.SessionStart' "$settings_override")" 'guild-session-start.sh' 'pre-existing SessionStart hook (guild) survives untouched'
[[ -f "$settings_override.bak" ]] && pass 'settings.json backed up to .bak before modification' \
  || fail 'settings.json backed up to .bak before modification'
[[ ! -e "$home/.claude/settings.json" ]] && pass 'override path honored: default $HOME/.claude/settings.json untouched' \
  || fail 'override path honored: default $HOME/.claude/settings.json untouched'

printf '\n== Installer: idempotent (run twice => one entry, byte-identical) ==\n'
cp "$settings_override" "$tmp/after-first.json"
out="$(HOME="$home" bash "$installer" --settings "$settings_override")"
assert_contains "$out" 'already up to date' 're-run reports no change'
cmp -s "$settings_override" "$tmp/after-first.json" && pass 're-run leaves settings.json byte-identical' \
  || fail 're-run leaves settings.json byte-identical'
assert_eq "$(count_session "$settings_override")" 1 'second run does not duplicate the SessionStart entry'
assert_eq "$(count_stop "$settings_override")" 1 'second run does not duplicate the Stop entry'

printf '\n== Installer: uninstall removes only our entries ==\n'
out="$(HOME="$home" bash "$installer" --settings "$settings_override" --uninstall)"
assert_contains "$out" 'uninstall: ' 'uninstall reports success'
assert_eq "$(count_session "$settings_override")" 0 'uninstall removes the SessionStart entry'
assert_eq "$(count_stop "$settings_override")" 0 'uninstall removes the Stop entry'
assert_eq "$(jq -r '.permissions.allow[0]' "$settings_override")" 'WebFetch(*)' 'uninstall leaves unrelated keys untouched'
assert_contains "$(jq -c '.hooks.SessionStart' "$settings_override")" 'guild-session-start.sh' 'uninstall keeps the unrelated guild hook'
out="$(HOME="$home" bash "$installer" --settings "$settings_override" --uninstall)"
assert_contains "$out" 'already up to date' 'uninstall of an already-clean file is a no-op'

printf '\n== Summary ==\n'
printf '%d passed, %d failed\n' "$passed" "$failed"
((failed == 0))
