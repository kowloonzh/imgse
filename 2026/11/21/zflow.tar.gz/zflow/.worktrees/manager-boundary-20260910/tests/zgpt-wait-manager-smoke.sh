#!/usr/bin/env bash
set -euo pipefail

# Offline smoke suite for zgpt-wait-manager.sh. Stubs `herdr` on PATH so no live
# server is needed: `agent wait` / `agent get` / `pane read` are faked against a
# configurable ZGPT_FAKE_AGENT_STATUS. Exits non-zero on any failure.

script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")/../scripts" && pwd)"
wait_script="$script_dir/zgpt-wait-manager.sh"
tmp="$(mktemp -d "${TMPDIR:-/tmp}/zgpt-wait-manager.XXXXXX")"
trap 'rm -rf "$tmp"' EXIT

bin="$tmp/bin"
mkdir -p "$bin"

cat >"$bin/herdr" <<'STUB'
#!/usr/bin/env bash
set -euo pipefail
cmd="${1:-}"; shift || true
case "$cmd" in
  agent)
    sub="${1:-}"; shift || true
    case "$sub" in
      wait)
        until=""
        while [[ $# -gt 0 ]]; do
          [[ "${1:-}" == "--until" ]] && { until="$2"; shift 2; continue; }
          [[ "${1:-}" == "--timeout" ]] && { shift 2; continue; }
          shift
        done
        if [[ "${ZGPT_FAKE_AGENT_STATUS:-}" == "$until" ]]; then
          exit 0
        fi
        exit 1
        ;;
      get)
        printf '{"result":{"agent":{"agent_status":"%s"}}}\n' "${ZGPT_FAKE_AGENT_STATUS:-}"
        ;;
    esac
    ;;
  pane)
    sub="${1:-}"; shift || true
    case "$sub" in
      wait-output)
        regex=""
        while [[ $# -gt 0 ]]; do
          [[ "${1:-}" == "--regex" ]] && { regex="$2"; shift 2; continue; }
          [[ "${1:-}" == "--timeout" ]] && { shift 2; continue; }
          shift
        done
        if [[ -n "${ZGPT_FAKE_STATUS_LINE:-}" ]] && grep -qE "$regex" <<<"${ZGPT_FAKE_STATUS_LINE}"; then
          exit 0
        fi
        exit 1
        ;;
      read)
        if [[ -n "${ZGPT_FAKE_STATUS_LINE:-}" ]]; then
          printf '%s\n' "$ZGPT_FAKE_STATUS_LINE"
        else
          printf 'last line from %s\n' "${ZGPT_FAKE_PANE_ID:-pane}"
        fi
        ;;
    esac
    ;;
esac
STUB
chmod +x "$bin/herdr"

passed=0; failed=0
pass() { printf 'PASS: %s\n' "$1"; passed=$((passed + 1)); }
fail() { printf 'FAIL: %s\n' "$1" >&2; failed=$((failed + 1)); }

run() {
  # usage: run <agent_status> [extra args...] -> prints output, returns via rc var
  local st="$1"; shift
  ZGPT_FAKE_AGENT_STATUS="$st" ZGPT_FAKE_PANE_ID="w1:p9" \
    PATH="$bin:$PATH" "$wait_script" "$@" 2>&1 || return $?
  return 0
}

printf '\n== idle manager => idle_for_steer, exit 0 ==\n'
out="$(run idle --pane-id w1:p9 --timeout 5)" && rc=0 || rc=$?
[[ "$rc" == 0 ]] && pass "exit 0 on idle" || fail "expected 0, got $rc"
grep -q 'status=idle_for_steer' <<<"$out" && pass "status=idle_for_steer" || fail "bad status line: $out"
grep -q 'agent_status=idle' <<<"$out" && pass "agent_status=idle printed" || fail "agent_status missing: $out"

printf '\n== blocked manager => blocked, exit 2 ==\n'
out="$(run blocked --pane-id w1:p9 --timeout 5)" && rc=0 || rc=$?
[[ "$rc" == 2 ]] && pass "exit 2 on blocked" || fail "expected 2, got $rc"
grep -q 'status=blocked' <<<"$out" && pass "status=blocked" || fail "bad status line: $out"

printf '\n== working past timeout => timeout, exit 3 ==\n'
out="$(run working --pane-id w1:p9 --timeout 1)" && rc=0 || rc=$?
[[ "$rc" == 3 ]] && pass "exit 3 on timeout" || fail "expected 3, got $rc"
grep -q 'status=timeout' <<<"$out" && pass "status=timeout" || fail "bad status line: $out"

printf '\n== unknown state => working_unknown, exit 4 ==\n'
out="$(run unknown --pane-id w1:p9 --timeout 1)" && rc=0 || rc=$?
[[ "$rc" == 4 ]] && pass "exit 4 on unknown" || fail "expected 4, got $rc"
grep -q 'status=working_unknown' <<<"$out" && pass "status=working_unknown" || fail "bad status line: $out"

printf '\n== status-regex: MANAGER_STATUS idle_for_steer => idle_for_steer, exit 0 ==\n'
out="$(ZGPT_FAKE_STATUS_LINE='MANAGER_STATUS: idle_for_steer a1 /tmp/a.md' run idle --pane-id w1:p9 --timeout 5 --status-regex 'MANAGER_STATUS: (idle_for_steer|blocked)')" && rc=0 || rc=$?
[[ "$rc" == 0 ]] && pass "exit 0 on status-regex idle_for_steer" || fail "expected 0, got $rc"
grep -q 'status=idle_for_steer' <<<"$out" && pass "status=idle_for_steer from MANAGER_STATUS line" || fail "bad status line: $out"

printf '\n== status-regex: MANAGER_STATUS blocked => blocked, exit 2 ==\n'
out="$(ZGPT_FAKE_STATUS_LINE='MANAGER_STATUS: blocked need human' run idle --pane-id w1:p9 --timeout 5 --status-regex 'MANAGER_STATUS: (idle_for_steer|blocked)')" && rc=0 || rc=$?
[[ "$rc" == 2 ]] && pass "exit 2 on status-regex blocked" || fail "expected 2, got $rc"
grep -q 'status=blocked' <<<"$out" && pass "status=blocked from MANAGER_STATUS line" || fail "bad status line: $out"

printf '\n== status-regex: MANAGER_STATUS working => timeout (still working), exit 3 ==\n'
out="$(ZGPT_FAKE_STATUS_LINE='MANAGER_STATUS: working a1' run idle --pane-id w1:p9 --timeout 5 --status-regex 'MANAGER_STATUS: working')" && rc=0 || rc=$?
[[ "$rc" == 3 ]] && pass "exit 3 on status-regex working" || fail "expected 3, got $rc"
grep -q 'status=timeout' <<<"$out" && pass "status=timeout from working line" || fail "bad status line: $out"

printf '\n== status-regex not matched => falls back to agent state ==\n'
out="$(run idle --pane-id w1:p9 --timeout 5 --status-regex 'MANAGER_STATUS: (idle_for_steer|blocked)')" && rc=0 || rc=$?
[[ "$rc" == 0 ]] && pass "exit 0 on fallback idle" || fail "expected 0, got $rc"
grep -q 'status=idle_for_steer' <<<"$out" && pass "fallback status=idle_for_steer" || fail "bad status line: $out"

printf '\n== artifact reporting (status line + head) ==\n'
art="$tmp/artifact.md"
printf 'status: DONE\nsummary: did the thing\n' >"$art"
out="$(run idle --pane-id w1:p9 --timeout 5 --artifact "$art")" && rc=0 || rc=$?
grep -q 'artifact_status=DONE' <<<"$out" && pass "artifact_status=DONE extracted" || fail "artifact_status missing: $out"
grep -q -- '-- artifact head --' <<<"$out" && pass "artifact head printed" || fail "artifact head missing"

printf '\n== pane tail printed ==\n'
grep -q -- '-- pane tail --' <<<"$out" && pass "pane tail printed" || fail "pane tail missing"

printf '\n== missing artifact is silent (no artifact section) ==\n'
out="$(run idle --pane-id w1:p9 --timeout 5 --artifact "$tmp/does-not-exist.md")" && rc=0 || rc=$?
grep -q -- '-- artifact head --' <<<"$out" && fail "missing artifact printed a head" || pass "missing artifact prints no head"

printf '\n== missing --pane-id => usage error ==\n'
if PATH="$bin:$PATH" "$wait_script" --timeout 5 >/dev/null 2>&1; then
  fail "missing --pane-id accepted"
else
  pass "missing --pane-id rejected"
fi

printf '\nSummary: %d/%d passed\n' "$passed" "$((passed + failed))"
((failed == 0))
