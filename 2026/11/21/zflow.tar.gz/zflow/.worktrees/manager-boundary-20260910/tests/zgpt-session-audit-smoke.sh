#!/usr/bin/env bash
# zgpt-session-audit-smoke.sh — offline fixture tests for the session auditor.
#
# Builds synthetic JSONL transcripts by hand in a temp dir and asserts the
# auditor's metrics. Exits non-zero on any failure; prints an N/M summary.
# No python3. No real ~/.claude/projects transcripts.
set -euo pipefail

script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")/../scripts" && pwd)"
audit="$script_dir/zgpt-session-audit.sh"

# Tests need a writable area OUTSIDE /tmp, because a path under /tmp is
# classified as `scratch` by design (temp drafts). Repo classification cases
# must use a real repo on disk that is not under /tmp.
root="$(mktemp -d "${HOME}/.zflow-audit-smoke.XXXXXX")"
trap 'rm -rf "$root"' EXIT

pass=0
fail=0
fails=()

ok() { pass=$((pass+1)); printf '  ok: %s\n' "$1"; }
bad() { fail=$((fail+1)); fails+=("$1"); printf '  FAIL: %s\n' "$1"; }

# Emit one assistant JSONL row with given usage + content array.
emit() { # id usage_json content_json >> file
  local id="$1" usage="$2" content="$3" file="$4"
  jq -nc --arg id "$id" --argjson usage "$usage" --argjson content "$content" \
    '{type:"assistant",timestamp:"2026-08-04T10:00:00Z",message:{id:$id,model:"claude-x",usage:$usage,content:$content}}' >>"$file"
}
eb() { jq -nc --arg n "$1" --arg fp "$2" '{type:"tool_use",id:"t",name:$n,input:{file_path:$fp}}'; }
bb() { jq -nc --arg c "$1" '{type:"tool_use",id:"t",name:"Bash",input:{command:$c}}'; }

echo "== case 1: dedupe =="
{
  f="$root/dup.jsonl"
  for i in 1 2 3; do
    emit "msg_same" '{"input_tokens":1000,"cache_read_input_tokens":0,"cache_creation_input_tokens":0}' '[]' "$f"
  done
  out="$("$audit" "$f" --format json)"
  turns="$(printf '%s' "$out" | jq -r '.turns')"
  pt="$(printf '%s' "$out" | jq -r '.prompt_tokens')"
  [[ "$turns" == "1" ]] && ok "dedupe turns=1" || bad "dedupe turns (got $turns want 1)"
  [[ "$pt" == "1000" ]] && ok "dedupe prompt_tokens=1000" || bad "dedupe prompt_tokens (got $pt want 1000)"
}

echo "== case 2: edit classification =="
{
  git init -q "$root/repo"
  ( cd "$root/repo" && git config user.email t@t.t && git config user.name t \
      && echo a >a && git add a && git commit -qm init )
  git -C "$root/repo" worktree add -q "$root/repo-wt"
  f="$root/edits.jsonl"
  emit m1 '{"input_tokens":1000,"cache_read_input_tokens":0,"cache_creation_input_tokens":0}' "[$(eb Edit "$root/repo/a")]" "$f"
  emit m2 '{"input_tokens":1000,"cache_read_input_tokens":0,"cache_creation_input_tokens":0}' "[$(eb Edit "$root/repo-wt/b")]" "$f"
  emit m3 '{"input_tokens":1000,"cache_read_input_tokens":0,"cache_creation_input_tokens":0}' "[$(eb Write "/tmp/scratch.txt")]" "$f"
  out="$("$audit" "$f" --format json)"
  primary="$(printf '%s' "$out" | jq -r '.primary')"
  edits="$(printf '%s' "$out" | jq -r '.edits')"
  [[ "$primary" == "1" ]] && ok "edit primary=1" || bad "edit primary (got $primary want 1)"
  [[ "$edits" == "3" ]] && ok "edit edits=3" || bad "edit edits (got $edits want 3)"
  # worktree + /tmp must not be violations: primary stays 1, violations==1
  viol="$(printf '%s' "$out" | jq -r '.violations')"
  [[ "$viol" == "1" ]] && ok "edit only primary is a violation" || bad "edit violations (got $viol want 1)"
  fixture2="$f"  # reused by case 6
}

echo "== case 3: launch detection =="
{
  f="$root/launch.jsonl"
  emit m1 '{"input_tokens":1000,"cache_read_input_tokens":0,"cache_creation_input_tokens":0}' "[$(bb "zgpt-run-worker.sh --name w --task hi --difficulty hard --artifact /tmp/a.md")]" "$f"
  emit m2 '{"input_tokens":1000,"cache_read_input_tokens":0,"cache_creation_input_tokens":0}' "[$(bb "grep -n x /p/zgpt-run-worker.sh")]" "$f"
  emit m3 '{"input_tokens":1000,"cache_read_input_tokens":0,"cache_creation_input_tokens":0}' "[$(bb "cat /p/zgpt-run-worker.sh")]" "$f"
  out="$("$audit" "$f" --format json)"
  launches="$(printf '%s' "$out" | jq -r '.launches')"
  [[ "$launches" == "1" ]] && ok "launch launches=1" || bad "launch launches (got $launches want 1)"
}

echo "== case 4: --command counting =="
{
  f="$root/cmd.jsonl"
  emit m1 '{"input_tokens":1000,"cache_read_input_tokens":0,"cache_creation_input_tokens":0}' "[$(bb "zgpt-run-worker.sh --name w --command glm --task hi --artifact /tmp/a.md")]" "$f"
  emit m2 '{"input_tokens":1000,"cache_read_input_tokens":0,"cache_creation_input_tokens":0}' "[$(bb "zgpt-run-worker.sh --name w --command glm --difficulty hard --task hi --artifact /tmp/b.md")]" "$f"
  out="$("$audit" "$f" --format json)"
  cf="$(printf '%s' "$out" | jq -r '.command_flag')"
  # --command counts on every launch that passes it; --difficulty no longer
  # exempts (the real-transcript fixture's ground truth is 6, including a launch
  # with --difficulty normal). Both launches here pass --command.
  [[ "$cf" == "2" ]] && ok "--command counted on both launches (got $cf want 2)" || bad "--command counting (got $cf want 2)"
}

echo "== case 5: suspect accounting =="
{
  f="$root/suspect.jsonl"
  for i in 1 2 3; do
    emit "s$i" '{"input_tokens":100,"cache_read_input_tokens":500,"cache_creation_input_tokens":0}' '[]' "$f"
  done
  jsonout="$("$audit" "$f" --format json)"
  tabout="$("$audit" "$f")"
  ta="$(printf '%s' "$jsonout" | jq -r '.token_accounting')"
  unc="$(printf '%s' "$jsonout" | jq -r '.uncached')"
  [[ "$ta" == "suspect" ]] && ok "suspect token_accounting=suspect" || bad "suspect accounting label (got $ta)"
  [[ "$unc" == "null" ]] && ok "suspect uncached=null in json" || bad "suspect uncached (got $unc)"
  printf '%s\n' "$tabout" | grep -q 'n/a' && ok "suspect table shows n/a" || bad "suspect table no n/a"
  printf '%s\n' "$tabout" | grep -q 'suspect' && ok "suspect table shows suspect" || bad "suspect table no suspect label"
}

echo "== case 6: --strict =="
{
  # reuse case-2 fixture (has primary=1 violation)
  set +e
  "$audit" "$fixture2" --strict >/dev/null 2>&1; rc_strict=$?
  "$audit" "$fixture2" >/dev/null 2>&1; rc_loose=$?
  set -e
  [[ "$rc_strict" == "1" ]] && ok "strict exits 1 on violation" || bad "strict exit (got $rc_strict want 1)"
  [[ "$rc_loose" == "0" ]] && ok "loose exits 0 on violation" || bad "loose exit (got $rc_loose want 0)"
}

echo "== case 7: poll-wait detection =="
{
  f="$root/poll.jsonl"
  emit m1 '{"input_tokens":1000,"cache_read_input_tokens":0,"cache_creation_input_tokens":0}' "[$(bb "sleep 3; herdr pane read pane1")]" "$f"
  emit m2 '{"input_tokens":1000,"cache_read_input_tokens":0,"cache_creation_input_tokens":0}' "[$(bb "sleep 3; echo done")]" "$f"
  out="$("$audit" "$f" --format json)"
  polls="$(printf '%s' "$out" | jq -r '.polls')"
  [[ "$polls" == "1" ]] && ok "poll polls=1" || bad "poll detection (got $polls want 1)"
}

echo "== case 8: real-transcript fixture ground truth =="
{
  # Frozen real-session fixture (see rework-task.md). @@REPO@@ is substituted
  # with a temp dir built to match the fixture's classification assumptions:
  # a primary clone (polaris-iaas), a live linked worktree under .worktrees
  # (havip-az-20260803), a second primary clone (polaris-test), and deliberately
  # NO havip-table-20260803 worktree so those paths classify as unknown.
  real_fixture="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/fixtures/session-audit-real.jsonl"
  if [[ ! -f "$real_fixture" ]]; then
    bad "fixture missing: $real_fixture"
  else
    git init -q "$root/polaris-iaas"
    ( cd "$root/polaris-iaas" && git config user.email t@t.t && git config user.name t \
        && echo a >a && git add a && git commit -qm init )
    git -C "$root/polaris-iaas" worktree add -q "$root/polaris-iaas/.worktrees/agent/havip-az-20260803"
    git init -q "$root/polaris-test"
    ( cd "$root/polaris-test" && git config user.email t@t.t && git config user.name t \
        && echo a >a && git add a && git commit -qm init )
    f="$root/real.jsonl"
    sed "s#@@REPO@@#$root#g" "$real_fixture" > "$f"
    out="$("$audit" "$f" --format json)"
    get() { printf '%s' "$out" | jq -r "$1"; }
    [[ "$(get .turns)" == "458" ]] && ok "fixture turns=458" || bad "fixture turns (got $(get .turns) want 458)"
    [[ "$(get .edits)" == "44" ]] && ok "fixture edits=44" || bad "fixture edits (got $(get .edits) want 44)"
    [[ "$(get .launches)" == "6" ]] && ok "fixture launches=6" || bad "fixture launches (got $(get .launches) want 6)"
    [[ "$(get .command_flag)" == "6" ]] && ok "fixture command_flag=6" || bad "fixture command_flag (got $(get .command_flag) want 6)"
    [[ "$(get .no_artifact)" == "5" ]] && ok "fixture no_artifact=5" || bad "fixture no_artifact (got $(get .no_artifact) want 5)"
    [[ "$(get .polls)" == "12" ]] && ok "fixture polls=12" || bad "fixture polls (got $(get .polls) want 12)"
    # Classification split under the corrected rules: 4 primary-clone edits in
    # polaris-iaas + 6 in polaris-test = 10 primary; the deleted havip-table
    # worktree's 18 edits are unknown (never a primary-clone violation); the
    # remaining 14 are the live havip-az worktree and 2 are scratch (/tmp + $root).
    [[ "$(get .primary)" == "10" ]] && ok "fixture primary=10" || bad "fixture primary (got $(get .primary) want 10)"
    [[ "$(get .unknown)" == "18" ]] && ok "fixture unknown=18" || bad "fixture unknown (got $(get .unknown) want 18)"
  fi
}

echo
echo "Summary: $pass/$((pass+fail)) passed"
if (( fail > 0 )); then
  printf 'Failed: %s\n' "${fails[*]}"
  exit 1
fi
printf 'session-audit smoke ok\n'
