#!/usr/bin/env bash
set -euo pipefail

# Offline smoke suite for zgpt-watch-managers.sh. Stubs `herdr` on PATH so no
# live server is needed: `agent get` answers from per-pane status files under
# ZGPT_FAKE_STATUS_DIR. Exits non-zero on any failure.

script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")/../scripts" && pwd)"
watch_script="$script_dir/zgpt-watch-managers.sh"
tmp="$(mktemp -d "${TMPDIR:-/tmp}/zgpt-watch-managers.XXXXXX")"
trap 'rm -rf "$tmp"' EXIT

bin="$tmp/bin"
status_dir="$tmp/status"
registry="$tmp/registry.tsv"
mkdir -p "$bin" "$status_dir"

cat >"$bin/herdr" <<'STUB'
#!/usr/bin/env bash
set -euo pipefail
# Optional session prefix: herdr --session X <cmd> ...
if [[ "${1:-}" == --session ]]; then shift 2; fi
cmd="${1:-}"; shift || true
case "$cmd" in
  agent)
    sub="${1:-}"; shift || true
    case "$sub" in
      get)
        pane="${1:-}"
        st="unknown"
        if [[ -f "$ZGPT_FAKE_STATUS_DIR/$pane.status" ]]; then
          st="$(cat "$ZGPT_FAKE_STATUS_DIR/$pane.status")"
        fi
        printf '{"result":{"agent":{"agent_status":"%s"}}}\n' "$st"
        ;;
      prompt)
        # herdr agent prompt [--help] <pane> <text> — must answer --help truthfully
        # so zgpt_herdr_has_agent_prompt's probe passes and the inject path runs.
        if [[ "${1:-}" == "--help" ]]; then
          printf 'usage: herdr agent prompt <pane> <text> [opts]\n'
          exit 0
        fi
        pane="${1:-}"; text="${2:-}"
        if [[ -n "${ZGPT_FAKE_DELIVER_LOG:-}" ]]; then
          printf 'agent-prompt pane=%s text=%s\n' "$pane" "$text" >>"$ZGPT_FAKE_DELIVER_LOG"
        fi
        ;;
    esac
    ;;
  pane)
    sub="${1:-}"; shift || true
    case "$sub" in
      get)
        # A pane exists unless a "<pane>.missing" marker was placed, which the
        # suite uses to simulate a closed pane for the auto-unregister path.
        pane="${1:-}"
        if [[ -f "$ZGPT_FAKE_STATUS_DIR/$pane.missing" ]]; then
          printf 'error: no such pane\n' >&2
          exit 1
        fi
        printf '{"result":{"pane":{"pane_id":"%s"}}}\n' "$pane"
        ;;
      list)
        # Fake panes for the supermanager discovery tests: ZGPT_FAKE_PANE_LIST
        # is a TSV of "pane_id<TAB>label" lines. Empty when unset.
        if [[ -n "${ZGPT_FAKE_PANE_LIST:-}" && -f "$ZGPT_FAKE_PANE_LIST" ]]; then
          printf '{"result":{"panes":['
          first=1
          while IFS=$'\t' read -r pid lbl; do
            [[ -n "$pid" ]] || continue
            [[ "$first" -eq 1 ]] || printf ','
            printf '{"pane_id":"%s","label":"%s"}' "$pid" "$lbl"
            first=0
          done <"$ZGPT_FAKE_PANE_LIST"
          printf ']}}\n'
        fi
        ;;
      send-text)
        # herdr pane send-text <pane> <msg>
        pane="${1:-}"; msg="${2:-}"
        if [[ -n "${ZGPT_FAKE_DELIVER_LOG:-}" ]]; then
          printf 'send-text pane=%s msg=%s\n' "$pane" "$msg" >>"$ZGPT_FAKE_DELIVER_LOG"
        fi
        ;;
      send-keys)
        # herdr pane send-keys <pane> Enter
        pane="${1:-}"; key="${2:-}"
        if [[ -n "${ZGPT_FAKE_DELIVER_LOG:-}" ]]; then
          printf 'send-keys pane=%s key=%s\n' "$pane" "$key" >>"$ZGPT_FAKE_DELIVER_LOG"
        fi
        ;;
    esac
    ;;
esac
STUB
chmod +x "$bin/herdr"

passed=0; failed=0
pass() { printf 'PASS: %s\n' "$1"; passed=$((passed + 1)); }
fail() { printf 'FAIL: %s\n' "$1" >&2; failed=$((failed + 1)); }

export PATH="$bin:$PATH"
export ZGPT_FAKE_STATUS_DIR="$status_dir"
export ZGPT_MANAGER_REGISTRY="$registry"

printf '\n== register ==\n'
out="$( "$watch_script" register w1:p1 --workstream zflow )"
grep -q 'registered=w1:p1' <<<"$out" && pass "register prints registered=" || fail "register output: $out"
[[ -f "$registry" ]] && pass "registry file created" || fail "registry missing"

printf '\n== once: first poll reports current state (delta from -) ==\n'
printf 'working\n' >"$status_dir/w1:p1.status"
out="$( "$watch_script" once )"
grep -q 'event=working pane=w1:p1 workstream=zflow' <<<"$out" && pass "first once reports working" || fail "first once: $out"

printf '\n== once: no delta on the same state => silent, exit 0 ==\n'
out="$( "$watch_script" once )"
[[ -z "$out" ]] && pass "no delta => no output" || fail "expected silence, got: $out"

printf '\n== once: transition working -> blocked emits event=blocked ==\n'
printf 'blocked\n' >"$status_dir/w1:p1.status"
out="$( "$watch_script" once )"
grep -q 'event=blocked pane=w1:p1' <<<"$out" && pass "transition to blocked emitted" || fail "blocked delta: $out"

printf '\n== once: blocked -> idle with artifact expectation ==\n'
printf 'idle\n' >"$status_dir/w1:p1.status"
art="$tmp/a1.md"
"$watch_script" register w1:p1 --workstream zflow --artifact "$art" >/dev/null  # reset baseline
printf 'status: DONE\n' >"$art"
out="$( "$watch_script" once )"
grep -q 'event=idle_for_steer pane=w1:p1' <<<"$out" && pass "idle + present artifact => idle_for_steer" || fail "idle_for_steer: $out"
grep -q 'artifact='"$art" <<<"$out" && pass "artifact path carried" || fail "artifact path missing: $out"

printf '\n== once: idle without artifact and no change => silent (idle alone is not done) ==\n'
printf 'idle\n' >"$status_dir/w1:p1.status"          # same idle state, same artifact mtime
out="$( "$watch_script" once )"
[[ -z "$out" ]] && pass "unchanged idle => silent" || fail "expected silence, got: $out"

printf '\n== idle_for_steer artifact_state machine: missing -> silent -> present -> silent -> present again ==\n'
art_s="$tmp/a_s.md"
printf 'idle\n' >"$status_dir/w1:pA.status"
"$watch_script" register w1:pA --workstream zflow --artifact "$art_s" >/dev/null   # baseline last_status='-'
# 1. working/idle transition with artifact missing => one idle_for_steer ... artifact_state=missing
out="$( "$watch_script" once )"
grep -q 'event=idle_for_steer pane=w1:pA' <<<"$out" && pass "idle + missing artifact emits idle_for_steer" || fail "missing emit: $out"
grep -q 'artifact='"$art_s"' artifact_state=missing' <<<"$out" && pass "missing carries artifact_state=missing" || fail "missing state: $out"
grep -q 'artifact_mtime=' <<<"$out" && fail "missing artifact must not carry artifact_mtime" || pass "missing omits artifact_mtime"
# 2. still idle, still missing => silent
out="$( "$watch_script" once )"
[[ -z "$out" ]] && pass "steady idle + missing artifact stays silent" || fail "expected silence, got: $out"
# 3. artifact appears => present with mtime
printf 'status: DONE\n' >"$art_s"
out="$( "$watch_script" once )"
grep -q 'event=idle_for_steer pane=w1:pA' <<<"$out" && pass "artifact appearing re-emits idle_for_steer" || fail "present emit: $out"
grep -qE 'artifact='"$art_s"' artifact_state=present artifact_mtime=[0-9]+' <<<"$out" && pass "present carries artifact_state=present + mtime" || fail "present fields: $out"
# 4. mtime unchanged => silent
out="$( "$watch_script" once )"
[[ -z "$out" ]] && pass "unchanged mtime stays silent" || fail "expected silence on same mtime, got: $out"
# 5. artifact rewritten (mtime changes) => present again with the new mtime
touch -d '2030-01-01 00:00:00' "$art_s"
m2="$(stat -c %Y "$art_s")"
out="$( "$watch_script" once )"
grep -q 'event=idle_for_steer pane=w1:pA' <<<"$out" && pass "rewritten artifact re-emits idle_for_steer" || fail "re-emit on mtime change: $out"
grep -q 'artifact_state=present artifact_mtime='"$m2" <<<"$out" && pass "present carries the new mtime" || fail "new mtime: $out"
"$watch_script" unregister w1:pA >/dev/null

printf '\n== list ==\n'
out="$( "$watch_script" list )"
grep -qF $'pane_id\tworkstream\texpect_artifact' <<<"$out" && pass "list prints header" || fail "list header: $out"
grep -q 'w1:p1' <<<"$out" && pass "list contains w1:p1" || fail "list missing pane: $out"

printf '\n== unregister ==\n'
out="$( "$watch_script" unregister w1:p1 )"
grep -q 'unregistered=w1:p1' <<<"$out" && pass "unregister prints unregistered=" || fail "unregister: $out"
out="$( "$watch_script" list )"
grep -q 'w1:p1' <<<"$out" && fail "unregistered pane still listed" || pass "unregistered pane removed"
out="$( "$watch_script" once )"
[[ -z "$out" ]] && pass "once after unregister is silent" || fail "once after unregister: $out"

printf '\n== watch: bounded by --max-runtime, silent without deltas ==\n'
printf 'working\n' >"$status_dir/w1:p2.status"
"$watch_script" register w1:p2 --workstream xcloud >/dev/null
start="$(date +%s)"
out="$( "$watch_script" watch --interval 1 --max-runtime 2 )"
elapsed=$(( $(date +%s) - start ))
grep -q 'event=working pane=w1:p2' <<<"$out" && pass "watch emitted the first delta" || fail "watch first delta: $out"
[[ "$elapsed" -ge 2 ]] && pass "watch ran >= max-runtime" || fail "watch stopped too early (${elapsed}s)"
"$watch_script" unregister w1:p2 >/dev/null

printf '\n== watch --registry: parsed inline (was "unknown argument"), overrides env ==\n'
printf 'working\n' >"$status_dir/w1:p3.status"
reg2="$tmp/registry2.tsv"
"$watch_script" --registry "$reg2" register w1:p3 --workstream yg >/dev/null
out="$( "$watch_script" watch --registry "$reg2" --interval 1 --max-runtime 1 )"
grep -q 'event=working pane=w1:p3 workstream=yg' <<<"$out" && pass "watch --registry parsed and polled that registry" || fail "watch --registry: $out"
grep -q 'w1:p3' "$reg2" && pass "--registry path received the poll (last_status advanced)" || fail "--registry not used, poll hit env registry instead"
"$watch_script" --registry "$reg2" unregister w1:p3 >/dev/null

printf '\n== watch --exit-on-delta: exits promptly after the first delta ==\n'
printf 'blocked\n' >"$status_dir/w1:p4.status"
"$watch_script" register w1:p4 --workstream zflow >/dev/null
start="$(date +%s)"
# --max-runtime 15 is only a hang backstop: a prompt exit should land far under it.
out="$( "$watch_script" watch --exit-on-delta --interval 1 --max-runtime 15 )"
elapsed=$(( $(date +%s) - start ))
grep -q 'event=blocked pane=w1:p4' <<<"$out" && pass "--exit-on-delta emitted the first delta" || fail "--exit-on-delta delta: $out"
[[ "$elapsed" -lt 10 ]] && pass "--exit-on-delta exited promptly (${elapsed}s)" || fail "--exit-on-delta did not exit (${elapsed}s)"
"$watch_script" unregister w1:p4 >/dev/null

printf '\n== watch --exit-on-delta: still silent + bounded when there is no delta ==\n'
printf 'working\n' >"$status_dir/w1:p5.status"
"$watch_script" register w1:p5 --workstream zflow >/dev/null
"$watch_script" once >/dev/null                     # consume the first (working) delta
start="$(date +%s)"
out="$( "$watch_script" watch --exit-on-delta --interval 1 --max-runtime 2 )"
elapsed=$(( $(date +%s) - start ))
[[ -z "$out" ]] && pass "--exit-on-delta without a delta stays silent" || fail "--exit-on-delta silence: $out"
[[ "$elapsed" -ge 2 ]] && pass "--exit-on-delta still honors --max-runtime" || fail "--exit-on-delta exited without a delta (${elapsed}s)"
"$watch_script" unregister w1:p5 >/dev/null

printf '\n== deliver-to-pane: idle_for_steer injects into super; working does not ==\n'
deliver_log="$tmp/deliver.log"
: >"$deliver_log"
export ZGPT_FAKE_DELIVER_LOG="$deliver_log"
super_pane="w9:super"
# Register two panes: one will go working (should NOT deliver by default),
# one will go idle_for_steer with artifact (SHOULD deliver).
printf 'working\n' >"$status_dir/w1:p6.status"
"$watch_script" register w1:p6 --workstream noisy >/dev/null
art6="$tmp/a6.md"
printf 'idle\n' >"$status_dir/w1:p7.status"
printf 'status: DONE\nsummary: phase1 done\n' >"$art6"
"$watch_script" register w1:p7 --workstream sch026 --artifact "$art6" >/dev/null
out="$( "$watch_script" once --deliver-to-pane "$super_pane" --deliver-settle 0 )"
grep -q 'event=working pane=w1:p6' <<<"$out" && pass "deliver path still prints working event=" || fail "working event missing: $out"
grep -q 'event=idle_for_steer pane=w1:p7' <<<"$out" && pass "deliver path still prints idle_for_steer event=" || fail "idle event missing: $out"
# working must NOT be delivered by default
if grep -q 'agent-prompt pane='"$super_pane"' text=\[zflow-manager\] event=working' "$deliver_log"; then
  fail "working was delivered (should be excluded by default)"
else
  pass "working not delivered by default"
fi
# idle_for_steer MUST be delivered
if grep -q 'agent-prompt pane='"$super_pane"' text=\[zflow-manager\] event=idle_for_steer pane=w1:p7' "$deliver_log"; then
  pass "idle_for_steer delivered via agent prompt inject"
else
  fail "idle_for_steer not delivered; log=$(cat "$deliver_log")"
fi
grep -q "delivered_to=$super_pane event=idle_for_steer" <<<"$out" && pass "stdout carries delivered_to=" || fail "delivered_to missing: $out"
"$watch_script" unregister w1:p6 >/dev/null
"$watch_script" unregister w1:p7 >/dev/null

printf '\n== deliver-events override: can include working ==\n'
: >"$deliver_log"
printf 'working\n' >"$status_dir/w1:p8.status"
"$watch_script" register w1:p8 --workstream fleet >/dev/null
out="$( "$watch_script" once --deliver-to-pane "$super_pane" --deliver-events working --deliver-settle 0 )"
if grep -q 'agent-prompt pane='"$super_pane"' text=\[zflow-manager\] event=working pane=w1:p8' "$deliver_log"; then
  pass "--deliver-events working overrides default exclusion"
else
  fail "override did not deliver working; log=$(cat "$deliver_log") out=$out"
fi
"$watch_script" unregister w1:p8 >/dev/null

printf '\n== deliver via env ZGPT_SUPER_PANE_ID ==\n'
: >"$deliver_log"
export ZGPT_SUPER_PANE_ID="$super_pane"
printf 'blocked\n' >"$status_dir/w1:p9.status"
"$watch_script" register w1:p9 --workstream zflow >/dev/null
# no --deliver-to-pane flag: env default should fire (script reads env at top level)
out="$( env -u ZFLOW_SUPER_PANE_ID "$watch_script" once --deliver-settle 0 )"
if grep -q 'agent-prompt pane='"$super_pane"' text=\[zflow-manager\] event=blocked' "$deliver_log"; then
  pass "ZGPT_SUPER_PANE_ID env delivers blocked"
else
  fail "env deliver failed; log=$(cat "$deliver_log") out=$out"
fi
unset ZGPT_SUPER_PANE_ID
"$watch_script" unregister w1:p9 >/dev/null 2>/dev/null || true
unset ZGPT_FAKE_DELIVER_LOG

printf '\n== deliver gate: working super defers; pending file persists across invocations ==\n'
: >"$deliver_log"
export ZGPT_FAKE_DELIVER_LOG="$deliver_log"
export ZGPT_SUPER_PANE_ID="$super_pane"
printf 'working\n' >"$status_dir/$super_pane.status"   # super pane is busy
printf 'working\n' >"$status_dir/w1:g1.status"
"$watch_script" register w1:g1 --workstream zflow >/dev/null
"$watch_script" once >/dev/null                        # consume the working baseline (not enqueued)
printf 'blocked\n' >"$status_dir/w1:g1.status"
# invocation #1: blocked event enqueued, flush sees a working super => deferred
out="$( "$watch_script" once )"
grep -q 'deferred_to='"$super_pane"' event=blocked' <<<"$out" && pass "working super defers delivery (deferred_to=)" || fail "deferred missing: $out"
pending="$tmp/manager-deliver-pending.log"
grep -q 'event=blocked pane=w1:g1' "$pending" && pass "pending file retains the event" || fail "pending file: $(cat "$pending" 2>/dev/null)"
if grep -q 'agent-prompt' "$deliver_log"; then
  fail "injected while super was working"
else
  pass "no inject while super is working"
fi
# invocation #2: super idle now => one inject delivers the backlog, clears pending
printf 'idle\n' >"$status_dir/$super_pane.status"
out="$( "$watch_script" once )"
grep -q 'delivered_to='"$super_pane"' event=blocked' <<<"$out" && pass "idle super delivers the queued event" || fail "delivered missing: $out"
[[ -s "$pending" ]] && fail "pending not cleared: $(cat "$pending")" || pass "pending cleared after delivery"
grep -q 'agent-prompt pane='"$super_pane"' text=\[zflow-manager\] event=blocked pane=w1:g1' "$deliver_log" \
  && pass "one inject carried the queued event" || fail "inject missing; log=$(cat "$deliver_log")"
"$watch_script" unregister w1:g1 >/dev/null
rm -f "$status_dir/$super_pane.status" "$pending"
unset ZGPT_SUPER_PANE_ID
unset ZGPT_FAKE_DELIVER_LOG

printf '\n== register --registry: accepted inline and as leading flag ==\n'
reg3="$tmp/registry3.tsv"
"$watch_script" register w1:r1 --registry "$reg3" --workstream zflow >/dev/null
grep -q 'w1:r1' "$reg3" && pass "register --registry inline writes the given registry" || fail "register inline --registry: registry3=$(cat "$reg3" 2>/dev/null)"
"$watch_script" --registry "$reg3" unregister w1:r1 >/dev/null
grep -q 'w1:r1' "$reg3" && fail "unregister --registry (leading) did not remove" || pass "unregister --registry leading works"
"$watch_script" register w1:r2 --registry "$reg3" >/dev/null
"$watch_script" unregister --registry "$reg3" w1:r2 >/dev/null
grep -q 'w1:r2' "$reg3" && fail "unregister --registry (inline) did not remove" || pass "unregister --registry inline works"

printf '\n== once: pane gone => auto-unregister (event=gone, dropped, then silent) ==\n'
"$watch_script" register w1:p10 --workstream zflow >/dev/null
printf 'working\n' >"$status_dir/w1:p10.status"
out="$( "$watch_script" once )"
grep -q 'event=working pane=w1:p10' <<<"$out" && pass "gone-test: initial working delta" || fail "gone-test initial: $out"
touch "$status_dir/w1:p10.missing"   # simulate the pane being closed
out="$( "$watch_script" once )"
grep -q 'event=gone pane=w1:p10' <<<"$out" && pass "gone pane emits event=gone" || fail "event=gone missing: $out"
out="$( "$watch_script" list )"
grep -q 'w1:p10' <<<"$out" && fail "gone pane still registered" || pass "gone pane auto-unregistered"
out="$( "$watch_script" once )"
[[ -z "$out" ]] && pass "once after gone is silent" || fail "once after gone not silent: $out"
rm -f "$status_dir/w1:p10.missing"

printf '\n== once: gone is NOT delivered to super by default (log-only) ==\n'
: >"$deliver_log"
export ZGPT_FAKE_DELIVER_LOG="$deliver_log"
printf 'working\n' >"$status_dir/w1:p11.status"
"$watch_script" register w1:p11 --workstream zflow >/dev/null
"$watch_script" once >/dev/null   # consume the working baseline
touch "$status_dir/w1:p11.missing"
out="$( "$watch_script" once --deliver-to-pane "$super_pane" --deliver-settle 0 )"
grep -q 'event=gone pane=w1:p11' <<<"$out" && pass "gone still prints event=gone on stdout" || fail "gone event missing: $out"
if grep -q 'agent-prompt' "$deliver_log"; then
  fail "gone delivered to super by default"
else
  pass "gone not delivered to super by default"
fi
out="$( "$watch_script" list )"
grep -q 'w1:p11' <<<"$out" && fail "gone pane still registered" || pass "gone pane auto-unregistered"
rm -f "$status_dir/w1:p11.missing"
unset ZGPT_FAKE_DELIVER_LOG

printf '\n== once: --deliver-events idle_for_steer,blocked,gone delivers gone ==\n'
: >"$deliver_log"
export ZGPT_FAKE_DELIVER_LOG="$deliver_log"
printf 'working\n' >"$status_dir/w1:p15.status"
"$watch_script" register w1:p15 --workstream zflow >/dev/null
"$watch_script" once >/dev/null   # consume the working baseline
touch "$status_dir/w1:p15.missing"
out="$( "$watch_script" once --deliver-to-pane "$super_pane" --deliver-events idle_for_steer,blocked,gone --deliver-settle 0 )"
grep -q "delivered_to=$super_pane event=gone" <<<"$out" && pass "explicit gone delivers (delivered_to=)" || fail "explicit gone delivered_to missing: $out"
grep -q 'agent-prompt pane='"$super_pane"' text=\[zflow-manager\] event=gone pane=w1:p15' "$deliver_log" \
  && pass "explicit gone delivered via inject" || fail "explicit gone inject missing; log=$(cat "$deliver_log") out=$out"
rm -f "$status_dir/w1:p15.missing"
unset ZGPT_FAKE_DELIVER_LOG

printf '\n== super self-discovery: unique supermanager: pane enables deliver ==\n'
unset ZGPT_SUPER_PANE_ID ZFLOW_SUPER_PANE_ID
: >"$deliver_log"
export ZGPT_FAKE_DELIVER_LOG="$deliver_log"
cat >"$tmp/panes.tsv" <<'EOF'
w1:other	worker:some · repo@branch
w9:super	supermanager:fleet · multi-project
EOF
export ZGPT_FAKE_PANE_LIST="$tmp/panes.tsv"
art12="$tmp/a12.md"
printf 'idle\n' >"$status_dir/w1:p12.status"
printf 'status: DONE\n' >"$art12"
"$watch_script" register w1:p12 --workstream zflow --artifact "$art12" >/dev/null
out="$( "$watch_script" once --deliver-settle 0 )"
grep -q 'delivered_to=w9:super event=idle_for_steer' <<<"$out" \
  && pass "discovery finds the unique supermanager pane" || fail "discovery deliver: $out"
grep -q 'agent-prompt pane=w9:super' "$deliver_log" && pass "discovered super received the delivery" || fail "no deliver to discovered super; log=$(cat "$deliver_log")"
"$watch_script" unregister w1:p12 >/dev/null

printf '\n== super self-discovery: ambiguous (2 super panes) skips deliver with warn ==\n'
: >"$deliver_log"
cat >"$tmp/panes2.tsv" <<'EOF'
w1:superA	supermanager:alpha
w1:superB	supermanager:beta
EOF
export ZGPT_FAKE_PANE_LIST="$tmp/panes2.tsv"
printf 'idle\n' >"$status_dir/w1:p13.status"
"$watch_script" register w1:p13 --workstream zflow --artifact "$art12" >/dev/null
out="$( "$watch_script" once --deliver-settle 0 2>"$tmp/once.err" )"
grep -q '2 supermanager panes found' "$tmp/once.err" && pass "ambiguous discovery warns on stderr" || fail "ambiguous warn missing: $(cat "$tmp/once.err")"
grep -q 'agent-prompt' "$deliver_log" && fail "ambiguous discovery still delivered" || pass "ambiguous discovery skips deliver"
"$watch_script" unregister w1:p13 >/dev/null
unset ZGPT_FAKE_PANE_LIST

printf '\n== super self-discovery: no supermanager pane => no deliver, events still print ==\n'
cat >"$tmp/panes0.tsv" <<'EOF'
w1:worker1	worker:a · repo@branch
EOF
export ZGPT_FAKE_PANE_LIST="$tmp/panes0.tsv"
: >"$deliver_log"
export ZGPT_FAKE_DELIVER_LOG="$deliver_log"
printf 'blocked\n' >"$status_dir/w1:p14.status"
"$watch_script" register w1:p14 --workstream zflow >/dev/null
out="$( "$watch_script" once --deliver-settle 0 )"
grep -q 'event=blocked pane=w1:p14' <<<"$out" && pass "no super: event line still printed (delta contract)" || fail "no super event: $out"
grep -q 'agent-prompt' "$deliver_log" && fail "no super but delivered" || pass "no super => no deliver"
"$watch_script" unregister w1:p14 >/dev/null
unset ZGPT_FAKE_PANE_LIST ZGPT_FAKE_DELIVER_LOG

printf '\n== ensure-watch: no deliver target => watch=none ==\n'
unset ZGPT_SUPER_PANE_ID ZFLOW_SUPER_PANE_ID
out="$( "$watch_script" ensure-watch --registry "$reg3" )"
grep -q 'watch=none' <<<"$out" && pass "ensure-watch without a super => watch=none" || fail "watch=none: $out"

printf '\n== ensure-watch: starts a durable watcher, pidfile holds a live pid ==\n'
export ZGPT_SUPER_PANE_ID="$super_pane"
reg4="$tmp/registry4.tsv"
: >"$reg4"
out="$( "$watch_script" ensure-watch --registry "$reg4" )"
grep -q 'watch=started deliver_to='"$super_pane" <<<"$out" && pass "ensure-watch starts a durable watcher" || fail "watch=started: $out"
pidfile="$tmp/manager-watch.pid"   # dirname(registry4)
[[ -f "$pidfile" ]] && pass "ensure-watch writes the pidfile next to the registry" || fail "pidfile missing: $pidfile"
live_pid="$(head -n1 "$pidfile" 2>/dev/null | tr -d '[:space:]')"
[[ -n "$live_pid" ]] && kill -0 "$live_pid" 2>/dev/null && pass "pidfile holds a live watcher pid" || fail "watcher pid not alive: $live_pid"

printf '\n== ensure-watch: reuses a running watcher (watch=running) ==\n'
out="$( "$watch_script" ensure-watch --registry "$reg4" )"
grep -q 'watch=running deliver_to='"$super_pane" <<<"$out" && pass "ensure-watch reuses the running watcher" || fail "watch=running: $out"

# Cleanup the durable watcher so it does not outlive the suite.
[[ -n "$live_pid" ]] && kill "$live_pid" 2>/dev/null || true
rm -f "$pidfile"
unset ZGPT_SUPER_PANE_ID

printf '\n== help documents deliver flags ==\n'
help_out="$( "$watch_script" --help )"
grep -q -- '--deliver-to-pane' <<<"$help_out" && pass "help documents --deliver-to-pane" || fail "help missing --deliver-to-pane"
grep -q -- '--deliver-events' <<<"$help_out" && pass "help documents --deliver-events" || fail "help missing --deliver-events"
grep -q -- 'ensure-watch' <<<"$help_out" && pass "help documents ensure-watch" || fail "help missing ensure-watch"

printf '\nSummary: %d/%d passed\n' "$passed" "$((passed + failed))"
((failed == 0))
