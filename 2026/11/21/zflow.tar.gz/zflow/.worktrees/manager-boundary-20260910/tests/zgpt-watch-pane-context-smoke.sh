#!/usr/bin/env bash
set -euo pipefail

# Context-exhaustion detection: a worker that fills its window keeps streaming
# tokens and prints no marker, so it must be caught from the CLI status line in
# the visible region rather than from the new-lines diff.

script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")/../scripts" && pwd)"
watcher="$script_dir/zgpt-watch-pane.sh"
tmp="$(mktemp -d "${TMPDIR:-/tmp}/zgpt-watch-context.XXXXXX")"
trap 'rm -rf "$tmp"' EXIT
bin="$tmp/bin"
mkdir -p "$bin"
printf '0\n' >"$tmp/read.count"

cat >"$bin/herdr" <<'STUB'
#!/usr/bin/env bash
set -euo pipefail
if [[ "${1:-}" == --session ]]; then shift 2; fi
case "${1:-} ${2:-}" in
  "session list") printf '{"sessions":[{"name":"test-session","running":true}]}\n' ;;
  "pane get") exit 0 ;;
  "pane read")
    source=""
    for ((i=1; i<=$#; i++)); do
      if [[ "${!i:-}" == "--source" ]]; then
        j=$((i + 1)); source="${!j:-}"; break
      fi
    done
    n="$(cat "$ZGPT_READ_COUNT")"; n=$((n + 1)); printf '%s\n' "$n" >"$ZGPT_READ_COUNT"
    if [[ "$source" == "visible" ]]; then
      # The status line is redrawn in place: it appears only in the visible
      # region, never as appended output.
      printf 'Searching for 1 pattern... (ctrl+o to expand)\n'
      [[ "${ZGPT_FAKE_CONTEXT_FULL:-false}" == true ]] && printf '%s\n' "${ZGPT_FAKE_STATUS_LINE:-100% context used}"
    else
      # Still streaming tokens each poll: every other detector reads this as healthy.
      printf 'Puzzling... (%dm · down 13.%dk tokens)\n' "$n" "$n"
      [[ "${ZGPT_FAKE_DONE_MARKER:-false}" == true ]] && printf 'WORKER_DONE:ctx\n'
    fi
    :
    ;;
  "agent get")
    printf '{"result":{"agent":{"pane_id":"w1:p1","agent_status":"working"}}}\n'
    ;;
  *) exit 1 ;;
esac
STUB
chmod +x "$bin/herdr"

run_case() {
  local label="$1"; shift
  local out_file="$tmp/$label.out"
  printf '0\n' >"$tmp/read.count"
  set +e
  PATH="$bin:$PATH" ZGPT_READ_COUNT="$tmp/read.count" "$@" \
    "$watcher" --session test-session --pane-id w1:p1 \
    --log "$tmp/$label.ndjson" --scrollback 0 >"$out_file" 2>&1
  rc=$?
  set -e
  cat "$out_file"
  return "$rc"
}

# 1. Status line reporting a spent window is terminal, with a distinct exit code.
set +e
ctx_out="$(run_case context-full env ZGPT_FAKE_CONTEXT_FULL=true)"
ctx_rc=$?
set -e
printf '%s\n' "$ctx_out" | grep -q '^state=context_exhausted reason=context-window-full$'
[[ "$ctx_rc" == 2 ]] || { printf 'expected exit 2, got %s\n' "$ctx_rc" >&2; exit 1; }

# 2. The auto-compact wording is caught by the same default regex.
set +e
compact_out="$(run_case compact-zero env ZGPT_FAKE_CONTEXT_FULL=true \
  ZGPT_FAKE_STATUS_LINE='Context left until auto-compact: 0%')"
compact_rc=$?
set -e
printf '%s\n' "$compact_out" | grep -q '^state=context_exhausted reason=context-window-full$'
[[ "$compact_rc" == 2 ]]

# 3. A healthy worker streaming output is not misread as exhausted.
healthy_file="$tmp/healthy.out"
printf '0\n' >"$tmp/read.count"
PATH="$bin:$PATH" ZGPT_READ_COUNT="$tmp/read.count" \
  "$watcher" --session test-session --pane-id w1:p1 --log "$tmp/healthy.ndjson" \
  --scrollback 0 --keep-watching >"$healthy_file" 2>&1 &
watch_pid=$!
sleep 5
kill "$watch_pid" 2>/dev/null || true
wait "$watch_pid" 2>/dev/null || true
grep -q '^state=running reason=working$' "$healthy_file"
! grep -q 'context_exhausted' "$healthy_file"

# 4. --no-context-check disables detection even with the status line present.
off_file="$tmp/off.out"
printf '0\n' >"$tmp/read.count"
PATH="$bin:$PATH" ZGPT_READ_COUNT="$tmp/read.count" ZGPT_FAKE_CONTEXT_FULL=true \
  "$watcher" --session test-session --pane-id w1:p1 --log "$tmp/off.ndjson" \
  --scrollback 0 --keep-watching --no-context-check >"$off_file" 2>&1 &
watch_pid=$!
sleep 5
kill "$watch_pid" 2>/dev/null || true
wait "$watch_pid" 2>/dev/null || true
! grep -q 'context_exhausted' "$off_file"

# 5. A worker that finished on its last breath is done, not exhausted:
#    the marker outranks the status line.
set +e
done_out="$(run_case done-wins env ZGPT_FAKE_CONTEXT_FULL=true ZGPT_FAKE_DONE_MARKER=true)"
done_rc=$?
set -e
printf '%s\n' "$done_out" | grep -q '^state=done reason=WORKER_DONE:$'
[[ "$done_rc" == 0 ]]

printf 'watch context smoke ok\n'
