#!/usr/bin/env bash
# zgpt-superboard-steer-smoke.sh — offline fixture tests for the fleet survey
# (zgpt-superboard.sh) and the decision injector (zgpt-steer.sh).
#
# Stubs `herdr` on PATH so no live server is needed: pane list / pane read /
# pane get / pane send-text / pane send-keys are all faked. Exits non-zero on
# any failure; prints an N/M summary.
set -euo pipefail

script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")/../scripts" && pwd)"
superboard="$script_dir/zgpt-superboard.sh"
steer="$script_dir/zgpt-steer.sh"
tmp="$(mktemp -d "${TMPDIR:-/tmp}/zgpt-superboard.XXXXXX")"
trap 'rm -rf "$tmp"' EXIT

bin="$tmp/bin"
tails="$tmp/tails"
mkdir -p "$bin" "$tails"

# Fixture tails, one file per pane id.
printf 'thinking...\nCogitated for 1m\n\n要我按这个方案推进吗？\n' >"$tails/w1:p1.txt"
printf 'working...\n' >"$tails/w1:p2.txt"

cat >"$bin/herdr" <<'STUB'
#!/usr/bin/env bash
set -euo pipefail
cmd="${1:-}"; shift || true
case "$cmd" in
  "pane")
    sub="${1:-}"; shift || true
    case "$sub" in
      list)
        printf '%s\n' "$ZGPT_FAKE_PANE_LIST"
        ;;
      read)
        pane="${1:-}"; shift || true
        while [[ $# -gt 0 ]]; do
          [[ "${1:-}" == "--lines" || "${1:-}" == "--source" ]] && { shift; shift; continue; }
          shift
        done
        if [[ -f "$ZGPT_TAIL_DIR/$pane.txt" ]]; then
          cat "$ZGPT_TAIL_DIR/$pane.txt"
        fi
        ;;
      get)
        pane="${1:-}"; shift || true
        case "$pane" in
          nope:p0) exit 1 ;;
          *) printf '{"result":{"agent":{"agent_status":"idle"}}}\n' ;;
        esac
        ;;
      send-text)
        printf 'send-text %s %s\n' "$1" "${2:-}" >>"$ZGPT_SENT_LOG"
        ;;
      send-keys)
        printf 'send-keys %s\n' "${1:-}" >>"$ZGPT_SENT_LOG"
        ;;
    esac
    ;;
  "agent")
    sub="${1:-}"; shift || true
    case "$sub" in
      prompt)
        if [[ "${1:-}" == "--help" ]]; then
          printf 'usage: herdr agent prompt TARGET TEXT [--wait] [--timeout MS]\n'
          exit 0
        fi
        printf 'agent-prompt %s\n' "${1:-}" >>"$ZGPT_AGENT_LOG"
        case "${ZGPT_FAKE_PROMPT_MODE:-success}" in
          definitive)
            printf 'error: agent_not_detected\n' >&2
            exit 1
            ;;
          *) printf '{"result":{"ok":true}}\n' ;;
        esac
        ;;
      *) exit 1 ;;
    esac
    ;;
esac
STUB
chmod +x "$bin/herdr"
export PATH="$bin:$PATH"
export ZGPT_TAIL_DIR="$tails"
export ZGPT_AGENT_LOG="$tmp/agent.log"

ZGPT_FAKE_PANE_LIST="$(
  jq -nc '{result:{panes:[
    {pane_id:"w1:p1",tab_id:"w1:t1",agent:"claude",agent_status:"idle",terminal_title_stripped:"Review X",foreground_cwd:"/da1/wen/git/yg/yg-aio"},
    {pane_id:"w1:p2",tab_id:"w1:t1",agent:"claude",agent_status:"working",terminal_title_stripped:"Implement Y",foreground_cwd:"/da1/wen/git/yg/yg-aio"},
    {pane_id:"w1:p3",tab_id:"w1:t2",agent:null,agent_status:"unknown",terminal_title_stripped:"shell",foreground_cwd:"/da1/wen/git/yg/yg-aio"}
  ]}}'
)"
export ZGPT_FAKE_PANE_LIST

pass=0; fail=0; fails=()
ok() { pass=$((pass + 1)); printf '  ok: %s\n' "$1"; }
bad() { fail=$((fail + 1)); fails+=("$1"); printf '  FAIL: %s\n' "$1"; }

echo "== superboard: agent panes only =="
code=0
out="$("$superboard" --lines 60 2>&1)" || code=$?
grep -q 'w1:p1.*needs_human' <<<"$out" && ok "p1 classified needs_human (trailing ?)" || bad "p1 not needs_human: $out"
grep -q 'w1:p2.*working' <<<"$out" && ok "p2 classified working" || bad "p2 not working: $out"
if grep -q 'w1:p3' <<<"$out"; then bad "shell pane shown without --all"; else ok "shell pane hidden without --all"; fi
[[ "$code" == 2 ]] && ok "exit 2 when an agent needs human" || bad "expected exit 2, got $code"

echo "== superboard: grouped by tab (workstream) =="
grep -q '\[w1:t1\]' <<<"$out" && ok "table prints a tab group header for w1:t1" || bad "missing [w1:t1] group header: $out"
w1t1_line="$(grep -n 'w1:p1' <<<"$out" | head -1 | cut -d: -f1)"
header_line="$(grep -n '\[w1:t1\]' <<<"$out" | head -1 | cut -d: -f1)"
[[ -n "$w1t1_line" && -n "$header_line" && "$w1t1_line" -gt "$header_line" ]] \
  && ok "pane rows sort under their tab header" || bad "pane row before/without tab header"

echo "== superboard: --json carries the tab field =="
jout="$("$superboard" --json --lines 60)"
jq -e '.[] | select(.id=="w1:p1" and .state=="needs_human" and .tab=="w1:t1")' <<<"$jout" >/dev/null \
  && ok "json p1 needs_human with tab" || bad "json p1 wrong: $jout"

echo "== superboard: --all includes shells =="
aout="$("$superboard" --all --lines 60 2>/dev/null)" || true
grep -q 'w1:p3.*shell' <<<"$aout" && ok "--all shows shell pane" || bad "--all missing shell"

echo "== superboard: --min-working alarm =="
mcode=0
"$superboard" --min-working 5 --lines 60 >/dev/null 2>&1 || mcode=$?
[[ "$mcode" == 3 ]] && ok "exit 3 below min-working" || bad "expected exit 3, got $mcode"

echo "== steer: prefers agent prompt on a detected pane =="
export ZGPT_SENT_LOG="$tmp/sent.log"
: >"$ZGPT_SENT_LOG"; : >"$ZGPT_AGENT_LOG"
export ZGPT_FAKE_PROMPT_MODE=success
"$steer" -p w1:p1 "continue" >/dev/null
grep -q '^agent-prompt w1:p1$' "$ZGPT_AGENT_LOG" && ok "steer used agent prompt" || bad "no agent prompt: $(cat "$ZGPT_AGENT_LOG")"
[[ ! -s "$ZGPT_SENT_LOG" ]] && ok "no pane dance when agent prompt succeeds" || bad "unexpected pane dance: $(cat "$ZGPT_SENT_LOG")"

echo "== steer: falls back and double-enters on long message when prompt fails =="
: >"$ZGPT_SENT_LOG"; : >"$ZGPT_AGENT_LOG"
export ZGPT_FAKE_PROMPT_MODE=definitive
long_msg="这是一条超过八十字符的长消息，用来触发 double-enter 分支，因为消息很长需要第二次回车确认粘贴完成避免丢失内容。ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
[[ "${#long_msg}" -ge 80 ]] || bad "fixture long_msg only ${#long_msg} chars (need >=80)"
"$steer" -p w1:p1 "$long_msg" >/dev/null
grep -q '^send-text w1:p1 ' "$ZGPT_SENT_LOG" && ok "steer fell back to send-text" || bad "steer did not send-text"
[[ "$(grep -c '^send-keys' "$ZGPT_SENT_LOG")" -ge 2 ]] && ok "steer double-entered on long message" \
  || bad "expected >=2 send-keys: $(cat "$ZGPT_SENT_LOG")"

echo "== steer: single enter on short message in fallback =="
: >"$ZGPT_SENT_LOG"; : >"$ZGPT_AGENT_LOG"
"$steer" -p w1:p1 "continue" >/dev/null
[[ "$(grep -c '^send-keys' "$ZGPT_SENT_LOG")" == 1 ]] && ok "steer single-enter on short message" \
  || bad "expected 1 send-keys: $(cat "$ZGPT_SENT_LOG")"

echo "== steer: missing pane fails =="
if "$steer" -p nope:p0 "x" >/dev/null 2>&1; then
  bad "steer accepted a missing pane"
else
  ok "steer rejects missing pane"
fi

printf '\nSummary: %d/%d passed\n' "$pass" "$((pass + fail))"
[[ ${#fails[@]} -eq 0 ]] || { printf 'Failed: %s\n' "${fails[@]}"; exit 1; }
