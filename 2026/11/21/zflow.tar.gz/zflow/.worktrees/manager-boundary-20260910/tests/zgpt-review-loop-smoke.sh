#!/usr/bin/env bash
set -euo pipefail

scripts="$(cd "$(dirname "${BASH_SOURCE[0]}")/../scripts" && pwd)"
glab_mr="$scripts/zgpt-glab-mr.sh"
loop="$scripts/zgpt-review-loop.sh"
tmp="$(mktemp -d "${TMPDIR:-/tmp}/zgpt-review-loop-smoke.XXXXXX")"
trap '[[ -n "${KEEP_ZGPT_SMOKE_TMP:-}" ]] || rm -rf "$tmp"' EXIT

passed=0
failed=0
pass() { printf 'PASS: %s\n' "$1"; passed=$((passed + 1)); }
fail() { printf 'FAIL: %s\n' "$1" >&2; failed=$((failed + 1)); }
assert_contains() { if grep -q -- "$2" <<< "$1"; then pass "$3"; else fail "$3"; fi; }
assert_eq() { if [[ "$1" == "$2" ]]; then pass "$3"; else fail "$3 (got=$1 expected=$2)"; fi; }

bin="$tmp/bin"
mkdir -p "$bin"
fake_glab="$bin/glab"
cat > "$fake_glab" <<'FAKE'
#!/usr/bin/env bash
set -euo pipefail
[[ -n "${FAKE_GLAB_LOG:-}" ]] && printf '%q ' "$@" >> "$FAKE_GLAB_LOG" && printf '\n' >> "$FAKE_GLAB_LOG"
if [[ "${1:-}" == mr && "${2:-}" == create ]]; then
    for arg in "$@"; do
        [[ "$arg" == --hostname || "$arg" == -H ]] && {
            printf '%s\n' 'error: use GITLAB_HOST for glab mr commands' >&2
            exit 2
        }
    done
    [[ -n "${GITLAB_HOST:-}" ]] && printf 'GITLAB_HOST=%s\n' "$GITLAB_HOST" >> "${FAKE_GLAB_LOG:-/dev/null}"
    printf '%s\n' "${FAKE_MR_URL:-https://git-biz.qianxin-inc.cn/group/repo/-/merge_requests/42}"
    exit 0
fi
if [[ "${1:-}" == mr && "${2:-}" == view ]]; then
    for arg in "$@"; do
        [[ "$arg" == --hostname || "$arg" == -H ]] && {
            printf '%s\n' 'error: use GITLAB_HOST for glab mr commands' >&2
            exit 2
        }
    done
    [[ -n "${GITLAB_HOST:-}" ]] && printf 'GITLAB_HOST=%s\n' "$GITLAB_HOST" >> "${FAKE_GLAB_LOG:-/dev/null}"
    jq -cn --arg state "${ZGPT_FAKE_MR_STATE:-opened}" \
        '{state:$state,source_branch:"feature-x",target_branch:"main"}'
    exit 0
fi
if [[ "${1:-}" != api ]]; then exit 0; fi
path=''
is_post=false
for arg in "$@"; do
    [[ "$arg" == projects/* ]] && path="$arg"
    [[ "$arg" == POST ]] && is_post=true
done
if [[ "$is_post" == true ]]; then
    [[ -n "${FAKE_POST_FAIL:-}" ]] && { printf 'post failed\n' >&2; exit 9; }
    printf '{"id":999}\n'
    exit 0
fi
case "$path" in
    */notes\?*)
        [[ "${FAKE_API_FAIL:-}" == notes ]] && { printf 'notes failed\n' >&2; exit 7; }
        if [[ -n "${FAKE_API_PAGES:-}" && "$path" == *'page=1' ]]; then
            jq -cn '[range(0;100) | {id:.,body:"system",system:true,author:{username:"gitlab"}}]'
        elif [[ -n "${FAKE_API_PAGES:-}" ]]; then printf '[]\n'
        elif [[ -n "${ZGPT_FAKE_NOTES_FILE:-}" ]]; then cat "$ZGPT_FAKE_NOTES_FILE"
        else printf '[]\n'; fi ;;
    */discussions*)
        [[ "${FAKE_API_FAIL:-}" == discussions ]] && { printf 'discussions failed\n' >&2; exit 8; }
        if [[ -n "${FAKE_API_PAGES:-}" && "$path" == *'page=1' ]]; then
            jq -cn '[range(0;100) | {id:("d"+tostring),notes:[{id:.,body:"system",system:true,author:{username:"gitlab"}}]}]'
        elif [[ -n "${FAKE_API_PAGES:-}" ]]; then printf '[]\n'
        elif [[ -n "${ZGPT_FAKE_DISCUSSIONS_FILE:-}" ]]; then cat "$ZGPT_FAKE_DISCUSSIONS_FILE"
        else printf '[]\n'; fi ;;
    */approvals)
        [[ "${FAKE_API_FAIL:-}" == approvals ]] && { printf 'approvals failed\n' >&2; exit 6; }
        if [[ -n "${ZGPT_FAKE_APPROVALS_FILE:-}" ]]; then cat "$ZGPT_FAKE_APPROVALS_FILE"
        else printf '{"approved":false}\n'; fi ;;
    */merge_requests/*)
        jq -cn --arg state "${ZGPT_FAKE_MR_STATE:-opened}" \
            --arg source "${ZGPT_FAKE_SOURCE_BRANCH:-feature-x}" \
            '{state:$state,source_branch:$source,source_project_id:1}' ;;
    *) printf '{}\n' ;;
esac
FAKE
chmod +x "$fake_glab"

notes="$tmp/notes.json"
discussions="$tmp/discussions.json"
approvals="$tmp/approvals.json"
posts="$tmp/posts.log"
printf '[]\n' > "$notes"
printf '[]\n' > "$discussions"
printf '{"approved":false}\n' > "$approvals"
: > "$posts"

export ZGPT_GLAB_CMD="$fake_glab"
export ZGPT_FAKE_NOTES_FILE="$notes"
export ZGPT_FAKE_DISCUSSIONS_FILE="$discussions"
export ZGPT_FAKE_APPROVALS_FILE="$approvals"
export ZGPT_FAKE_POST_LOG="$posts"
export ZGPT_FAKE_RUN_WORKER=1
export ZGPT_FAKE_MR_STATE=opened
export ZGPT_FAKE_SLEEP=1
export ZGPT_REVIEW_LOOP_MAX_POLLS=1
export ZGPT_REVIEW_LOOP_MAX_RUNTIME=3600
export ZGPT_REVIEW_LOOP_SELF_USERNAME=zflow-user
export ZGPT_REVIEW_LOOP_LAUNCH_BACKEND=background
export ZGPT_REVIEW_LOOP_ALLOW_PUSH=true
export ZGPT_REVIEW_LOOP_TRUSTED_REVIEWERS=reviewer
export FAKE_GLAB_LOG="$tmp/glab.log"

mr='https://git-biz.qianxin-inc.cn/group/repo/-/merge_requests/42'
identity='git-biz.qianxin-inc.cn_group_repo_mr42'

wait_status() {
    local state_root="$1" wanted="$2" remaining=100 file
    file="$state_root/review-loops/$identity/status"
    while ((remaining > 0)); do
        [[ -f "$file" && "$(cat "$file")" == "$wanted" ]] && return 0
        sleep 0.02
        remaining=$((remaining - 1))
    done
    printf 'last status: %s\n' "$(cat "$file" 2>/dev/null || echo missing)" >&2
    return 1
}

assert_status() {
    if wait_status "$1" "$2"; then pass "$3"; else fail "$3"; fi
}

run_once() {
    local state_root="$1"
    ZGPT_STATE_DIR_OVERRIDE="$state_root" "$loop" start "$mr" --cwd "$tmp" >/dev/null
    wait_status "$state_root" poll_limit
}

printf '\n== URL parsing ==\n'
parsed="$($glab_mr parse-url "$mr#note_3")"
assert_contains "$parsed" '^project_path=group/repo$' 'parses project path'
assert_contains "$parsed" '^mr_iid=42$' 'parses IID'

subgroup_mr='https://git-biz.qianxin-inc.cn/group/subgroup/repo/-/merge_requests/987?tab=diffs#note_3'
parsed="$($glab_mr parse-url "$subgroup_mr")"
assert_contains "$parsed" '^host=https://git-biz.qianxin-inc.cn$' 'parses internal host'
assert_contains "$parsed" '^project_path=group/subgroup/repo$' 'parses nested project path with query and fragment'
assert_contains "$parsed" '^mr_iid=987$' 'parses IID before query string'

legacy_mr='http://git-biz.qianxin-inc.cn/group/repo/merge_requests/7'
parsed="$($glab_mr parse-url "$legacy_mr")"
assert_contains "$parsed" '^host=http://git-biz.qianxin-inc.cn$' 'parses legacy http host'
assert_contains "$parsed" '^project_path=group/repo$' 'parses legacy project path'
assert_contains "$parsed" '^mr_iid=7$' 'parses legacy IID'

fake_sed="$bin/sed"
cat > "$fake_sed" <<'SED'
#!/usr/bin/env bash
printf 'sed must not be required for parse-url\n' >&2
exit 99
SED
chmod +x "$fake_sed"
parsed="$(PATH="$bin:$PATH" "$glab_mr" parse-url "$mr")"
assert_contains "$parsed" '^mr_iid=42$' 'parse-url does not depend on GNU/BSD sed behavior'
rm -f "$fake_sed"
if ! "$glab_mr" parse-url 'not-a-url' >/dev/null 2>&1; then pass 'rejects invalid URL'; else fail 'rejects invalid URL'; fi
if ! "$glab_mr" parse-url 'https://github.com/group/repo/pull/42' >/dev/null 2>&1; then pass 'rejects GitHub'; else fail 'rejects GitHub'; fi
if ! "$glab_mr" parse-url 'https://gitlab.example.com/group/repo/-/merge_requests/42' >/dev/null 2>&1; then pass 'rejects other GitLab hosts'; else fail 'rejects other GitLab hosts'; fi
if ! "$glab_mr" parse-url 'https://user@git-biz.qianxin-inc.cn/group/repo/-/merge_requests/42' >/dev/null 2>&1; then pass 'rejects URL userinfo'; else fail 'rejects URL userinfo'; fi

printf '\n== Defaults ==\n'
config="$(env -u ZGPT_REVIEW_LOOP_MAX_RUNTIME -u ZGPT_REVIEW_LOOP_MAX_POLLS \
    -u ZGPT_REVIEW_LOOP_TRUSTED_REVIEWERS -u ZGPT_REVIEW_LOOP_ALLOW_PUSH "$loop" config)"
assert_contains "$config" '^poll_interval=60$' 'defaults to 60-second polling'
assert_contains "$config" '^max_runtime=900$' 'defaults to 15-minute observation window'
assert_contains "$config" '^max_attempts=3$' 'defaults to 3 attempts per item'
assert_contains "$config" '^trusted_reviewers=$' 'defaults to no trusted reviewers'
assert_contains "$config" '^allow_push=false$' 'defaults to push disabled'


printf '\n== Production launch uses pane helper by default ==\n'
fake_pane="$bin/fake-pane-helper"
cat > "$fake_pane" <<'PANE'
#!/usr/bin/env bash
printf '%s\n' "$*" > "${ZGPT_FAKE_PANE_CALL:?}"
printf 'pane_id=w1:p-review\n'
PANE
chmod +x "$fake_pane"
state="$tmp/state-pane-default"
pane_call="$tmp/pane-call.log"
ZGPT_REVIEW_LOOP_LAUNCH_BACKEND=herdr \
ZGPT_WORKER_PANE_CMD="$fake_pane" \
ZGPT_FAKE_PANE_CALL="$pane_call" \
ZGPT_STATE_DIR_OVERRIDE="$state" \
    "$loop" start "$mr" --cwd "$tmp" --name visible-supervisor --command worker-cmd >/dev/null
if grep -q -- '--mode print' "$pane_call" && grep -q -- '--command-arg supervise' "$pane_call"; then
    pass 'default production launch calls pane helper for supervise'
else
    fail 'default production launch calls pane helper for supervise'
fi
assert_contains "$(cat "$pane_call")" '--command-arg --trusted-reviewers --command-arg reviewer' 'forwards trusted reviewers to visible supervisor'
assert_contains "$(cat "$pane_call")" '--command-arg --allow-push --command-arg true' 'forwards push authorization to visible supervisor'
assert_eq "$(cat "$state/review-loops/$identity/supervisor.pane")" 'w1:p-review' 'records supervisor pane identity'

printf '\n== Create wrapper and auto-start ==\n'
state="$tmp/state-create"
: > "$FAKE_GLAB_LOG"
output="$(ZGPT_STATE_DIR_OVERRIDE="$state" "$glab_mr" create --repo group/repo --title hello --draft --cwd "$tmp")"
assert_contains "$output" '^status=started$' 'create auto-starts supervisor'
assert_contains "$output" '^supervisor_pid=[0-9]' 'create returns supervisor PID'
assert_contains "$(cat "$FAKE_GLAB_LOG")" 'GITLAB_HOST=git-biz.qianxin-inc.cn' 'sets GITLAB_HOST for mr commands'
assert_contains "$(cat "$FAKE_GLAB_LOG")" 'mr create.*--repo group/repo' 'uses --repo and forwards create arguments'
if ! grep -q 'mr create.*--hostname' "$FAKE_GLAB_LOG"; then pass 'mr create omits unsupported --hostname'; else fail 'mr create omits unsupported --hostname'; fi
assert_contains "$(cat "$FAKE_GLAB_LOG")" 'mr view.*-R group/repo 42' 'mr view uses project path and IID'
assert_status "$state" poll_limit 'auto-started supervisor completed'

no_review="$(ZGPT_GLAB_MR_FAKE_URL="$mr" "$glab_mr" create --no-review)"
if ! grep -q '^supervisor_pid=' <<< "$no_review"; then pass '--no-review skips loop'; else fail '--no-review skips loop'; fi

printf '\n== PID dedupe and stop cleanup ==\n'
state="$tmp/state-dedupe"
unset ZGPT_FAKE_SLEEP
export ZGPT_REVIEW_LOOP_POLL_INTERVAL=30
export ZGPT_REVIEW_LOOP_MAX_POLLS=0
first="$(ZGPT_STATE_DIR_OVERRIDE="$state" "$loop" start "$mr" --cwd "$tmp")"
second="$(ZGPT_STATE_DIR_OVERRIDE="$state" "$loop" start "$mr" --cwd "$tmp")"
assert_contains "$first" '^status=started$' 'first loop starts'
assert_contains "$second" '^status=already_active$' 'second loop is deduplicated'
pid="$(sed -n 's/^supervisor_pid=//p' <<< "$first")"
kill -HUP "$pid"
sleep 0.05
if kill -0 "$pid" 2>/dev/null; then pass 'supervisor survives parent HUP'; else fail 'supervisor survives parent HUP'; fi
child=''
for _ in $(seq 1 100); do
    child="$(ps -axo pid=,ppid= | awk -v ppid="$pid" '$2 == ppid {print $1; exit}')"
    [[ -n "$child" ]] && break
    sleep 0.02
done
if [[ "$child" =~ ^[0-9]+$ ]]; then pass 'supervisor has a descendant to clean up'; else fail 'supervisor has a descendant to clean up'; fi
ZGPT_FAKE_SLEEP=1 ZGPT_STATE_DIR_OVERRIDE="$state" "$loop" stop "$mr" >/dev/null
for _ in $(seq 1 100); do
    if ! kill -0 "$pid" 2>/dev/null && { [[ -z "$child" ]] || ! kill -0 "$child" 2>/dev/null; }; then break; fi
    sleep 0.02
done
if ! kill -0 "$pid" 2>/dev/null && { [[ -z "$child" ]] || ! kill -0 "$child" 2>/dev/null; } && [[ ! -d "$state/review-loops/$identity/lock" ]]; then
    pass 'stop terminates supervisor children and removes lock'
else fail 'stop terminates supervisor children and removes lock'; fi
export ZGPT_FAKE_SLEEP=1 ZGPT_REVIEW_LOOP_MAX_POLLS=1
unset ZGPT_REVIEW_LOOP_POLL_INTERVAL

printf '\n== Per-item attempts and follow-up gating ==\n'
state="$tmp/state-attempts"
jq -cn '[{id:"thread-a",notes:[{id:101,body:"fix the nil check",system:false,author:{username:"reviewer"},position:{new_path:"main.go",new_line:9}}]}]' > "$discussions"
jq -cn '[{id:101,body:"fix the nil check",system:false,author:{username:"reviewer"},position:{new_path:"main.go",new_line:9}}]' > "$notes"
run_once "$state"
assert_eq "$(jq -r '.["thread-a"]' "$state/review-loops/$identity/attempts.json")" 1 'first review consumes attempt 1'
assert_eq "$(jq -r '.["101"] // 0' "$state/review-loops/$identity/attempts.json")" 0 'discussion note duplicated by flat notes is processed once'
run_once "$state"
assert_eq "$(jq -r '.["thread-a"]' "$state/review-loops/$identity/attempts.json")" 1 'unchanged review does not consume another attempt'
jq '.[0].notes += [{id:102,body:"still broken",system:false,author:{username:"reviewer"},position:{new_path:"main.go",new_line:9}}]' "$discussions" > "$discussions.tmp" && mv "$discussions.tmp" "$discussions"
run_once "$state"
assert_eq "$(jq -r '.["thread-a"]' "$state/review-loops/$identity/attempts.json")" 2 'same-thread follow-up consumes attempt 2'
jq '.[0].notes += [{id:103,body:"edge case remains",system:false,author:{username:"reviewer"}}]' "$discussions" > "$discussions.tmp" && mv "$discussions.tmp" "$discussions"
run_once "$state"
assert_eq "$(jq -r '.["thread-a"]' "$state/review-loops/$identity/attempts.json")" 3 'same-thread follow-up consumes attempt 3'
jq '.[0].notes += [{id:104,body:"still not fixed",system:false,author:{username:"reviewer"}}] |
    . += [{id:"thread-b",notes:[{id:201,body:"another issue",system:false,author:{username:"reviewer"}}]}]' \
    "$discussions" > "$discussions.tmp" && mv "$discussions.tmp" "$discussions"
run_once "$state"
assert_eq "$(jq -r '.["thread-a"]' "$state/review-loops/$identity/attempts.json")" 3 'fourth same-item report is capped'
assert_eq "$(jq -r '.["thread-b"]' "$state/review-loops/$identity/attempts.json")" 1 'different item has independent attempts'
assert_contains "$(cat "$posts")" 'Fix submitted.*thread-a' 'posts fix action to MR'
assert_contains "$(cat "$posts")" 'Manual review required.*thread-a' 'posts cap status to MR'

printf '\n== Observation window does not bound an in-flight worker ==\n'
state="$tmp/state-worker-past-window"
time_file="$tmp/fake-time"
printf '100\n' > "$time_file"
printf '[]\n' > "$notes"
jq -cn '[{id:"long-fix",notes:[{id:240,body:"apply a long fix",system:false,author:{username:"reviewer"}}]}]' > "$discussions"
: > "$posts"
ZGPT_FAKE_TIME_FILE="$time_file" \
ZGPT_FAKE_WORKER_ADVANCE_TIME_TO=1000 \
ZGPT_REVIEW_LOOP_MAX_RUNTIME=900 \
ZGPT_REVIEW_LOOP_MAX_POLLS=0 \
ZGPT_STATE_DIR_OVERRIDE="$state" "$loop" start "$mr" --cwd "$tmp" >/dev/null
assert_status "$state" timeout 'watcher waits for in-flight worker before ending observation'
assert_eq "$(jq -r '.["long-fix"]' "$state/review-loops/$identity/attempts.json")" 1 'worker finishing after observation deadline records its attempt'
assert_contains "$(cat "$posts")" 'Fix submitted.*long-fix' 'worker action is posted before watcher stops'

printf '\n== git-biz origin enforcement ==\n'
fake_worker="$bin/fake-worker"
cat > "$fake_worker" <<'WORKER'
#!/usr/bin/env bash
set -euo pipefail
artifact=''
while (($#)); do
    case "$1" in
        --artifact) artifact="${2:?}"; shift 2 ;;
        *) shift ;;
    esac
done
[[ -n "$artifact" ]] || { printf 'missing --artifact\n' >&2; exit 2; }
printf 'schema=zflow.review_loop.worker_result.v1\nstatus=fixed\ncommit_sha=0000000000000000000000000000000000000abc\n' > "$artifact"
printf 'status=ok\nartifact=%s\n' "$artifact"
exit 7
WORKER
chmod +x "$fake_worker"
jq -cn '[{id:"origin-check",notes:[{id:250,body:"fix origin check",system:false,author:{username:"reviewer"}}]}]' > "$discussions"
printf '[]\n' > "$notes"
internal_repo="$tmp/internal-repo"; git -C "$tmp" init -q -b feature-x "$internal_repo"
git -C "$internal_repo" remote add origin 'git@git-biz:group/repo.git'
state="$tmp/state-internal-origin"
env -u ZGPT_FAKE_RUN_WORKER ZGPT_FAKE_SKIP_COMMIT_VERIFY=1 ZGPT_REVIEW_LOOP_ALLOW_PUSH=true ZGPT_RUN_WORKER_CMD="$fake_worker" ZGPT_STATE_DIR_OVERRIDE="$state" \
    "$loop" start "$mr" --cwd "$internal_repo" >/dev/null
assert_status "$state" poll_limit 'accepts git-biz SSH key/alias origin'
assert_contains "$(cat "$posts")" 'Fix submitted' 'worker fix is submitted with commit SHA'
external_repo="$tmp/external-repo"; git -C "$tmp" init -q -b feature-x "$external_repo"
git -C "$external_repo" remote add origin 'git@github.com:group/repo.git'
state="$tmp/state-external-origin"
env -u ZGPT_FAKE_RUN_WORKER ZGPT_REVIEW_LOOP_ALLOW_PUSH=true ZGPT_RUN_WORKER_CMD="$fake_worker" ZGPT_STATE_DIR_OVERRIDE="$state" \
    "$loop" start "$mr" --cwd "$external_repo" >/dev/null
assert_status "$state" blocked_fix 'rejects GitHub origin before fixing'

printf '\n== Push authorization gate ==\n'
jq -cn '[{id:"push-gate",notes:[{id:290,body:"fix this",system:false,author:{username:"reviewer"}}]}]' > "$discussions"
printf '[]\n' > "$notes"; : > "$posts"
state="$tmp/state-push-gate"
env -u ZGPT_FAKE_RUN_WORKER ZGPT_REVIEW_LOOP_ALLOW_PUSH=false ZGPT_STATE_DIR_OVERRIDE="$state" \
    "$loop" start "$mr" --cwd "$tmp" >/dev/null
assert_status "$state" poll_limit 'push-disabled loop keeps observing'
assert_eq "$(jq -r '.["push-gate"] // 0' "$state/review-loops/$identity/attempts.json")" 0 'push-disabled item consumes no attempt'
assert_eq "$(jq -r '.["push-gate"] // empty' "$state/review-loops/$identity/last-seen.json")" 290 'push-disabled item is marked seen'
assert_contains "$(cat "$posts")" 'Push authorization required.*push-gate' 'push-disabled item requests manager authorization'

printf '\n== Trusted reviewer allowlist (default-deny) ==\n'
# Default deny: empty TRUSTED_REVIEWERS means no text LGTM ends loop
printf '[]\n' > "$discussions"
jq -cn '[{id:301,body:"LGTM!",system:false,author:{username:"reviewer"}}]' > "$notes"
state="$tmp/state-trust-default-deny"
ZGPT_REVIEW_LOOP_TRUSTED_REVIEWERS="" ZGPT_STATE_DIR_OVERRIDE="$state" "$loop" start "$mr" --cwd "$tmp" >/dev/null
assert_status "$state" poll_limit 'default-deny: text LGTM does not end loop'

# Default deny also prevents an untrusted actionable comment from launching a worker.
jq -cn '[{id:"untrusted-action",notes:[{id:304,body:"change the parser",system:false,author:{username:"stranger"}}]}]' > "$discussions"
printf '[]\n' > "$notes"
state="$tmp/state-untrusted-action"
ZGPT_REVIEW_LOOP_TRUSTED_REVIEWERS="" ZGPT_STATE_DIR_OVERRIDE="$state" "$loop" start "$mr" --cwd "$tmp" >/dev/null
assert_status "$state" poll_limit 'untrusted actionable comment is ignored'
assert_eq "$(jq -r '.["untrusted-action"] // 0' "$state/review-loops/$identity/attempts.json")" 0 'untrusted comment launches no worker'

# Trusted match: reviewer in allowlist, LGTM ends loop
printf '[]\n' > "$discussions"
jq -cn '[{id:301,body:"LGTM!",system:false,author:{username:"Reviewer"}}]' > "$notes"
state="$tmp/state-trust-match"
ZGPT_REVIEW_LOOP_TRUSTED_REVIEWERS='alice, reviewer ' ZGPT_STATE_DIR_OVERRIDE="$state" "$loop" start "$mr" --cwd "$tmp" >/dev/null
assert_status "$state" approved 'trusted reviewer match ignores CSV whitespace and case'

# Rejections still work (negative, bot, self)
jq -cn '[{id:302,body:"not lgtm yet",system:false,author:{username:"reviewer"}}]' > "$notes"
state="$tmp/state-trust-negative"
ZGPT_REVIEW_LOOP_TRUSTED_REVIEWERS=reviewer ZGPT_STATE_DIR_OVERRIDE="$state" "$loop" start "$mr" --cwd "$tmp" >/dev/null
assert_status "$state" poll_limit 'negative text does not match from trusted reviewer'

jq -cn '[{id:303,body:"LGTM",system:false,author:{username:"review-bot",bot:true}}]' > "$notes"
state="$tmp/state-bot-lgtm"
ZGPT_REVIEW_LOOP_TRUSTED_REVIEWERS=review-bot ZGPT_STATE_DIR_OVERRIDE="$state" "$loop" start "$mr" --cwd "$tmp" >/dev/null
assert_status "$state" poll_limit 'bot LGTM is ignored even when trusted'

# API approved stays terminal regardless of trusted reviewers
printf '[]\n' > "$notes"; printf '{"approved":true}\n' > "$approvals"
state="$tmp/state-api-terminal"; ZGPT_STATE_DIR_OVERRIDE="$state" "$loop" start "$mr" --cwd "$tmp" >/dev/null
assert_status "$state" approved 'API approval remains terminal without trusted reviewers'
printf '{"approved":false}\n' > "$approvals"

printf '\n== Resolved discussions ==\n'
printf '[]\n' > "$notes"
jq -cn '[
  {id:"resolved-thread",resolved:true,notes:[{id:310,body:"LGTM",resolved:false,system:false,author:{username:"reviewer"}}]},
  {id:"resolved-note",notes:[{id:311,body:"fix this",resolved:true,system:false,author:{username:"reviewer"}}]}
]' > "$discussions"
state="$tmp/state-resolved"
ZGPT_STATE_DIR_OVERRIDE="$state" "$loop" start "$mr" --cwd "$tmp" >/dev/null
assert_status "$state" poll_limit 'resolved threads and notes are not terminal or actionable'
assert_eq "$(jq 'length' "$state/review-loops/$identity/attempts.json")" 0 'resolved review items launch no worker'

printf '\n== Global state per MR ==\n'
# Create a minimal git repo for a loop that needs a valid cwd
global_repo="$tmp/global-repo"; git -C "$tmp" init -q -b feature-x "$global_repo"
git -C "$global_repo" remote add origin 'git@git-biz:group/repo.git'
state="$tmp/state-global"
ZGPT_STATE_DIR_OVERRIDE="$state" "$loop" start "$mr" --cwd "$global_repo" >/dev/null
# Use assert_status (guarded by if) so bare wait_status doesn't trigger set -e on timeout
assert_status "$state" poll_limit 'global state: loop completes'
# Check status from a DIFFERENT cwd to verify global state
other_cwd_status="$(cd /tmp && ZGPT_STATE_DIR_OVERRIDE="$state" "$loop" status "$mr" 2>/dev/null)"
assert_contains "$other_cwd_status" 'identity=git-biz.qianxin-inc.cn_group_repo_mr42' 'global state: identity from different cwd'
assert_contains "$other_cwd_status" 'status=' 'global state: status from any cwd'

printf '\n== Strict worker result artifact ==\n'
artifact_worker="$bin/artifact-worker"
cat > "$artifact_worker" <<'WORKER'
#!/usr/bin/env bash
set -euo pipefail
artifact=''
while (($#)); do
    case "$1" in
        --artifact) artifact="${2:?}"; shift 2 ;;
        *) shift ;;
    esac
done
[[ -n "$artifact" ]] || exit 2
printf '%b' "${ZGPT_FAKE_RESULT_BODY:?}" > "$artifact"
printf 'status=fixed\ncommit_sha=ffffffffffffffffffffffffffffffffffffffff\n'
WORKER
chmod +x "$artifact_worker"
jq -cn '[{id:"artifact-item",notes:[{id:320,body:"fix artifact case",system:false,author:{username:"reviewer"}}]}]' > "$discussions"
printf '[]\n' > "$notes"

run_artifact_case() {
    local case_name="$1" body="$2" expected_post="$3" case_state="$tmp/state-artifact-$1"
    : > "$posts"
    env -u ZGPT_FAKE_RUN_WORKER ZGPT_FAKE_SKIP_COMMIT_VERIFY=1 \
        ZGPT_FAKE_RESULT_BODY="$body" ZGPT_RUN_WORKER_CMD="$artifact_worker" \
        ZGPT_STATE_DIR_OVERRIDE="$case_state" "$loop" start "$mr" --cwd "$internal_repo" >/dev/null
    assert_status "$case_state" poll_limit "artifact $case_name loop completes"
    assert_contains "$(cat "$posts")" "$expected_post" "artifact $case_name has expected outcome"
}

run_artifact_case valid-fixed 'schema=zflow.review_loop.worker_result.v1\nstatus=fixed\ncommit_sha=0000000000000000000000000000000000000abc\n' 'Fix submitted'
run_artifact_case lifecycle-conflict 'schema=zflow.review_loop.worker_result.v1\nstatus=failed\n' 'Fix attempt failed'
run_artifact_case missing-schema 'status=fixed\ncommit_sha=0000000000000000000000000000000000000abc\n' 'Fix attempt failed'
run_artifact_case duplicate-schema 'schema=zflow.review_loop.worker_result.v1\nschema=zflow.review_loop.worker_result.v1\nstatus=fixed\ncommit_sha=0000000000000000000000000000000000000abc\n' 'Fix attempt failed'
run_artifact_case duplicate-status 'schema=zflow.review_loop.worker_result.v1\nstatus=fixed\nstatus=not_actionable\ncommit_sha=0000000000000000000000000000000000000abc\n' 'Fix attempt failed'
run_artifact_case duplicate-commit 'schema=zflow.review_loop.worker_result.v1\nstatus=fixed\ncommit_sha=0000000000000000000000000000000000000abc\ncommit_sha=1111111111111111111111111111111111111111\n' 'Fix attempt failed'
run_artifact_case not-actionable-commit 'schema=zflow.review_loop.worker_result.v1\nstatus=not_actionable\ncommit_sha=0000000000000000000000000000000000000abc\n' 'Fix attempt failed'
run_artifact_case failed-commit 'schema=zflow.review_loop.worker_result.v1\nstatus=failed\ncommit_sha=0000000000000000000000000000000000000abc\n' 'Fix attempt failed'

: > "$posts"
state="$tmp/state-artifact-valid-not-actionable"
env -u ZGPT_FAKE_RUN_WORKER ZGPT_FAKE_SKIP_COMMIT_VERIFY=1 \
    ZGPT_FAKE_RESULT_BODY='schema=zflow.review_loop.worker_result.v1\nstatus=not_actionable\n' \
    ZGPT_RUN_WORKER_CMD="$artifact_worker" ZGPT_STATE_DIR_OVERRIDE="$state" \
    "$loop" start "$mr" --cwd "$internal_repo" >/dev/null
assert_status "$state" poll_limit 'artifact valid-not-actionable loop completes'
assert_eq "$(jq -r '.["artifact-item"] // 0' "$state/review-loops/$identity/attempts.json")" 0 'valid not_actionable consumes no attempt'
if ! grep -q 'Fix attempt' "$posts"; then pass 'valid not_actionable posts no fix attempt'; else fail 'valid not_actionable posts no fix attempt'; fi

printf '\n== Timeout and merged cleanup status ==\n'
state="$tmp/state-timeout"
ZGPT_REVIEW_LOOP_MAX_RUNTIME=0 ZGPT_STATE_DIR_OVERRIDE="$state" "$loop" start "$mr" --cwd "$tmp" >/dev/null
assert_status "$state" timeout 'timeout posts done and stops'
state="$tmp/state-merged"
ZGPT_FAKE_MR_STATE=merged ZGPT_STATE_DIR_OVERRIDE="$state" "$loop" start "$mr" --cwd "$tmp" >/dev/null
assert_status "$state" merged 'merged MR posts done and stops'
export ZGPT_FAKE_MR_STATE=opened
assert_contains "$(cat "$posts")" 'Done.*MR is merged' 'merged action is posted before cleanup'

owned_root="/tmp/zflow/zgpt-review-loop-smoke-$$"
owned_repo="$owned_root/repo"
owned_path="$owned_root/worktrees/owned"
mkdir -p "$owned_repo"
git -C "$owned_repo" init -q
git -C "$owned_repo" config user.name smoke
git -C "$owned_repo" config user.email smoke@example.invalid
printf 'base\n' > "$owned_repo/file.txt"
git -C "$owned_repo" add file.txt
git -C "$owned_repo" commit -qm init
git -C "$owned_repo" worktree add -qb zgpt/owned "$owned_path"
state="$tmp/state-owned-merge"
ZGPT_FAKE_MR_STATE=merged ZGPT_STATE_DIR_OVERRIDE="$state" "$loop" start "$mr" --cwd "$owned_path" --owned-worktree "$owned_path" >/dev/null
assert_status "$state" merged 'owned worktree reaches merged state'
# Cleanup now completes before the terminal status is published, so this
# should return almost immediately; the generous 30s budget is defense in
# depth against slow/loaded machines rather than a timing dependency.
for _ in $(seq 1 1500); do [[ ! -d "$owned_path" ]] && break; sleep 0.02; done
if [[ ! -d "$owned_path" ]] && ! git -C "$owned_repo" show-ref --verify --quiet refs/heads/zgpt/owned; then
    pass 'merged cleanup removes only recorded worktree and local branch'
else fail 'merged cleanup removes only recorded worktree and local branch'; fi
rm -rf "$owned_root"

printf '\n== Pagination and API failures ==\n'
unset ZGPT_FAKE_NOTES_FILE ZGPT_FAKE_DISCUSSIONS_FILE ZGPT_FAKE_APPROVALS_FILE
export FAKE_API_PAGES=1
: > "$FAKE_GLAB_LOG"
state="$tmp/state-pages"; ZGPT_STATE_DIR_OVERRIDE="$state" "$loop" start "$mr" --cwd "$tmp" >/dev/null
wait_status "$state" poll_limit || fail 'paginated loop completed'
assert_contains "$(cat "$FAKE_GLAB_LOG")" 'notes.*page=2' 'fetches notes page 2'
assert_contains "$(cat "$FAKE_GLAB_LOG")" 'discussions.*page=2' 'fetches discussions page 2'
unset FAKE_API_PAGES
export FAKE_API_FAIL=notes
state="$tmp/state-api-error"; ZGPT_STATE_DIR_OVERRIDE="$state" "$loop" start "$mr" --cwd "$tmp" >/dev/null
assert_status "$state" blocked_api 'API error blocks instead of becoming empty comments'
unset FAKE_API_FAIL

printf '\n== Post failure is surfaced ==\n'
unset ZGPT_FAKE_POST_LOG
export FAKE_POST_FAIL=1
state="$tmp/state-post-error"
ZGPT_REVIEW_LOOP_MAX_RUNTIME=0 ZGPT_STATE_DIR_OVERRIDE="$state" "$loop" start "$mr" --cwd "$tmp" >/dev/null
assert_status "$state" blocked_post 'terminal post failure is surfaced'
unset FAKE_POST_FAIL
export ZGPT_FAKE_POST_LOG="$posts"

printf '\n== Summary ==\n'
printf '%d passed, %d failed\n' "$passed" "$failed"
((failed == 0))
