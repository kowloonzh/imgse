#!/usr/bin/env bash
# Label this session's herdr pane as "human:<repo> · <session title>".
#
# Hand-started Claude sessions have no manual pane label, so herdr falls back to
# the detected agent label and every pane reads "claude". zflow workers already
# get a "worker:<name> · <repo>@<branch>" label from zgpt-worker-pane.sh, so this
# skips them: a worker is often a Claude session too, and relabelling it would
# destroy the orchestrator's own naming. Keep-alive manager:/supermanager: panes
# are preserved the same way, and a session marked ZFLOW_SUPERMANAGER=1 labels
# as supermanager:fleet · multi-project instead of human:<repo>.
#
# Installed copy: this file lives inside the zflow-workers skill, which
# scripts/install-skill.sh symlinks to ~/.claude/skills/zflow-workers, so the
# path is stable and tracks `git pull`. Wire it into settings.json with
# scripts/install-herdr-pane-label-hook.sh (registers on SessionStart and Stop,
# Stop async). Runs on SessionStart (initial label) and Stop (refresh once the
# conversation has a title). Always exits 0 — a labelling failure must never
# break a session.

set -u

# Not running under herdr: nothing to label.
[ -n "${HERDR_PANE_ID:-}" ] || exit 0

# zflow worker: the manager owns this pane's label.
[ -z "${ZFLOW_WORKER_DEPTH:-}" ] || exit 0

command -v herdr >/dev/null 2>&1 || exit 0
command -v jq >/dev/null 2>&1 || exit 0

pane_json="$(herdr pane get "$HERDR_PANE_ID" 2>/dev/null)" || exit 0
[ -n "$pane_json" ] || exit 0

current_label="$(printf '%s' "$pane_json" | jq -r '.result.pane.label // ""' 2>/dev/null)"

# Second guard: a pane zflow labelled directly, even if the env var didn't reach us.
# manager:/supermanager: panes (keep-alive ring-1 managers and the ring-0 pane)
# are also preserved — only an unlabelled hand-started session becomes human:.
case "$current_label" in
    worker:*|fleet:*|advisor:*|manager:*|supermanager:*) exit 0 ;;
esac

# Ring-0 supermanager detection. A session explicitly marked ZFLOW_SUPERMANAGER=1
# (or that already carries a supermanager: label, preserved by the guard above)
# is the top-level human pane: label it supermanager:<repo> instead of human:<repo>.
supermanager=0
[ "${ZFLOW_SUPERMANAGER:-}" = "1" ] && supermanager=1
case "$current_label" in
    supermanager:*) supermanager=1 ;;
esac

repo="$(git rev-parse --show-toplevel 2>/dev/null)"
if [ -n "$repo" ]; then
    repo="$(basename "$repo")"
else
    repo="$(basename "$PWD")"
fi

title="$(printf '%s' "$pane_json" | jq -r '.result.pane.terminal_title_stripped // ""' 2>/dev/null)"

# "Claude Code" is the placeholder title before the conversation has a topic.
if [ "$supermanager" = "1" ]; then
    # A ring-0 supermanager is by definition multi-project; label it as the
    # fleet pane rather than pinning it to whatever repo cwd it started in.
    label="supermanager:fleet · multi-project"
elif [ -n "$title" ] && [ "$title" != "Claude Code" ]; then
    label="human:${repo} · ${title}"
else
    label="human:${repo}"
fi

herdr pane rename "$HERDR_PANE_ID" "$label" >/dev/null 2>&1 || true
exit 0
