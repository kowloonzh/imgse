---
name: zflow-workers
description: Manage visible GPT or other AI worker agents as herdr panes from an existing manager session such as Claude or Codex. Use when the user wants worker CLIs, pane monitoring, prompt injection, or cross-repo worker coordination instead of hidden runtime subagents.
---

# zflow Workers

Use this skill when the user wants visible AI worker agents in terminal panes. The manager is the
current Claude/Codex session. Workers can be any CLI that can run in a terminal pane and take a
prompt: `claude`, `aider`, `codex`, `startomni-*` launchers, `bash`, test runners, or project-specific
tools.

Worker commands are per-machine and four-tier when you want them:

| Env | Role | Default when unset |
|---|---|---|
| `ZFLOW_FAST_CMD` | Cheap fleet / high-volume collectors (`--difficulty fast\|simple\|routine`) | falls back to ordinary worker |
| `ZFLOW_MANAGER_CMD` | Keep-alive manager / supermanager panes (`--role manager\|supermanager`, no `--command`) | falls back to advisor (`ZFLOW_ADVISOR_CMD`) |
| `ZFLOW_WORKER_CMD` | Ordinary implement / explore / fix (legacy `GPT_WORKER_CMD` still honored) | `startomni-alice` |
| `ZFLOW_ADVISOR_CMD` | Reasoning-heavy plan / design / review / escalate | falls back to manager (`ZFLOW_MANAGER_CMD`), then `startbridge` |

Pass `--command` to override any tier for one launch. Keep roles distinct: the advisor classifies
or handles difficult task boundaries; the ordinary worker is the default do path; the optional
fast command is for volume work that should not burn the workhorse or advisor. The manager tier is
the *default command* for a keep-alive manager pane only — it never changes difficulty routing, so
`--role manager` with `--difficulty hard` still resolves to the advisor command. When
`ZFLOW_MANAGER_CMD` is unset, manager panes fall back to `ZFLOW_ADVISOR_CMD` (and vice versa: an
unset `ZFLOW_ADVISOR_CMD` falls back to `ZFLOW_MANAGER_CMD`); both bottom out at `startbridge`.
In this repo, see `docs/omniroute-launcher-strengths.md` for verified launcher names and tradeoffs.

Example native Grok CLI machine profile:

```bash
export ZFLOW_FAST_CMD=startgrok-build
export ZFLOW_WORKER_CMD=startgrok43
export ZFLOW_ADVISOR_CMD=startgrok45
```

Bridge wrappers remain available when you want Claude-compatible transport:

```bash
export ZFLOW_FAST_CMD=startbridge-grok-build
export ZFLOW_WORKER_CMD=startbridge-grok43
export ZFLOW_ADVISOR_CMD=startbridge-grok45
```

### Nested workers re-anchor to their own panel — and are depth-limited by default

When a worker launches another worker, the nested (child) worker must open beside the
invoking worker's own pane — not the grandparent manager pane. The launcher writes the new
worker's own pane id into the runner it generates, and that runner exports it as
`ZGPT_MANAGER_PANE_ID` (and `ZJ_PANE_ID`) while clearing any stale inherited pane/tab
anchors. This keeps nested placement anchored to the current worker panel
automatically; you do not need to set anchor env vars for nested calls.

Nesting is depth-limited by default to stop accidental worker-to-worker recursion. Keep-alive
manager/supermanager panes (launched with `--role manager|supermanager`) do NOT consume a worker
depth slot: their runner leaves `ZFLOW_WORKER_DEPTH` **unset** (nesting still treats that as
depth 0 via `${ZFLOW_WORKER_DEPTH:-0}`) and exports `ZFLOW_ROLE=manager|supermanager`, so a
ring-0-launched manager may launch product workers under the default `ZFLOW_MAX_WORKER_DEPTH=0`
without `--allow-nested`, and role detection that keys on "is `ZFLOW_WORKER_DEPTH` set?" still
classifies the pane as a manager rather than a worker. Product workers (`worker|fleet|advisor`)
inherit `ZFLOW_WORKER_DEPTH` incremented by the runner they execute in (depth 1 for a
manager-launched worker), and `zgpt-run-worker.sh` refuses to start above
`ZFLOW_MAX_WORKER_DEPTH` (default 0) unless `--allow-nested` is passed — so a manager may
launch workers (depth 1) freely, but any worker spawning a sub-worker is refused by default:
deliberate fan-out requires the opt-in, and a worker cannot silently recurse into an
ever-deeper chain. Raise `ZFLOW_MAX_WORKER_DEPTH` or pass `--allow-nested` only for deliberate
nested fan-out; the
default `--route implement` prompt also states that a worker is the terminal executor and
must not delegate its edits to sub-workers. The routing ledger records `depth=` on every
run so recursion is measurable.

## Core Rule

Create worker panes with `scripts/zgpt-worker-pane.sh` (launch path: `pane split`/`tab create --cwd` + `pane run`, not `herdr agent start` — worker_cmd is a custom wrapper, not a Herdr kind); do not
hand-roll pane creation. The helper is repo-aware and resolves placement with this precedence: explicit `--tab-id`, `ZGPT_TAB_ID`/`ZJ_TAB_ID`, `ZGPT_MANAGER_PANE_ID`/`ZJ_PANE_ID`, `herdr pane current`, `herdr pane process-info --current` + `pane get`, and finally the repo-tab fallback.

When herdr can identify the current manager pane/tab and that pane's cwd belongs to the same Git repository as the worker `--cwd`, the worker opens beside that pane by default; worktrees count as the same repository because matching uses Git's common directory. Automatic `herdr pane current` and `herdr pane process-info --current` anchors are ignored when the detected cwd belongs to another repository, so cross-repo launches fall back to the target repo's `agents:<repo>` tab. Explicit `--tab-id`, `ZGPT_TAB_ID`/`ZJ_TAB_ID`, and `ZGPT_MANAGER_PANE_ID`/`ZJ_PANE_ID` anchors are trusted and are not repo-scoped. The helper reports `placement_source`, `target_tab_id`, and `manager_pane_id` when known; repo-tab fallback also sets `placement_reason` so logs can explain why it had to create or reuse `agents:<repo>`. For Git worktrees, `<repo>` resolves through Git's common directory so the tab uses the real repository name rather than the worktree slice folder. `--cwd` controls the worker process directory; placement controls where the pane appears.

If no live current-pane metadata exists, the helper reuses or creates a repo-named tab, `agents:<repo>` (for example, `agents:zflow`), then launches the worker pane there. A newly created tab drops Herdr's bootstrap shell after the worker has started, so the worker is its first and only pane. Later workers for that repo share the tab.

Placement inside a shared tab is chosen from the tab's **live layout** (`herdr pane layout`), never from pane order:

- **Anchor**: panes labelled `supermanager:*` or `human:*` are never anchors — ring-0 and human panes are not splittable land, so a worker never splits the supermanager's pane. Among the remaining panes the roomiest one (largest `rect.width * rect.height`, ties broken by width then pane id) is split.
- **Direction**: along the anchor's long edge — `width > 2*height` splits `right`, otherwise `down` (terminal cells are ~2:1 tall:wide). An explicit `--direction` still wins over the geometry.
- **Equal shares**: the split `--ratio` is computed from the tab area so the fresh pane gets `area / (pane_count+1)`, capped at half the anchor, keeping every pane in the tab within 2x of the smallest. A binary split tree cannot tile 3 or 5 equal panes, so 2x (not exact equality) is the bound.
- **6-pane cap**: a tab that already holds 6 live panes — or holds no splittable pane at all — is skipped; the worker lands in the next `agents:<repo>-2`, `agents:<repo>-3`, … tab, or in a freshly created one.

Tabs that the helper creates are treated as temporary infrastructure. `zgpt-run-worker.sh --close`
closes the worker pane and closes its created tab only after no worker panes remain there. Reused,
anchored, and explicitly targeted tabs are never auto-closed.

## Operating Model

The stack is three layers; only the bottom does real work.

- **Ring 0 — supermanager (human)** sits in the top-level session. It surveys the fleet
  (`zgpt-superboard.sh`), surfaces decisions to the human, and steers idle agents
  (`zgpt-steer.sh`). It does ZERO real work — no edits, no implementation, no investigation.
  superboard is a *monitoring* tool, not a *work* tool: running it builds a board, it never
  accomplishes a task.
- **Ring 1 — manager** plans, delegates, reviews, integrates. It does real work only for the
  coordination/configuration that its own duties require; every task edit and execution is a
  worker's job (see "Manager / worker execution boundary").
- **Ring 2 — worker** implements/investigates in its own pane/worktree.

### Manager / worker execution boundary

Scope: any task that uses zflow. The default worker writes product code; the manager does not.

- The manager analyzes, plans, assigns, reads code/diff/logs, monitors execution status, reviews
  evidence, accepts, and talks to the user; it may maintain the orchestration/coordination config
  those duties require.
- Task code and test-script edits, builds, tests, deploys, and test-evidence collection must be
  performed by a visible zflow worker.
- When the manager finds a problem it gives the worker an explicit branch/change requirement; it
  must not execute itself on the excuse of a small fix, verification, easier debugging, or the
  logic being complex/hard to delegate.
- If execution remains after a worker delivers, exits, fails, or times out, resume the existing
  worker or start a follow-up worker, and responsibility never silently reverts to the manager.
  Routine re-delegation needs no new user confirmation.
- Manager verification means reviewing the actual diff, logs, exit codes, and artifacts. When a new
  or re-run test/verification command is needed, a worker still runs it — reading existing
  state/evidence is distinct from running tests.
- When no worker is available, handle the orchestration problem or report the affected execution as
  blocked; do not silently fall back to the manager doing the work.
- The only exception is explicit user authorization for the manager to execute; the authorization
  is limited to the named action/scope and never expands into taking over the whole task.

The human operates ONE pane and reaches every other pane via survey + steer + read; it never
physically enters a worker pane. What must be in the correct place is the WORK — a worker
launched into the right worktree via `zgpt-worker-pane.sh`/`zgpt-worktree.sh` — not the manager
relocating itself. Before steering, orient first: `guild_session_start` + a `zgpt-superboard.sh`
run tells you which agents are `needs_human` and which are busy.

### Ring lifecycle

The three layers are roles with distinct lifecycle rules, not just labels:

1. **Ring 0 — supermanager** surveys and steers only. It may **start** a ring-1 manager, but it
   must **never launch product workers directly** — a deploy/implement worker is ring-2 work, and
   the manager it reports to is the one who spawns it. Wrong shape: ring 0 runs `zgpt-run-worker.sh`
   for a real task (e.g. `sch026-deploy-883`). Right shape: ring 0 starts a manager, and that
   manager launches the deploy worker. The supermanager is a **normal chat session**, not a fleet
   daemon that prints boards on a timer (see [Supermanager UX](#supermanager-ux)).
2. **Ring 1 — manager** plans, spawns workers, reviews, integrates. It may **keep-alive** — stay
   idle in its pane waiting for steer from ring 0 — instead of exiting when its current unit of
   work ends. A keep-alive manager is labelled `manager:` and is never auto-closed.
3. **Ring 2 — worker** implements/investigates in its own pane/worktree, spawned by a manager. It
   usually runs with `--close` and exits when finished.

Close policy:
- Auto-close a finished worker with no residual (default `--close`).
- **Never** auto-close a manager waiting for steer — that idle state is the keep-alive, not a
  finished run.
- **Never** auto-close a multi-step residual business pane that still owns an in-flight task.

Pane labels: `supermanager:` (ring 0) / `manager:` (keep-alive ring 1) / `worker:` · `fleet:` ·
`advisor:` (ring 2, from `zgpt-worker-pane.sh --role` / the resolved command tier).

Keep-alive manager launch note: `--route manager` on `zgpt-run-worker.sh` is a **no-launch gate** —
it prints `status=routed_out` and exits without starting anything. It is not how a keep-alive
manager is created. Use a normal route + a manager prompt + `--role manager` so the pane is
labelled `manager:` and stays open. The pane then defaults to `ZFLOW_MANAGER_CMD` as its worker
command (falling back to `ZFLOW_WORKER_CMD` when unset), so a manager session can run a different
CLI than product workers without changing `ZFLOW_WORKER_CMD`; `--command` still overrides it for
one launch.

### Supermanager UX

The ring-0 pane is a **normal chat**, not a fleet daemon that prints boards on a timer:

1. **Chat-first.** Default mode is the conversation with the human; the fleet is side context the
   human can probe. The supermanager speaks only on **real news** — a `needs_human`/product fork,
   a stuck or context-death pane, or an assignment that finished with residual — or when the human
   asks for status. A quiet fleet means **print nothing**: no periodic "Fleet quiet. Awaiting next
   order." ticks.
2. **Multi-project.** One human chat steers many managers across repos (xcloud, zflow, yg-aio, …).
   The superboard `REPO` column is the map; steers go by **pane id** regardless of which guild
   project the pane's cwd resolves to.
3. **Steer is a chat action.** The human tells the supermanager what to do; the supermanager turns
   that into a `zgpt-steer.sh --pane-id <id> "<decision>"` delivery to the right manager pane.
4. **Ring-0 starts managers only**, never product workers. Managers keep-alive waiting for steer;
   workers usually `--close`.
5. **Status answers are short chat prose**, not full board dumps — unless the human explicitly
   asks for the board.

### Workspace & tab ownership

Ownership is by **workstream**, not by herdr workspace:

- A manager owns a **workstream** — usually one primary repo (controller, API, …) — not a whole
  herdr workspace. A workspace is human layout furniture only: it groups panes on screen and is
  **never the unit of authority**. Resize/rearrange a workspace freely; it does not change who owns
  what work.
- The UI home for a manager is its repo agent tab, **`agents:<primary-repo>`** — the existing
  placement fallback (`agents:zflow`, `agents:xcloud`, …). A keep-alive manager lives in its primary
  repo's `agents:` tab so the tab itself names the workstream.
- The supermanager chat steers many managers **across tabs and workspaces by pane id** — a pane's
  id is what identifies it for a steer, not which workspace/tab it happens to sit in.
- Cross-repo stack (e.g. controller + API + test): still **one manager**, primary tab =
  `agents:<controller>`; workers may land in each repo's `agents:<repo>` tab as the work requires.

Launch conventions:

- **Keep-alive manager**: normal route (NOT the `--route manager` no-launch gate) + `--role manager`
  + **no `--close`**; place into `agents:<primary-repo>` (or an explicit `--tab-id`). It stays open
  waiting for steer.
- **Workers**: `--close` as usual; same placement rules (beside the manager pane when same repo,
  else the target repo's `agents:<repo>` tab).
- **Never** put the supermanager chat inside an `agents:*` tab as if it were a worker — the ring-0
  pane is labelled `supermanager:fleet · multi-project`, outside the repo tabs.

### Manager ↔ supermanager channel

The reporting channel between a keep-alive manager and the ring-0 supermanager chat:

- **Super → Manager**: `zgpt-steer.sh --pane-id <id> "<decision>"` (or raw `herdr pane send-text`
  + `pane send-keys Enter`). Steering is a chat action, not a bus subscription.
- **Manager → Super — PRIMARY (artifact + greppable line)**: the manager writes an
  **assignment artifact** whose first line is a status, e.g. `status: DONE`, then prints a
  greppable status line into its own pane transcript so the super can find it with
  `herdr pane wait-output --regex`:

  ```bash
  printf 'MANAGER_STATUS: idle_for_steer <assignment-id> <artifact-path>\n'
  # or, when parked for a human decision:
  printf 'MANAGER_STATUS: blocked <reason>\n'
  # or, while still working:
  printf 'MANAGER_STATUS: working <assignment-id>\n'
  ```

  `idle_for_steer` is the completion signal, `blocked` parks the manager for a human decision,
  and `working` says the assignment is still in flight. The artifact is the durable record; the
  `MANAGER_STATUS:` line is the greppable wake-up signal. Neither requires `report-agent`.
- **Super → wait**: `zgpt-wait-manager.sh --pane-id <id> --artifact <path> [--status-regex
  'MANAGER_STATUS: (idle_for_steer|blocked)']` (blocks on the agent state and/or the printed
  status line, then reads the artifact head) and/or a direct `herdr pane wait-output --regex
  'MANAGER_STATUS: (idle_for_steer|blocked)' --timeout <ms> <pane>` and/or the
  `zgpt-watch-managers.sh` L2 poll as a safety net.
- **Optional extras**: a human-eye UI flash via `zgpt-manager-notify.sh` (which calls `herdr
  notification show`) — for human UI attention only, it does not replace the artifact or the
  status line and does not enter the super's chat; and `report-metadata` tokens (`assignment`,
  `artifact`, `manager_status`) on the pane for the board.
- **idle alone is not completion.** A manager sitting at `agent_status=idle` without a reported
  `idle_for_steer` line (or an artifact) is not done — judge from the wait-manager status, not the
  bare idle state. `idle_for_steer` vs `blocked` vs `working` are the meaningful states.
- **`herdr pane report-agent` is broken on herdr 0.8.0** — every form fails with
  `unknown option: <source-or-flag>`. The protocol must NOT require it; do not gate completion on
  it until fixed upstream. (Revisit if a later herdr restores the option.)
- **`send-text` is NOT a manager→super channel**: it injects into the manager's input. The
  manager→super direction is the artifact + status line only.
- herdr is **not a chat bus into the super transcript**: nothing herdr publishes lands in the
  super's conversation by itself; the super decides whether to surface an event.

#### Manager publish protocol (on assignment end)

When a manager finishes an assignment it should:

1. Write the artifact with a status line first, e.g. `status: DONE` (+ a summary section).
2. Print the greppable status line into its own pane transcript:

   ```bash
   printf 'MANAGER_STATUS: idle_for_steer <assignment-id> <artifact-path>\n'
   ```

   A manager that needs a human decision prints instead:

   ```bash
   printf 'MANAGER_STATUS: blocked <what is blocked / what decision is needed>\n'
   ```

   A manager still working past a checkpoint prints:

   ```bash
   printf 'MANAGER_STATUS: working <assignment-id>\n'
   ```

3. Optional: add `report-metadata` tokens (`assignment`, `artifact`, `manager_status`) and, when
   human attention is wanted, a UI flash via `zgpt-manager-notify.sh --status blocked|idle_for_steer
   --workstream <name> [--body <text>]` (it calls `herdr notification show`). The notification is a
   human-eye hint at the terminal — it does not enter the super's chat and does not replace the
   artifact/status line; pair it with `watch --exit-on-delta` on the super side if the super should
   also be woken.

The super then waits with `zgpt-wait-manager.sh` (`status=idle_for_steer` → read the artifact;
`status=blocked` → surface the decision to the human) and steers the manager with `zgpt-steer.sh`.

#### Layered channel (safety net when the manager misses the status line)

1. **L1 — primary**: manager writes the artifact + prints the `MANAGER_STATUS:` line; super uses
   `zgpt-wait-manager.sh` / `herdr pane wait-output`. This is the fast, authoritative path.
2. **L2 — safety net**: `zgpt-watch-managers.sh` — a **low-rate, delta-only poll of REGISTERED
   managers** (never the whole fleet). It keeps a small registry (`pane_id, workstream,
   expect_artifact, last_status, last_artifact_mtime`) and prints ONLY state transitions
   (`event=idle_for_steer|blocked|working`). **Quiet when there is no delta** — no periodic
   "Fleet quiet"/still-working spam. Run it as a continuous poll (`watch`) or as a one-shot
   wake-up job (`watch --exit-on-delta`) — see [Three ways to watch a keep-alive
   manager](#three-ways-to-watch-a-keep-alive-manager).
3. **L3 — human ask**: only when a delta matters does the super surface it to the human.

Rule that holds across all layers: **idle alone ≠ done** — an `idle_for_steer` line is completion
only when it carries the expected artifact (`artifact_state=present`). A manager idling before its
artifact is written is still surfaced as `idle_for_steer ... artifact_state=missing`, never as done.

#### Super wait protocol

- Prefer `zgpt-wait-manager.sh` for an active assignment — it blocks until the manager is
  steer-ready or blocked (optionally with `--status-regex` matching the `MANAGER_STATUS:` line).
- Direct alternative: `herdr pane wait-output --regex 'MANAGER_STATUS: (idle_for_steer|blocked)'
  --timeout <ms> <pane-id>`.
- Add `zgpt-watch-managers.sh register <pane-id> --workstream <name> [--artifact <path>]` while
  waiting, or for a keep-alive fleet, so a missed status line is caught by the L2 poll.
- Interval guidance: **3–5 minutes** for an active assignment wait; **10–15 minutes** for idle
  keep-alive managers.

#### Four ways to watch a keep-alive manager

All four are built on the same manager→super protocol (artifact + `MANAGER_STATUS:` line);
they differ in how the super is woken up:

1. **Active wait (block)** — `zgpt-wait-manager.sh`. Blocks until the manager is steer-ready
   or blocked, then prints `status=` and exits. Use for one active assignment where the super
   wants to wait inline and read the artifact immediately:

   ```bash
   zgpt-wait-manager.sh --pane-id w1:p5 --artifact "$run_dir/a5.md" --timeout 1800
   ```

2. **Continuous poll (safety net)** — `zgpt-watch-managers.sh watch`. Polls registered panes
   every `--interval` seconds, prints only deltas, and keeps running until `--max-runtime`
   (default forever). Use as a background safety net over a keep-alive fleet — no news means no
   output, so it stays quiet until a manager's status actually changes:

   ```bash
   zgpt-watch-managers.sh watch --registry "$run_dir/registry.tsv" --interval 300
   ```

3. **Incremental exit (wake-up job)** — `zgpt-watch-managers.sh watch --exit-on-delta`. The
   same poll, but it prints the **first** delta and exits 0 immediately. Launched as a background
   Bash task, the task completing *is* the wake-up signal: the super's next step runs the moment
   a manager's status changes, with no polling loop to keep alive. Use a short `--interval`
   (e.g. 10–30s) since the loop is one-shot:

   ```bash
   zgpt-watch-managers.sh watch --registry "$run_dir/registry.tsv" --exit-on-delta
   # when this returns, the manager state changed; read $out for `event=`
   ```

4. **Super inbox (auto-receive)** — `zgpt-watch-managers.sh watch --deliver-to-pane <super-pane>`.
   Same continuous poll as mode 2, but matching deltas (`idle_for_steer` / `blocked` by default;
   not `working` / `gone`) are queued to `<registry dir>/manager-deliver-pending.log` and flushed
   once per poll round into the **supermanager pane** as one `[zflow-manager] ...` turn. A delivery
   gate never injects while the super pane is `working` — the queue waits (reported as
   `deferred_to=`) and is delivered whole when the super is idle. That creates a real user turn in
   the super chat without interrupting a busy ring-0 and without the super blocking on a shell poll.
   This is the fix for the structural gap that herdr has no native "manager DONE → super transcript"
   bus.

   ```bash
   # after starting a keep-alive manager:
   zgpt-watch-managers.sh register w4N:p2 --workstream sch026 --artifact "$run_dir/result.md"
   # arm the inbox (background; set ZGPT_SUPER_PANE_ID once per super session if preferred)
   zgpt-watch-managers.sh watch \
     --registry "$run_dir/registry.tsv" \
     --deliver-to-pane w4N:p1 \
     --interval 30 &
   # or: export ZGPT_SUPER_PANE_ID=w4N:p1   # then --deliver-to-pane can be omitted
   ```

   Default deliver events: `idle_for_steer,blocked`. `gone` only enters the log by default —
   add it explicitly (`--deliver-events idle_for_steer,blocked,gone`) to hear about closed panes
   in chat. Delivery failures print `warn:` to stderr, keep the queue, and retry next round.

Pick mode 1 for an inline wait on one assignment, mode 2 for a silent log-only fleet net,
mode 3 when a background task's exit should trigger the next step, and **mode 4 as the
default ring-0 arm** whenever a keep-alive manager is running and the super should auto-receive
completion.

#### Manager launch auto-inbox（launch 自动 register + durable watch）

Keep-alive manager/supermanager 的 launch 会自动完成 mode 4 的两步（register + arm），
super 无需手动跑命令：

- **触发条件**：`zgpt-run-worker.sh --role manager|supermanager` 且存在可解析的 assignment
  artifact —— `--artifact <path>` > `$ZGPT_ASSIGNMENT_ARTIFACT` > `--assignment-dir <dir>`
  （取 `<dir>/result.md`）。没有 artifact 就不注册（没有可 watch 的交付物）。
- **自动行为**：
  1. `zgpt-watch-managers.sh register <pane-id> --workstream <repo> --artifact <path>`
     （workstream 默认取 repo 名）；
  2. `zgpt-watch-managers.sh ensure-watch --registry <state_dir>/manager-registry.tsv` ——
     保证一个 **durable watch** 在跑：pidfile 在 `<registry dir>/manager-watch.pid`，
     watcher 用 `nohup + disown` 脱离 ephemeral launch shell；已有存活 watcher 则复用，
     不会重复起；
  3. launch 打印 `registered=<pane-id> watch=running|started|none deliver_to=<id>`。
- **deliver 目标解析**（ensure-watch 内）：`ZGPT_SUPER_PANE_ID` / `ZFLOW_SUPER_PANE_ID`
  优先；未设时自发现唯一 label 含 `supermanager:` 的 pane（`herdr pane list`）。多个 super
  则跳过 deliver 并在 stderr 打 `warn:`；没有 super 则 `watch=none`（注册仍发生）。
- **关闭自动**：`--no-auto-register`。

配套 P1：

- **idle 上报 + artifact 状态**：`once` 只要看到 idle/done 就发 `idle_for_steer`（转入 idle、
  或注册的 artifact 出现 / mtime 变化时各一次）；注册了 `--artifact` 的事件行总是带
  `artifact=<path> artifact_state=present|missing`（present 时再加 `artifact_mtime=<epoch>`）。
  没有注册 artifact 的静默规则不变。
- **投递闸门**：匹配的事件先进 `<registry dir>/manager-deliver-pending.log` 队列，`once`
  每轮末尾统一 flush。目标 super pane 是 `working` 时不注入（打 `deferred_to=`，队列保留），
  其它状态把积压一次性注入（每条打 `delivered_to=`）后清空。注入失败队列保留，下轮重试。
- **死 pane 自动清理**：`once` 发现注册的 pane 已不存在（被关/消失）→ 自动 `unregister`
  并打印 `event=gone`。gone 默认只进日志（stdout/log），不进 super 聊天；显式打开
  `--deliver-events idle_for_steer,blocked,gone` 才会投递 gone。
- **`--registry` 前后置统一**：`register` / `unregister` 与 `watch` / `once` 一样接受
  前置全局 flag 或内联 `--registry <path>`。

The human-eye UI hint is a separate axis from all watch modes: a manager that blocks or
finishes with residuals can call `zgpt-manager-notify.sh --status blocked|idle_for_steer
--workstream <name>` to flash a `herdr notification show` in the human's terminal. That flash is a
UI hint — it does not enter the super's chat transcript and does not wake the super on its own;
pair it with mode 4 (`--deliver-to-pane`) when the super should also be woken.

#### Teammate mode (SendMessage to main) — future architecture item

Modes 1–4 above route manager→super through the artifact + `MANAGER_STATUS:` line, with mode 4
(`--deliver-to-pane`) providing a practical push into the super chat for keep-alive herdr
managers. A fifth mechanism — the manager itself calling `SendMessage` into the super's chat —
exists only when the manager runs as a Claude Code *teammate*:

- **When to use**: a manager that should talk straight into the super transcript instead of
  writing an artifact the super later polls. Right for interactive steer-in-the-same-thread
  workflows; wrong for keep-alive fleets, because a herdr-pane manager cannot do it.
- **How it would launch**: spawn the manager as a teammate/subagent (`claude --subagent` or
  agent-team mode) rather than as a herdr pane. The super then holds the manager inside its own
  conversation instead of a herdr tab.
- **Contract**: the manager calls `SendMessage` to `"main"` — a message that lands directly in the
  super's transcript with no artifact intermediate layer. Delivery is push; the super does not poll.
- **Limitations / why it is not implemented here**: a claude process running as a herdr pane is
  **not** a teammate — it cannot `SendMessage` to main. Teammate mode therefore requires changing
  the *spawn* architecture (launch the manager via the team/subagent path instead of a herdr pane),
  which is orthogonal to the keep-alive pane model this skill manages today. **Documented, not
  implemented.**
- **Current default for keep-alive fleets**: artifact + `MANAGER_STATUS:` line (durable record) +
  `watch --deliver-to-pane <super>` (super inbox) + optional `zgpt-manager-notify.sh` (human UI
  flash). Teammate mode remains a later, larger change.

Default to an interactive worker model:

- The manager pane plans, steers, monitors, and assigns tasks.
- The manager is usually the smarter but scarcer model, such as `startcodex` or `startclaude`.
- Worker panes are usually cheaper/faster CLIs. Configure tiers per machine with
  `ZFLOW_FAST_CMD` / `ZFLOW_WORKER_CMD` / `ZFLOW_ADVISOR_CMD`, and override individual launches
  with `--command` when a task needs a specific launcher. `--command` always wins over
  difficulty/advisor routing.
- Configure `ZFLOW_ADVISOR_CMD` for stronger task-boundary judgment or escalation. If unset,
  the advisor route uses `startbridge`; it is not disabled. Advisor-routed workers default to
  `xhigh` effort while ordinary and fast workers keep their existing `--effort`/default behavior.
- Use `$ZFLOW_WORKER_CMD` for implementation, exploration, fix loops, and ordinary inspection.
- Use `$ZFLOW_FAST_CMD` (or `--difficulty fast|simple|routine`) for high-volume collection,
  scouts, and fleet-style map-reduce slices when a cheaper launcher is configured.
- **Treat `--difficulty hard`/`complex`/`risky` (or `advisor`) as a rare escalation**, not the
  default for work that sounds hard. Planning, design, review, and deep thinking belong on the
  ordinary worker unless the task has already failed there, or a wrong answer is both expensive
  and hard to catch in review; state the reason when you escalate. The tier is disproportionately
  costly: across the first 160 recorded runs it was 35% of launches but 61% of worker wall-clock
  (median 518s vs 92s, p90 1433s vs 468s). Check the real rate with `zgpt-ledger.sh summary`.
  `--difficulty auto` uses a bounded local heuristic that
  chooses only between the ordinary worker command and `ZFLOW_ADVISOR_CMD`; it never accepts a
  command from task text or model output, and it does not auto-select the fast tier.
- 
## Preferred prompt injection (herdr ≥ 0.8.0)

For **detected agent panes** (claude / codex / grok), prefer:

```bash
herdr agent prompt <pane-or-agent-id> "<text>" --wait --timeout 120000
```

`agent prompt` atomically submits text + Enter with bracketed paste, removing the
`send-text` → Enter → sleep 2 → Enter dance for ordinary agent work (trialled
2026-08-12 against herdr 0.8.0 skill contract; LORE-619 / QUEST-32).

Keep `herdr pane send-text` + `send-keys Enter` only for:
- non-agent panes / raw shells
- herdr versions without `agent prompt`
- cases where agent detection is `unknown`

Prefer launching interactive CLIs without `-p`; then inject prompts with `herdr pane send-text <pane-id> "<text>"`
  plus `herdr pane send-keys <pane-id> Enter`.
- Use one-shot `--mode print` only for quick smoke tests or summaries, not for the main workflow.
- Human input in a worker pane is allowed. The manager should re-read the pane, treat human input
  as external steering, and avoid blind auto-injection while the worker is active.
- Bias to cost-saving: prefer the fewest workers that cover the goal. Escalate model tier or
  worker count only when breadth or reasoning demand justifies it, and say why.
- **Parallel when it can:** if the goal splits into independent scopes (disjoint files/slices,
  independent collectors, non-overlapping worktrees), launch those workers in parallel with
  `zgpt-fanout.sh` or background `zgpt-run-worker.sh` jobs and wait on their artifacts. Prefer
  parallel over serial for independent work; stay sequential when a later step needs an earlier
  artifact, or when shared mutable state would collide.
- The manager reviews and verifies worker output. Do **not** launch an extra worker solely for
  casual review of ordinary implement work unless the user asks — day-to-day verification is the
  manager's job from the artifact/diff.
- **Independent second-pass (pre-push) is different — and required for controller-class changes.**
  When a worker (the default author; only an explicitly user-authorized manager edit is the
  exception) authored admission/webhook/reconcile/CRD
  (or similarly high-blast-radius) code that is about to be pushed, run a **fresh second-pass
  review** before push:
  - **Must use a zflow advisor worker** — `zgpt-run-worker.sh` / `zgpt-worker-pane.sh` with
    `--difficulty hard` (or equivalent) so routing selects `ZFLOW_ADVISOR_CMD`, pane role
    `advisor:`. Feed **only** the diff (staged or `base...HEAD`) plus acceptance criteria /
    red lines; **do not** paste the implementation reasoning chain.
  - **Must not** use a session-local subagent (Claude Agent / general-purpose / "Independent
    second-pass diff review" under the same manager conversation). That shares context with the
    author and is not fleet-visible.
  - **Must not** use `codex-review` when that path is unavailable on the machine.
  - Small mechanical follow-ups: a manager self-check of the diff is enough; skip advisor. This
    self-check is read-only review of the evidence and does not relax the execution boundary above.
  - Classify findings accepted / rejected / needs-human; have a worker apply accepted fixes before push.
- **Do not delegate judgment; delegate execution.** Semantics-dense code (admission/webhook rules,
  reconcile ordering, protocol/compat decisions) still requires the manager's judgment: it decides
  and specifies the exact branch structure in the worker prompt, and the **worker implements it**.
  Workers are for mechanical, checkable work — table-driven tests,
  running builds/deploys/e2e, collecting evidence, batch call-site updates. The second-pass
  *reviewer* is not writing product semantics; it adversarially checks the author's diff.
- **Never instruct a worker to "follow the pattern in X".** That phrasing outsources the judgment of
  *which* parts of X are load-bearing. A cheap tier copies the shape and silently drops the semantics
  (a create-vs-update branch, a field comparison). Give the exact branch structure and each
  condition's rationale; let the worker fill in the body.
- Bound each worker's scope and effort in its prompt. State the deliverable, a command/time
  ceiling when appropriate, and "write the file and stop" explicitly.
- Every worker launch must be followed by a watcher or a lifecycle wait. `zgpt-run-worker.sh`
  handles this with marker-primary completion and a sliding inactivity deadline: the marker
  wait extends while the pane keeps producing output (capped by `--max-timeout`), so a long
  healthy task like an e2e is never killed just because it outlives `--timeout`. An artifact
  is a bounded idle/done fallback, not a second full wait.
- **Long tasks outlive the marker timeout by producing output.** `--timeout` is an inactivity
  window, not a wall clock — the deadline slides while the pane emits output and only a worker
  that goes silent for `--timeout` seconds is reaped. For tasks expected to run very long (e2e,
  migrations, multi-hour deploys), leave `--max-timeout` generous or set it to `0` (no cap)
  explicitly, since it bounds the whole run from launch.
- **Default `--close` on implement workers.** One-shot implement / inspect / verify / fleet
  launches should pass `--close` so the pane exits after the marker. Managers often forget this
  and leave orphan panes. **Omit `--close` only when you plan to keep steering the same pane**
  (manager review → inject more edits on that live worker). If the pane is already closed, use a
  new bounded run (or `zgpt-gh-pr.sh fix`) rather than reopening by habit without `--close`.
- For implementation work, review the worker artifact and diff. With `--close`, review happens
  from the artifact/diff after the run; without `--close`, review may continue on the live pane.
- Keep orchestration flat. A single manager owns monitoring, artifacts, integration, and cleanup.
- Risky outward actions remain manager/human gated. Wait for user confirmation before force-pushes
  or equivalent irreversible updates.
- Exit workers gracefully first with `/exit` or the CLI's normal exit command. Force close only
  when graceful exit fails or the pane is already held/exited.

## Supermanager Loop (fleet survey -> human -> steer)

`zgpt-watch-pane.sh` monitors one pane you already track. The **supermanager loop** is the
fleet-level counterpart: keep an eye on *every* agent pane at once, decide where a human decision
is needed, and steer idle agents with the answer. This is how the manager stays on top of many
workers without staring at each one.

UX default: **chat-first and quiet**. The supermanager is a conversation, not a board daemon — a
quiet fleet produces no output (no periodic "Fleet quiet. Awaiting next order."). Speak only on
real news (`needs_human`, stuck/context-death, an assignment finished with residual) or when the
human asks. Status replies are short prose, not full board dumps, unless the board is explicitly
requested. (See [Supermanager UX](#supermanager-ux) in Operating Model.)

The loop has four steps, and `zgpt-superboard.sh` + `zgpt-steer.sh` cover the mechanical half:

1. **Survey** — `zgpt-superboard.sh` lists all panes, reads each agent pane's recent output,
   classifies state (`working | needs_human | idle-done | worker_gone`), and prints one compact
   row per pane. Non-agent shells are hidden unless `--all`.

   ```bash
   zgpt-superboard.sh              # table
   zgpt-superboard.sh --json       # machine-readable
   zgpt-superboard.sh --min-working 2   # exit 3 if fewer than 2 panes are working
   ```

2. **Surface** — an idle agent that ends its last real line with `？/ ?` (or is `blocked` natively,
   or printed `BLOCKED:`) is `needs_human`: it finished a unit of work and is waiting on a
   decision, not on nothing. Batch those decisions to the human once, with your recommendation for
   each — a question a worker asks is the worker surfacing a fork, and the human owns the verdict.
   `superboard` exits `2` when any agent is in this state, so it can gate a loop.

3. **Steer** — once the human decides, deliver the answer into the pane with
   `zgpt-steer.sh --pane-id <id> "<decision>"`. It wraps the send-text + settle + Enter dance
   (and the second Enter that large/multi-line pastes need) so the manager never re-types it.

   ```bash
   zgpt-steer.sh -p w1:p5 "合入 main 并清理，完成后报告 commit hash" --confirm
   ```

4. **Re-survey** — re-run `zgpt-superboard.sh` to confirm the steered pane left `needs_human`
   (it is working again or the terminal state changed). Two surveys in a row on the same pane
   usually means the steer did not land or the worker pushed back — read that pane before steering
   again.

Rules that keep the loop safe:

- **Steer decisions, not new requirements.** A decision the worker already asked about is
  correction-within-scope and safe to inject. A new requirement discovered after launch is a fresh
  worker, not a `send-text` (same rule as the [Manager Prompt-Architecture Loop](#manager-prompt-architecture-loop)).
- **Idle is not done.** `agent_status: idle` alone does not mean finished — it often means the
  worker printed a question and stopped. Classify from content (trailing `？/ ?`), not status alone.
- **`--confirm` before trusting a steer.** The readback shows whether the pane actually accepted
  the text (it lands on the input line, not a closed/exited pane).
- **Never blind-inject into a `working` pane.** Steering is for panes that stopped and asked.
  A busy pane that needs a course correction is a review decision, handled by reading it first.

## Manager Prompt-Architecture Loop

Before spawning workers, compile the initial prompt context:

1. Understand the user's goal and constraints.
2. Collect repo state, relevant files, issue/PR status, review comments, and background docs.
3. Use Guild when available: load oath/status, appraise lore, claim or post quests, and use prior
   decisions in worker prompts.
4. Decide whether planning is needed before execution.
5. Break work into worker-sized responsibilities. If those responsibilities are independent,
   plan a parallel fan-out (not a serial chain); if they depend on prior artifacts, sequence them.
   "Worker-sized" is measurable, not a feeling — see [Worker Sizing Budget](#worker-sizing-budget).
6. Write worker prompts with context, allowed scope, output format, markers, stop conditions, and
   escalation rules. Assign fast / worker / manager / advisor command tiers per role.
7. Let workers do the real work while the manager monitors, steers, reviews, and stores durable
   lessons back into Guild.
8. Decide `--close` vs keep-alive before launch: default `--close` for one-shot work; omit only
   when the next step is more edits on that same pane. Review the artifact/diff; for a live pane,
   either inject a revision, approve and close, or hand off follow-up elsewhere.
9. A new *requirement* discovered after launch is a follow-up worker with a fresh context, not a
   `send-text` into a running one. Injection is for corrections that do not change the design —
   a typo, a wrong path, a missed constraint on work not yet written. A semantic change lands on
   a context that is already partly spent and forces a re-plan of code the worker has already
   produced, which is how a nearly-done worker turns into an exhausted one.

## Worker Sizing Budget

Capping what a worker may *read* does not cap what it will *write*. A task that is small to
describe can still be too large to execute, because the edits, their diffs, and the tool output
they provoke all land in the same window. Size on output:

- **At most 3 files touched, at most 1 of them new**, per implement worker.
- **At most 3 numbered change sections** in the task file. A fourth is a second worker.
- **At most ~150 lines / ~6 KB of task file.** Past that, the prompt alone is a meaningful
  fraction of the budget before any file is opened.

Over budget means split, then sequence only on real artifact dependencies — usually one worker
lays down shared types/constants and commits, and the rest fan out in parallel against them.

Two workers failing the same way at the same point is the signature of an over-budget task, not
of a weak model or a bad prompt. Re-tightening the prompt and relaunching will reproduce it; the
second attempt is the point to split, not to re-word.

## Workflow

Confirm herdr is reachable:

```bash
herdr session list --json
```

Launch an interactive worker pane without an initial prompt:

```bash
~/.claude/skills/zflow-workers/scripts/zgpt-worker-pane.sh \
  --name worker-docs \
  --cwd ~/github/chinglinwen/zflow \
  --direction right
```

The launcher prints the created pane id:

```text
pane_id=w1:p8
```

Inject a manager-written prompt:

```bash
herdr pane send-text w1:p8 "<manager-written prompt>"
herdr pane send-keys w1:p8 Enter
```

For real orchestration, prefer `zgpt-run-worker.sh`, which encodes the
launch -> visible-editor readiness -> one-shot inject -> marker/deadline -> cleanup loop.

The canonical adapter is `scripts/zgpt-cli-adapter.sh`. It classifies executable basenames (including
absolute paths) as `claude`, `codex`, `pi`, `grok`, or `generic`; use `--family` for a wrapper override.
`startcccodex`, `startbridge`, `startds`, and `startdsf` are intentionally Claude-compatible
(including `startbridge-grok*`). Native Grok Build (`grok`, `startgrok`, `startgrok*`) is the `grok`
family. Startup flags, readiness glyphs, print-mode syntax, and graceful-exit commands are separate
adapter capabilities.
Managed Pi workers add `--approve` unless the caller supplies an explicit `--approve`/`--no-approve`
policy. Managed Grok workers add `--always-approve` unless the caller already set `--always-approve`
or `--permission-mode`. Managed Codex-family workers (`codex` and `startcodex*`) launched through
`zgpt-run-worker.sh` add `--disable apps` before caller-supplied `--command-arg` values so
app-provided MCP servers do not delay startup; append `--command-arg --enable --command-arg apps`
to re-enable apps for a specific worker. Ordinary Claude-family and Grok-family workers also get
`--effort high` by default (override with `--effort` / `--no-effort-flag`). Readiness supports
literal `--ready-pattern` (higher precedence) or regex `--ready-regex`; Pi defaults to the bordered
editor rather than a Codex glyph.

## Orchestration Helpers

### `zgpt-run-worker.sh` - one worker, launch to artifact

Launches an interactive worker with family-supported startup flags, waits for the visible input
editor, injects the task exactly once, and uses `WORKER_DONE:<token>` as the primary completion
signal. A supplied artifact can produce `artifact_ok` only after the one completion deadline and
only with a live idle/done worker. It prints `family=` and a unique `agent_name=` alongside
`pane_id=`; the logical `--name` remains unchanged. It also prints `pane_label=`, the
`<role>:<name> · <repo>@<branch>` string applied to the pane via `herdr pane rename`
(role comes from the resolved `command_source` tier: `fast_*`→`fleet`, `advisor_*`→`advisor`,
else `worker`).
For ordinary Claude-family and Grok-family CLIs it also injects `--effort high` explicitly
(override with `--effort <level>` or disable with `--no-effort-flag`) so the worker doesn't inherit
whatever effort level the manager session happens to be on — some model routes 400 on levels they
don't support. When difficulty routing selects the advisor command, the default effort becomes
`xhigh`; Claude-compatible and Grok-family advisors receive `--effort xhigh`,
`startcodex*`/`startpi*` advisors receive `x=xhigh`, and native `codex`/`pi` advisors receive their
native effort flag equivalents.

```bash
zgpt-run-worker.sh \
  --name worker-do --cwd "$PWD" \
  --artifact "$run_dir/summary.md" --close \
  --route inspect --report-mode compact \
  --max-commands 4 --time-budget "10 minutes" \
  --task "Read docs/idea.md and write a concise 5-bullet summary."
```

Worker-efficiency options are backward-compatible and only add prompt/output
metadata unless explicitly routed to `manager`:

- `--route implement|inspect|review|verify|report|manager` is the task-routing
  gate. `manager` returns `status=routed_out` without launching; report-like
  routes append a no-edit default unless the task grants writable paths. Every
  route gate also states that the worker is the **terminal executor**: it must
  make the edits (or write the report) itself, must not launch nested zflow
  workers (`zgpt-run-worker.sh` / `zgpt-worker-pane.sh` / `zgpt-fanout.sh` /
  `zgpt-scout.sh`), must not spawn subagents, and must not delegate the work to
  a sub-worker and then review the result. The same rule is enforced by the
  `ZFLOW_WORKER_DEPTH` launcher guard, so a delegating worker is refused rather
  than obeyed.
- `--report-mode compact|full|none` appends a report schema. Compact asks for
  summary, commands/tests, changed files, and risks.
- `--chinese-issue-style` (or `ZFLOW_CHINESE_ISSUE_STYLE=1|true|on|yes`) prepends
  the Chinese technical-issue writing contract to the injected prompt: natural
  short Chinese, fixed terms (预留 / 请求键 / 首次试算 / 标准节点资源过滤),
  structure 现象→根因编号→已修复→仍开放→复现→验收, ≤4 lines/paragraph, no
  invented `rc1/rc2`, self-check for translationese. **Default off** — enable
  only when the worker is writing a GitLab issue / investigation note for
  Chinese colleagues; do **not** turn it on for pure implement/code tasks.
  Metadata prints `chinese_issue_style=on|off`. Interactive "outline first, wait
  for confirm" stays a live manager-session step; one-shot workers write the
  full structured body once under the same section order.
- `--verify-budget`, `--max-commands`, and `--time-budget` append the per-task
  verification/command budget to the worker prompt.
- `--difficulty worker|normal|standard` keeps the ordinary worker path.
  `--difficulty fast|simple|routine` routes to `ZFLOW_FAST_CMD` / `--fast-command`
  when set; otherwise it falls back to the ordinary worker (backward compatible).
  `--difficulty hard|complex|risky|advisor|strong|escalate` routes to
  `ZFLOW_ADVISOR_CMD` (default `startbridge`) when `--command` is absent.
  `--difficulty auto` is intentionally bounded and local: it recognizes broad,
  risky, ambiguous, migration, architecture, security, regression, or failure
  terms and chooses only between the already configured worker/advisor commands
  (never the fast tier, never a command from task text). The runner prints
  `difficulty=` and `command_source=` (`worker_*`, `fast_*`, `advisor_*`, or
  `explicit`) for auditability, plus advisor effort metadata when an advisor
  effort flag is actually applied (or explicitly disabled).

Compose calls sequentially for a pipeline. For fan-out, prefer the bounded helper
over raw `&`/`wait` when more than a couple of workers are possible:

```bash
cat >"$run_dir/fanout.commands" <<EOF
zgpt-run-worker.sh --name scan-a --artifact "$run_dir/a.md" --close --route inspect --report-mode compact --task "..."
zgpt-run-worker.sh --name scan-b --artifact "$run_dir/b.md" --close --route inspect --report-mode compact --task "..."
EOF
zgpt-fanout.sh --max-parallel 2 <"$run_dir/fanout.commands"
zgpt-run-worker.sh --name verify --command startomni-smart \
  --artifact "$run_dir/verified.md" --close \
  --route verify --report-mode compact --max-commands 3 \
  --task "Read $run_dir/a.md and $run_dir/b.md and verify the findings."
```

Known interactive families never treat startup native idle as prompt readiness. Key delivery is
`pane send-text`, Enter, a two-second settling wait, Enter; pane identity is re-resolved before keys
when the old pane fails. `--close` sends the family exit command, waits boundedly, then force-closes
the pane and any tab created by this run. **Pass `--close` by default** for implement and other
one-shot workers; skip it only when the manager will keep using that same pane for follow-up
steering. Interrupts use the same owned-resource cleanup. Completion scans normalize terminal
whitespace only for comparison against the full nonce-bearing marker, so hard-wrapped
`WORKER_DONE:<token>` output is recognized without weakening the token contract.


### `zgpt-ledger.sh` - routing telemetry

`zgpt-run-worker.sh` records one JSON line per launch decision so tier utilization is
measurable. Without it, `difficulty=` and `command_source=` were printed and discarded,
and there was no way to tell whether the three-tier design produced any cost saving.

Default path is `<state_dir>/routing-ledger.jsonl`. Writes are advisory: a missing,
unwritable, or disabled ledger never fails a worker run.

```bash
zgpt-ledger.sh path                 # where the ledger lives for this checkout
zgpt-ledger.sh summary              # distribution by command_source / difficulty / route / status
zgpt-ledger.sh tail -n 5            # last 5 raw records
zgpt-ledger.sh auto-rate            # advisor selection rate among --difficulty auto runs
```

| Variable | Default | Purpose |
|---|---|---|
| `ZFLOW_LEDGER` | `on` | Set to `off`/`0`/`false`/`no` to disable recording |
| `ZFLOW_LEDGER_PATH` | `<state_dir>/routing-ledger.jsonl` | Explicit ledger file |

Recorded fields: `ts`, `name`, `repo`, `cwd`, `route`, `difficulty`, `command_source`,
`command`, `advisor_selected`, `advisor_effort`, `family`, `token`, `status`,
`duration_s`. Empty fields are omitted. Records are written on every exit path that
reaches the launch stage, including `routed_out`, interrupts, and failures; environment
failures before launch (herdr/jq missing) are not recorded.

`auto-rate` is the falsification test for the over-routing hypothesis in
`docs/advisor-consult-loop.md`. Do not tune the `--difficulty auto` keyword list before
running it.

### `zgpt-session-audit.sh` - session-discipline scorecard

Run this after a manager session (or on a batch of them) to catch the discipline failures a
hand-audit would find: edits made in a primary clone instead of a worktree, workers launched with
`--command` instead of `--difficulty` routing, `--artifact`-less launches whose result lives only in
pane scrollback, and `sleep`-polling a worker pane instead of letting `zgpt-run-worker.sh` block on
its `WORKER_DONE:<token>` marker. It reads a Claude Code JSONL transcript and prints one row per
session plus a per-session violation detail block. Use it when a session felt undisciplined, before
compaction, or periodically over recent sessions — it costs manager context once instead of a
hand-audit.

```bash
# Audit the single most recent session in every project.
scripts/zgpt-session-audit.sh
# Audit the 5 most recent sessions of one project; fail on any violation.
scripts/zgpt-session-audit.sh --project zflow --latest 5 --strict
# Audit one explicit transcript.
scripts/zgpt-session-audit.sh ~/.claude/projects/<slug>/<uuid>.jsonl --format json
```

Token figures are de-duplicated by `.message.id` (the transcript repeats one row per content block of
the same response); without that, every number is inflated ~2.5x. When a provider reports
`cache_read_input_tokens > input_tokens` for more than 10% of turns, the row is marked
`token_accounting: suspect` and token columns print `n/a` rather than a misleading figure. `--strict`
exits 1 on any violation counter > 0; without it the exit is 0 unless the invocation itself failed.

### `zgpt-scout.sh` - non-blocking read-only scout

Use scouts when the manager needs background information gathering but should not block on
watching. `zgpt-scout.sh` starts `zgpt-run-worker.sh` in the background with a report-like route
(default `inspect`), compact report mode, and `--close`; that background runner owns readiness,
watching, artifact completion, and cleanup. Scout routes are restricted to
`inspect|review|verify|report`, so they are read-only/report-only unless the task text explicitly
grants writable paths.

```bash
zgpt-scout.sh --name scout-api --artifact "$run_dir/api-scout.md"   --task "Read the API docs and report the three files likely involved. Do not edit."
# prints status=background, pid=..., artifact=..., log=...
```

### `zgpt-watch-pane.sh` - pane monitor

Polls a herdr pane, writes transcript events, and detects worker state using herdr-native agent
state plus marker scanning. `--agent-name <unique-name>` enables pane replacement rebinding while
plain `--pane-id` mode remains supported; an unrecoverable identity is reported as `worker_gone`.

```bash
source ~/.claude/skills/zflow-workers/scripts/zgpt-common.sh
zgpt-watch-pane.sh --pane-id w1:p8 --log "$(zgpt_state_dir "$PWD")/runs/demo/transcript.ndjson"
```

States emitted today:

```text
running
waiting
done
needs_human
context_exhausted
error
worker_gone
```

Marker mapping:

- `WORKER_DONE:<token>` -> `done`
- `LOOP_WAIT:<token>` -> `waiting`
- `BLOCKED:<token>` -> `needs_human`
- status line matches `--context-regex` -> `context_exhausted` (exit code 2)
- stack-trace/error output -> `error`
- any other output -> `running`

`context_exhausted` closes the gap that marker scanning cannot see. A worker that fills its
context window prints no marker and keeps streaming tokens, so every other detector reads it as
healthy and it stays `running` until a human notices — which in practice means twenty minutes of
a pane producing nothing. The signal lives in the CLI status line (`100% context used`), which is
redrawn in place rather than appended, so it is scanned from the visible region instead of the
new-lines diff. Override with `--context-regex` for a CLI that words it differently, or disable
with `--no-context-check`.

Treat it as terminal and needing intervention, not as failure to retry: relaunching the same task
reproduces it. Salvage the worktree into a WIP commit first, then split the task per the
[Worker Sizing Budget](#worker-sizing-budget) before relaunching.

### `zgpt-superboard.sh` - fleet survey over all herdr panes

Where `zgpt-watch-pane.sh` polls one pane you already track, `zgpt-superboard.sh` walks every
pane herdr knows about, reads each agent pane's recent output, classifies its live state, and
prints a compact board the manager can act on. It is the survey half of the
[Supermanager Loop](#supermanager-loop-fleet-survey---human---steer).

```bash
zgpt-superboard.sh                     # table: PANE | STATE | REPO | TASK | TAIL
zgpt-superboard.sh --json              # one JSON object per pane
zgpt-superboard.sh --all               # include plain shells / ssh panes
zgpt-superboard.sh --min-working 2     # exit 3 when the fleet looks idle
```

Read the board **multi-project by REPO/tab (workstream), not by workspace number**: rows are
grouped by tab (each tab is usually one repo's `agents:<repo>` placement) with a `[<tab-id>]`
header, and the `REPO` column names the workstream. JSON output carries a `tab` field per pane.
A workspace is just screen furniture — two panes in different workspaces are still the same
workstream if they share the same repo tab; two panes in one workspace may be different
workstreams. Steer by pane id, never by workspace.

Classification (for agent panes): `working` (herdr-native) > `needs_human` (native `blocked`,
`BLOCKED:`, or last real line ends in `？/ ?`) > `idle-done` (`WORKER_DONE:`, 任务完成, or quiet).
Exit codes: `0` clean, `2` at least one agent awaits a human decision, `3` below
`--min-working`. The `--lines` window defaults to 60 so a trailing question above the CLI status
lines is still seen.

### `zgpt-steer.sh` - inject a decision into an existing agent pane

`herdr pane send-text` only pastes literal text; the agent CLI acts once Enter is sent, and a
large/multi-line paste needs a settling pause then a second Enter. `zgpt-steer.sh` wraps that
dance. It is the steer half of the [Supermanager Loop](#supermanager-loop-fleet-survey---human---steer).

```bash
zgpt-steer.sh -p w1:p5 "合入 main 并清理，完成后报告 merge commit hash"
zgpt-steer.sh -p w1:p5 "确认推进方案 (a)，暂缓 (b)" --confirm
```

`--confirm` reads back the last 6 lines so the manager can verify the text landed on the pane's
input line (a closed/exited pane will not show it). `--no-double-enter` sends Enter exactly once;
`--settle` tunes the pause before the second Enter.

### `zgpt-worktree.sh` - isolated checkouts

For migration or multi-lane scenarios where several workers edit in parallel, give each its own
git worktree so edits never collide. Branch `zgpt/<name>`, path under `/tmp/zflow/<repo>/<worktree>/worktrees/<name>`.

```bash
wt="$(zgpt-worktree.sh create --name slice-a | sed -n 's/^path=//p')"
zgpt-run-worker.sh --name worker-slice-a --cwd "$wt" \
  --artifact "$run_dir/slice-a.md" --close \
  --task "Implement slice A here and report changed files."
# Omit --close only if the manager will keep steering this worker on the same pane next.
zgpt-worktree.sh remove --name slice-a --delete-branch
```

The manager owns integration and merge order; slice workers never merge each other.

### `zgpt-primary-clone-guard.sh` - PreToolUse hook against primary-clone edits

The standing rule is that feature edits happen in an isolated git worktree, never in a
primary clone. Prose in an instruction file does not hold at 300k+ context; a hook does,
because the harness enforces it. This script is a Claude Code `PreToolUse` hook: it blocks
`Edit`/`Write`/`MultiEdit`/`NotebookEdit` against any path inside a *primary* clone, and
allows the same path inside a linked worktree. It fails open on any internal error and
fails closed only on a confident primary-clone hit.

**Wiring (manager-owned; register in `~/.claude/settings.json`):**

```json
{
  "hooks": {
    "PreToolUse": [
      {
        "matcher": "Edit|Write|MultiEdit|NotebookEdit",
        "hooks": [
          {
            "type": "command",
            "command": "$HOME/.claude/skills/zflow-workers/scripts/zgpt-primary-clone-guard.sh"
          }
        ]
      }
    ]
  }
}
```

If the skill is checked out somewhere other than `$HOME/.claude/skills/zflow-workers`,
point `command` at that path. The `matcher` is advisory — the script also gates on
`tool_name` itself — but it keeps the hook from running on unrelated tools.

**How it decides.** It extracts `.tool_input.file_path` (falling back to
`.tool_input.notebook_path`), resolves it to its physical path with `realpath -m` *before*
anything else — a symlink from an allowlisted root into a repo must be judged by where it
lands, not by the name it was addressed under — then resolves the nearest *existing*
ancestor directory and asks git: `git -C <dir> rev-parse --git-common-dir`. If that resolves *outside* the
checkout's own top level it is a linked worktree → allow; otherwise it is the primary
clone → deny with exit code 2 (and a structured `permissionDecision: "deny"` on stdout).
A path whose file does not yet exist (the Write-a-new-file case) is attributed to its
parent directory, so it is still caught.

**Bypass (legitimate cases only).** The default allowlist covers
`$HOME/.claude:/tmp:$HOME/.config` — config, instruction files and scratch are
manager-owned, not feature work. To allow another prefix, set
`ZFLOW_GUARD_ALLOW=/some/repo:/other` (colon-separated). To disable the guard entirely for
a session, set `ZFLOW_GUARD=off`. There is no other bypass by design: it must be
inconvenient to defeat by accident.

## Worker Contract

Every worker prompt should include:

```text
Role:
You are worker-<name>.

Goal:
<single bounded goal>

Allowed:
- Read files.
- Run safe commands needed for this task.
- Write only to <handoff-path> unless explicitly assigned a writable worktree.

Forbidden:
- Do not commit unless explicitly told.
- Do not push.
- Do not delete files.

Required when assigned a writable worktree:
- Commit after each numbered change: `wip(<scope>): <change N>`.
- The manager squashes before the MR/PR.

Report format:
Write final report to <handoff-path> with:
1. Summary
2. Commands run
3. Files read
4. Files changed
5. Findings
6. Recommended next step
```

Use a task-specific completion marker/nonce. When injecting prompts into interactive CLIs, never
write the literal `WORKER_DONE:<token>` in the prompt because the CLI may echo it and trigger a
false-positive monitor match. Instead tell the worker to assemble it from pieces:

```text
When fully done, print on its own line the word WORKER immediately followed by _DONE:
immediately followed by this id with no spaces: task-20260702-a
```

Also require the worker to write its artifact file as the last action before printing the marker.
`zgpt-run-worker.sh` already appends this instruction.

### Checkpoint commits

`Do not commit unless explicitly told` is the right default for a read-only scout and the wrong
one for a multi-edit worker that owns an isolated worktree. Without checkpoints, a worker killed
for context exhaustion costs the whole run rather than one change, and the worktree is left in a
non-compiling intermediate state the manager has to salvage by hand. Grant the commit permission
whenever the worker is assigned a writable worktree, and keep `Do not push` regardless — outward
actions stay manager-gated.

### Never write "follow the pattern in X"

Do not tell a worker 照抄/参考 the structure of an existing implementation. It outsources deciding
which parts of the reference are load-bearing, and the reliable failure is a copy that keeps the
shape while dropping the semantics — the guard clause, the not-found check, the throttle. Enumerate
the reference's branches and say why each exists. If you cannot state them, you are not ready to
launch the worker; that is a signal to write a tighter spec, not to buy a bigger model.

### Language-server noise

A refactor spanning several files is *deliberately* broken partway through: symbols are deleted
before their replacements exist. If the worker's CLI feeds language-server diagnostics back after
every edit, each batch re-enters the context that is already the binding constraint. For Go
workers, include:

```text
先写完本任务的全部文件，再处理编译与诊断错误。
中途 gopls 报 undefined/unused 属预期，不要逐条追。
```

The same clause applies to any language with a live diagnostics feed; only the tool name changes.

## Loop Worker Pattern

Use loop workers when the useful behavior is repeated observation and rework rather than a single
answer: review-comment polling, test reruns, recurring status checks, or rework loops.

Loop prompt shape:

```text
You are worker-review-loop for <PR/task>.
Loop until STOP condition or max <N> iterations:
1. Check current review/comment/test state.
2. If there is actionable feedback, make only the allowed local changes in <worktree/path>.
3. Run the specified verification.
4. Report iteration summary and print LOOP_WAIT:<token> if waiting, BLOCKED:<token> if blocked,
   or WORKER_DONE:<token> if complete.
Do not push or force-push unless the manager explicitly sends a follow-up prompt granting that action.
```

## GitHub PR Manager Workflow

Use `zgpt-gh-pr.sh` for GitHub pull requests. Say PR for GitHub and MR only for
GitLab. The default model is manager-led review: after normal implementation or
PR creation, the manager reviews the evidence (diff, logs, exit codes) and has a
worker run any additional verification or repeat an existing check. If the
implementation worker was launched **without** `--close` and is still live, send
corrections to that same pane; if it used `--close` (the usual default) or is
gone, use one bounded `zgpt-gh-pr.sh fix` run instead. Do not launch a separate
reviewer worker merely because a GitHub PR exists.

### Commands

```bash
# Create a GitHub PR; does not start a review worker
zgpt-gh-pr.sh create --repo owner/repo --title "feat: ..." --body "..."

# Parse or inspect a PR using gh
zgpt-gh-pr.sh parse-url https://github.com/owner/repo/pull/123
zgpt-gh-pr.sh info https://github.com/owner/repo/pull/123

# If the implementation worker is gone, run one consolidated manager-feedback fix
zgpt-gh-pr.sh fix https://github.com/owner/repo/pull/123 \
  --cwd /path/to/pr-feature-worktree \
  --feedback-file /tmp/manager-feedback.md

# Optional outward write gate: still only a normal current-branch push
zgpt-gh-pr.sh fix https://github.com/owner/repo/pull/123 \
  --cwd /path/to/pr-feature-worktree \
  --feedback "manager feedback batch" \
  --allow-push

# Explicit read-only reviewer for unusual size/risk only
zgpt-gh-pr.sh review https://github.com/owner/repo/pull/123 --large-change
zgpt-gh-pr.sh review https://github.com/owner/repo/pull/123 --high-risk
```

### Safety Behavior

- **No review worker by default**: `create`, `info`, `parse-url`, and `fix` never
  start a reviewer. The manager reviews normal GitHub PR diffs.
- **One-shot fallback correction**: `fix` is for one consolidated manager
  feedback batch when no live implementation worker remains. It invokes
  `zgpt-run-worker.sh` exactly once and has no polling loop.
- **GitHub URL/state validation**: PR URLs must be `github.com/OWNER/REPO/pull/N`;
  PR state and branch metadata come from `gh pr view`. GitLab MR URLs are
  rejected here and still belong to the GitLab-specific scripts.
- **Open PR and clean worktree validation**: `fix` requires `gh pr view` state
  `OPEN`. The local cwd must be a clean git worktree on the PR head branch, with
  a GitHub `origin` matching the PR head repository. Main, master, dev, test, and
  release branches are refused as protected sources.
- **Push gate**: push is disabled by default and the worker prompt says not to
  push. `--allow-push` permits only a normal push of the current PR head branch
  after verification. Force-push, force-with-lease, rebase, amend, merge,
  protected-branch push, and PR comments remain prohibited.
- **Auditable one-commit correction**: `fix` captures the starting HEAD before
  launch. A fix worker artifact must start with
  `schema=zflow.github_pr.fix_result.v1`, contain exactly one
  `status=<fixed|not_actionable|failed>` line and exactly one `pushed=<true|false>`
  line. `fixed` requires one 40-hex `commit_sha=` matching HEAD, exactly one new
  direct child commit of the starting HEAD, and a clean worktree; if `pushed=true`,
  the commit must also match upstream. `not_actionable` and `failed` must leave
  HEAD unchanged, leave a clean worktree, omit `commit_sha=`, and report
  `pushed=false`. A valid `status=failed` artifact makes the command return
  nonzero.
- **Explicit advisor review opt-in**: `review` requires `--large-change` or
  `--high-risk`, uses route `review`, passes `--difficulty hard` so the configured
  advisor handles the reasoning-heavy path unless `--command` explicitly
  overrides it, asks for read-only behavior, and validates
  `schema=zflow.github_pr.review_result.v1`. A valid `status=failed` review
  artifact returns nonzero. Do not call it from normal create or fix flows;
  ordinary `fix` remains on the ordinary worker command.

## GitLab MR Review Loop

Use the explicit wrapper only for one allowed GitLab host, defaulting to the internal `git-biz`
GitLab (`git-biz.qianxin-inc.cn`); override with `ZGPT_GITLAB_HOST` (and `ZGPT_GITLAB_SSH_ALIAS`
for the corresponding SSH alias) to point at a different single host. GitHub and any other GitLab
host are rejected. It starts one deterministic supervisor for that MR, polls every 60 seconds for
15 minutes, and launches a visible fix worker only when a new actionable review item appears.

### Commands

```bash
# Create an MR and automatically start its review loop
zgpt-glab-mr.sh create --repo owner/repo --title "feat: ..." --description "..."

# Attach the loop to an existing MR
zgpt-glab-mr.sh attach https://git-biz.qianxin-inc.cn/group/repo/-/merge_requests/42

# Check status of a running loop (works from any cwd — state is global per MR)
zgpt-review-loop.sh status https://git-biz.qianxin-inc.cn/group/repo/-/merge_requests/42

# List all active review loops (works from any cwd)
zgpt-review-loop.sh list

# Stop a review loop
zgpt-review-loop.sh stop https://git-biz.qianxin-inc.cn/group/repo/-/merge_requests/42

# Show current configuration including trusted-reviewers and allow-push
zgpt-review-loop.sh config

# Start with trusted reviewers and push allowed
zgpt-review-loop.sh start https://git-biz.qianxin-inc.cn/group/repo/-/merge_requests/42 \
  --cwd /path/to/worktree \
  --trusted-reviewers alice,bob \
  --allow-push true
```

### MR Creation Workflow

```bash
zgpt-glab-mr.sh create --repo owner/repo --title "feat: ..." --description "..."
```

The wrapper is explicit: it does not intercept an unrelated `glab mr create`. Pass `--no-review`
when no loop is wanted. The lower-level command also attaches an existing MR and forks its own
supervisor, so do not append `&`:

```bash
zgpt-review-loop.sh start https://git-biz.qianxin-inc.cn/group/repo/-/merge_requests/42
```

### Safety Behavior

- **Exactly one supervisor per MR**: deduplication uses host + project path + IID.
  Attempting to start a second loop for the same MR prints `status=already_active`.
- **Global state per MR**: state files live under `$ZGPT_STATE_DIR_OVERRIDE/review-loops/`
  or `$(zgpt_state_root)/review-loops/` (default `/tmp/zflow/review-loops/`) independent of
  the current working directory. `list`, `status`, and `stop` can be called from any directory.
- **Portable process tree**: process discovery uses `ps -axo pid=,ppid=` with awk recursion
  instead of GNU `ps --ppid`, working on macOS/BSD and Linux alike.
- **3 rounds per review item**: the discussion ID is the stable key, falling back to a standalone
  note ID. An unchanged comment never consumes another attempt; only a new human follow-up in the
  same discussion can advance attempts 2 and 3. Different items have independent limits.
- **No force-push ever**: only normal new commits to the MR source branch after successful
  verification. Unsafe branch/repo/permissions are blocked and reported.
- **Reviewer-risk triage**: the visible fix worker decides whether a comment is actionable and
  gives correctness risk priority; a `status=not_actionable` result is recorded without consuming
  a fix attempt.
- **Trusted-reviewer allowlist**: set `ZGPT_REVIEW_LOOP_TRUSTED_REVIEWERS` to a comma-separated
  list of usernames whose review items and text-based LGTM/approve signals may drive the loop.
  When empty (default), no human comment launches a worker and no one's text is trusted — only
  GitLab API approval (`approved: true`) is terminal. Negative text such as
  `not lgtm`, bots, system notes, the current user, and `[zflow-review-loop]` notes are always
  ignored even when the author is trusted.
- **API approval remains terminal**: GitLab API `.approved == true` always stops the loop,
  independent of the trusted-reviewer allowlist.
- **Allow-push gate**: set `ZGPT_REVIEW_LOOP_ALLOW_PUSH=true` or `=1` to permit fix workers to
  push changes. When false (default), editing workers are not launched; instead a manager
  authorization note is posted and the item is marked seen without consuming a fix attempt.
- **Result artifact schema**: every fix worker artifact must start with
  `schema=zflow.review_loop.worker_result.v1` on the first line, followed by exactly one
  `status=<fixed|not_actionable|failed>` line. `fixed` requires exactly one `commit_sha=<sha>` line
  and the commit must match both HEAD and upstream. `not_actionable` and `failed` must not contain
  `commit_sha=`.
- **Action reports**: every attempted fix posts its item ID, attempt number, verification result,
  and pushed commit SHA. Merge, approval, timeout, cancellation, or blockers post a final status
  before the loop stops; a post failure is surfaced as `blocked_post`.
- **Persistence**: `attempts.json` and `last-seen.json` survive restarts under the global per-MR
  state directory.

### Lifecycle

1. The supervisor polls paginated notes, discussions, approval, and MR state every 60 seconds.
2. If `ZGPT_REVIEW_LOOP_ALLOW_PUSH` is false (default), new eligible items post a manager
   authorization required note instead of launching a worker. The item is marked seen without
   consuming a fix attempt.
3. When push is allowed and the reviewer is on the trusted allowlist, a new eligible item launches
   a visible worker through `zgpt-run-worker.sh`.
4. The worker writes an artifact with schema `zflow.review_loop.worker_result.v1`, exactly one
   status, and (for `fixed`) one `commit_sha=` matching both HEAD and upstream.
5. The supervisor posts the result and waits for a new reviewer follow-up.
6. It stops after API approval, merge/close, cancellation, blocker, or the 900-second observation
   window. That window is checked between items and never terminates an in-flight fix worker.
7. Resolved discussion threads are skipped.
8. Any owned-worktree cleanup runs before the terminal status file is published, never after — a
   poller that observes a terminal status is guaranteed the worktree/branch are already gone.

### Limitations

- Uses `glab` CLI for GitLab API calls; not compatible with GitHub or Bitbucket.
- Host scope is a strict single-host allowlist, not "any GitLab host": it defaults to internal
  `git-biz.qianxin-inc.cn` but is configurable via `ZGPT_GITLAB_HOST`/`ZGPT_GITLAB_SSH_ALIAS`.
  Repository SSH origins must use either the configured SSH alias (default `git-biz`) or the
  configured exact hostname; every other host is still rejected.
- Polls both paginated flat notes and discussion threads via the GitLab API; does not parse
  `glab mr view` localized text output.
- Fix selection and implementation are AI-driven; polling, pagination, dedupe, limits, terminal
  decisions, and MR status notes are deterministic shell behavior.
- Does not auto-merge the MR. The manager or a human must merge.
- Force-push is explicitly prohibited; rebase workflows are not supported.
- Merge cleanup removes a worktree/local branch only when it is auto-detected as a `/tmp/zflow`
  worktree on a `zgpt/*` branch, or when started with `--owned-worktree`. It never deletes a remote
  branch or an arbitrary checkout.

### Environment Overrides

| Variable | Default | Purpose |
|---|---|---|
| `ZGPT_REVIEW_LOOP_POLL_INTERVAL` | 60 | Poll interval in seconds |
| `ZGPT_REVIEW_LOOP_MAX_ATTEMPTS` | 3 | Max fix attempts per finding |
| `ZGPT_REVIEW_LOOP_MAX_RUNTIME` | 900 | Observation window in seconds; independent of fix-worker runtime |
| `ZGPT_REVIEW_LOOP_TRUSTED_REVIEWERS` | (empty) | Comma-separated usernames whose review items and text LGTM/approve signals may drive the loop. Empty = default-deny; only API approval is terminal. |
| `ZGPT_REVIEW_LOOP_ALLOW_PUSH` | false | Literal `true` or `1` to allow fix workers to push changes. When false, editing workers are not launched and a manager authorization note is posted. |
| `ZGPT_GLAB_CMD` | glab | Path to glab CLI |
| `ZGPT_GITLAB_HOST` | `git-biz.qianxin-inc.cn` | The single allowed GitLab host. Changes which one host is allowed; other GitLab instances and GitHub are still rejected. |
| `ZGPT_GITLAB_SSH_ALIAS` | `git-biz` | SSH host alias accepted for `git@<alias>:...` origins matching the allowed host, since the alias in `~/.ssh/config` is conventionally shorter than the hostname and is not derivable from it. |
| `ZGPT_FAKE_SLEEP` | (unset) | If set, sleep is no-op |
| `ZGPT_FAKE_TIME` | (unset) | Fake timestamp for current time |
| `ZGPT_FAKE_NOTES_FILE` | (unset) | Path to fake notes JSON file |
| `ZGPT_FAKE_DISCUSSIONS_FILE` | (unset) | Path to fake discussions JSON file |
| `ZGPT_FAKE_APPROVALS_FILE` | (unset) | Path to fake approvals JSON file |
| `ZGPT_FAKE_RUN_WORKER` | (unset) | If set, run-worker is no-op |
| `ZGPT_STATE_DIR_OVERRIDE` | (unset) | Override state root for tests |

## Manager Conventions

- Use Claude/Codex/startcodex as the manager.
- Keep related worker panes in the same repo-named tab unless the user asks otherwise.
- Panes and their tab are labeled automatically: `zgpt-worker-pane.sh` renames each pane to
  `<role>:<name> · <repo>@<branch>` (e.g. `worker:auth-fix · zflow@zgpt/auth-fix`) via
  `herdr pane rename` right after the pane exists, and renames a same-tab manager tab still
  carrying its auto-generated numeric label. `--name` still drives the `<name>` segment and the
  log-only `agent_name=`; pick a task- or repo-scoped `--name` (`auth-fix`, `zflow-docs`) so the
  label stays meaningful. `role` defaults to `worker`; `zgpt-run-worker.sh` passes its resolved
  command tier through `--role` automatically (`fast_*`→`fleet`, `advisor_*`→`advisor`, else
  `worker`), and `--role manager` overrides it so a keep-alive manager pane labels `manager:`
  (`zgpt-worker-pane.sh --role` accepts `manager` and `supermanager`; both also select
  `ZFLOW_MANAGER_CMD` as the default command). Labeling and the accompanying
  `report-metadata` status overlay are both advisory
  (`|| true`) and never fail a launch; opt out of the tab rename with `--no-tab-rename`.
- Use repo-local worktrees for product repo edits. Do not let two workers edit the same checkout.
- For risky work, launch workers with report-only prompts first.
- If a worker must write files, state the exact writable path in the prompt.
- **Treat the worker's report as a claim, not evidence.** Check the raw log/diff/cluster state for the
  specific fields the claim rests on. Observed failures: a worker reported "resources cleaned up" while
  leaving a live CR behind, and reported "all PASS" after quietly weakening a test (it swapped a running
  VM for a stopped one, so the behavior under test never occurred). **PASS is not coverage** — read what
  the assertions actually assert.
- **Accept a copy only after diffing it against its reference.** When a worker's task was to mirror an
  existing implementation, diff the new function against the model one and enumerate every branch the
  model has that the copy lacks. Reviewing only the added lines misses what was dropped.
- State red lines in the prompt for anything you would refuse to accept — "do not downgrade the scenario
  to make it pass", "report the failure instead of working around it", "do not widen scope" — and check
  those specific lines on return.
- Prefer natural-language prompt injection into AI worker CLIs before auto-running generated shell
  commands.
- **`--close` default for implement workers.** Add `--close` on ordinary implement / inspect /
  verify / fleet runs. Leave it off only when the next action is more work on that same pane
  (manager steers corrections into the live worker). After a closed run, start a new bounded
  worker for further edits — do not leave panes open "just in case."

## Cross-Repo Usage

This skill is a reusable cross-repo worker launcher; it is not tied to zflow. Two things must be
reachable from the other repo: the skill and the scripts.

Install once from the zflow checkout:

```bash
scripts/install-skill.sh
```

This symlinks the skill into `~/.claude/skills` and `~/.agents/skills` so Claude and Codex discover
it in every repo. Use `--claude` or `--codex` to install into just one; `--uninstall` removes the
symlinks.

Use it in another repo:

```bash
cd ~/git/another-repo
source ~/.claude/skills/zflow-workers/scripts/zgpt-common.sh
run_dir="$(zgpt_state_dir "$PWD")/runs/audit-$(date +%Y%m%d-%H%M%S)"; mkdir -p "$run_dir"
~/.claude/skills/zflow-workers/scripts/zgpt-run-worker.sh \
  --name worker-inspect --cwd "$PWD" \
  --artifact "$run_dir/inspect.md" --close \
  --task "Inspect this repo. Do not edit files. Report structure and risks."
```

For writable work:

1. Create an isolated worktree with `zgpt-worktree.sh create --name <slice>`.
2. Pass that path as `--cwd` to the worker.
3. Review and integrate as manager.
4. Clean up with `zgpt-worktree.sh remove --name <slice> --delete-branch`.

## herdr pane label hook

A hand-started Claude session (no `ZFLOW_WORKER_DEPTH`, no pane label) shows only
`claude` on its herdr pane border, because herdr falls back to the detected agent
label. `hooks/herdr-pane-label.sh` fixes that by labelling the session's own pane
(`HERDR_PANE_ID`) `human:<repo> · <title>` on SessionStart, then refreshing on
Stop (async) once the conversation has a title.

It ships inside this skill, so the installed path
`~/.claude/skills/zflow-workers/hooks/herdr-pane-label.sh` is stable and tracks
`git pull`. Wire it into `~/.claude/settings.json` once:

```bash
scripts/install-skill.sh                          # symlink the skill (needed first)
scripts/install-herdr-pane-label-hook.sh          # or: make install-herdr-hook
scripts/install-herdr-pane-label-hook.sh --uninstall   # undo; removes only its entries
```

The installer merges with jq (never overwrites), backs up settings.json to
`settings.json.bak` before the first change, and is idempotent — re-running adds
nothing. It registers on `SessionStart` and on `Stop` with `"async": true`. The
hook always exits 0 and skips zflow worker panes (both the `ZFLOW_WORKER_DEPTH`
env guard and a `worker:`/`fleet:`/`advisor:`/`manager:`/`supermanager:` existing-label
guard), so a worker or keep-alive manager that is itself a Claude session never
destroys the orchestrator's label. A session started with `ZFLOW_SUPERMANAGER=1`
is labelled `supermanager:fleet · multi-project` instead of `human:<repo>`.

Known herdr limitation: pane borders only render on tabs with **2+ panes**, so a
single-pane tab shows no title regardless. This is not a bug to fix here — see
`docs/herdr-single-pane-title-finding.md`.

## Testing

```bash
make test        # offline suites only, from the zflow repo root
make test-live   # offline suites + the herdr-dependent live cross-CLI smoke test
make lint        # shellcheck -S warning over skill scripts, tests, and scripts/
make check       # lint then test
```

`tests/run-all.sh` runs every `.claude/skills/zflow-workers/tests/*-smoke.sh` it finds — new
offline suites (CLI-family classification, difficulty-tier routing, etc.) are picked up
automatically. `zgpt-live-cross-cli-smoke.sh` is the one suite excluded by default; it requires
a live herdr session and only runs under `ZFLOW_RUN_LIVE_TESTS=1` (`make test-live`). CI runs
`make lint` and `make test` on every push and PR.

## Useful Commands

```bash
herdr session list --json
herdr agent list
herdr pane read w1:p8 --source visible --lines 40
herdr pane read w1:p8 --source recent-unwrapped --lines 200
herdr pane send-text w1:p8 "continue with the bounded task"
herdr pane send-keys w1:p8 Enter
herdr pane close w1:p8
# fleet survey + steer (Supermanager Loop)
zgpt-superboard.sh
zgpt-steer.sh -p w1:p8 "合入 main 并清理" --confirm
# manager→super: wait for one manager, or quietly watch a registered fleet
zgpt-wait-manager.sh --pane-id w1:p5 --artifact "$run_dir/a5.md" --timeout 1800
zgpt-watch-managers.sh register w1:p5 --workstream zflow --artifact "$run_dir/a5.md"
zgpt-watch-managers.sh once                 # prints event= lines only on deltas
zgpt-watch-managers.sh watch --exit-on-delta  # wake-up job: exits on the first delta
# manager→human: flash the herdr UI when attention is wanted (no-op on repeated state)
zgpt-manager-notify.sh --status blocked --workstream zflow --body "needs a decision"
```
