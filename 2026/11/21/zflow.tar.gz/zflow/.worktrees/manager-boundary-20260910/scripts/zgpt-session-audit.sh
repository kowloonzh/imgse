#!/usr/bin/env bash
# zgpt-session-audit.sh — session-discipline scorecard for manager sessions.
#
# Audits one or more Claude Code JSONL transcripts and reports manager-discipline
# violations: edits in a primary clone (not a worktree), worker launches via
# --command instead of --difficulty routing, --artifact-less launches, and
# sleep-polling a worker pane instead of letting zgpt-run-worker.sh block.
#
# Dependencies: bash, jq, git. No python3.
#
# Usage:
#   zgpt-session-audit.sh [<session.jsonl> ...] [--project <slug>] [--latest <n>]
#                          [--format table|json] [--strict] [--min-turns <n>]
#
# Exit codes:
#   0  ok (or violations found when --strict not set)
#   1  invocation error / --strict and violations present
#   2  missing dependency (jq)
set -euo pipefail

script_name="$(basename "$0")"

die() { printf '%s: %s\n' "$script_name" "$*" >&2; exit 1; }

command -v jq >/dev/null 2>&1 || die "jq is required (no python3 fallback)"
command -v git >/dev/null 2>&1 || true  # git optional; classify as scratch/unknown without it

# ── arg parsing ──────────────────────────────────────────────────────────────
files=()
project=""
latest=""
format="table"
strict=0
min_turns=25

while [[ $# -gt 0 ]]; do
  case "$1" in
    --project) project="${2:?--project needs a slug}"; shift 2;;
    --latest)  latest="${2:?--latest needs a number}"; shift 2;;
    --format)  format="${2:?--format needs table|json}"; shift 2;;
    --strict)  strict=1; shift;;
    --min-turns) min_turns="${2:?--min-turns needs a number}"; shift 2;;
    -h|--help)
      sed -n '2,/^set -euo/p' "$0" | sed 's/^# \{0,1\}//'
      exit 0;;
    --) shift; while [[ $# -gt 0 ]]; do files+=("$1"); shift; done;;
    -*) die "unknown option: $1";;
    *) files+=("$1"); shift;;
  esac
done

[[ "$format" == "table" || "$format" == "json" ]] || die "--format must be table or json"

# Resolve the file set.
claude_projects_dir="${CLAUDE_PROJECTS_DIR:-$HOME/.claude/projects}"

if [[ ${#files[@]} -eq 0 ]]; then
  # Multi-file mode. Default latest depends on whether --project was given.
  if [[ -z "$latest" ]]; then
    if [[ -n "$project" ]]; then latest=1; else latest=0; fi
  fi

  search_dirs=()
  if [[ -n "$project" ]]; then
    search_dirs=("$claude_projects_dir/$project")
  else
    [[ -d "$claude_projects_dir" ]] || die "no projects dir: $claude_projects_dir"
    while IFS= read -r -d '' d; do search_dirs+=("$d"); done \
      < <(find "$claude_projects_dir" -mindepth 1 -maxdepth 1 -type d -print0)
  fi

  mapfile -t files < <(
    for d in "${search_dirs[@]}"; do
      [[ -d "$d" ]] || continue
      find "$d" -maxdepth 1 -name '*.jsonl' -type f -printf '%T@ %p\n' 2>/dev/null || true
    done | sort -rn | awk '{ $1=""; sub(/^ /,""); print }' | \
      if [[ "$latest" -gt 0 ]]; then head -n "$latest"; else cat; fi
  )
fi

[[ ${#files[@]} -gt 0 ]] || die "no session files to audit"

# ── per-directory git classification cache ───────────────────────────────────
# classify_dir <dir>  → echoes: scratch|worktree|primary|unknown
declare -A dir_class_cache
classify_dir() {
  local dir="$1"
  [[ -n "$dir" ]] || { echo unknown; return; }
  [[ -n "${dir_class_cache[$dir]:-}" ]] && { echo "${dir_class_cache[$dir]}"; return; }

  # /tmp and friends are scratch.
  case "$dir" in
    /tmp|/tmp/*|/var/tmp|/var/tmp/*|/dev/shm|/dev/shm/*) dir_class_cache[$dir]=scratch; echo scratch; return;;
  esac

  command -v git >/dev/null 2>&1 || { dir_class_cache[$dir]=unknown; echo unknown; return; }

  # git -C on a missing dir fails → scratch-ish (not in a repo). Walk up to nearest
  # existing ancestor if the path itself no longer exists.
  local probe="$dir"
  if [[ ! -d "$probe" ]]; then
    local parent
    parent="$(dirname "$probe")"
    while [[ "$parent" != "/" && ! -d "$parent" ]]; do parent="$(dirname "$parent")"; done
    if [[ ! -d "$parent" ]]; then dir_class_cache[$dir]=unknown; echo unknown; return; fi
    probe="$parent"
  fi

  local toplevel common
  if ! toplevel="$(git -C "$probe" rev-parse --show-toplevel 2>/dev/null)"; then
    dir_class_cache[$dir]=scratch; echo scratch; return
  fi
  if ! common="$(git -C "$probe" rev-parse --git-common-dir 2>/dev/null)"; then
    # No common dir info → treat as primary (conservative) only if toplevel resolved.
    dir_class_cache[$dir]=primary; echo primary; return
  fi

  # Resolve common to an absolute path for comparison.
  common="$(cd "$probe" && cd "$common" 2>/dev/null && pwd || echo "$common")"
  # A linked worktree's common dir lives OUTSIDE its own checkout (points at the
  # main repo's .git). A primary clone's common dir is its own .git.
  local own_git="$toplevel/.git"
  if [[ "$common" -ef "$own_git" ]] || [[ "$common" == "$own_git" ]]; then
    # Resolved to a primary clone. A path that no longer exists and carries a
    # .worktrees component is a deleted worktree → unknown, never reported as a
    # primary-clone edit (walking up would otherwise land in the primary).
    if [[ ! -d "$dir" ]] && [[ "$dir" == */.worktrees || "$dir" == */.worktrees/* ]]; then
      dir_class_cache[$dir]=unknown; echo unknown; return
    fi
    dir_class_cache[$dir]=primary; echo primary; return
  fi
  dir_class_cache[$dir]=worktree; echo worktree; return
}

# ── launch detection helpers ─────────────────────────────────────────────────
# is_launch_block <command> → 0 if the Bash block launches zgpt-run-worker.sh as
# a command on any line. Split the command on newlines; a line is a launch when
# its first token (after stripping a leading '(' or '$') ends in
# zgpt-run-worker.sh, or is bash/nohup/timeout with zgpt-run-worker.sh in the
# second token. Reading the script (grep/cat/sed/head/…) is not a launch. One
# launch per Bash block even if several lines match.
is_launch_block() {
  local cmd="$1"
  local line tok rest tok2 _rest2 base base2
  while IFS= read -r line; do
    [[ -n "${line//[[:space:]]/}" ]] || continue
    tok="${line#"("}"; tok="${tok#"$"}"
    read -r tok rest <<< "$tok"
    tok="${tok%\\}"                         # drop line-continuation backslash
    base="${tok##*/}"
    if [[ "$base" == *"zgpt-run-worker.sh" ]]; then
      return 0
    fi
    case "$base" in
      bash|nohup|timeout)
        read -r tok2 _rest2 <<< "$rest"
        tok2="${tok2%\\}"
        base2="${tok2##*/}"
        [[ "$base2" == *"zgpt-run-worker.sh" ]] && return 0
        ;;
    esac
  done <<< "$cmd"
  return 1
}

# ── per-file audit ───────────────────────────────────────────────────────────
audit_one() {
  local file="$1"
  [[ -r "$file" ]] || { jq -nc --arg f "$file" --arg e "unreadable" '{file:$f,error:$e}'; return; }

  # Emit one JSON object describing the session.
  # We do this in two jq passes: first reduce over records, then post-process.
  jq -n --arg file "$file" --slurpfile raw <(jq -c 'select(.type=="assistant")' "$file" 2>/dev/null || true) '
    def clamp0(x): if x < 0 then 0 else x end;

    ($raw // []) as $rows
    | if ($rows | length) == 0 then
        {file:$file, error:"no assistant records", turns:0}
      else
        # Dedupe by .message.id (one row per content block of the same response).
        # Preserve first-seen order; keep the first row for each id.
        ( $rows
          | map(.mid = (.message.id // ("noid:" + (.//{}|tostring))))
          | group_by(.mid)
          | map(.[0])
        ) as $turns
        | ($turns | length) as $nturns
        | ($turns | map(.message.usage.input_tokens // 0)) as $ins
        | ($turns | map(.message.usage.cache_read_input_tokens // 0)) as $cached
        | ($turns | map(.message.usage.cache_creation_input_tokens // 0)) as $cc
        | ($ins | add // 0) as $prompt_tokens
        | ($cached | add // 0) as $cached_sum
        # suspect accounting: more than 10% of turns have cache_read > input
        | ( [$turns[] | (.message.usage.cache_read_input_tokens // 0) > ((.message.usage.input_tokens // 0) + 0)] | map(select(.)) | length ) as $overcount
        | (if ($nturns > 0) and ($overcount * 10 > $nturns) then true else false end) as $suspect
        # uncached per turn clamped at 0 before sum
        | ( [$turns[] | clamp0((.message.usage.input_tokens // 0) - (.message.usage.cache_read_input_tokens // 0))] | add // 0 ) as $uncached
        # ctx per turn = input_tokens + cache_creation_input_tokens
        | ( [$turns[] | ((.message.usage.input_tokens // 0) + (.message.usage.cache_creation_input_tokens // 0))] ) as $ctxs
        | (if ($ctxs|length)>0 then ($ctxs|sort) else [] end) as $ctxs_sorted
        | (if ($ctxs_sorted|length)>0 then ($ctxs_sorted[($ctxs_sorted|length)/2|floor]) else 0 end) as $median
        | (if ($ctxs_sorted|length)>0 then ($ctxs_sorted|last) else 0 end) as $peak
        # model = most frequent non-null .message.model
        | ( [$turns[].message.model] | map(select(. != null)) | group_by(.) | sort_by(length) | last | .[0] // null ) as $model
        # timestamps
        | ( [$turns[].timestamp] | map(select(. != null)) | sort | .[0] ) as $first_ts
        | ( [$turns[].timestamp] | map(select(. != null)) | sort | .[0] ) as $first_asst_ts
        # tool_use blocks span ALL rows: the transcript writes one row per content
        # block of the same response, so the deduped $turns (first row per id)
        # would drop most tool_use blocks. Keep the per-id dedupe for the
        # usage/model/timestamp metrics above; scan tool_use with no dedupe here.
        | ( [ $rows[]
              | .message.content // []
              | .[]
              | select(.type=="tool_use")
              | select(.name=="Edit" or .name=="Write" or .name=="MultiEdit" or .name=="NotebookEdit")
              | .input.file_path // empty
            ] ) as $edit_paths
        | ($edit_paths | length) as $edits
        # edits by directory for later shell classification (pass dirs out)
        | ( [$edit_paths[] | (sub("/[^/]+$"; ""))] | unique ) as $edit_dirs
        # launches + flags + polls: scan Bash tool_use blocks across all rows.
        | ( [ $rows[]
              | .message.content // []
              | .[]
              | select(.type=="tool_use" and .name=="Bash")
              | (.input.command // "") as $c
              | {cmd:$c, ts:(. // {} | .timestamp // null)}
            ] ) as $bash_blocks
        | ( [ $bash_blocks[].cmd ] ) as $all_cmds
        | ( [ $bash_blocks[] | select((.cmd|tostring) | test("zgpt-run-worker\\.sh")) ] ) as $maybe_launches
        | {
          file: $file,
          turns: $nturns,
          prompt_tokens: $prompt_tokens,
          cached: $cached_sum,
          uncached: $uncached,
          median_ctx: $median,
          peak_ctx: $peak,
          model: $model,
          token_accounting: (if $suspect then "suspect" else "ok" end),
          suspect: $suspect,
          edits: $edits,
          edit_paths: $edit_paths,
          edit_dirs: $edit_dirs,
          maybe_cmds: [ $maybe_launches[].cmd ],
          all_bash: $all_cmds,
          first_ts: $first_asst_ts
        }
      end
  ' 2>/dev/null
}

# ── main ─────────────────────────────────────────────────────────────────────
total_violations=0
any_error=0
header_printed=0

for f in "${files[@]}"; do
  raw="$(audit_one "$f")" || { any_error=1; continue; }
  err="$(printf '%s' "$raw" | jq -r '.error // empty' 2>/dev/null || true)"
  if [[ -n "$err" ]]; then
    # Unreadable file = invocation failure → non-zero exit. An empty transcript
    # (no assistant records) is a legitimate zero-turn row, not a failure.
    [[ "$err" == "unreadable" ]] && any_error=1
    if [[ "$format" == "json" ]]; then
      printf '%s\n' "$raw"
    else
      printf '%s\tERROR: %s\n' "$f" "$err"
    fi
    continue
  fi

  nturns="$(printf '%s' "$raw" | jq -r '.turns // 0')"
  # Skip trivially short sessions in multi-file mode.
  if [[ ${#files[@]} -gt 1 ]] && [[ "$nturns" -lt "$min_turns" ]]; then
    continue
  fi

  # ── classify edits via shell (cache per dir) ──
  edit_paths_json="$(printf '%s' "$raw" | jq -c '.edit_paths // []')"
  primary_count=0
  unknown_count=0
  primary_paths=()
  declare -A seen_viol_path=()
  # iterate paths
  while IFS= read -r p; do
    [[ -n "$p" ]] || continue
    dir="$(dirname "$p")"
    cls="$(classify_dir "$dir")"
    if [[ "$cls" == "primary" ]]; then
      primary_count=$((primary_count+1))
      if [[ -z "${seen_viol_path[$p]:-}" ]]; then
        seen_viol_path[$p]=1
        primary_paths+=("$p")
      fi
    elif [[ "$cls" == "unknown" ]]; then
      unknown_count=$((unknown_count+1))
    fi
  done < <(printf '%s' "$edit_paths_json" | jq -r '.[]?')

  # ── launches: real launches only, with --command / --artifact flags ──
  launches=0
  command_flag_count=0
  no_artifact_count=0
  launch_cmds=()
  declare -A seen_launch_cmd=()
  while IFS= read -r cjson; do
    [[ -n "$cjson" ]] || continue
    # Commands are emitted @json so multi-line Bash blocks survive as one item.
    c="$(printf '%s' "$cjson" | jq -r .)"
    if is_launch_block "$c"; then
      launches=$((launches+1))
      if [[ -z "${seen_launch_cmd[$c]:-}" ]]; then
        seen_launch_cmd[$c]=1
        launch_cmds+=("$c")
      fi
      # --command passed anywhere in the launch block?
      if printf '%s' "$c" | grep -Eq -- '--command[[:space:]]'; then
        command_flag_count=$((command_flag_count+1))
      fi
      # no --artifact?
      if ! printf '%s' "$c" | grep -Eq -- '--artifact[[:space:]]'; then
        no_artifact_count=$((no_artifact_count+1))
      fi
    fi
  done < <(printf '%s' "$raw" | jq -c '.maybe_cmds[]?')

  # ── poll waits ──
  polls=0
  poll_cmds=()
  while IFS= read -r cjson; do
    [[ -n "$cjson" ]] || continue
    c="$(printf '%s' "$cjson" | jq -r .)"
    if printf '%s' "$c" | grep -q 'sleep'; then
      if printf '%s' "$c" | grep -Eq 'herdr pane read|herdr pane list|git status|\.output'; then
        polls=$((polls+1))
        poll_cmds+=("$c")
      fi
    fi
  done < <(printf '%s' "$raw" | jq -c '.all_bash[]?')

  # ── time to first worker ──
  first_asst_ts="$(printf '%s' "$raw" | jq -r '.first_ts // empty')"
  ttfw="never"
  if [[ "$launches" -gt 0 ]] && [[ -n "$first_asst_ts" ]]; then
    # find first launch timestamp from the bash blocks that are real launches
    # We stored all_bash without ts; re-derive from file is costly — instead
    # approximate using first maybe_launch occurrence. For accuracy we re-scan
    # the file for the first real-launch command timestamp.
    first_launch_ts="$(jq -r '
      select(.type=="assistant")
      | .timestamp as $ts
      | (.message.content // [])[]
      | select(.type=="tool_use" and .name=="Bash")
      | (.input.command // "") as $c
      | select($c | test("zgpt-run-worker\\.sh"))
      | $ts
    ' "$f" 2>/dev/null | grep -v '^null$' | head -1 || true)"
    # We must still confirm it's a real launch (not a grep). Re-check via shell.
    # To keep it simple and correct, iterate the qualifying commands in order.
    first_launch_ts=""
    while IFS= read -r line; do
      ts="${line%%$'\t'*}"
      cjson="${line#*$'\t'}"
      c="$(printf '%s' "$cjson" | jq -r . 2>/dev/null || true)"
      if is_launch_block "$c"; then first_launch_ts="$ts"; break; fi
    done < <(jq -r '
      select(.type=="assistant")
      | .timestamp as $ts
      | (.message.content // [])[]
      | select(.type=="tool_use" and .name=="Bash")
      | (.input.command // "") as $c
      | select($c | test("zgpt-run-worker\\.sh"))
      | "\($ts)\t\($c | @json)"
    ' "$f" 2>/dev/null)
    if [[ -n "$first_launch_ts" ]]; then
      # compute diff as MM:SS (best-effort ISO8601 → epoch via date)
      t0="$(date -d "$first_asst_ts" +%s 2>/dev/null || echo 0)"
      t1="$(date -d "$first_launch_ts" +%s 2>/dev/null || echo 0)"
      if [[ "$t0" -gt 0 && "$t1" -gt 0 && "$t1" -ge "$t0" ]]; then
        diff=$((t1-t0))
        ttfw="$(printf '%02d:%02d' $((diff/60)) $((diff%60)))"
      fi
    fi
  fi

  edits_total="$(printf '%s' "$raw" | jq -r '.edits // 0')"
  delegation_ratio="$(awk -v l="$launches" -v e="$edits_total" 'BEGIN{ if(e<1)e=1; printf "%.2f", l/e }')"
  project_slug="$(basename "$(dirname "$f")")"
  model="$(printf '%s' "$raw" | jq -r '.model // "?"')"
  suspect="$(printf '%s' "$raw" | jq -r '.suspect // false')"

  # token display
  if [[ "$suspect" == "true" ]]; then
    uncached_disp="n/a(suspect)"
    uncached_json="null"
  else
    uncached_disp="$(printf '%s' "$raw" | jq -r '.uncached // 0')"
    uncached_json="$(printf '%s' "$raw" | jq -r '.uncached // 0')"
  fi

  violations=$(( primary_count + command_flag_count + no_artifact_count + polls ))
  total_violations=$((total_violations + violations))

  # ── emit ──
  if [[ "$format" == "json" ]]; then
    jq -nc \
      --arg file "$f" \
      --arg project "$project_slug" \
      --arg model "$model" \
      --argjson turns "$nturns" \
      --argjson edits "$edits_total" \
      --argjson primary "$primary_count" \
      --argjson unknown "$unknown_count" \
      --argjson launches "$launches" \
      --argjson command_flag "$command_flag_count" \
      --argjson no_artifact "$no_artifact_count" \
      --argjson polls "$polls" \
      --arg ttfw "$ttfw" \
      --arg delegation_ratio "$delegation_ratio" \
      --argjson uncached "$uncached_json" \
      --arg token_accounting "$(printf '%s' "$raw" | jq -r '.token_accounting')" \
      --argjson prompt_tokens "$(printf '%s' "$raw" | jq -r '.prompt_tokens // 0')" \
      --argjson cached "$(printf '%s' "$raw" | jq -r '.cached // 0')" \
      --argjson median_ctx "$(printf '%s' "$raw" | jq -r '.median_ctx // 0')" \
      --argjson peak_ctx "$(printf '%s' "$raw" | jq -r '.peak_ctx // 0')" \
      --argjson violations "$violations" \
      --argjson primary_paths "$(printf '%s' "${primary_paths[*]:-}" | jq -R . | jq -s .)" \
      --argjson launch_cmds "$(printf '%s' "${launch_cmds[*]:-}" | jq -R . | jq -s .)" \
      --argjson poll_cmds "$(printf '%s' "${poll_cmds[*]:-}" | jq -R . | jq -s .)" \
      '{file:$file,project:$project,model:$model,turns:$turns,edits:$edits,
        primary:$primary,unknown:$unknown,launches:$launches,command_flag:$command_flag,
        no_artifact:$no_artifact,polls:$polls,ttfw:$ttfw,delegation_ratio:$delegation_ratio,
        uncached:$uncached,token_accounting:$token_accounting,
        prompt_tokens:$prompt_tokens,cached:$cached,median_ctx:$median_ctx,peak_ctx:$peak_ctx,
        violations:$violations,
        primary_paths:$primary_paths,launch_cmds:$launch_cmds,poll_cmds:$poll_cmds}'
  else
    # table header (once)
    if [[ $header_printed == 0 ]]; then
      printf '%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\n' \
        "start" "project" "model" "turns" "uncached" "edits" \
        "primary" "launches" "--cmd" "no-art" "polls" "ttfw"
      header_printed=1
    fi
    # table row
    printf '%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\n' \
      "$(printf '%s' "$raw" | jq -r '.first_ts // "?" | sub("T.*";"")')" \
      "$project_slug" \
      "$model" \
      "$nturns" \
      "$uncached_disp" \
      "$edits_total" \
      "$primary_count" \
      "$launches" \
      "$command_flag_count" \
      "$no_artifact_count" \
      "$polls" \
      "$ttfw"
    # violation detail block
    if [[ $violations -gt 0 ]]; then
      printf '  violations for %s:\n' "$f"
      if [[ ${#primary_paths[@]} -gt 0 ]]; then
        printf '  primary-clone edits:\n'
        i=0
        for p in "${primary_paths[@]}"; do
          [[ $i -ge 10 ]] && break
          printf '    %s\n' "$p"
          i=$((i+1))
        done
      fi
      if [[ ${#launch_cmds[@]} -gt 0 ]]; then
        printf '  worker launches:\n'
        i=0
        for c in "${launch_cmds[@]}"; do
          [[ $i -ge 10 ]] && break
          printf '    %s\n' "$(printf '%s' "$c" | cut -c1-100)"
          i=$((i+1))
        done
      fi
      if [[ ${#poll_cmds[@]} -gt 0 ]]; then
        printf '  poll-waits:\n'
        i=0
        for c in "${poll_cmds[@]}"; do
          [[ $i -ge 10 ]] && break
          printf '    %s\n' "$(printf '%s' "$c" | cut -c1-100)"
          i=$((i+1))
        done
      fi
    fi
  fi
done

if [[ "$strict" == "1" && $total_violations -gt 0 ]]; then
  exit 1
fi
if [[ $any_error -eq 1 ]]; then
  exit 1
fi
exit 0
