#!/usr/bin/env bash
set -euo pipefail

usage() {
    cat <<'EOF'
Usage: zgpt-worker-pane.sh [options]
       zgpt-worker-pane.sh tab-for-pane <pane-id>

Launch a visible AI worker in a herdr pane. Same CLI interface as earlier
zgpt releases; current internals use herdr.

Subcommands:
  tab-for-pane <pane-id>    Print the tab id that owns the given pane id.
                            Uses herdr pane get (no jq flat-array footgun).

Placement is repo-aware. Precedence:
  explicit --tab-id  >  ZGPT_TAB_ID/ZJ_TAB_ID  >  ZGPT_MANAGER_PANE_ID/ZJ_PANE_ID  >
  herdr pane current  >  herdr pane process-info --current + pane get  >  repo-tab fallback.
If no anchor or live current pane is found, the script reuses or creates a repo-named tab,
agents:<basename of --cwd>, so background launches do not depend on session-wide UI focus.

When a worker launches another worker, the child worker must target the invoking worker's
own pane, not the grandparent manager pane. The launcher writes the new worker's own
pane id into the runner it generates, and the runner exports that id as
ZGPT_MANAGER_PANE_ID (and the ZJ_PANE_ID alias) while clearing stale inherited pane/tab
anchors. This keeps nested placement anchored to the current worker panel.

Options:
  --name <name>             Pane/worker name. Default: gpt-worker-<timestamp>
  --role <role>             Display tier word for the pane label:
                            worker|fleet|advisor|manager|supermanager.
                            Default: worker. zgpt-run-worker.sh passes its resolved
                            command_source tier (fast_*->fleet, advisor_*->advisor, else worker);
                            pass --role manager|supermanager for keep-alive manager panes,
                            which also selects ZFLOW_MANAGER_CMD as the default command.
  --no-tab-rename           Do not rename an anchored manager tab (repo tabs are already named).
  --no-restore-focus        Leave focus on the new worker pane instead of restoring the manager pane.
  --tab-id <id>             Target this herdr tab id explicitly (e.g. w1:t3).
  --print-created-tab-id    Also print created_tab_id=<id> when the helper creates a repo tab.
  --cwd <dir>               Working directory for the worker. Default: current directory
  --direction <dir>         Pane direction: right, down, left, up. Default: right
  --mode <mode>             interactive or print. Default: interactive
  --prompt <text>           Prompt to pass to the worker command
  --prompt-file <path>      Read prompt from a file
  --ready-timeout <secs>    Visible-editor readiness deadline for interactive prompt injection. Default: 90
  --ready-pattern <str>     Literal readiness text; higher precedence than --ready-regex.
  --ready-regex <regex>     Regex readiness expression. Pi defaults to its bordered editor.
  --log <path>              Log path for launcher metadata and print-mode output
  --command <cmd>           Worker command. Always wins. Defaults (in order) to
                            ZFLOW_MANAGER_CMD (falling back to ZFLOW_ADVISOR_CMD) for
                            --role manager|supermanager panes, else ZFLOW_WORKER_CMD, then
                            legacy GPT_WORKER_CMD, then startomni-alice
                            (see docs/omniroute-launcher-strengths.md if present in the target
                            repo for real, verified launcher names on this machine)
  --command-arg <arg>       Extra argument passed to the worker command. Repeatable
  --family <family>          Override CLI family: claude|codex|pi|grok|generic
  --close-on-exit           Close interactive pane when worker exits
  -h, --help                Show this help

Examples:
  ZFLOW_WORKER_CMD=glm zgpt-worker-pane.sh --name worker-docs --prompt "Read status and wait."
  zgpt-worker-pane.sh --mode print --name worker-summary --command "$ZFLOW_WORKER_CMD" --prompt "Summarize git status."

Output:
  Prints pane_id=<id> when herdr returns the created pane id (e.g. pane_id=w1:p8).
  Prints pane_label=<label> alongside it: the "<role>:<name> · <repo>@<branch>" label
  applied via `herdr pane rename` (best-effort; never fails the launch).
EOF
}

die() {
    printf 'error: %s\n' "$*" >&2
    exit 1
}
positive_integer() { [[ "${1:-}" =~ ^[1-9][0-9]*$ ]]; }

# Persist ownership of a repo tab this launcher created, so the last worker
# pane in it can remove the tab when it exits (a tab that predated the launcher
# has no marker). Safe to call more than once; empty arg is a no-op.
mark_owned_tab() {
    local tab="${1:-}"
    [[ -n "$tab" ]] || return 0
    local marker
    marker="$(zgpt_state_dir "$cwd")/owned-tabs/$tab"
    mkdir -p "$(dirname "$marker")"
    : >"$marker"
}

script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$script_dir/zgpt-common.sh"
source "$script_dir/zgpt-cli-adapter.sh"

# Subcommand dispatch
if [[ "${1:-}" == "tab-for-pane" ]]; then
    pane_arg="${2:-}"
    [[ -n "$pane_arg" ]] || die "tab-for-pane: missing <pane-id>"
    zgpt_herdr_require
    zgpt_herdr_resolve_session
    tab_id="$(zgpt_herdr_tab_id_for_pane "$pane_arg")" || true
    [[ -n "$tab_id" ]] || die "tab-for-pane: no tab found for pane $pane_arg (unknown pane or not in current session)"
    printf '%s\n' "$tab_id"
    exit 0
fi

name=""
role="worker"
command_explicit=false
no_tab_rename=false
restore_focus=true
cwd="$PWD"
direction="right"
direction_explicit=false
mode="interactive"
prompt=""
prompt_file=""
ready_pattern=""
ready_regex=""
log_path=""
worker_cmd="${ZFLOW_WORKER_CMD:-${GPT_WORKER_CMD:-startomni-alice}}"
worker_args=()
family_override="${ZGPT_CLI_FAMILY:-}"
close_on_exit=false
ready_timeout=90
tab_id=""
print_created_tab_id=false
created_tab_id=""
root_pane_id=""
runner=""
pane_id=""
launched=false
launcher_finished=false
cleanup_done=false

# Anchor handoff file: the outer launcher writes this worker's OWN pane id
# here immediately after `herdr agent start` returns, so the generated runner
# (which executes inside this pane) can export it as the nested placement anchor.
# Without this, a worker that inherits the grandparent manager's
# ZGPT_MANAGER_PANE_ID / ZGPT_TAB_ID would hand that stale anchor to any worker it
# launches, sending nested workers back to the manager pane instead of beside this
# worker (see LORE-276 / LORE-278).
# Reserve a private directory and final handoff path. The launcher writes the
# worker's OWN pane id to a temp file in this directory and atomically mv's
# the completed content into place, so the runner's [[ -f ]] poll only succeeds
# once the handoff is whole (never a partial/empty file). The private directory
# avoids collisions with stale handoff files from earlier runs.
handoff_dir="$(mktemp -d "${TMPDIR:-/tmp}/zgpt-worker-anchor.XXXXXX")"
handoff_file="$handoff_dir/anchor.env"

while [[ $# -gt 0 ]]; do
    case "$1" in
        --name)
            name="${2:?missing value for --name}"
            shift 2
            ;;
        --role)
            role="${2:?missing value for --role}"
            shift 2
            ;;
        --no-tab-rename)
            no_tab_rename=true
            shift
            ;;
        --no-restore-focus)
            restore_focus=false
            shift
            ;;
        --session)
            export ZGPT_HERDR_SESSION="${2:?missing value for --session}"
            shift 2
            ;;
        --tab-id)
            tab_id="${2:?missing value for --tab-id}"
            shift 2
            ;;
        --print-created-tab-id)
            print_created_tab_id=true
            shift
            ;;
        --cwd)
            cwd="${2:?missing value for --cwd}"
            shift 2
            ;;
        --direction)
            direction="${2:?missing value for --direction}"
            direction_explicit=true
            shift 2
            ;;
        --mode)
            mode="${2:?missing value for --mode}"
            shift 2
            ;;
        --prompt)
            prompt="${2:?missing value for --prompt}"
            shift 2
            ;;
        --prompt-file)
            prompt_file="${2:?missing value for --prompt-file}"
            shift 2
            ;;
        --ready-timeout)
            ready_timeout="${2:?missing value for --ready-timeout}"
            shift 2
            ;;
        --ready-pattern)
            ready_pattern="${2:?missing value for --ready-pattern}"
            shift 2
            ;;
        --ready-regex)
            ready_regex="${2:?missing value for --ready-regex}"
            shift 2
            ;;
        --log)
            log_path="${2:?missing value for --log}"
            shift 2
            ;;
        --command)
            worker_cmd="${2:?missing value for --command}"
            command_explicit=true
            shift 2
            ;;
        --command-arg)
            worker_args+=("${2:?missing value for --command-arg}")
            shift 2
            ;;
        --family)
            family_override="${2:?missing value for --family}"
            shift 2
            ;;
        --close-on-exit)
            close_on_exit=true
            shift
            ;;
        -h|--help)
            usage
            exit 0
            ;;
        *)
            die "unknown argument: $1"
            ;;
    esac
done

# Default command precedence: explicit --command always wins; otherwise a
# keep-alive manager pane (--role manager|supermanager) prefers ZFLOW_MANAGER_CMD
# over the ordinary worker chain, so manager sessions can run a different CLI
# without touching ZFLOW_WORKER_CMD. Unset ZFLOW_MANAGER_CMD falls back to the
# advisor command (ZFLOW_ADVISOR_CMD -> startbridge), mirroring the advisor's
# fallback to ZFLOW_MANAGER_CMD.
if [[ "$command_explicit" != true && ( "$role" == "manager" || "$role" == "supermanager" ) ]]; then
    worker_cmd="${ZFLOW_MANAGER_CMD:-${ZFLOW_ADVISOR_CMD:-startbridge}}"
fi

zgpt_herdr_require
zgpt_herdr_resolve_session

[[ -n "$worker_cmd" ]] || die "no worker command: pass --command <cmd> or set ZFLOW_MANAGER_CMD (manager panes) / ZFLOW_WORKER_CMD (legacy GPT_WORKER_CMD is also honored)"
command -v "$worker_cmd" >/dev/null || die "worker command not found: $worker_cmd"
[[ -d "$cwd" ]] || die "cwd does not exist: $cwd"
positive_integer "$ready_timeout" || die "--ready-timeout must be a positive integer"
worker_family="$(zgpt_cli_family "$worker_cmd" "$family_override")"
if zgpt_cli_startup_approve "$worker_cmd" "$family_override" ${worker_args[@]+"${worker_args[@]}"}; then
    approve_flag="$(zgpt_cli_approve_flag "$worker_cmd" "$family_override")"
    if [[ -n "$approve_flag" ]]; then
        worker_args+=("$approve_flag")
    fi
fi

case "$direction" in
    right|down) ;;
    left|up)
        # herdr agent start only supports right|down; map left->right, up->down
        # as graceful fallback (direction is a hint for split orientation)
        printf 'warning: herdr only supports --split right|down; mapping %s->%s\n' \
            "$direction" "$( [[ "$direction" == "left" ]] && printf 'right' || printf 'down')" >&2
        [[ "$direction" == "left" ]] && direction="right" || direction="down"
        ;;
    *) die "invalid --direction: $direction" ;;
esac

case "$mode" in
    interactive|print) ;;
    *) die "invalid --mode: $mode" ;;
esac

case "$role" in
    worker|fleet|advisor|manager|supermanager) ;;
    *) die "invalid --role: $role (must be worker, fleet, advisor, manager, or supermanager)" ;;
esac

if [[ -n "$prompt_file" ]]; then
    [[ -f "$prompt_file" ]] || die "prompt file does not exist: $prompt_file"
    prompt="$(<"$prompt_file")"
fi

if [[ -z "$name" ]]; then
    name="gpt-worker-$(date +%Y%m%d-%H%M%S)"
fi
pane_label="$(zgpt_pane_label "$role" "$name" "$cwd")"

# herdr manager pane anchor: ZGPT_MANAGER_PANE_ID / ZJ_PANE_ID.
manager_pane_id="${ZGPT_MANAGER_PANE_ID:-${ZJ_PANE_ID:-}}"
restore_focus_pane_id=""
if [[ "$restore_focus" == true && -n "$manager_pane_id" ]]; then
    # Verify the pane exists in herdr
    if hd pane get "$manager_pane_id" >/dev/null 2>&1; then
        restore_focus_pane_id="$manager_pane_id"
    fi
fi

# Resolve placement metadata. The helper already preserves explicit/env/current
# precedence and falls back to the repo tab when no live current pane is known.
placement_meta="$(zgpt_herdr_resolve_target_placement "$tab_id" "$cwd")"
placement_rc=$?
if [[ "$placement_rc" -ne 0 ]]; then
    exit "$placement_rc"
fi

target_tab_id="$(printf '%s\n' "$placement_meta" | sed -n 's/^target_tab_id=//p' | sed -n '1p')"
created_tab_id="$(printf '%s\n' "$placement_meta" | sed -n 's/^created_tab_id=//p' | sed -n '1p')"
placement_source="$(printf '%s\n' "$placement_meta" | sed -n 's/^placement_source=//p' | sed -n '1p')"
manager_pane_id="$(printf '%s\n' "$placement_meta" | sed -n 's/^manager_pane_id=//p' | sed -n '1p')"
placement_reason="$(printf '%s\n' "$placement_meta" | sed -n 's/^placement_reason=//p' | sed -n '1p')"
root_pane_id="$(printf '%s\n' "$placement_meta" | sed -n 's/^root_pane_id=//p' | sed -n '1p')"

# Persist ownership so later workers reusing this repo tab can remove it when
# they are the last pane.  A tab that predated the launcher has no marker.
mark_owned_tab "$created_tab_id"

if [[ -n "$target_tab_id" ]]; then
    # Previously skipped renaming when placement_source was herdr-pane-current
    # or herdr-process-info-current (the manager's own detected tab), which left
    # a manager's numerically-labeled tab ("1", "2") unnamed forever. The
    # numeric-label guard below is what actually protects a deliberately named
    # tab, so that guard alone is sufficient; --no-tab-rename remains the
    # explicit opt-out.
    if [[ "$no_tab_rename" != true ]]; then
        tab_label="$(zgpt_repo_tab_name "$cwd")"
        current_tab_label="$(zgpt_herdr_tab_label_for_id "$target_tab_id" || true)"
        # Rename only if the tab still has its auto-generated numeric label (e.g. "1", "2")
        if [[ "$current_tab_label" =~ ^[0-9]+$ ]]; then
            hd tab rename "$target_tab_id" "$tab_label" >/dev/null 2>&1 || true
        fi
    fi
fi

safe_name="$(printf '%s' "$name" | tr -c 'A-Za-z0-9_.-' '-')"
run_suffix="$(date +%Y%m%d-%H%M%S)-$$-${RANDOM}"
agent_name="worker-${safe_name}-${run_suffix}"
if [[ -z "$log_path" ]]; then
    log_path="$(zgpt_state_dir "$cwd")/logs/agents/$safe_name-$run_suffix.log"
fi

log_dir="$(dirname "$log_path")"
mkdir -p "$log_dir"
{
    printf '[%s] launch name=%s mode=%s cwd=%s direction=%s command=%s args=%q\n' \
        "$(date '+%Y-%m-%dT%H:%M:%S%z')" "$name" "$mode" "$cwd" "$direction" "$worker_cmd" "${worker_args[*]:-}"
    printf '[%s] family=%s agent_name=%s pane_label=%s\n' "$(date '+%Y-%m-%dT%H:%M:%S%z')" "$worker_family" "$agent_name" "$pane_label"
    [[ -n "$placement_source" ]] && printf '[%s] placement_source=%s\n' "$(date '+%Y-%m-%dT%H:%M:%S%z')" "$placement_source" || true
    [[ -n "$target_tab_id" ]] && printf '[%s] target_tab_id=%s\n' "$(date '+%Y-%m-%dT%H:%M:%S%z')" "$target_tab_id" || true
    [[ -n "$manager_pane_id" ]] && printf '[%s] manager_pane_id=%s\n' "$(date '+%Y-%m-%dT%H:%M:%S%z')" "$manager_pane_id" || true
    [[ -n "$placement_reason" ]] && printf '[%s] placement_reason=%s\n' "$(date '+%Y-%m-%dT%H:%M:%S%z')" "$placement_reason" || true
    [[ -n "$created_tab_id" ]] && printf '[%s] created_tab_id=%s\n' "$(date '+%Y-%m-%dT%H:%M:%S%z')" "$created_tab_id" || true
    [[ -n "$restore_focus_pane_id" ]] && printf '[%s] restore_focus_pane_id=%s\n' "$(date '+%Y-%m-%dT%H:%M:%S%z')" "$restore_focus_pane_id" || true
} >>"$log_path"

# ── Build herdr agent start invocation ─────────────────────────────────────
# Agent name is unique per run while the logical --name remains stable.

cleanup_partial() {
    local rc=$?
    [[ "$cleanup_done" == true ]] && return "$rc"
    cleanup_done=true
    if [[ "$launcher_finished" != true && "$launched" == true && -n "$pane_id" ]]; then
        hd pane close "$pane_id" >/dev/null 2>&1 || true
    fi
    if [[ "$launcher_finished" != true && -n "$created_tab_id" ]]; then
        hd tab close "$created_tab_id" >/dev/null 2>&1 || true
    fi
    if [[ "$launcher_finished" != true ]]; then
        [[ -z "$runner" ]] || rm -f -- "$runner"
        [[ -z "$handoff_dir" ]] || rm -rf -- "$handoff_dir"
    fi
    return "$rc"
}
trap 'cleanup_partial' EXIT
trap 'exit 130' INT TERM

# For print mode: wrap the worker command in a one-shot shell script that runs
# it non-interactively, tees to the log, then closes the pane after a short pause.
# herdr has no built-in one-shot close-on-exit flag for this wrapper, so use a
# small runner and close via herdr after the worker exits.
auto_close_created_tab=false
if [[ -n "$created_tab_id" && ( "$mode" == "print" || "$close_on_exit" == true ) ]]; then
    auto_close_created_tab=true
fi

# Emit the generated runner's worker-depth propagation lines, role-aware. The
# role is decided here, at generation time (the runner itself cannot re-read the
# launch role). Keep-alive manager/supermanager panes do NOT consume a worker
# depth slot: they stay at depth 0 (top level), so a ring-0-launched manager can
# launch product workers under the default ZFLOW_MAX_WORKER_DEPTH=0 without
# needing --allow-nested. Product workers (worker|fleet|advisor or default)
# still increment depth so the nesting guard keeps refusing recursion by default.
emit_depth_propagation() {
    if [[ "$role" == "manager" || "$role" == "supermanager" ]]; then
        # Leave ZFLOW_WORKER_DEPTH unset (not "0"): CLAUDE.md / role detection treats
        # "ZFLOW_WORKER_DEPTH is set" as "you are a worker". Nesting still sees depth 0
        # via ${ZFLOW_WORKER_DEPTH:-0}. Unset any inherited value so a manager pane is
        # never mistaken for a product worker.
        printf '%s\n' \
            '# ── Worker depth propagation (role-aware) ────────────────────────────────' \
            '# Keep-alive manager/supermanager panes do NOT consume a worker depth slot.' \
            '# Leave ZFLOW_WORKER_DEPTH unset (depth 0 via ${ZFLOW_WORKER_DEPTH:-0}) so a' \
            '# ring-0-launched manager can launch product workers under the default' \
            '# ZFLOW_MAX_WORKER_DEPTH=0 without --allow-nested, and so role detection that' \
            '# keys on "ZFLOW_WORKER_DEPTH is set" still classifies this pane as a manager.' \
            'unset ZFLOW_WORKER_DEPTH 2>/dev/null || true' \
            "export ZFLOW_ROLE=$role"
    else
        cat <<'EOF'
# ── Worker depth propagation ─────────────────────────────────────────────
# Inherit the caller's nesting depth (unset = top-level manager, 0) and export
# one deeper so this worker's own nested zgpt-run-worker.sh call knows it is a
# child launch. zgpt-run-worker.sh hard-refuses to start above
# ZFLOW_MAX_WORKER_DEPTH (default 0) unless --allow-nested is passed, which is
# how accidental worker-to-worker recursion is stopped at the launcher.
export ZFLOW_WORKER_DEPTH=$(( ${ZFLOW_WORKER_DEPTH:-0} + 1 ))
export ZFLOW_ROLE=worker
EOF
    fi
}

runner="$(mktemp "${TMPDIR:-/tmp}/zgpt-worker.XXXXXX")"
chmod +x "$runner"

if [[ "$mode" == "print" ]]; then
    {
        printf '#!/usr/bin/env bash\n'
        printf 'set -euo pipefail\n'
        printf 'trap "rm -f -- \"$0\"" EXIT\n'
        printf 'name=%q\n' "$name"
        printf 'prompt=%q\n' "$prompt"
        printf 'log_path=%q\n' "$log_path"
        printf 'worker_cmd=%q\n' "$worker_cmd"
        printf 'worker_family=%q\n' "$worker_family"
        printf 'adapter_path=%q\n' "$script_dir/zgpt-cli-adapter.sh"
        printf 'herdr_session=%q\n' "${ZGPT_HERDR_SESSION:-}"
        printf 'created_tab_id=%q\n' "$created_tab_id"
        printf 'auto_close_created_tab=%q\n' "$auto_close_created_tab"
        declare -p worker_args
        # Note: agent_name used for self-identification after launch
        printf 'agent_name=%q\n' "$agent_name"
        # PANE_ID_FILE is written by the outer script right after launch; the runner
        # reads it to learn this worker's own pane id and re-anchor nested calls.
        printf 'pane_id_file=%q\n' "$handoff_file"
        cat <<'EOF'
echo "[zgpt] worker=$name mode=print"
echo "[zgpt] log=$log_path"
# ── Nested worker anchor propagation ────────────────────────────────────
# This runner executes inside the worker's own herdr pane. When this worker later
# launches another zflow worker (a nested worker), that child must target THIS
# pane/tab, not the grandparent manager pane it may have inherited via the env.
# The outer launcher wrote this pane's id to pane_id_file; export it as the anchor
# and clear any stale inherited manager anchor so it cannot win the placement
# precedence check inside zgpt_herdr_resolve_target_placement.
self_anchor_file="${pane_id_file:-}"
if [[ -n "$self_anchor_file" ]]; then
    for _zgpt_wait in 1 2 3 4 5 6 7 8 9 10; do
        [[ -f "$self_anchor_file" ]] && break
        sleep 0.2
    done
fi
# Clear any anchor vars inherited from the grandparent manager BEFORE sourcing
# the handoff, so the only values we keep are the ones the handoff declares.
unset ZGPT_MANAGER_PANE_ID ZGPT_TAB_ID ZJ_PANE_ID ZJ_TAB_ID 2>/dev/null || true
self_pane_id=""
if [[ -f "${self_anchor_file:-}" ]]; then
    . "$self_anchor_file" || true
    self_pane_id="${ZGPT_MANAGER_PANE_ID:-}"
    rm -f "$self_anchor_file" || true
    rmdir "$(dirname "$self_anchor_file")" 2>/dev/null || true
fi
# Only re-export when the handoff actually yielded a nonempty self pane id.
# If the source failed (empty/missing file), anchors stay cleared rather than
# preserving any stale inherited manager anchor.
if [[ -n "$self_pane_id" ]]; then
    export ZGPT_MANAGER_PANE_ID="$self_pane_id"
    export ZJ_PANE_ID="$self_pane_id"
fi
EOF
        emit_depth_propagation
        cat <<'EOF'
set +e
if [[ -n "$prompt" ]]; then
    . "$adapter_path"
    zgpt_cli_run_print 2>&1 | tee -a "$log_path"
else
    "$worker_cmd" "${worker_args[@]+"${worker_args[@]}"}" 2>&1 | tee -a "$log_path"
fi
rc=${PIPESTATUS[0]}
set -e
echo "[zgpt] exit=$rc; closing in 3s" | tee -a "$log_path"
sleep 3
if [[ "$auto_close_created_tab" == true && -n "$created_tab_id" ]]; then
    if [[ -n "$herdr_session" ]]; then
        herdr --session "$herdr_session" tab close "$created_tab_id" 2>/dev/null || true
    else
        herdr tab close "$created_tab_id" 2>/dev/null || true
    fi
fi
exit "$rc"
EOF
    } >"$runner"
else
    {
        printf '#!/usr/bin/env bash\n'
        printf 'set -euo pipefail\n'
        printf 'trap "rm -f -- \"$0\"" EXIT\n'
        printf 'name=%q\n' "$name"
        printf 'prompt=%q\n' "$prompt"
        printf 'log_path=%q\n' "$log_path"
        printf 'worker_cmd=%q\n' "$worker_cmd"
        printf 'worker_family=%q\n' "$worker_family"
        printf 'adapter_path=%q\n' "$script_dir/zgpt-cli-adapter.sh"
        printf 'herdr_session=%q\n' "${ZGPT_HERDR_SESSION:-}"
        printf 'created_tab_id=%q\n' "$created_tab_id"
        printf 'auto_close_created_tab=%q\n' "$auto_close_created_tab"
        declare -p worker_args
        printf 'agent_name=%q\n' "$agent_name"
        # PANE_ID_FILE is written by the outer script right after launch; the runner
        # reads it to learn this worker's own pane id and re-anchor nested calls.
        printf 'pane_id_file=%q\n' "$handoff_file"
        cat <<'EOF'
echo "[zgpt] worker=$name mode=interactive"
echo "[zgpt] cwd=$PWD"
echo "[zgpt] launcher log=$log_path"
echo "[zgpt] runner=$0"
# ── Nested worker anchor propagation ────────────────────────────────────
# This runner executes inside the worker's own herdr pane. When this worker later
# launches another zflow worker (a nested worker), that child must target THIS
# pane/tab, not the grandparent manager pane it may have inherited via the env.
# The outer launcher wrote this pane's id to pane_id_file; export it as the anchor
# and clear any stale inherited manager anchor so it cannot win the placement
# precedence check inside zgpt_herdr_resolve_target_placement.
self_anchor_file="${pane_id_file:-}"
if [[ -n "$self_anchor_file" ]]; then
    for _zgpt_wait in 1 2 3 4 5 6 7 8 9 10; do
        [[ -f "$self_anchor_file" ]] && break
        sleep 0.2
    done
fi
# Clear any anchor vars inherited from the grandparent manager BEFORE sourcing
# the handoff, so the only values we keep are the ones the handoff declares.
unset ZGPT_MANAGER_PANE_ID ZGPT_TAB_ID ZJ_PANE_ID ZJ_TAB_ID 2>/dev/null || true
self_pane_id=""
if [[ -f "${self_anchor_file:-}" ]]; then
    . "$self_anchor_file" || true
    self_pane_id="${ZGPT_MANAGER_PANE_ID:-}"
    rm -f "$self_anchor_file" || true
    rmdir "$(dirname "$self_anchor_file")" 2>/dev/null || true
fi
# Only re-export when the handoff actually yielded a nonempty self pane id.
# If the source failed (empty/missing file), anchors stay cleared rather than
# preserving any stale inherited manager anchor.
if [[ -n "$self_pane_id" ]]; then
    export ZGPT_MANAGER_PANE_ID="$self_pane_id"
    export ZJ_PANE_ID="$self_pane_id"
fi
EOF
        emit_depth_propagation
        cat <<'EOF'
set +e
if [[ -n "$prompt" ]]; then
    "$worker_cmd" "${worker_args[@]+"${worker_args[@]}"}" "$prompt"
else
    "$worker_cmd" "${worker_args[@]+"${worker_args[@]}"}"
fi
rc=$?
set -e
echo "[zgpt] exit=$rc"
if [[ "$auto_close_created_tab" == true && -n "$created_tab_id" ]]; then
    if [[ -n "$herdr_session" ]]; then
        herdr --session "$herdr_session" tab close "$created_tab_id" 2>/dev/null || true
    else
        herdr tab close "$created_tab_id" 2>/dev/null || true
    fi
fi
exit "$rc"
EOF
    } >"$runner"
fi

# ── Launch the agent ────────────────────────────────────────────────────────
# herdr >=0.7.5 removed the combined "agent start --cwd --split --tab" pane
# launcher: `agent start` now only attaches a fixed --kind (claude/codex/pi/...)
# to an EXISTING pane already at a shell prompt, and treats extra args as
# arguments to that named executable rather than an arbitrary command to run
# (verified live: `agent start --kind claude --pane X -- runner.sh` executes
# `claude runner.sh`, not `runner.sh`). Since worker_cmd is not one of herdr's
# fixed agent kinds, panes are created with `pane split`/`tab create --cwd` and
# the runner is launched with the generic `pane run <pane_id> <command>`.
#
# When zgpt_herdr_ensure_repo_tab just created a fresh tab, its bootstrap pane
# (root_pane_id) is already at $cwd — reuse it directly as the worker pane
# instead of splitting off a second pane and closing the bootstrap afterward.
# Otherwise split from a concrete anchor pane directly into the target tab, so
# no post-hoc "re-home" move is needed either.
# ── Anchor selection: live geometry, never the first pane ─────────────────
# The split anchor is chosen from the target tab's LIVE layout (herdr pane
# layout), never from pane order. Panes whose label (from herdr pane list)
# starts with supermanager: or human: are excluded — ring-0 and human panes
# are not splittable land. Among the rest pick the largest rect area; ties
# break on width, then lexicographically smaller pane id. Split along the
# anchor's long edge: width > 2*height => right, else down (terminal cells
# are ~2:1 tall:wide). An explicit --direction still wins over the geometry.
reuse_root_pane=false
anchor_pane_id=""
split_ratio=""
if [[ -n "$created_tab_id" && -n "$root_pane_id" ]]; then
    anchor_pane_id="$root_pane_id"
    reuse_root_pane=true
else
    anchor_meta="$(zgpt_herdr_anchor_for_tab "$target_tab_id" || true)"
    if [[ -z "$anchor_meta" ]]; then
        # Target tab is full (>= 6 live panes) or holds no splittable pane
        # (e.g. a tab whose panes are all supermanager/human). Re-route to a
        # repo tab that can take a worker, creating agents:<repo>-N if needed.
        printf 'info: target tab %s cannot take another worker; re-routing to a repo tab\n' "$target_tab_id" >&2
        repo_tab_info="$(zgpt_herdr_ensure_repo_tab "$cwd")" || {
            rm -f -- "$runner"
            exit 1
        }
        target_tab_id="$(printf '%s\n' "$repo_tab_info" | sed -n 's/^target_tab_id=//p' | sed -n '1p')"
        created_tab_id="$(printf '%s\n' "$repo_tab_info" | sed -n 's/^created_tab_id=//p' | sed -n '1p')"
        root_pane_id="$(printf '%s\n' "$repo_tab_info" | sed -n 's/^root_pane_id=//p' | sed -n '1p')"
        if [[ -n "$created_tab_id" && -n "$root_pane_id" ]]; then
            anchor_pane_id="$root_pane_id"
            reuse_root_pane=true
        else
            anchor_meta="$(zgpt_herdr_anchor_for_tab "$target_tab_id" || true)"
            anchor_pane_id="$(printf '%s\n' "$anchor_meta" | sed -n 's/^anchor_pane_id=//p' | sed -n '1p')"
            [[ -n "$anchor_pane_id" ]] || {
                printf 'error: no splittable pane in target tab %s and no repo tab could host the worker\n' "$target_tab_id" >&2
                rm -f -- "$runner"
                exit 1
            }
        fi
        # Own the freshly created tab so the last worker in it can remove it.
        mark_owned_tab "$created_tab_id"
        # Keep the launcher log honest about the final placement.
        {
            printf '[%s] placement_reroute=1\n' "$(date '+%Y-%m-%dT%H:%M:%S%z')"
            printf '[%s] target_tab_id=%s\n' "$(date '+%Y-%m-%dT%H:%M:%S%z')" "$target_tab_id"
            [[ -z "$created_tab_id" ]] || printf '[%s] created_tab_id=%s\n' "$(date '+%Y-%m-%dT%H:%M:%S%z')" "$created_tab_id"
        } >>"$log_path" 2>/dev/null || true
    else
        anchor_pane_id="$(printf '%s\n' "$anchor_meta" | sed -n 's/^anchor_pane_id=//p' | sed -n '1p')"
    fi
fi

if [[ "$reuse_root_pane" != true && -n "$anchor_pane_id" ]]; then
    anchor_w="$(printf '%s\n' "$anchor_meta" | sed -n 's/^anchor_width=//p' | sed -n '1p')"
    anchor_h="$(printf '%s\n' "$anchor_meta" | sed -n 's/^anchor_height=//p' | sed -n '1p')"
    tab_w="$(printf '%s\n' "$anchor_meta" | sed -n 's/^tab_width=//p' | sed -n '1p')"
    tab_h="$(printf '%s\n' "$anchor_meta" | sed -n 's/^tab_height=//p' | sed -n '1p')"
    pane_count="$(printf '%s\n' "$anchor_meta" | sed -n 's/^pane_count=//p' | sed -n '1p')"
    if [[ "$direction_explicit" != true ]]; then
        direction="$(zgpt_split_direction_for_rect "$anchor_w" "$anchor_h")"
    fi
    split_ratio="$(zgpt_split_ratio_for_equal_share "$anchor_w" "$anchor_h" "$tab_w" "$tab_h" "$pane_count" "$direction")"
fi

if [[ "$reuse_root_pane" == true ]]; then
    pane_id="$anchor_pane_id"
else
    split_result="$(hd pane split "$anchor_pane_id" --direction "$direction" --ratio "$split_ratio" --cwd "$cwd" --no-focus 2>&1)"
    pane_id="$(printf '%s\n' "$split_result" | jq -r '.result.pane.pane_id // empty' 2>/dev/null)"
    [[ -n "$pane_id" ]] || {
        printf 'error: herdr pane split did not return a pane_id; output was: %s\n' "$split_result" >&2
        rm -f "$runner"
        exit 1
    }
fi
launched=true

# Label the pane immediately once it exists (both the reused-root-pane and the
# split-off-a-new-pane paths land here with $pane_id set), before the runner
# starts. Labeling is cosmetic and must never fail a launch.
hd pane rename "$pane_id" "$pane_label" >/dev/null 2>&1 || true

# Live status overlay: set once at launch, no polling loop. state_labels is
# replaced wholesale on every report-metadata call, so working/idle must be
# set together here. No --ttl-ms: verified live (herdr 0.7.5) that an overlay
# set without --ttl-ms persists indefinitely, and only working/idle/done/unknown
# are accepted state-label keys (error/active/etc. are rejected outright and
# would abort the whole call, per the same live check). Advisory only.
mid_dot=$'\xc2\xb7'
display_agent="${pane_label%% $mid_dot *}"
hd pane report-metadata "$pane_id" --source zflow \
    --display-agent "$display_agent" \
    --state-label working="$pane_label ${mid_dot} running" \
    --state-label idle="$pane_label ${mid_dot} idle" \
    >/dev/null 2>&1 || true

if ! hd pane run "$pane_id" "$runner" >/dev/null 2>&1; then
    printf 'error: herdr pane run failed to launch %s in pane %s\n' "$runner" "$pane_id" >&2
    rm -f "$runner"
    exit 1
fi

# ── Nested worker anchor handoff ────────────────────────────────────────────
# Write this worker's OWN pane id so the generated runner (which runs inside
# this pane) can export it as the nested placement anchor. Without this, a worker
# that inherits the grandparent manager's ZGPT_MANAGER_PANE_ID / ZGPT_TAB_ID would
# hand that stale anchor to any worker it launches, sending nested workers back to
# the manager instead of beside this worker.
# Atomic handoff: write to a unique temp file, then mv into place so the
# runner can never source a partial/empty file.
handoff_tmp="$(mktemp "$handoff_dir/anchor.tmp.XXXXXX")"
{
    printf 'ZGPT_MANAGER_PANE_ID=%q\n' "$pane_id"
    printf 'ZJ_PANE_ID=%q\n' "$pane_id"
} >"$handoff_tmp"
mv -f "$handoff_tmp" "$handoff_file"

# ── Inject prompt (if provided) ─────────────────────────────────────────────
# Two-step: agent send (literal text, no auto-Enter) then pane send-keys Enter.
# The sleep and double Enter are not cosmetic: sending Enter once, immediately
# after a large multi-line paste, can race the worker CLI's paste-processing
# (observed live against real interactive AI CLIs — the text lands in the input
# box but the first Enter doesn't register as a submit). Resending Enter a
# moment later is a harmless no-op if the first one already worked. Mirrors
# the same fix in zgpt-run-worker.sh.
if [[ -n "$prompt" ]]; then
    rebind_worker_pane() {
        local resolved=""
        if hd pane get "$pane_id" >/dev/null 2>&1; then
            return 0
        fi
        resolved="$(zgpt_herdr_agent_pane_for_name "$agent_name" || true)"
        [[ -n "$resolved" ]] || return 1
        pane_id="$resolved"
        return 0
    }
    if [[ "$mode" == interactive ]] && zgpt_cli_requires_visible_editor "$worker_cmd" "$family_override"; then
        ready=false
        if [[ -z "$ready_pattern" && -z "$ready_regex" ]]; then
            ready_regex="$(zgpt_cli_ready_regex "$worker_cmd" "$family_override")"
            if [[ -z "$ready_regex" ]]; then
                ready_pattern="$(zgpt_cli_ready_pattern "$worker_cmd" "$family_override")"
            fi
        fi
        ready_deadline=$(( $(date +%s) + ready_timeout ))
        ready_ms=$(( ready_timeout * 1000 ))
        ready_settle_secs="$(zgpt_cli_ready_settle_secs "$worker_cmd" "$family_override")"
        positive_integer "$ready_settle_secs" || ready_settle_secs=0
        read_ready_screen() {
            local screen=""
            if ! screen="$(hd pane read "$pane_id" --source visible 2>/dev/null)"; then
                rebind_worker_pane || true
                screen="$(hd pane read "$pane_id" --source visible 2>/dev/null || true)"
            fi
            printf '%s\n' "$screen"
        }
        maybe_settle_ready() {
            local screen="${1:-}" now remaining_secs settle_secs
            zgpt_cli_visible_output_ready "$worker_cmd" "$family_override" "$screen" "$ready_pattern" "$ready_regex" || return 1
            settle_secs="$ready_settle_secs"
            if (( settle_secs > 0 )); then
                now="$(date +%s)"
                (( now < ready_deadline )) || return 1
                remaining_secs=$(( ready_deadline - now ))
                if (( settle_secs > remaining_secs )); then
                    settle_secs="$remaining_secs"
                fi
                if (( settle_secs > 0 )); then
                    sleep "$settle_secs"
                fi
                screen="$(read_ready_screen)"
                zgpt_cli_visible_output_ready "$worker_cmd" "$family_override" "$screen" "$ready_pattern" "$ready_regex" || return 1
            fi
            return 0
        }
        # herdr >=0.7.5 moved top-level `wait output` under `pane wait-output`
        # ("unknown command: wait" otherwise). The manual poll loop below
        # still worked as a fallback, but this fast-path silently no-opped.
        ready_wait_args=(pane wait-output "$pane_id" --source visible --timeout "$ready_ms")
        if [[ -n "$ready_pattern" ]]; then
            ready_wait_args+=(--match "$ready_pattern")
        else
            ready_wait_args+=(--regex "$ready_regex")
        fi
        if hd "${ready_wait_args[@]}" >/dev/null 2>&1; then
            if maybe_settle_ready "$(read_ready_screen)"; then
                ready=true
            fi
        fi
        while [[ "$ready" != true ]]; do
            now="$(date +%s)"
            if (( now >= ready_deadline )); then break; fi
            screen="$(read_ready_screen)"
            if maybe_settle_ready "$screen"; then
                ready=true
                break
            fi
            sleep 1
        done
        [[ "$ready" == true ]] || { printf 'error: worker prompt not ready: %s\n' "$agent_name" >&2; exit 1; }
    fi
    # A failed paste can still have reached the TUI. Never retry the send;
    # only re-resolve before key delivery, where an old pane id is unsafe.
    # herdr >=0.7.5 removed `agent send` (see `herdr agent --help`); the pane-
    # scoped equivalent `pane send-text` sends literal text without auto-Enter,
    # same as the old `agent send` did, and needs no agent registration.
    hd pane send-text "$pane_id" "$prompt" >/dev/null 2>&1 || true
    rebind_worker_pane || true
    sleep 2
    if ! hd pane send-keys "$pane_id" Enter >/dev/null 2>&1; then
        rebind_worker_pane || true
        hd pane send-keys "$pane_id" Enter >/dev/null 2>&1 || true
    fi
    sleep 2
    rebind_worker_pane || true
    hd pane send-keys "$pane_id" Enter >/dev/null 2>&1 || true
fi

# ── Restore manager focus (if requested and anchor exists) ──────────────────
# herdr's --no-focus means the worker pane never stole focus, so this is only
# needed when the caller explicitly overrides (and we have a restore target).
# In practice, --no-focus at launch is cleaner; this is a belt-and-suspenders.
if [[ -n "$restore_focus_pane_id" ]]; then
    hd pane focus --pane "$restore_focus_pane_id" >/dev/null 2>&1 || true
fi

{
    printf '[%s] pane_id=%s pane_label=%s\n' "$(date '+%Y-%m-%dT%H:%M:%S%z')" "$pane_id" "$pane_label"
} >>"$log_path"
printf 'pane_id=%s\n' "$pane_id"
printf 'pane_label=%s\n' "$pane_label"
printf 'name=%s\n' "$name"
printf 'family=%s\n' "$worker_family"
printf 'agent_name=%s\n' "$agent_name"
[[ -n "$placement_source" ]] && printf 'placement_source=%s\n' "$placement_source" || true
[[ -n "$target_tab_id" ]] && printf 'target_tab_id=%s\n' "$target_tab_id" || true
[[ -n "$manager_pane_id" ]] && printf 'manager_pane_id=%s\n' "$manager_pane_id" || true
[[ -n "$placement_reason" ]] && printf 'placement_reason=%s\n' "$placement_reason" || true
if [[ "$print_created_tab_id" == true ]]; then
    printf 'created_tab_id=%s\n' "$created_tab_id"
fi
launcher_finished=true
