#!/usr/bin/env bash
set -euo pipefail

# zgpt-gh-pr.sh — GitHub PR helper for manager-led review workflows.
# Normal create/info paths never auto-launch a review worker.  The one-shot
# correction command is for a consolidated manager feedback batch when the
# original implementation worker is gone.

script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=.claude/skills/zflow-workers/scripts/zgpt-common.sh
source "$script_dir/zgpt-common.sh"

GH_CMD="${ZGPT_GH_CMD:-gh}"
RUN_WORKER="${ZGPT_RUN_WORKER_CMD:-$script_dir/zgpt-run-worker.sh}"

usage() {
    cat <<'USAGE'
Usage: zgpt-gh-pr.sh <command> [args]

Commands:
  create [--repo OWNER/REPO] [--cwd DIR] [gh pr create args...]
      Create a GitHub pull request with gh. Prints pr_url= and parsed identity.
      This normal create path never launches a review worker.

  parse-url <github-pr-url>
      Parse https://github.com/OWNER/REPO/pull/NUMBER and print key=value lines.

  info <github-pr-url>
      Validate the URL and read PR state with gh pr view.

  fix <github-pr-url> --feedback TEXT|--feedback-file FILE [--cwd DIR]
      [--artifact FILE] [--command CMD] [--allow-push]
      Run exactly one bounded correction worker for one manager feedback batch.
      Push is disabled by default. --allow-push permits only a normal push of the
      checked-out PR head branch after a normal commit; force-push/rebase/amend/
      merge/protected-branch pushes remain prohibited.

  review <github-pr-url> (--large-change|--high-risk) [--cwd DIR]
      [--artifact FILE] [--command CMD]
      Explicit opt-in read-only review worker for unusually large/high-risk diffs.
      Never used by create or fix.
USAGE
}

die() { printf 'error: %s\n' "$*" >&2; exit 2; }

require_jq() { command -v jq >/dev/null 2>&1 || die "jq is required"; }

parse_pr_url() {
    local url="${1:-}" base_url rest authority host_port hostname path_part owner repo pr_number tail scheme
    [[ -n "$url" ]] || die "parse-url requires a URL argument"
    base_url="${url%%#*}"
    case "$base_url" in
        https://*) scheme='https'; rest="${base_url#https://}" ;;
        http://*) scheme='http'; rest="${base_url#http://}" ;;
        *) die "could not parse host from URL: $url" ;;
    esac
    [[ "$rest" == */* ]] || die "could not parse PR URL path: $url"
    authority="${rest%%/*}"
    path_part="${rest#*/}"
    [[ -n "$authority" && -n "$path_part" ]] || die "could not parse PR URL: $url"
    [[ "$authority" != *@* ]] || die "userinfo is not allowed in PR URL: $url"
    host_port="$authority"
    hostname="${host_port%%:*}"
    [[ "$hostname" == github.com ]] || die "unsupported PR host '$hostname'; only github.com is allowed"

    case "$path_part" in
        */pull/[0-9]*|*/pull/[0-9]*/*)
            owner="${path_part%%/*}"
            tail="${path_part#*/}"
            repo="${tail%%/*}"
            tail="${tail#*/pull/}"
            pr_number="${tail%%/*}"
            pr_number="${pr_number%%\?*}"
            ;;
        *) die "could not parse GitHub PR URL: $url" ;;
    esac
    [[ -n "$owner" && -n "$repo" ]] || die "could not parse owner/repo from URL: $url"
    [[ "$owner" != *'?'* && "$repo" != *'?'* ]] || die "could not parse owner/repo from URL: $url"
    [[ "$pr_number" =~ ^[0-9]+$ ]] || die "could not parse PR number from URL: $url"

    printf 'pr_url=%s\n' "$url"
    printf 'host=%s://%s\n' "$scheme" "$host_port"
    printf 'owner=%s\n' "$owner"
    printf 'repo=%s\n' "$repo"
    printf 'pr_number=%s\n' "$pr_number"
}

pr_field() {
    parse_pr_url "$1" | sed -n "s/^$2=//p"
}

pr_identity() {
    local host owner repo number raw
    host="$(pr_field "$1" host)"; host="${host#http://}"; host="${host#https://}"
    owner="$(pr_field "$1" owner)"; repo="$(pr_field "$1" repo)"; number="$(pr_field "$1" pr_number)"
    raw="${host}_${owner}_${repo}_pr${number}"
    printf '%s\n' "$raw" | sed 's/[^A-Za-z0-9._-]/_/g'
}

state_dir() {
    local base
    base="${ZGPT_STATE_DIR_OVERRIDE:-$(zgpt_state_dir "${2:-$PWD}")}"
    printf '%s/github-pr/%s\n' "$base" "$(pr_identity "$1")"
}

pr_view_json() {
    local url="$1" parsed owner repo number
    parsed="$(parse_pr_url "$url")"
    owner="$(sed -n 's/^owner=//p' <<< "$parsed")"
    repo="$(sed -n 's/^repo=//p' <<< "$parsed")"
    number="$(sed -n 's/^pr_number=//p' <<< "$parsed")"
    if [[ -n "${ZGPT_GH_PR_FAKE_VIEW_JSON:-}" ]]; then
        printf '%s\n' "$ZGPT_GH_PR_FAKE_VIEW_JSON"
        return 0
    fi
    "$GH_CMD" pr view "$url" \
        --json url,number,state,headRefName,baseRefName,headRepository,headRepositoryOwner,isCrossRepository \
        2>/dev/null | jq --arg fallback_url "$url" --arg owner "$owner" --arg repo "$repo" --argjson number "$number" \
        '. + {url:(.url // $fallback_url), number:(.number // $number), repo_owner:$owner, repo_name:$repo}'
}

remote_owner_repo() {
    local worktree="$1" remote rest host path
    remote="$(git -C "$worktree" remote get-url origin)" || return 1
    remote="${remote%.git}"
    if [[ "$remote" == *://* ]]; then
        rest="${remote#*://}"; rest="${rest#*@}"
        host="${rest%%/*}"; host="${host%%:*}"
        path="${rest#*/}"
    elif [[ "$remote" == *@*:* ]]; then
        rest="${remote#*@}"
        host="${rest%%:*}"
        path="${rest#*:}"
    else
        printf 'unsupported origin URL: %s\n' "$remote" >&2
        return 1
    fi
    [[ "$host" == github.com ]] || { printf 'origin host must be github.com, got %s\n' "$host" >&2; return 1; }
    [[ "$path" == */* ]] || { printf 'origin path is not OWNER/REPO: %s\n' "$path" >&2; return 1; }
    printf '%s\n' "$path"
}

json_head_repo_path() {
    jq -r '
      if (.headRepositoryOwner.login? and .headRepository.name?) then
        (.headRepositoryOwner.login + "/" + .headRepository.name)
      elif (.headRepository.owner.login? and .headRepository.name?) then
        (.headRepository.owner.login + "/" + .headRepository.name)
      elif (.headRepository.nameWithOwner?) then .headRepository.nameWithOwner
      elif (.repo_owner? and .repo_name?) then (.repo_owner + "/" + .repo_name)
      else empty end
    ' <<< "$1"
}

git_clean() {
    [[ -z "$(git -C "$1" status --porcelain=v1 --untracked-files=normal)" ]]
}

validate_fix_target() {
    local url="$1" cwd="$2" pr_json="$3" branch head base state remote_path expected
    [[ -d "$cwd" ]] || die "cwd does not exist: $cwd"
    git -C "$cwd" rev-parse --show-toplevel >/dev/null 2>&1 || die "cwd must be inside a git worktree: $cwd"
    state="$(jq -r '(.state // empty) | ascii_upcase' <<< "$pr_json")"
    [[ "$state" == OPEN ]] || die "PR must be OPEN for corrections (state=${state:-unknown})"
    branch="$(git -C "$cwd" branch --show-current)" || die "could not determine current branch"
    head="$(jq -r '.headRefName // empty' <<< "$pr_json")"
    base="$(jq -r '.baseRefName // empty' <<< "$pr_json")"
    [[ -n "$head" ]] || die "gh pr view did not return headRefName"
    [[ -n "$branch" && "$branch" == "$head" ]] || die "checked-out branch $branch does not match PR head branch $head"
    [[ ! "$branch" =~ ^(main|master|dev|test|release($|[-/])) ]] || die "refusing protected source branch: $branch"
    [[ -z "$base" || "$branch" != "$base" ]] || die "checked-out branch must not equal PR base branch: $base"
    git_clean "$cwd" || die "worktree must be clean before one-shot correction"
    remote_path="$(remote_owner_repo "$cwd")" || die "origin is not a supported GitHub remote"
    expected="$(json_head_repo_path "$pr_json")"
    [[ -n "$expected" ]] || die "gh pr view did not return head repository"
    [[ "$remote_path" == "$expected" ]] || die "origin $remote_path does not match PR head repository $expected"
}

validate_fix_artifact() {
    local artifact="$1" allow_push="$2" cwd="$3" start_head="$4" status commit pushed schema_count status_count commit_count pushed_count head upstream parents parent_count first_parent
    [[ -s "$artifact" ]] || { printf 'worker artifact is missing or empty: %s\n' "$artifact" >&2; return 1; }
    [[ "$(sed -n '1p' "$artifact")" == 'schema=zflow.github_pr.fix_result.v1' ]] || { printf 'artifact missing schema=zflow.github_pr.fix_result.v1\n' >&2; return 1; }
    schema_count="$(grep -c '^schema=' "$artifact" || true)"
    status_count="$(grep -c '^status=' "$artifact" || true)"
    commit_count="$(grep -c '^commit_sha=' "$artifact" || true)"
    pushed_count="$(grep -c '^pushed=' "$artifact" || true)"
    ((schema_count == 1 && status_count == 1 && pushed_count == 1)) || { printf 'artifact must contain exactly one schema=, status=, and pushed= line\n' >&2; return 1; }
    status="$(sed -n 's/^status=//p' "$artifact" | tail -1)"
    commit="$(sed -n 's/^commit_sha=//p' "$artifact" | tail -1)"
    pushed="$(sed -n 's/^pushed=//p' "$artifact" | tail -1)"
    [[ "$pushed" == true || "$pushed" == false ]] || { printf 'artifact pushed= must be true or false\n' >&2; return 1; }
    if [[ "$allow_push" != true && "$pushed" != false ]]; then
        printf 'push was not authorized, but artifact reports pushed=%s\n' "$pushed" >&2
        return 1
    fi
    case "$status" in
        not_actionable|failed)
            ((commit_count == 0)) || { printf '%s artifact must not contain commit_sha=\n' "$status" >&2; return 1; }
            [[ "$pushed" == false ]] || { printf '%s artifact must report pushed=false\n' "$status" >&2; return 1; }
            head="$(git -C "$cwd" rev-parse 'HEAD^{commit}')" || return 1
            [[ "$head" == "$start_head" ]] || { printf '%s artifact must leave HEAD unchanged\n' "$status" >&2; return 1; }
            git_clean "$cwd" || { printf '%s artifact must leave a clean worktree\n' "$status" >&2; return 1; }
            ;;
        fixed)
            ((commit_count == 1)) || { printf 'fixed artifact must contain exactly one commit_sha= line\n' >&2; return 1; }
            [[ "$commit" =~ ^[0-9a-f]{40}$ ]] || { printf 'commit_sha must be 40 lowercase hex chars\n' >&2; return 1; }
            head="$(git -C "$cwd" rev-parse 'HEAD^{commit}')" || return 1
            [[ "$head" == "$commit" ]] || { printf 'commit_sha does not match HEAD\n' >&2; return 1; }
            [[ "$head" != "$start_head" ]] || { printf 'fixed artifact must create exactly one new commit\n' >&2; return 1; }
            parents="$(git -C "$cwd" rev-list --parents -n 1 HEAD)" || return 1
            parent_count="$(( $(wc -w <<< "$parents" | tr -d ' ') - 1 ))"
            first_parent="$(awk '{print $2}' <<< "$parents")"
            [[ "$parent_count" == 1 && "$first_parent" == "$start_head" ]] || { printf 'fixed artifact HEAD must be one direct child of starting HEAD\n' >&2; return 1; }
            git_clean "$cwd" || { printf 'fixed artifact must leave a clean worktree\n' >&2; return 1; }
            if [[ "$pushed" == true ]]; then
                upstream="$(git -C "$cwd" rev-parse '@{upstream}^{commit}')" || return 1
                [[ "$upstream" == "$commit" ]] || { printf 'commit_sha does not match upstream\n' >&2; return 1; }
            fi
            ;;
        *) printf 'invalid artifact status: %s\n' "$status" >&2; return 1 ;;
    esac
}

build_fix_prompt() {
    local url="$1" feedback="$2" allow_push="$3"
    cat <<EOF_PROMPT
Apply one consolidated manager feedback batch for GitHub PR <$url>.

Manager feedback:
$feedback

Write your deliverable artifact with this exact schema:
First line: schema=zflow.github_pr.fix_result.v1
Exactly one line: status=<status> where status is fixed, not_actionable, or failed
Exactly one line: pushed=<true|false>
If status=fixed, include exactly one line: commit_sha=<full 40-char sha>.
If status=not_actionable or status=failed, do not include commit_sha.

Work only in the assigned PR feature worktree. Make the smallest safe correction.
Create exactly one normal direct child commit if a code/doc change is needed.
Leave the worktree clean. Never amend, rebase, merge, force-push, or push a
protected branch. Do not create or update any pull request comments.
EOF_PROMPT
    if [[ "$allow_push" == true ]]; then
        cat <<'EOF_PROMPT'

Manager has explicitly authorized one normal push of the checked-out PR head branch
after verification. Push only the current branch to its existing origin/upstream;
never use --force, --force-with-lease, rebase, amend, or merge.
EOF_PROMPT
    else
        cat <<'EOF_PROMPT'

Manager has not authorized outward writes. Do not push. Leave any normal correction
commit local in this worktree and report pushed=false.
EOF_PROMPT
    fi
}

cmd_create() {
    local repo_arg='' cwd="$PWD" gh_args=() output rc=0 pr_url parsed info_json
    while (($#)); do
        case "$1" in
            --repo) repo_arg="${2:?}"; shift 2 ;;
            --cwd) cwd="${2:?}"; shift 2 ;;
            -h|--help) usage; return ;;
            *) gh_args+=("$1"); shift ;;
        esac
    done
    if [[ -n "${ZGPT_GH_PR_FAKE_URL:-}" ]]; then
        pr_url="$ZGPT_GH_PR_FAKE_URL"
    else
        local cmd=("$GH_CMD" pr create)
        [[ -n "$repo_arg" ]] && cmd+=(--repo "$repo_arg")
        cmd+=("${gh_args[@]}")
        output="$(cd "$cwd" && "${cmd[@]}" 2>&1)" || rc=$?
        ((rc == 0)) || die "gh pr create failed (exit $rc): $output"
        pr_url="$(grep -oE 'https?://github\.com/[^[:space:]]+/[^[:space:]]+/pull/[0-9]+' <<< "$output" | tail -1 || true)"
        [[ -n "$pr_url" ]] || die "could not parse GitHub PR URL from gh output: $output"
    fi
    parsed="$(parse_pr_url "$pr_url")"
    printf '%s\n' "$parsed"
    if info_json="$(pr_view_json "$pr_url" 2>/dev/null)"; then
        jq -r '(.headRefName // empty) as $h | (.baseRefName // empty) as $b | if $h != "" then "head_branch="+$h else empty end, if $b != "" then "base_branch="+$b else empty end, "state="+((.state // "")|ascii_downcase)' <<< "$info_json" 2>/dev/null || true
    fi
    printf 'web_url=%s\n' "$pr_url"
    printf 'review_worker_started=false\n'
}

cmd_info() {
    local url="${1:-}" pr_json
    [[ -n "$url" ]] || die "info requires a PR URL"
    parse_pr_url "$url"
    pr_json="$(pr_view_json "$url")" || die "gh pr view failed for $url"
    jq -r '(.state // empty) as $s | (.headRefName // empty) as $h | (.baseRefName // empty) as $b | if $s != "" then "state="+($s|ascii_downcase) else empty end, if $h != "" then "head_branch="+$h else empty end, if $b != "" then "base_branch="+$b else empty end' <<< "$pr_json"
}

cmd_fix() {
    local url='' cwd="$PWD" feedback='' feedback_file='' artifact='' worker_cmd='' allow_push=false pr_json dir prompt output rc=0 args status start_head
    while (($#)); do
        case "$1" in
            --cwd) cwd="${2:?}"; shift 2 ;;
            --feedback) feedback="${2:?}"; shift 2 ;;
            --feedback-file) feedback_file="${2:?}"; shift 2 ;;
            --artifact) artifact="${2:?}"; shift 2 ;;
            --command) worker_cmd="${2:?}"; shift 2 ;;
            --allow-push) allow_push=true; shift ;;
            --allow-push=true) allow_push=true; shift ;;
            --allow-push=false) allow_push=false; shift ;;
            -h|--help) usage; return ;;
            *) [[ -z "$url" ]] || die "unknown argument: $1"; url="$1"; shift ;;
        esac
    done
    [[ -n "$url" ]] || die "fix requires a GitHub PR URL"
    [[ -z "$feedback" || -z "$feedback_file" ]] || die "use either --feedback or --feedback-file, not both"
    if [[ -n "$feedback_file" ]]; then
        [[ -f "$feedback_file" ]] || die "feedback file not found: $feedback_file"
        feedback="$(cat "$feedback_file")"
    fi
    [[ -n "$feedback" ]] || die "fix requires --feedback or --feedback-file"
    require_jq
    parse_pr_url "$url" >/dev/null
    pr_json="$(pr_view_json "$url")" || die "gh pr view failed for $url"
    validate_fix_target "$url" "$cwd" "$pr_json"
    start_head="$(git -C "$cwd" rev-parse 'HEAD^{commit}')" || die "could not capture starting HEAD"
    dir="$(state_dir "$url" "$cwd")"; mkdir -p "$dir"
    [[ -n "$artifact" ]] || artifact="$dir/fix-result-$(date +%Y%m%d-%H%M%S).txt"
    rm -f "$artifact"
    prompt="$(build_fix_prompt "$url" "$feedback" "$allow_push")"
    args=(--name "gh-pr-fix-$(pr_identity "$url")" --cwd "$cwd" --route implement --report-mode full --artifact "$artifact" --close --task "$prompt")
    [[ -n "$worker_cmd" ]] && args=(--command "$worker_cmd" "${args[@]}")
    output="$("$RUN_WORKER" "${args[@]}" 2>&1)" || rc=$?
    validate_fix_artifact "$artifact" "$allow_push" "$cwd" "$start_head" || { printf '%s\n' "$output" >&2; return 1; }
    status="$(sed -n 's/^status=//p' "$artifact" | tail -1)"
    printf 'status=%s\n' "$status"
    printf 'pr_url=%s\nartifact=%s\nallow_push=%s\nworker_launches=1\n' "$url" "$artifact" "$allow_push"
    sed -n 's/^commit_sha=/commit_sha=/p; s/^pushed=/pushed=/p' "$artifact"
    [[ "$status" == failed ]] && return 1
    return "$rc"
}

validate_review_artifact() {
    local artifact="$1" schema_count status_count status
    [[ -s "$artifact" ]] || { printf 'review artifact is missing or empty: %s\n' "$artifact" >&2; return 1; }
    [[ "$(sed -n '1p' "$artifact")" == 'schema=zflow.github_pr.review_result.v1' ]] || { printf 'artifact missing schema=zflow.github_pr.review_result.v1\n' >&2; return 1; }
    schema_count="$(grep -c '^schema=' "$artifact" || true)"
    status_count="$(grep -c '^status=' "$artifact" || true)"
    ((schema_count == 1 && status_count == 1)) || { printf 'review artifact must contain exactly one schema= and status= line\n' >&2; return 1; }
    status="$(sed -n 's/^status=//p' "$artifact" | tail -1)"
    [[ "$status" == reviewed || "$status" == needs_changes || "$status" == failed ]] || { printf 'invalid review status: %s\n' "$status" >&2; return 1; }
}

cmd_review() {
    local url='' cwd="$PWD" artifact='' worker_cmd='' opt_in='' dir prompt output rc=0 status
    while (($#)); do
        case "$1" in
            --cwd) cwd="${2:?}"; shift 2 ;;
            --artifact) artifact="${2:?}"; shift 2 ;;
            --command) worker_cmd="${2:?}"; shift 2 ;;
            --large-change) opt_in='large-change'; shift ;;
            --high-risk) opt_in='high-risk'; shift ;;
            -h|--help) usage; return ;;
            *) [[ -z "$url" ]] || die "unknown argument: $1"; url="$1"; shift ;;
        esac
    done
    [[ -n "$url" ]] || die "review requires a GitHub PR URL"
    [[ -n "$opt_in" ]] || die "review requires explicit --large-change or --high-risk opt-in"
    require_jq
    parse_pr_url "$url" >/dev/null
    pr_view_json "$url" >/dev/null || die "gh pr view failed for $url"
    dir="$(state_dir "$url" "$cwd")"; mkdir -p "$dir"
    [[ -n "$artifact" ]] || artifact="$dir/review-result-$(date +%Y%m%d-%H%M%S).txt"
    rm -f "$artifact"
    prompt="Review GitHub PR <$url> because the manager explicitly marked it $opt_in. Read-only review only: do not edit files, do not push, do not comment on GitHub. Write artifact first line schema=zflow.github_pr.review_result.v1, exactly one status=reviewed|needs_changes|failed line, then concise findings."
    local args=(--name "gh-pr-review-$(pr_identity "$url")" --cwd "$cwd" --route review --report-mode full --artifact "$artifact" --close --task "$prompt")
    [[ -z "$worker_cmd" ]] && args=(--difficulty hard "${args[@]}")
    [[ -n "$worker_cmd" ]] && args=(--command "$worker_cmd" "${args[@]}")
    output="$("$RUN_WORKER" "${args[@]}" 2>&1)" || rc=$?
    validate_review_artifact "$artifact" || { printf '%s\n' "$output" >&2; return 1; }
    status="$(sed -n 's/^status=//p' "$artifact" | tail -1)"
    printf 'status=%s\npr_url=%s\nartifact=%s\nreview_opt_in=%s\nworker_launches=1\n' "$status" "$url" "$artifact" "$opt_in"
    [[ "$status" == failed ]] && return 1
    return "$rc"
}

case "${1:-}" in
    create) shift; cmd_create "$@" ;;
    parse-url) shift; [[ -n "${1:-}" ]] || die "parse-url requires a URL argument"; parse_pr_url "$1" ;;
    info) shift; cmd_info "$@" ;;
    fix) shift; cmd_fix "$@" ;;
    review) shift; cmd_review "$@" ;;
    -h|--help) usage ;;
    *) die "unknown command: ${1:-}. Use create, parse-url, info, fix, or review." ;;
esac
