#!/usr/bin/env bash
set -euo pipefail

# zgpt-superboard.sh — fleet survey over ALL herdr panes.
#
# The per-pane monitor (zgpt-watch-pane.sh) needs an explicit --pane-id and a
# task it is already tracking. This script is the fleet-level counterpart: it
# walks every pane herdr knows about, reads each agent pane's recent output,
# classifies its live state, and prints a compact board the manager can act on.
#
# Classification precedence (for agent panes):
#   working > needs_human (BLOCKED:/blocked status line or trailing question)
#   > idle-done (WORKER_DONE: or quiet) > worker_gone (agent released).
# Non-agent panes (plain shells, ssh) are shown only with --all.
#
# The decision loop this feeds is documented in the zflow-workers skill under
# "Supermanager Loop": survey -> surface to the human -> steer via
# zgpt-steer.sh -> re-survey.

usage() {
    cat <<'EOF'
Usage: zgpt-superboard.sh [options]

Survey all herdr panes and print a manager-facing board.

Options:
  --all                    Include non-agent panes (plain shells, ssh) too.
  --json                   Emit machine-readable JSON (one object per pane).
  --lines <n>              Tail lines read per pane for classification. Default: 60
  --source <s>             herdr pane read source. Default: recent-unwrapped
  --min-working <n>        Warn (exit 3) when fewer than n panes are working.
  --session <name>         herdr session name (or export ZGPT_HERDR_SESSION)
  -h, --help               Show this help

Output:
  A compact table: pane-id | state | repo | task | tail signal, grouped by tab
  (each tab is one workstream — usually a repo's agents:<repo> placement — so the
  board is read by REPO/tab, not by workspace number). The REPO column names the
  workstream; the tab header groups its panes. States:
  working | needs_human | idle-done | worker_gone | shell

  exit codes:
    0  board printed (no needs_human)
    2  at least one agent pane is in needs_human (blocked, awaiting human)
    3  fewer than --min-working panes are working (liveness alarm)
EOF
}

die() { printf 'error: %s\n' "$*" >&2; exit 1; }

source "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/zgpt-common.sh"

include_all=false
as_json=false
lines="60"
source_mode="recent-unwrapped"
min_working=""
session="${ZGPT_HERDR_SESSION:-}"

while [[ $# -gt 0 ]]; do
    case "$1" in
        --all) include_all=true; shift ;;
        --json) as_json=true; shift ;;
        --lines) lines="${2:?--lines needs a value}"; shift 2 ;;
        --source) source_mode="${2:?--source needs a value}"; shift 2 ;;
        --min-working) min_working="${2:?--min-working needs a value}"; shift 2 ;;
        --session) session="${2:?--session needs a value}"; shift 2 ;;
        -h|--help) usage; exit 0 ;;
        *) die "unknown argument: $1 (see --help)" ;;
    esac
done

session_arg=()
if [[ -n "$session" ]]; then
    session_arg=(--session "$session")
fi

# --- 1. enumerate ---------------------------------------------------------
# session_arg is empty unless --session was given; under `set -u` an empty
# array expands to "session_arg[@]: unbound variable", so guard the expansion
# (bash 3.2 compatible) — the no-session path is the default.
list_json="$(herdr pane list ${session_arg[@]+"${session_arg[@]}"} 2>/dev/null)" ||
    die "herdr pane list failed (is the herdr server running?)"

# --- 2. classify each pane -------------------------------------------------
declare -a ids states repos tasks signals tabs

classify_pane() {
    local pane_id="$1" status="$2" agent="$3" title="$4" cwd="$5" tail_text="$6"

    if [[ "$agent" == "null" || -z "$agent" ]]; then
        printf 'shell'
        return
    fi
    case "$status" in
        working) printf 'working'; return ;;
        # herdr native blocked => agent parked waiting on the human
        blocked) printf 'needs_human'; return ;;
    esac
    # idle/unknown agent panes: classify from CONTENT, ignoring CLI chrome.
    # The bottom of a pane is status lines (⏵⏵ / GLM deepseek / ── separators),
    # so strip those before deciding whether the last real line asks a question.
    local content
    content="$(printf '%s' "$tail_text" \
        | grep -v '^[[:space:]]*$' \
        | grep -v '⏵⏵\|GLM \|deepseek\|◎ /goal\|^─*$\|^❯\|^✻' || true)"
    if [[ "$content" =~ BLOCKED: ]]; then
        printf 'needs_human'
        return
    fi
    if [[ "$content" =~ WORKER_DONE:|任务完成|已完成 ]]; then
        printf 'idle-done'
        return
    fi
    local lastline
    lastline="$(printf '%s' "$content" | tail -1 || true)"
    if [[ -n "$lastline" && "$lastline" =~ [？?][[:space:]]*$ ]]; then
        printf 'needs_human'
        return
    fi
    printf 'idle-done'
}

repo_of() {  # best-effort repo/branch label from a cwd
    local cwd="$1"
    if [[ -z "$cwd" || "$cwd" == "null" ]]; then printf '-'; return; fi
    local repo
    repo="$(zgpt_repo_name_for_cwd "$cwd")"
    [[ -n "$repo" ]] && printf '%s' "$repo" || printf '-'
}

sig_of() {  # last non-empty line of the tail, truncated
    local tail_text="$1"
    local sig
    sig="$(printf '%s' "$tail_text" | grep -v '^[[:space:]]*$' | tail -1 || true)"
    [[ -n "$sig" ]] && printf '%s' "${sig:0:90}" || printf '-'
}

while IFS= read -r pane_json; do
    [[ -z "$pane_json" ]] && continue
    pane_id="$(printf '%s' "$pane_json" | jq -r '.pane_id')"
    status="$(printf '%s' "$pane_json" | jq -r '.agent_status // "unknown"')"
    agent="$(printf '%s' "$pane_json" | jq -r '.agent // empty')"
    title="$(printf '%s' "$pane_json" | jq -r '.terminal_title_stripped // empty')"
    cwd="$(printf '%s' "$pane_json" | jq -r '.foreground_cwd // empty')"
    tab_id="$(printf '%s' "$pane_json" | jq -r '.tab_id // empty')"

    if [[ "$agent" == "null" || -z "$agent" ]]; then
        if [[ "$include_all" != "true" ]]; then
            continue
        fi
        tail_text=""
        state="shell"
    else
        # shellcheck disable=SC2016
        tail_text="$(herdr pane read "$pane_id" --source "$source_mode" --lines "$lines" 2>/dev/null || true)"
        state="$(classify_pane "$pane_id" "$status" "$agent" "$title" "$cwd" "$tail_text")"
    fi

    ids+=("$pane_id")
    states+=("$state")
    repos+=("$(repo_of "$cwd")")
    tasks+=("${title:-}")
    signals+=("$(sig_of "$tail_text")")
    tabs+=("$tab_id")
done < <(printf '%s' "$list_json" | jq -c '.result.panes[]' 2>/dev/null || printf '%s' "$list_json" | jq -c '.panes[]')

# --- 3. render -------------------------------------------------------------
need_human_count=0
working_count=0

# Group by tab id: a tab (usually one repo's agents:<repo> placement) is the
# workstream unit the board is read by. Sort rows so same-tab panes stay together
# regardless of the raw pane-list order; a pane with no tab id lands in the
# workspace-root group.
# mapfile is bash 4+; build the ordered index with a portable while-read loop.
# Same sort key (tab, then numeric index) so same-tab panes stay grouped.
order=()
while IFS=$'\t' read -r _order_idx; do
    order+=("$_order_idx")
done < <(for i in "${!ids[@]}"; do printf '%s\t%s\n' "${tabs[$i]:-}" "$i"; done | sort -k1,1 -k2,2n | cut -f2)

if [[ "$as_json" == "true" ]]; then
    printf '['
    first=1
    for i in "${order[@]}"; do
        [[ $first -eq 0 ]] && printf ','
        first=0
        jq -nc \
            --arg id "${ids[$i]}" --arg state "${states[$i]}" \
            --arg repo "${repos[$i]}" --arg tab "${tabs[$i]:-}" \
            --arg task "${tasks[$i]}" --arg sig "${signals[$i]}" \
            '{id:$id,state:$state,repo:$repo,tab:$tab,task:$task,signal:$sig}'
    done
    printf ']\n'
else
    printf '%-11s %-12s %-12s %-40s %s\n' 'PANE' 'STATE' 'REPO' 'TASK' 'TAIL'
    prev_tab=""
    for i in "${order[@]}"; do
        if [[ "${tabs[$i]:-}" != "$prev_tab" ]]; then
            printf '[%s]\n' "${tabs[$i]:-workspace-root}"
            prev_tab="${tabs[$i]:-}"
        fi
        printf '%-11s %-12s %-12s %-40s %s\n' \
            "${ids[$i]}" "${states[$i]}" "${repos[$i]}" "${tasks[$i]}" "${signals[$i]}"
        [[ "${states[$i]}" == "needs_human" ]] && need_human_count=$((need_human_count + 1))
        [[ "${states[$i]}" == "working" ]] && working_count=$((working_count + 1))
    done
fi

exit_code=0
if [[ "$include_all" == "false" ]]; then
    if [[ $need_human_count -gt 0 ]]; then
        printf '\n⚠ %d agent(s) await a human decision\n' "$need_human_count" >&2
        exit_code=2
    fi
    if [[ -n "$min_working" && "$working_count" -lt "$min_working" ]]; then
        printf '\n⚠ fewer than %s panes working (%d)\n' "$min_working" "$working_count" >&2
        exit_code=3
    fi
fi

exit "$exit_code"
