#!/usr/bin/env bash
set -euo pipefail

usage() {
    cat <<'USAGE'
Usage: zgpt-scout.sh --name <name> --artifact <path> (--task <text> | --task-file <path>) [zgpt-run-worker options]

Launch a non-blocking read-only scout. The scout starts zgpt-run-worker.sh in the
background with a report-like route, so the manager can continue while that
runner owns readiness, watching, artifact completion, and cleanup.

Defaults added unless supplied:
  --route inspect --report-mode compact --close

Rejected:
  --route implement|manager (scouts are read-only/report-only)
USAGE
}

die() { printf 'error: %s\n' "$*" >&2; exit 2; }

script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
run_worker="${ZGPT_SCOUT_RUN_WORKER:-$script_dir/zgpt-run-worker.sh}"
[[ -x "$run_worker" ]] || die "runner not executable: $run_worker"

args=()
name=""
artifact=""
route=""
report_mode=""
has_close=false
log_path=""
run_dir=""

while [[ $# -gt 0 ]]; do
    case "$1" in
        --name)
            name="${2:?}"; args+=("$1" "$2"); shift 2 ;;
        --artifact)
            artifact="${2:?}"; args+=("$1" "$2"); shift 2 ;;
        --route)
            route="${2:?}"; args+=("$1" "$2"); shift 2 ;;
        --report-mode)
            report_mode="${2:?}"; args+=("$1" "$2"); shift 2 ;;
        --close)
            has_close=true; args+=("$1"); shift ;;
        --log)
            log_path="${2:?}"; args+=("$1" "$2"); shift 2 ;;
        --command|--task|--task-file|--cwd|--direction|--tab-id|--command-arg|--family|--effort|--session|--token|--ready-pattern|--ready-regex|--ready-timeout|--timeout|--poll|--verify-budget|--verification-budget|--max-commands|--time-budget|--difficulty|--fast-command|--advisor-command)
            args+=("$1" "${2:?}"); shift 2 ;;
        --bare|--no-bare|--no-effort-flag|--no-restore-focus|--no-effort-note)
            args+=("$1"); shift ;;
        -h|--help)
            usage; exit 0 ;;
        *)
            die "unknown scout/runner argument: $1" ;;
    esac
done

[[ -n "$name" ]] || die "--name is required"
[[ -n "$artifact" ]] || die "--artifact is required for a non-blocking scout handoff"
case "${route:-inspect}" in
    inspect|review|verify|report) ;;
    implement|manager) die "scout route must be read-only/report-only, not: $route" ;;
    *) die "scout route must be one of: inspect, review, verify, report" ;;
esac

if [[ -z "$route" ]]; then
    args+=(--route inspect)
    route="inspect"
fi
if [[ -z "$report_mode" ]]; then
    args+=(--report-mode compact)
    report_mode="compact"
fi
if [[ "$has_close" != true ]]; then
    args+=(--close)
fi
if [[ -z "$log_path" ]]; then
    run_dir="$(dirname "$artifact")"
    mkdir -p "$run_dir"
    safe_name="$(printf '%s' "$name" | tr -c 'A-Za-z0-9_.-' '-')"
    log_path="$run_dir/$safe_name.scout.log"
else
    mkdir -p "$(dirname "$log_path")"
fi

( "$run_worker" "${args[@]}" >"$log_path" 2>&1 ) &
pid=$!
printf 'status=background\n'
printf 'pid=%s\n' "$pid"
printf 'route=%s\n' "$route"
printf 'report_mode=%s\n' "$report_mode"
printf 'artifact=%s\n' "$artifact"
printf 'log=%s\n' "$log_path"
