#!/usr/bin/env bash
set -euo pipefail

# zgpt-steer.sh — inject a decision/instruction into an existing agent pane.
#
# Prefers `herdr agent prompt` (bracketed paste + auto-Enter) for detected
# agent panes, falling back to the pane send-text + Enter dance for
# non-agent/unknown panes, unsupported herdr, and definitive prompt failures.
# The fallback wraps the historical paste dance so the manager never has to
# re-type it: send-text <pane> <msg>; sleep <settle>; send-keys Enter.
#
# Used by the "Supermanager Loop" (see SKILL.md): after zgpt-superboard.sh
# reports an agent in needs_human, the manager steers it here with the
# human's decision, then re-surveys.

script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=zgpt-common.sh
source "$script_dir/zgpt-common.sh"

usage() {
    cat <<'EOF'
Usage: zgpt-steer.sh --pane-id <pane-id> <message>

Deliver a decision/instruction to an existing agent pane.

Options:
  --pane-id/-p <id>        herdr pane id, e.g. w1:p5. Required.
  --settle <secs>          Pause before the (possibly repeated) Enter. Default: 2
  --no-double-enter        Send Enter exactly once even for large/multi-line messages.
  --confirm                After sending, read back the last 6 lines and echo them
                           so the manager can verify the pane accepted the input.
  --session <name>         herdr session name (or export ZGPT_HERDR_SESSION)
  -h, --help               Show this help

Examples:
  zgpt-steer.sh -p w1:p8 "合入 main 并清理，完成后报告 merge commit hash"
  zgpt-steer.sh -p w1:p8 "确认推进方案 (a)，暂缓 (b)" --confirm

Exit codes:
  0  message delivered
  1  pane not found / empty message / send failed
EOF
}

die() { printf 'error: %s\n' "$*" >&2; exit 1; }

pane_id=""
message=""
settle="2"
double_enter=true
confirm=false
session="${ZGPT_HERDR_SESSION:-}"

while [[ $# -gt 0 ]]; do
    case "$1" in
        --pane-id|-p) pane_id="${2:?--pane-id needs a value}"; shift 2 ;;
        --settle) settle="${2:?--settle needs a value}"; shift 2 ;;
        --no-double-enter) double_enter=false; shift ;;
        --confirm) confirm=true; shift ;;
        --session) session="${2:?--session needs a value}"; shift 2 ;;
        -h|--help) usage; exit 0 ;;
        --) shift; message="${*:-}"; break ;;
        -*) die "unknown argument: $1 (see --help)" ;;
        *) message="$1"; shift ;;
    esac
done

[[ -n "$pane_id" ]] || die "missing --pane-id (see --help)"
[[ -n "$message" ]] || die "empty message (see --help)"

# Drive the resolved session through the shared `hd()` wrapper (set once).
export ZGPT_HERDR_SESSION="$session"

# --- 1. confirm the pane exists --------------------------------------------
if ! hd pane get "$pane_id" >/dev/null 2>&1; then
    die "pane $pane_id not found"
fi

# --- 2. the steer dance ------------------------------------------------------
# Prefers `herdr agent prompt` for detected agent panes; falls back to the pane
# send-text + Enter dance for non-agent/unknown panes, unsupported herdr, and
# definitive prompt failures. `--double-enter large|never` reproduces the
# historical size-gated second Enter; send-once semantics are preserved.
double_mode="large"
[[ "$double_enter" == "true" ]] || double_mode="never"
zgpt_herdr_prompt_inject "$pane_id" "$message" --settle "$settle" --double-enter "$double_mode" \
    || printf 'warn: inject result uncertain; verify the pane accepted the message\n' >&2

# --- 3. optional readback -----------------------------------------------------
if [[ "$confirm" == "true" ]]; then
    printf '%s\n' "--- $pane_id after steer ---"
    hd pane read "$pane_id" --source recent-unwrapped --lines 6 2>/dev/null || true
fi

printf 'steered %s: %s\n' "$pane_id" "${message:0:60}"
exit 0
