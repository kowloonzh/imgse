#!/usr/bin/env bash
# Read path for the routing ledger written by zgpt-run-worker.sh.
#
# The ledger exists to make tier utilization measurable: zgpt-run-worker.sh
# chooses among the fast / worker / advisor commands on every launch, and
# without persisted decisions there is no way to tell whether the three-tier
# design produces the cost saving it exists to produce.
#
# See docs/advisor-consult-loop.md.
set -euo pipefail

script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$script_dir/zgpt-common.sh"

usage() {
    cat <<'EOF'
Usage: zgpt-ledger.sh <command> [options]

Commands:
  path                 Print the ledger file path for this checkout.
  tail [-n N]          Print the last N records as JSON lines (default 20).
  summary              Distribution of routing decisions.
  auto-rate            Advisor selection rate among --difficulty auto runs.
                       This is the falsification test for the "auto over-routes"
                       hypothesis in docs/advisor-consult-loop.md.

Options:
  --path <file>        Read this ledger instead of the default.
  --cwd <dir>          Resolve the default ledger path for this checkout.
  -h, --help           Show this help.

Environment:
  ZFLOW_LEDGER=off     Disables writing (this reader is unaffected).
  ZFLOW_LEDGER_PATH    Explicit ledger file, overrides the per-checkout default.
EOF
}

die() { printf 'error: %s\n' "$*" >&2; exit 2; }

cmd="${1:-}"
[[ -n "$cmd" ]] || { usage; exit 2; }
shift || true

explicit_path=""
cwd="$PWD"
tail_n=20

while [[ $# -gt 0 ]]; do
    case "$1" in
        --path) explicit_path="${2:?}"; shift 2;;
        --cwd) cwd="${2:?}"; shift 2;;
        -n) tail_n="${2:?}"; shift 2;;
        -h|--help) usage; exit 0;;
        *) die "unknown argument: $1";;
    esac
done

if [[ -n "$explicit_path" ]]; then
    ledger="$explicit_path"
else
    ledger="$(zgpt_ledger_path "$cwd")"
fi

require_jq() { command -v jq >/dev/null || die "jq is required to read the ledger"; }
require_ledger() {
    [[ -f "$ledger" ]] || die "no ledger at $ledger (no runs recorded yet, or ZFLOW_LEDGER=off)"
}

# Print "count  key" lines for one field, most frequent first.
distribution() {
    local field="$1"
    jq -r --arg f "$field" '.[$f] // "(unset)"' "$ledger" \
        | sort | uniq -c | sort -rn
}

case "$cmd" in
    path)
        printf '%s\n' "$ledger"
        ;;
    tail)
        require_ledger
        tail -n "$tail_n" "$ledger"
        ;;
    summary)
        require_jq; require_ledger
        total="$(wc -l <"$ledger" | tr -d ' ')"
        printf 'ledger=%s\n' "$ledger"
        printf 'records=%s\n' "$total"
        for field in command_source difficulty route status; do
            printf '\n[%s]\n' "$field"
            distribution "$field"
        done
        ;;
    auto-rate)
        require_jq; require_ledger
        auto_total="$(jq -s '[.[] | select(.difficulty == "auto")] | length' "$ledger")"
        if [[ "$auto_total" == "0" ]]; then
            printf 'auto_runs=0\n'
            printf 'verdict=insufficient_data\n'
            exit 0
        fi
        auto_advisor="$(jq -s '[.[] | select(.difficulty == "auto" and .advisor_selected == "true")] | length' "$ledger")"
        pct=$(( auto_advisor * 100 / auto_total ))
        printf 'auto_runs=%s\n' "$auto_total"
        printf 'auto_advisor_runs=%s\n' "$auto_advisor"
        printf 'auto_advisor_pct=%s\n' "$pct"
        # Threshold recorded in docs/advisor-consult-loop.md: below ~40% the
        # over-routing hypothesis is falsified and the keyword list stands.
        if (( pct >= 40 )); then
            printf 'verdict=hypothesis_supported\n'
        else
            printf 'verdict=hypothesis_falsified\n'
        fi
        ;;
    *)
        die "unknown command: $cmd"
        ;;
esac
