#!/usr/bin/env bash
set -euo pipefail

# zgpt-watch-pane.sh — poll a herdr pane, write transcript events, and detect
# worker state via herdr-native agent state + marker-text scanning.
#
# herdr exposes snapshot reads plus blocking waits rather than a persistent
# output subscription stream, so this script uses a polling loop:
#   1. Query native herdr agent state (idle/working/blocked/unknown) non-blockingly
#      via `herdr agent get <pane_id>` to extract `agent_status`.
#   2. Read output via `herdr pane read --source recent-unwrapped` (falling
#      back to `visible` when no scrollback is exposed); diff against the
#      previous content snapshot so only new lines are scanned/logged each tick.
#   3. Determine state with the same precedence the old script used, plus
#      context_exhausted between waiting and error:
#      done > needs_human (blocked) > waiting (LOOP_WAIT) > context_exhausted
#      > error > running.
#   4. Emit `state=<state> reason=<reason>` only on state change; exit when a
#      terminal state is reached (unless --keep-watching).
#
# A worker that fills its context window emits no marker: it keeps streaming
# tokens, so marker and stall heuristics both read it as healthy, and it stays
# `running` until a human looks at the pane. The CLI status line is the only
# reliable signal, so it is scanned separately from the marker path — it is
# redrawn in place rather than appended, and would never appear in the new-lines
# diff the other detectors consume.
#
# CLI interface is unchanged from earlier zgpt releases.

usage() {
    cat <<'EOF'
Usage: zgpt-watch-pane.sh --pane-id <pane-id> [options]

Poll a herdr pane for output, write transcript events, and detect worker state.

Options:
  --pane-id/-p <id>          herdr pane id, e.g. w1:p5. Required.
  --agent-name <name>        Optional unique herdr agent identity for pane rebinding.
  --log <path>               Transcript JSONL path. Default: <state_dir>/runs/herdr-workers/<pane-id>/transcript.ndjson
  --scrollback <n|all>       Initial scrollback lines to read on first poll. Default: 200
  --done-marker <text>       Completion marker. Default: WORKER_DONE:
  --blocked-marker <text>    Blocked marker. Default: BLOCKED:
  --wait-marker <text>       Loop wait marker. Default: LOOP_WAIT:
  --context-regex <re>       Status-line pattern meaning the context window is spent.
                             Default: 100% context used|Context left until auto-compact: *0%
  --no-context-check         Disable context-exhaustion detection entirely
  --ansi                     Request ANSI styling in pane read output
  --keep-watching            Do not exit when done/blocked/wait markers detected
  --session <name>           herdr session name (or export ZGPT_HERDR_SESSION)
  -h, --help                 Show this help

Examples:
  zgpt-watch-pane.sh --pane-id w1:p5 --log "$run_dir/transcript.ndjson"
  zgpt-watch-pane.sh --pane-id w1:p5 --scrollback all --keep-watching

Output:
  Prints state=<state> reason=<reason> lines on state transitions, and writes
  raw pane output events to the transcript log (one JSON object per line).

  States: running | done | needs_human | waiting | context_exhausted | error | worker_gone

  context_exhausted is terminal and requires manager intervention: the worker
  cannot finish, and anything not already committed will be lost when it is killed.
EOF
}

die() {
    printf 'error: %s\n' "$*" >&2
    exit 1
}

source "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/zgpt-common.sh"

pane_id=""
agent_name=""
log_path=""
scrollback="200"
done_marker="WORKER_DONE:"
blocked_marker="BLOCKED:"
wait_marker="LOOP_WAIT:"
context_regex='100% context used|Context left until auto-compact: *0%'
context_check=true
ansi=false
keep_watching=false
poll_interval=2   # seconds between polls

while [[ $# -gt 0 ]]; do
    case "$1" in
        --pane-id|-p)
            pane_id="${2:?missing value for --pane-id}"
            shift 2
            ;;
        --agent-name)
            agent_name="${2:?missing value for --agent-name}"
            shift 2
            ;;
        --log)
            log_path="${2:?missing value for --log}"
            shift 2
            ;;
        --scrollback)
            scrollback="${2:?missing value for --scrollback}"
            shift 2
            ;;
        --done-marker)
            done_marker="${2:?missing value for --done-marker}"
            shift 2
            ;;
        --blocked-marker)
            blocked_marker="${2:?missing value for --blocked-marker}"
            shift 2
            ;;
        --wait-marker)
            wait_marker="${2:?missing value for --wait-marker}"
            shift 2
            ;;
        --context-regex)
            context_regex="${2:?missing value for --context-regex}"
            shift 2
            ;;
        --no-context-check)
            context_check=false
            shift
            ;;
        --ansi)
            ansi=true
            shift
            ;;
        --session)
            export ZGPT_HERDR_SESSION="${2:?missing value for --session}"
            shift 2
            ;;
        --keep-watching)
            keep_watching=true
            shift
            ;;
        -h|--help)
            usage
            exit 0
            ;;
        *)
            die "unknown argument: $1"
            ;;
    esac
done

# Require herdr + jq + python3; resolve herdr session.
zgpt_herdr_require
command -v python3 >/dev/null || die "python3 not found (required for JSON/timestamps)"
zgpt_herdr_resolve_session   # sets/exports ZGPT_HERDR_SESSION (empty = default)

[[ -n "$pane_id" || -n "$agent_name" ]] || die "--pane-id or --agent-name is required"

rebind_watch_pane() {
    local rebound=""
    [[ -n "$agent_name" ]] || return 1
    if [[ -n "$pane_id" ]] && hd pane get "$pane_id" >/dev/null 2>&1; then
        return 0
    fi
    rebound="$(zgpt_herdr_agent_pane_for_name "$agent_name" || true)"
    [[ -n "$rebound" ]] || return 1
    pane_id="$rebound"
}

if [[ -z "$pane_id" ]]; then
    rebind_watch_pane || die "could not resolve agent: $agent_name"
fi

if [[ -z "$log_path" ]]; then
    safe_pane="$(printf '%s' "$pane_id" | tr -c 'A-Za-z0-9_.-' '-')"
    log_path="$(zgpt_state_dir "$PWD")/runs/herdr-workers/$safe_pane/transcript.ndjson"
fi
mkdir -p "$(dirname "$log_path")"

# ─── State tracking ───────────────────────────────────────────────────────────
last_state=""
last_snapshot=""
seen_native_working=false

emit_state() {
    local state="$1" reason="$2"
    if [[ "$state" != "$last_state" ]]; then
        printf 'state=%s reason=%s\n' "$state" "$reason"
        last_state="$state"
    fi
}

# ─── read_pane_lines: fetch current lines from the pane ──────────────────────
# Shared fallback logic lives in zgpt-common.sh's zgpt_pane_read_fallback
# (also used by zgpt-run-worker.sh). No rebind_fn: a failed read propagates
# immediately (return 1) so the caller can rebind and retry itself.
read_pane_all_lines() {
    local fmt_args=()
    [[ "$ansi" == true ]] && fmt_args=(--format ansi) || fmt_args=(--format text)
    zgpt_pane_read_fallback "" "${fmt_args[@]}"
}

read_pane_visible_lines() {
    local fmt_args=() text=""
    [[ "$ansi" == true ]] && fmt_args=(--format ansi) || fmt_args=(--format text)
    text="$(hd pane read "$pane_id" --source visible --lines 80 "${fmt_args[@]}" 2>/dev/null)" || return 1
    printf '%s\n' "$text"
}

# ─── log_lines: write new lines to the ndjson log ────────────────────────────
log_new_lines() {
    local new_text="$1"
    [[ -z "$new_text" ]] && return 0
    local ts
    ts="$(python3 -c 'import time; print(time.time())')"
    # Write one JSON object per new line
    while IFS= read -r line; do
        printf '{"ts":%s,"pane_id":"%s","agent_name":"%s","source":"recent-unwrapped","raw":%s}\n' \
            "$ts" "$pane_id" "$agent_name" "$(printf '%s' "$line" | python3 -c 'import sys,json; print(json.dumps(sys.stdin.read().rstrip()))')" \
            >> "$log_path"
    done <<< "$new_text"
}

pane_text_has_active_shell() {
    local text="$1"
    printf '%s\n' "$text" | grep -qiE '[1-9][0-9]*[[:space:]]+shells?[[:space:]]+still[[:space:]]+running'
}

# Return lines present in current_text that were not present in previous_text.
# This is deliberately content-based instead of absolute line-count based: terminal
# scrollback can be truncated or cleared, making line counts shrink. For the normal
# append-only case, keep only the suffix after the common prefix. If the snapshot
# changed discontinuously, resync by scanning/logging the returned snapshot tail.
python_lines() {
    local mode="$1" text="$2" n="${3:-}"
    local tmp
    tmp="$(mktemp "${TMPDIR:-/tmp}/zgpt-watch-lines.XXXXXX")"
    printf '%s\n' "$text" >"$tmp"
    python3 - "$mode" "$tmp" "$n" <<'PY'
import sys
mode, path, n_raw = sys.argv[1:4]
with open(path, encoding="utf-8", errors="replace") as f:
    lines = f.read().splitlines()
if mode == "drop-tail":
    n = int(n_raw)
    out = lines[:-n] if n > 0 else lines
elif mode == "tail":
    n = int(n_raw)
    out = lines[-n:] if n > 0 else []
else:
    out = lines
text = "\n".join(out)
if text:
    sys.stdout.write(text)
PY
    local rc=$?
    rm -f -- "$tmp"
    return "$rc"
}

# Return lines present in current_text that were not present in previous_text.
# This is deliberately content-based instead of absolute line-count based: terminal
# scrollback can be truncated or cleared, making line counts shrink. For the normal
# append-only case, keep only the suffix after the common prefix. If the snapshot
# changed discontinuously, resync by scanning/logging the returned snapshot tail.
new_lines_since_snapshot() {
    local previous_text="$1"
    local current_text="$2"
    local prev_tmp curr_tmp
    prev_tmp="$(mktemp "${TMPDIR:-/tmp}/zgpt-watch-prev.XXXXXX")"
    curr_tmp="$(mktemp "${TMPDIR:-/tmp}/zgpt-watch-curr.XXXXXX")"
    printf '%s\n' "$previous_text" >"$prev_tmp"
    printf '%s\n' "$current_text" >"$curr_tmp"
    python3 - "$scrollback" "$prev_tmp" "$curr_tmp" <<'PY'
import sys
scrollback, prev_path, curr_path = sys.argv[1:4]
with open(prev_path, encoding="utf-8", errors="replace") as f:
    prev_lines = f.read().splitlines()
with open(curr_path, encoding="utf-8", errors="replace") as f:
    curr_lines = f.read().splitlines()
common = 0
limit = min(len(prev_lines), len(curr_lines))
while common < limit and prev_lines[common] == curr_lines[common]:
    common += 1
new = curr_lines[common:]
if common < len(prev_lines):
    # Scrollback shrank, was cleared, or otherwise changed under us. Resync by
    # scanning a bounded tail so terminal markers are not missed forever.
    if scrollback == "all":
        new = curr_lines
    elif scrollback.isdigit():
        n = int(scrollback)
        # On discontinuity, even --scrollback 0 should scan the current snapshot:
        # visible buffers mutate the prompt line in place ("$" -> "$ echo ..."),
        # so otherwise we can miss markers produced after the baseline.
        new = curr_lines[-n:] if n > 0 else curr_lines
    else:
        new = curr_lines
ns = "\n".join(new)
if ns:
    sys.stdout.write(ns)
PY
    local rc=$?
    rm -f -- "$prev_tmp" "$curr_tmp"
    return "$rc"
}

# Establish the baseline before announcing readiness. Callers wait for the
# "watching ..." line before trusting that output produced afterward will be
# scanned. This preserves the old subscription behavior for --scrollback 0.
if ! initial_text="$(read_pane_all_lines)"; then
    if rebind_watch_pane; then
        initial_text="$(read_pane_all_lines)" || die "could not read pane or agent: $pane_id${agent_name:+ ($agent_name)}"
    else
        emit_state "worker_gone" "agent-not-found"
        exit 1
    fi
fi
if [[ "$scrollback" == "all" ]]; then
    last_snapshot=""
elif [[ "$scrollback" =~ ^[0-9]+$ && "$scrollback" -gt 0 ]]; then
    last_snapshot="$(python_lines drop-tail "$initial_text" "$scrollback")"
else
    last_snapshot="$initial_text"
fi

printf 'watching pane_id=%s log=%s\n' "$pane_id" "$log_path"

# ─── Main poll loop ───────────────────────────────────────────────────────────
while true; do
    # 1. Query native agent state (non-blocking single call).
    native_status=""
    agent_json="$(hd agent get "$pane_id" 2>/dev/null)" || agent_json=""
    if [[ -n "$agent_json" ]]; then
        native_status="$(printf '%s\n' "$agent_json" | \
            python3 -c 'import sys,json; d=json.load(sys.stdin); print(d.get("result",{}).get("agent",{}).get("agent_status",""))' 2>/dev/null)" || native_status=""
    fi

    # 2. Read all current pane text; compute new lines since last poll.
    read_ok=true
    if ! all_text="$(read_pane_all_lines)"; then
        if rebind_watch_pane && all_text="$(read_pane_all_lines)"; then
            :
        else
            read_ok=false
            all_text=""
        fi
    fi

    if [[ "$read_ok" != true ]]; then
        if [[ -n "$agent_name" ]]; then
            emit_state "worker_gone" "agent-not-found"
        else
            emit_state "error" "pane-read-failed"
        fi
        exit 1
    fi

    # Extract only lines we haven't seen yet. This handles scrollback truncation
    # by resyncing on content, not by trusting a monotonically-increasing line count.
    new_text="$(new_lines_since_snapshot "$last_snapshot" "$all_text")"
    last_snapshot="$all_text"
    if [[ -n "$new_text" ]]; then
        log_new_lines "$new_text"
    fi
    [[ "$native_status" == "working" ]] && seen_native_working=true

    # 3. Determine state with precedence: done > needs_human > waiting > error > running.
    # Text markers and error tokens are explicit worker signals and must be checked
    # before native idle. Native idle is only a done fallback after this watcher has
    # observed post-start activity; otherwise startup-at-idle would false-complete.

    next_state=""
    next_reason=""

    # done via marker text (also catches CLIs without native integration)
    if [[ -n "$done_marker" && -n "$new_text" ]]; then
        if printf '%s\n' "$new_text" | grep -qF "$done_marker" 2>/dev/null; then
            next_state="done"
            next_reason="$done_marker"
        fi
    fi

    # needs_human via marker text
    if [[ -z "$next_state" && -n "$blocked_marker" && -n "$new_text" ]]; then
        if printf '%s\n' "$new_text" | grep -qF "$blocked_marker" 2>/dev/null; then
            next_state="needs_human"
            next_reason="$blocked_marker"
        fi
    fi

    # needs_human: native blocked
    if [[ -z "$next_state" && "$native_status" == "blocked" ]]; then
        next_state="needs_human"
        next_reason="native:blocked"
    fi

    # waiting (LOOP_WAIT): marker-only, no native herdr equivalent
    if [[ -z "$next_state" && -n "$wait_marker" && -n "$new_text" ]]; then
        if printf '%s\n' "$new_text" | grep -qF "$wait_marker" 2>/dev/null; then
            next_state="waiting"
            next_reason="$wait_marker"
        fi
    fi

    # context_exhausted: the CLI status line reports a spent context window.
    # Read the visible region rather than $new_text: the status line is redrawn
    # in place at the bottom of the pane, so it is never part of the new-lines
    # diff. Checked only when nothing above already classified this poll, which
    # keeps the extra pane read off the common path.
    if [[ -z "$next_state" && "$context_check" == true && -n "$context_regex" ]]; then
        status_text="$(read_pane_visible_lines || true)"
        if [[ -n "$status_text" ]] && \
           printf '%s\n' "$status_text" | grep -qE "$context_regex" 2>/dev/null; then
            next_state="context_exhausted"
            next_reason="context-window-full"
        fi
    fi

    # error: heuristic token scan (same tokens as old script)
    if [[ -z "$next_state" && -n "$new_text" ]]; then
        if printf '%s\n' "$new_text" | grep -qE '(Traceback|panic:|ERROR|Error:|failed|FAILED)' 2>/dev/null; then
            next_state="error"
            next_reason="error-token"
        fi
    fi

    # done via native idle/done only after this watcher observed a native working
    # state, and only when no explicit marker/error from this poll says otherwise.
    # This prevents a just-started or prompt-waiting worker from false-completing.
    # Claude can be agent-idle while a background shell is still active (UI shows
    # "1 shell still running"); keep that actionable as running, not done.
    if [[ -z "$next_state" && "$seen_native_working" == true && ( "$native_status" == "idle" || "$native_status" == "done" ) ]]; then
        visible_text="$(read_pane_visible_lines || true)"
        if pane_text_has_active_shell "$visible_text"; then
            next_state="running"
            next_reason="native:${native_status}:active-shell"
        else
            next_state="done"
            next_reason="native:${native_status}"
        fi
    fi

    # running: native working, new output with no other signal, or unknown with output
    if [[ -z "$next_state" ]]; then
        if [[ "$native_status" == "working" || -n "$new_text" ]]; then
            next_state="running"
            next_reason="${native_status:-output}"
        fi
        # If no new text and no interesting native state, skip emit (no change)
    fi

    # 4. Emit on state change.
    [[ -n "$next_state" ]] && emit_state "$next_state" "$next_reason"

    # 5. Exit when terminal state reached (unless --keep-watching).
    if [[ "$keep_watching" != true ]]; then
        case "${next_state:-}" in
            done|needs_human|waiting)
                exit 0
                ;;
            context_exhausted)
                # Not a success: the worker cannot finish on its own and the
                # manager must salvage the worktree before killing the pane.
                exit 2
                ;;
        esac
    fi

    sleep "$poll_interval"
done
