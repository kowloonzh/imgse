#!/usr/bin/env bash
set -euo pipefail

usage() {
    cat <<'USAGE'
Usage: zgpt-worker-ledger.sh (--run-dir <dir> | --ledger <path>) --worker <name> --command <cmd> --outcome <outcome> [options]

Append one structured worker attempt/switch record to a run-local TSV ledger.

Required:
  --run-dir <dir>           Run directory; ledger defaults to <dir>/worker-ledger.tsv.
  --ledger <path>           Explicit ledger path; overrides --run-dir default.
  --worker <name>           Worker/pane logical name.
  --command <cmd>           Worker CLI or launcher command used.
  --outcome <text>          Result, e.g. started, ok, blocked, empty_response, context_overflow, switched.

Options:
  --pane-id <id>            herdr pane id, if known.
  --artifact <path>         Expected/produced artifact path.
  --reason <text>           Why this outcome or switch happened.
  --next <text>             Next action after this attempt.
  --next-action <text>      Alias for --next.
  --time <iso8601>          Timestamp override for deterministic tests. Default: UTC now.
  -h, --help                Show this help.

Output:
  ledger=<path>
  status=recorded
USAGE
}

die() { printf 'error: %s\n' "$*" >&2; exit 2; }

ts_now() { date -u +%Y-%m-%dT%H:%M:%SZ; }

clean_field() {
    local s="${1-}"
    s=${s//$'\t'/ }
    s=${s//$'\r'/ }
    s=${s//$'\n'/ }
    printf '%s' "$s"
}

run_dir=""
ledger=""
worker=""
command_cmd=""
pane_id=""
artifact=""
outcome=""
reason=""
next_action=""
timestamp=""

while [[ $# -gt 0 ]]; do
    case "$1" in
        --run-dir) run_dir="${2:?}"; shift 2;;
        --ledger) ledger="${2:?}"; shift 2;;
        --worker) worker="${2:?}"; shift 2;;
        --command) command_cmd="${2:?}"; shift 2;;
        --pane-id) pane_id="${2:?}"; shift 2;;
        --artifact) artifact="${2:?}"; shift 2;;
        --outcome) outcome="${2:?}"; shift 2;;
        --reason) reason="${2:?}"; shift 2;;
        --next|--next-action) next_action="${2:?}"; shift 2;;
        --time) timestamp="${2:?}"; shift 2;;
        -h|--help) usage; exit 0;;
        *) die "unknown argument: $1";;
    esac
done

[[ -n "$worker" ]] || die "--worker is required"
[[ -n "$command_cmd" ]] || die "--command is required"
[[ -n "$outcome" ]] || die "--outcome is required"
if [[ -z "$ledger" ]]; then
    [[ -n "$run_dir" ]] || die "provide --run-dir or --ledger"
    ledger="$run_dir/worker-ledger.tsv"
fi
[[ -n "$timestamp" ]] || timestamp="$(ts_now)"

mkdir -p "$(dirname "$ledger")"
if [[ ! -e "$ledger" ]]; then
    printf 'time\tworker\tcommand\tpane_id\tartifact\toutcome\treason\tnext_action\n' >"$ledger"
fi

printf '%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\n' \
    "$(clean_field "$timestamp")" \
    "$(clean_field "$worker")" \
    "$(clean_field "$command_cmd")" \
    "$(clean_field "$pane_id")" \
    "$(clean_field "$artifact")" \
    "$(clean_field "$outcome")" \
    "$(clean_field "$reason")" \
    "$(clean_field "$next_action")" \
    >>"$ledger"

printf 'ledger=%s\n' "$ledger"
printf 'status=recorded\n'
