#!/usr/bin/env bash
set -euo pipefail

# zgpt-manager-notify.sh — fire a herdr UI notification to catch a human's eye
# when a keep-alive manager needs attention (blocked) or finished with residuals
# (idle_for_steer). This is a UI hint for the human at the terminal: it does NOT
# enter the super's chat transcript and does NOT replace the durable channel. The
# three manager→super mechanisms are complementary:
#
#   artifact + MANAGER_STATUS: line  durable record + greppable wake-up (always)
#   watch --exit-on-delta            background task completes = super wake-up
#   herdr notification show          human-eye UI flash (this script)
#
# Dedup: the same (workstream, status) pair is notified only once, so a manager
# that stays blocked does not flash the UI on every heartbeat. When the pair is
# unchanged this script prints nothing and exits 0 (quiet no-op); it fires again
# on the next state change or the first call. Pass --state-file /dev/null to
# disable dedup.

usage() {
    cat <<'EOF'
Usage: zgpt-manager-notify.sh --status <status> --workstream <name> [--body <text>]
                             [--state-file <path>] [--dry-run]

Fire a herdr UI notification for human attention. Complements the artifact +
MANAGER_STATUS: line (machine-readable) and watch --exit-on-delta (wakes the
super); this only lights up the human's herdr UI — it does not enter super chat.

Options:
  --status <status>     MANAGER_STATUS to surface: blocked or idle_for_steer.
  --workstream <name>   Workstream/assignment name; becomes part of the title.
  --body <text>         Optional detail line shown in the notification.
  --state-file <path>   Dedup state (default: <zgpt state dir>/manager-notify.tsv,
                        or $ZGPT_MANAGER_NOTIFY_STATE). /dev/null disables dedup.
  --dry-run             Print the would-be notification instead of firing it.
  -h, --help            Show this help.

Exit status:
  0  fired (or --dry-run) OR no-op because the (workstream,status) delta is unchanged
  2  usage error / unsupported status
EOF
}

die() { printf 'error: %s\n' "$*" >&2; exit 2; }

script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$script_dir/zgpt-common.sh"

state_dir="$(zgpt_state_dir "$PWD")"
state_file="${ZGPT_MANAGER_NOTIFY_STATE:-$state_dir/manager-notify.tsv}"
status=""
workstream=""
body=""
dry_run=0

while [[ $# -gt 0 ]]; do
    case "$1" in
        --status) status="${2:?--status needs a value}"; shift 2 ;;
        --workstream) workstream="${2:?--workstream needs a value}"; shift 2 ;;
        --body) body="${2:?--body needs a value}"; shift 2 ;;
        --state-file) state_file="${2:?--state-file needs a value}"; shift 2 ;;
        --dry-run) dry_run=1; shift ;;
        -h|--help) usage; exit 0 ;;
        *) die "unknown argument: $1 (see --help)" ;;
    esac
done

[[ -n "$status" ]] || die "--status is required (blocked|idle_for_steer)"
[[ -n "$workstream" ]] || die "--workstream is required"
case "$status" in
    blocked|idle_for_steer) ;;
    *) die "unsupported --status: $status (blocked|idle_for_steer)" ;;
esac

# Dedup: notify a (workstream,status) pair only once. Unchanged => quiet no-op;
# the pair being new or changed is the delta that warrants human attention.
if [[ "$state_file" != "/dev/null" && -f "$state_file" ]]; then
    pair="${workstream}"$'\t'"${status}"
    if grep -qF -- "$pair" "$state_file"; then
        exit 0
    fi
fi

title="MANAGER_STATUS: $status ($workstream)"
if [[ "$dry_run" == "1" ]]; then
    printf 'notify: %s' "$title"
    [[ -n "$body" ]] && printf ' | %s' "$body"
    printf '\n'
else
    zgpt_herdr_require
    zgpt_herdr_resolve_session
    if [[ -n "$body" ]]; then
        hd notification show "$title" --body "$body" >/dev/null 2>&1 || true
    else
        hd notification show "$title" >/dev/null 2>&1 || true
    fi
    printf 'notified=%s status=%s workstream=%s\n' "$title" "$status" "$workstream"
fi

# Record the fired pair (also on --dry-run, so offline runs exercise dedup).
if [[ "$state_file" != "/dev/null" ]]; then
    mkdir -p "$(dirname "$state_file")"
    printf '%s\t%s\n' "$workstream" "$status" >>"$state_file"
fi
exit 0
