#!/usr/bin/env bash
set -euo pipefail

# zgpt-wait-manager.sh — block until a keep-alive ring-1 manager pane reaches a
# steer-ready state (idle/done) or a blocked state, then print a machine-readable
# status line plus (optionally) the head of the assignment artifact.
#
# The supermanager uses this after a manager writes its assignment artifact and
# prints a `MANAGER_STATUS:` line in its pane (or the pane reaches idle/done): the
# manager is *idle_for_steer* once it is idle/done — a bare idle agent_status is
# NOT completion by itself, the idle_for_steer status (with artifact) is the
# signal — *blocked* when it parked waiting for a human decision, *timeout* when
# it is still working past the window, and *working_unknown* when its native
# state cannot be determined. `--status-regex` matches the manager's greppable
# `MANAGER_STATUS:` line via `herdr pane wait-output` (report-agent is broken on
# herdr 0.8.0, so the MANAGER_STATUS line is the primary wake-up signal).
#
# This is NOT a chat bus into the super transcript: it only observes the manager
# pane's herdr state and its artifact. It never injects text into the manager.

usage() {
    cat <<'EOF'
Usage: zgpt-wait-manager.sh --pane-id <id> [--artifact <path>] [--timeout <secs>]
                           [--status-regex <pattern>]

Wait for a keep-alive manager pane to become steer-ready or blocked.

Options:
  --pane-id <id>        (required) herdr pane id of the keep-alive manager.
  --artifact <path>     Optional artifact the manager was asked to write; when it
                        exists, its status line and head are printed.
  --status-regex <patt> Optional regex matching the manager's `MANAGER_STATUS:`
                        line; when given, wait on `herdr pane wait-output` for it
                        first and classify from the matched line (idle_for_steer /
                        blocked / working). This is the primary signal because
                        report-agent is broken on herdr 0.8.0.
  --timeout <secs>      Max wall-clock wait. Default: 3600.
  --poll <secs>         Idle-wait poll interval. Default: 3.
  --session <name>      herdr session name (or export ZGPT_HERDR_SESSION).
  -h, --help            Show this help.

Output (key=value lines, then two optional sections):
  status=idle_for_steer|blocked|timeout|working_unknown
  agent_status=<native herdr agent status>
  artifact=<path>            (only when --artifact was given and the file exists)
  artifact_status=<status>   (first `status:` line inside the artifact)
  -- artifact head --        (first lines of the artifact)
  -- pane tail --            (last lines of the pane, for a quick read)

Exit status:
  0  status=idle_for_steer (manager is ready for steer)
  2  status=blocked (manager parked waiting for a human decision)
  3  status=timeout (still working past the window)
  4  status=working_unknown (native state could not be determined)
EOF
}

die() { printf 'error: %s\n' "$*" >&2; exit 2; }
positive_integer() { [[ "${1:-}" =~ ^[1-9][0-9]*$ ]]; }

script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$script_dir/zgpt-common.sh"

pane_id=""
artifact=""
status_regex=""
timeout=3600
poll=3

while [[ $# -gt 0 ]]; do
    case "$1" in
        --pane-id) pane_id="${2:?--pane-id needs a value}"; shift 2 ;;
        --artifact) artifact="${2:?--artifact needs a value}"; shift 2 ;;
        --status-regex) status_regex="${2:?--status-regex needs a value}"; shift 2 ;;
        --timeout) timeout="${2:?--timeout needs a value}"; shift 2 ;;
        --poll) poll="${2:?--poll needs a value}"; shift 2 ;;
        --session) export ZGPT_HERDR_SESSION="${2:?--session needs a value}"; shift 2 ;;
        -h|--help) usage; exit 0 ;;
        *) die "unknown argument: $1 (see --help)" ;;
    esac
done

[[ -n "$pane_id" ]] || die "--pane-id is required"
positive_integer "$timeout" || die "--timeout must be a positive integer"
positive_integer "$poll" || die "--poll must be a positive integer"

zgpt_herdr_require
zgpt_herdr_resolve_session

# 1) Blocking wait for a steer-ready state. Primary signal: when --status-regex is
#    given, wait on the manager's greppable `MANAGER_STATUS:` line via
#    `herdr pane wait-output` and classify from the matched line (report-agent is
#    broken on herdr 0.8.0, so the line is the authoritative completion signal).
#    Fallback: a keep-alive manager reaches idle when it is waiting for steer; done
#    is the terminal state of a finished run and is equally steer-ready. A blocked
#    pane matches neither, so it is classified from `herdr agent get` after the
#    idle/done wait window elapses.
wait_ms=$(( timeout * 1000 ))
status=""
exit_rc=0
native_status=""

if [[ -n "$status_regex" ]] && hd pane wait-output --regex "$status_regex" --timeout "$wait_ms" "$pane_id" >/dev/null 2>&1; then
    status_line="$(hd pane read "$pane_id" --source recent-unwrapped 2>/dev/null \
        | grep -E "$status_regex" | tail -n1 || true)"
    case "$status_line" in
        *blocked*)  status="blocked";  exit_rc=2 ;;
        *working*)  status="timeout";  exit_rc=3 ;;
        *)          status="idle_for_steer"; exit_rc=0 ;;
    esac
else
    ready=false
    if hd agent wait "$pane_id" --until idle --timeout "$wait_ms" >/dev/null 2>&1; then
        ready=true
    elif hd agent wait "$pane_id" --until "done" --timeout 2000 >/dev/null 2>&1; then
        ready=true
    fi
    native_status="$(zgpt_herdr_agent_status "$pane_id")"
    if [[ "$ready" == true ]]; then
        status="idle_for_steer"
        exit_rc=0
    else
        case "$native_status" in
            blocked) status="blocked"; exit_rc=2 ;;
            working) status="timeout"; exit_rc=3 ;;
            *) status="working_unknown"; exit_rc=4 ;;
        esac
    fi
fi

printf 'status=%s\n' "$status"
[[ -n "$native_status" ]] && printf 'agent_status=%s\n' "$native_status"

# 2) Optional artifact: report its status line + head so the super reads the
#    manager's deliverable without a second pane read.
if [[ -n "$artifact" && -f "$artifact" ]]; then
    printf 'artifact=%s\n' "$artifact"
    art_status="$(sed -n 's/^[[:space:]]*status:[[:space:]]*//Ip' "$artifact" | sed -n '1p')"
    [[ -n "$art_status" ]] && printf 'artifact_status=%s\n' "$art_status"
    printf '%s\n' '-- artifact head --'
    sed -n '1,8p' "$artifact"
fi

# 3) Quick pane tail so the super sees what the manager was last doing.
pane_tail="$(hd pane read "$pane_id" --source recent-unwrapped --lines 8 2>/dev/null || true)"
if [[ -n "$pane_tail" ]]; then
    printf '%s\n' '-- pane tail --'
    printf '%s\n' "$pane_tail"
fi

exit "$exit_rc"
