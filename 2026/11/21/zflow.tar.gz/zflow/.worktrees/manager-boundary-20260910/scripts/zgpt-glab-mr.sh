#!/usr/bin/env bash
set -euo pipefail

# zgpt-glab-mr.sh — internal git-biz GitLab MR wrapper with stable URL parsing
# and automatic review-loop worker launch.
#
# Usage:
#   zgpt-glab-mr.sh create [--repo <owner/repo>] [--no-review] [glab mr create options...]
#   zgpt-glab-mr.sh attach <merge-request-url> [--cwd <dir>] [--command <cmd>]
#   zgpt-glab-mr.sh parse-url <merge-request-url>
#   zgpt-glab-mr.sh info   <merge-request-url>
#
# The create command wraps `glab mr create`, parses the output URL, and
# automatically starts a nonblocking review-loop worker in the background.
# Pass --no-review to skip the automatic review worker.
#
# attach starts a review-loop worker for an existing MR without creating one.
# parse-url extracts structured repo/project/MR identity from a GitLab URL.
# info prints key=value lines suitable for state-dir construction.
#
# Env overrides for testing:
#   ZGPT_GLAB_CMD              path to glab (default: glab)
#   ZGPT_GLAB_MR_FAKE_URL      fake URL returned by create (bypasses real glab)
#   ZGPT_REVIEW_LOOP_NO_AUTO   if set, skip auto-review-worker launch
#   ZGPT_GITLAB_HOST           allowed GitLab host (default: git-biz.qianxin-inc.cn)

script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
review_loop="$script_dir/zgpt-review-loop.sh"

usage() {
    cat <<'EOF'
Usage: zgpt-glab-mr.sh <command> [args...]

Commands:
  create [--repo <owner/repo>] [--no-review] [glab mr create args...]
      Create a GitLab MR via glab. Prints key=value lines including mr_url=,
      mr_iid=, source_branch=, target_branch=, web_url=.
      Automatically starts a nonblocking review-loop worker after successful
      creation unless --no-review is given or ZGPT_REVIEW_LOOP_NO_AUTO is set.

  attach <merge-request-url> [--cwd <dir>] [--command <cmd>]
      Attach a review-loop worker to an existing MR (no create step).

  parse-url <merge-request-url>
      Parse a GitLab MR URL and print key=value lines:
      mr_url=, project_path=, mr_iid=, host=.

  info <merge-request-url>
      Print key=value lines with full MR metadata (same fields as create).

Options:
  -h, --help    Show this help.
EOF
}

die() { printf 'error: %s\n' "$*" >&2; exit 2; }
log() { printf '[zgpt-glab-mr] %s\n' "$*" >&2; }

glab_cmd="${ZGPT_GLAB_CMD:-glab}"
internal_host="${ZGPT_GITLAB_HOST:-git-biz.qianxin-inc.cn}"

# ── URL parsing ────────────────────────────────────────────────────────
# Accepts forms like:
#   https://git-biz.qianxin-inc.cn/group/subgroup/repo/-/merge_requests/42
#   https://git-biz.qianxin-inc.cn/group/repo/-/merge_requests/42#note_123
#   https://git-biz.qianxin-inc.cn/group/repo/merge_requests/42  (older GitLab)

parse_mr_url() {
    local url="${1:-}"
    [[ -n "$url" ]] || die "parse-url requires a URL argument"

    # Strip fragments and parse with shell parameter expansion. Avoid sed regex
    # dialect differences between GNU sed and macOS/BSD sed.
    local base_url="${url%%#*}" scheme rest authority host_port hostname path_part project_path mr_iid tail
    case "$base_url" in
        http://*) scheme='http'; rest="${base_url#http://}" ;;
        https://*) scheme='https'; rest="${base_url#https://}" ;;
        *) die "could not parse host from URL: $url" ;;
    esac
    [[ "$rest" == */* ]] || die "could not parse MR URL path: $url"
    authority="${rest%%/*}"
    path_part="${rest#*/}"
    [[ -n "$authority" && -n "$path_part" ]] || die "could not parse MR URL: $url"
    [[ "$authority" != *@* ]] || die "userinfo is not allowed in MR URL: $url"

    host_port="$authority"
    hostname="${host_port%%:*}"
    [[ -n "$hostname" ]] || die "could not parse host from URL: $url"
    [[ "$hostname" == "$internal_host" ]] \
        || die "unsupported MR host '$hostname'; only internal git-biz ($internal_host) is allowed"

    case "$path_part" in
        */-/merge_requests/[0-9]*|*/-/merge_requests/[0-9]*/*)
            project_path="${path_part%%/-/merge_requests/*}"
            tail="${path_part#*/-/merge_requests/}"
            ;;
        */merge_requests/[0-9]*|*/merge_requests/[0-9]*/*)
            project_path="${path_part%%/merge_requests/*}"
            tail="${path_part#*/merge_requests/}"
            ;;
        *)
            die "could not parse MR URL: $url"
            ;;
    esac
    mr_iid="${tail%%/*}"
    mr_iid="${mr_iid%%\?*}"

    [[ -n "$project_path" ]] || die "could not parse project path from URL: $url"
    [[ "$project_path" != *'?'* ]] || die "could not parse project path from URL: $url"
    [[ "$mr_iid" =~ ^[0-9]+$ ]] || die "could not parse MR IID from URL: $url"

    printf 'mr_url=%s\n' "$url"
    printf 'host=%s://%s\n' "$scheme" "$host_port"
    printf 'project_path=%s\n' "$project_path"
    printf 'mr_iid=%s\n' "$mr_iid"
}

# ── Helper: fetch MR info from git-biz via glab ────────────────────────

mr_view_info() {
    local url="${1:-}"
    [[ -n "$url" ]] || die "mr_view_info requires a URL argument"

    local parsed project_path mr_iid
    parsed="$(parse_mr_url "$url")"
    project_path="$(printf '%s\n' "$parsed" | sed -n 's/^project_path=//p')"
    mr_iid="$(printf '%s\n' "$parsed" | sed -n 's/^mr_iid=//p')"
    [[ -n "$project_path" ]] || die "could not extract project_path from: $url"
    [[ -n "$mr_iid" ]] || die "could not extract mr_iid from: $url"

    GITLAB_HOST="$internal_host" "$glab_cmd" mr view -R "$project_path" "$mr_iid" --output json 2>/dev/null || true
}

maybe_launch_review_loop() {
    local mr_url="$1" cwd="${2:-$PWD}" worker_cmd="${3:-}"
    # Skip if disabled
    if [[ -n "${ZGPT_REVIEW_LOOP_NO_AUTO:-}" ]]; then
        log "auto review worker disabled via ZGPT_REVIEW_LOOP_NO_AUTO"
        return 0
    fi
    # start forks the supervisor itself and returns after recording its PID.
    # Keep this call in the foreground so the caller gets a reliable start or
    # dedupe acknowledgement without inheriting a detached stdout pipe.
    local start_args=(start "$mr_url" --cwd "$cwd")
    [[ -n "$worker_cmd" ]] && start_args+=(--command "$worker_cmd")
    log "auto-starting review-loop worker for $mr_url"
    "$review_loop" "${start_args[@]}"
}

# ── MR creation ────────────────────────────────────────────────────────

create_mr() {
    local repo_arg="" no_review=false glab_args=() cwd="$PWD" worker_cmd=""

    while [[ $# -gt 0 ]]; do
        case "$1" in
            --repo)
                repo_arg="${2:?}"; shift 2 ;;
            --no-review)
                no_review=true; shift ;;
            --cwd)
                cwd="${2:?}"; shift 2 ;;
            --command)
                worker_cmd="${2:?}"; shift 2 ;;
            *)
                glab_args+=("$1"); shift ;;
        esac
    done

    if [[ -n "${ZGPT_GLAB_MR_FAKE_URL:-}" ]]; then
        # Test mode: return a fake URL
        local fake_url="${ZGPT_GLAB_MR_FAKE_URL}"
        parse_mr_url "$fake_url"
        printf 'source_branch=%s\n' "${ZGPT_GLAB_MR_FAKE_SOURCE_BRANCH:-feature-branch}"
        printf 'target_branch=%s\n' "${ZGPT_GLAB_MR_FAKE_TARGET_BRANCH:-main}"
        printf 'web_url=%s\n' "$fake_url"
        if [[ "$no_review" != true ]]; then
            maybe_launch_review_loop "$fake_url" "$cwd" "$worker_cmd"
        fi
        return 0
    fi

    # Build glab command
    local cmd=(env GITLAB_HOST="$internal_host" "$glab_cmd" "mr" "create")
    [[ -n "$repo_arg" ]] && cmd+=("--repo" "$repo_arg")
    cmd+=("${glab_args[@]}")

    local output rc=0
    output="$("${cmd[@]}" 2>&1)" || rc=$?
    if [[ $rc -ne 0 ]]; then
        die "glab mr create failed (exit $rc): $output"
    fi

    # Parse the URL from glab output
    local mr_url
    mr_url="$(printf '%s\n' "$output" | grep -oE 'https?://[^[:space:]]+/-/merge_requests/[0-9]+' | tail -1)" || true
    if [[ -z "$mr_url" ]]; then
        mr_url="$(printf '%s\n' "$output" | grep -oE 'https?://[^[:space:]]+/merge_requests/[0-9]+' | tail -1 || true)"
    fi

    if [[ -z "$mr_url" ]]; then
        printf 'error: could not parse MR URL from glab output:\n%s\n' "$output" >&2
        exit 2
    fi

    # Get MR details for branch info via mr_view_info helper
    local mr_info source_branch target_branch
    mr_info="$(mr_view_info "$mr_url")"
    source_branch="$(printf '%s\n' "$mr_info" | jq -r '.source_branch // empty' 2>/dev/null || true)"
    target_branch="$(printf '%s\n' "$mr_info" | jq -r '.target_branch // empty' 2>/dev/null || true)"

    parse_mr_url "$mr_url"
    [[ -n "$source_branch" ]] && printf 'source_branch=%s\n' "$source_branch"
    [[ -n "$target_branch" ]] && printf 'target_branch=%s\n' "$target_branch"
    printf 'web_url=%s\n' "$mr_url"

    # Auto-start review loop unless --no-review
    if [[ "$no_review" != true ]]; then
        maybe_launch_review_loop "$mr_url" "$cwd" "$worker_cmd"
    fi
}

# ── attach: start review loop for an existing MR ──────────────────────

cmd_attach() {
    local mr_url="${1:-}" cwd="$PWD" worker_cmd=""
    shift || true
    while [[ $# -gt 0 ]]; do
        case "$1" in
            --cwd) cwd="${2:?}"; shift 2 ;;
            --command) worker_cmd="${2:?}"; shift 2 ;;
            *) shift ;;
        esac
    done
    [[ -n "$mr_url" ]] || die "attach requires an MR URL"
    [[ "$mr_url" =~ ^https?:// ]] || die "MR URL must start with http:// or https://"

    local start_args=(start "$mr_url" --cwd "$cwd")
    [[ -n "$worker_cmd" ]] && start_args+=(--command "$worker_cmd")
    "$review_loop" "${start_args[@]}"
    printf 'status=attached\n'
    printf 'mr_url=%s\n' "$mr_url"
}

# ── info: parse URL and add repo context ───────────────────────────────

mr_info() {
    local url="${1:-}"
    [[ -n "$url" ]] || die "info requires a URL argument"
    parse_mr_url "$url"

    if command -v "$glab_cmd" >/dev/null 2>&1; then
        local mr_info
        mr_info="$(mr_view_info "$url")"
        local source_branch target_branch
        source_branch="$(printf '%s\n' "$mr_info" | jq -r '.source_branch // empty' 2>/dev/null || true)"
        target_branch="$(printf '%s\n' "$mr_info" | jq -r '.target_branch // empty' 2>/dev/null || true)"
        [[ -n "$source_branch" ]] && printf 'source_branch=%s\n' "$source_branch"
        [[ -n "$target_branch" ]] && printf 'target_branch=%s\n' "$target_branch"
    fi
}

# ── Main ────────────────────────────────────────────────────────────────

case "${1:-}" in
    create)
        shift
        create_mr "$@"
        ;;
    attach)
        shift
        cmd_attach "$@"
        ;;
    parse-url)
        [[ -n "${2:-}" ]] || die "parse-url requires a URL argument"
        parse_mr_url "$2"
        ;;
    info)
        [[ -n "${2:-}" ]] || die "info requires a URL argument"
        mr_info "$2"
        ;;
    -h|--help)
        usage
        ;;
    *)
        die "unknown command: ${1:-}. Use create, attach, parse-url, or info."
        ;;
esac
