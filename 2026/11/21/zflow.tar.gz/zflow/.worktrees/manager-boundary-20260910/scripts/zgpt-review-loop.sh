#!/usr/bin/env bash
set -euo pipefail

# Deterministic GitLab MR review-loop supervisor.
# Polls every 60 seconds for at most 15 minutes, while visible workers only
# decide and implement individual review fixes.

script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=.claude/skills/zflow-workers/scripts/zgpt-common.sh
source "$script_dir/zgpt-common.sh"

glab_mr_script="$script_dir/zgpt-glab-mr.sh"
run_worker="${ZGPT_RUN_WORKER_CMD:-$script_dir/zgpt-run-worker.sh}"
pane_helper="${ZGPT_WORKER_PANE_CMD:-$script_dir/zgpt-worker-pane.sh}"

POLL_INTERVAL="${ZGPT_REVIEW_LOOP_POLL_INTERVAL:-60}"
MAX_RUNTIME="${ZGPT_REVIEW_LOOP_MAX_RUNTIME:-900}"
MAX_ATTEMPTS="${ZGPT_REVIEW_LOOP_MAX_ATTEMPTS:-3}"
MAX_POLLS="${ZGPT_REVIEW_LOOP_MAX_POLLS:-0}"
GLAB_CMD="${ZGPT_GLAB_CMD:-glab}"
SELF_USERNAME="${ZGPT_REVIEW_LOOP_SELF_USERNAME:-}"
TRUSTED_REVIEWERS="${ZGPT_REVIEW_LOOP_TRUSTED_REVIEWERS:-}"
ALLOW_PUSH="${ZGPT_REVIEW_LOOP_ALLOW_PUSH:-false}"
# TrustBotSelfReview: when true, yg-bot's own auto-review comment
# ("## AI Code Review (yg-bot)" containing a findings table and no approval
# conclusion) counts as an actionable item WITHOUT being in TRUSTED_REVIEWERS.
# Fail-closed (default false). Never makes the bot's own comment a positive
# approval signal — the merge gate stays independent.
TRUST_BOT_SELF_REVIEW="${ZGPT_REVIEW_LOOP_TRUST_BOT_SELF_REVIEW:-false}"
# BOT_REVIEW_AUTHOR: the GitLab username that posts yg-bot auto-reviews. When
# TRUST_BOT_SELF_REVIEW=true this binds the marker so arbitrary commenters
# cannot forge a bot review. Resolved via `glab api user` when not provided.
BOT_REVIEW_AUTHOR="${ZGPT_REVIEW_LOOP_BOT_REVIEW_AUTHOR:-}"
MARKER='[zflow-review-loop]'
# ZGPT_GITLAB_HOST overrides the allowed GitLab host; default preserves prior
# hardcoded behavior. This is a safety allowlist of exactly one host, not a
# convenience switch — other hosts (including GitHub) are still rejected.
INTERNAL_HOST="${ZGPT_GITLAB_HOST:-git-biz.qianxin-inc.cn}"
INTERNAL_SSH_KEY="${ZGPT_GITLAB_SSH_ALIAS:-git-biz}"

usage() {
    cat <<'EOF'
Usage: zgpt-review-loop.sh <command> [args]

Commands:
  start <mr-url> [--cwd DIR] [--name NAME] [--command CMD]
                 [--worktree DIR] [--owned-worktree DIR]
                 [--trusted-reviewers "user1,user2"] [--allow-push true|false]
                 [--trust-bot-self-review true|false] [--bot-review-author USER]
  supervise <mr-url> --cwd DIR --name NAME [--command CMD] --worktree DIR
                 --poll-interval N --max-runtime N --max-attempts N --max-polls N
                 --glab-cmd CMD [--self-username USER]
                 [--trusted-reviewers LIST] [--allow-push true|false]
                 [--trust-bot-self-review true|false] [--bot-review-author USER]
  status <mr-url>
  stop <mr-url>
  list
  config

Only the internal git-biz GitLab host is supported; GitHub and other GitLab
hosts are rejected. The default poll interval is 60 seconds and the observation
window is 900 seconds. Each item has its own 3-attempt limit. The observation
window is checked between items and never terminates an in-flight fix worker. Production start
launches the supervisor in a visible herdr pane via zgpt-worker-pane.sh; tests
may set ZGPT_REVIEW_LOOP_LAUNCH_BACKEND=background.
EOF
}

die() { printf 'error: %s\n' "$*" >&2; exit 2; }
log() { printf '[zgpt-review-loop] %s\n' "$*" >&2; }

current_secs() {
    if [[ -n "${ZGPT_FAKE_TIME_FILE:-}" ]]; then
        local value
        IFS= read -r value < "$ZGPT_FAKE_TIME_FILE"
        printf '%s\n' "$value"
    elif [[ -n "${ZGPT_FAKE_TIME:-}" ]]; then
        printf '%s\n' "$ZGPT_FAKE_TIME"
    else
        date +%s
    fi
}

maybe_sleep() {
    [[ -n "${ZGPT_FAKE_SLEEP:-}" ]] || sleep "${1:-1}"
}

require_jq() {
    command -v jq >/dev/null 2>&1 || die "jq is required"
}

mr_fields() {
    "$glab_mr_script" parse-url "$1"
}

mr_field() {
    local output
    output="$(mr_fields "$1")" || return 1
    printf '%s\n' "$output" | sed -n "s/^$2=//p"
}

mr_identity() {
    local host project iid raw
    host="$(mr_field "$1" host)"
    project="$(mr_field "$1" project_path)"
    iid="$(mr_field "$1" mr_iid)"
    host="${host#http://}"
    host="${host#https://}"
    raw="${host}_${project}_mr${iid}"
    printf '%s\n' "$raw" | sed 's/[^A-Za-z0-9._-]/_/g'
}

# State is global per MR under <root>/review-loops/<identity>, independent of cwd.
# Root is ZGPT_STATE_DIR_OVERRIDE (test override) or zgpt_state_root (default /tmp/zflow).
review_loop_state_dir() {
    local base
    base="${ZGPT_STATE_DIR_OVERRIDE:-$(zgpt_state_root)}"
    printf '%s/review-loops/%s\n' "$base" "$(mr_identity "$1")"
}

state_file() { printf '%s/%s\n' "$(review_loop_state_dir "$1" "${3:-$PWD}")" "$2"; }
lock_dir() { state_file "$1" lock "${2:-$PWD}"; }
pid_file() { state_file "$1" supervisor.pid "${2:-$PWD}"; }
pane_file() { state_file "$1" supervisor.pane "${2:-$PWD}"; }
attempts_file() { state_file "$1" attempts.json "${2:-$PWD}"; }
seen_file() { state_file "$1" last-seen.json "${2:-$PWD}"; }
owned_worktree_file() { state_file "$1" owned-worktree "${2:-$PWD}"; }
status_file() { state_file "$1" status "${2:-$PWD}"; }
log_file() { state_file "$1" supervisor.log "${2:-$PWD}"; }

init_state() {
    local dir
    dir="$(review_loop_state_dir "$1" "${2:-$PWD}")"
    mkdir -p "$dir"
    [[ -f "$(attempts_file "$1" "${2:-$PWD}")" ]] || printf '{}\n' > "$(attempts_file "$1" "${2:-$PWD}")"
    [[ -f "$(seen_file "$1" "${2:-$PWD}")" ]] || printf '{}\n' > "$(seen_file "$1" "${2:-$PWD}")"
}

json_get() {
    local file="$1" key="$2" fallback="$3"
    jq -r --arg key "$key" --arg fallback "$fallback" '.[$key] // $fallback' "$file"
}

json_set() {
    local file="$1" key="$2" value="$3" type="${4:-string}"
    local tmp="${file}.tmp.$$"
    if [[ "$type" == number ]]; then
        jq --arg key "$key" --argjson value "$value" '.[$key] = $value' "$file" > "$tmp"
    else
        jq --arg key "$key" --arg value "$value" '.[$key] = $value' "$file" > "$tmp"
    fi
    mv "$tmp" "$file"
}

attempt_count() { json_get "$(attempts_file "$1" "$3")" "$2" 0; }
last_seen() { json_get "$(seen_file "$1" "$3")" "$2" ''; }
mark_seen() { json_set "$(seen_file "$1" "$3")" "$2" "$4"; }

increment_attempt() {
    local current
    current="$(attempt_count "$1" "$2" "$3")"
    current=$((current + 1))
    json_set "$(attempts_file "$1" "$3")" "$2" "$current" number
    printf '%s\n' "$current"
}

kill_tree() {
    local pid="${1:-}" child
    [[ "$pid" =~ ^[0-9]+$ ]] || return 0
    # Portable: use ps -axo + awk instead of GNU ps --ppid / --no-headers
    while IFS= read -r child; do
        [[ -n "$child" ]] && kill_tree "$child"
    done < <(ps -axo pid=,ppid= 2>/dev/null | awk -v ppid="$pid" '$2 == ppid {print $1}')
    kill -TERM "$pid" 2>/dev/null || true
}

is_live_pane() {
    local pane_id="${1:-}"
    [[ -n "$pane_id" ]] || return 1
    "$pane_helper" tab-for-pane "$pane_id" >/dev/null 2>&1
}

acquire_lock() {
    local mr_url="$1" cwd="$2" lock pid pane
    lock="$(lock_dir "$mr_url" "$cwd")"
    mkdir -p "$(dirname "$lock")"
    if mkdir "$lock" 2>/dev/null; then
        # Close the lock/PID race: the starter owns it until the supervisor PID or
        # visible pane identity replaces this value.
        printf '%s\n' "$$" > "$(pid_file "$mr_url" "$cwd")"
        return 0
    fi
    pid="$(cat "$(pid_file "$mr_url" "$cwd")" 2>/dev/null || true)"
    pane="$(cat "$(pane_file "$mr_url" "$cwd")" 2>/dev/null || true)"
    if [[ "$pid" =~ ^[0-9]+$ ]] && kill -0 "$pid" 2>/dev/null; then
        return 1
    fi
    if is_live_pane "$pane"; then
        return 1
    fi
    rm -rf "$lock"
    mkdir "$lock"
    printf '%s\n' "$$" > "$(pid_file "$mr_url" "$cwd")"
}
release_lock() {
    rm -rf "$(lock_dir "$1" "${2:-$PWD}")"
}

encoded_project() {
    mr_field "$1" project_path | sed 's|/|%2F|g'
}

mr_iid() { mr_field "$1" mr_iid; }

api_get() {
    local path="$1" result rc=0
    result="$("$GLAB_CMD" api --hostname "$INTERNAL_HOST" "$path" 2>&1)" || rc=$?
    if ((rc != 0)); then
        printf 'GitLab API GET failed (%d): %s\n' "$rc" "$result" >&2
        return "$rc"
    fi
    printf '%s\n' "$result"
}

resolve_self_username() {
    [[ -n "$SELF_USERNAME" ]] && return 0
    local user_json
    user_json="$(api_get user)" || return 1
    SELF_USERNAME="$(jq -r '.username // empty' <<< "$user_json")"
    [[ -n "$SELF_USERNAME" ]]
}

fetch_paginated() {
    local base="$1" page=1 page_json length all='[]' separator='?'
    [[ "$base" == *\?* ]] && separator='&'
    while true; do
        page_json="$(api_get "${base}${separator}per_page=100&page=${page}")" || return 1
        jq -e 'type == "array"' >/dev/null <<< "$page_json" || {
            printf 'GitLab API returned non-array page for %s\n' "$base" >&2
            return 1
        }
        length="$(jq 'length' <<< "$page_json")"
        all="$(jq -cn --argjson left "$all" --argjson right "$page_json" '$left + $right')"
        ((length < 100)) && break
        page=$((page + 1))
    done
    printf '%s\n' "$all"
}

fetch_notes() {
    if [[ -n "${ZGPT_FAKE_NOTES_FILE:-}" ]]; then cat "$ZGPT_FAKE_NOTES_FILE"; return; fi
    fetch_paginated "projects/$(encoded_project "$1")/merge_requests/$(mr_iid "$1")/notes?sort=asc"
}

fetch_discussions() {
    if [[ -n "${ZGPT_FAKE_DISCUSSIONS_FILE:-}" ]]; then cat "$ZGPT_FAKE_DISCUSSIONS_FILE"; return; fi
    fetch_paginated "projects/$(encoded_project "$1")/merge_requests/$(mr_iid "$1")/discussions"
}

fetch_approvals() {
    if [[ -n "${ZGPT_FAKE_APPROVALS_FILE:-}" ]]; then cat "$ZGPT_FAKE_APPROVALS_FILE"; return; fi
    api_get "projects/$(encoded_project "$1")/merge_requests/$(mr_iid "$1")/approvals"
}

fetch_mr() {
    if [[ -n "${ZGPT_FAKE_MR_STATE:-}" ]]; then
        jq -cn --arg state "$ZGPT_FAKE_MR_STATE" --arg source "${ZGPT_FAKE_SOURCE_BRANCH:-feature-x}" \
            '{state:$state, source_branch:$source, source_project_id:1}'
        return
    fi
    api_get "projects/$(encoded_project "$1")/merge_requests/$(mr_iid "$1")"
}

post_note() {
    local mr_url="$1" body="$2" result rc=0
    if [[ -n "${ZGPT_FAKE_POST_LOG:-}" ]]; then
        printf '%s\t%s\n' "$(current_secs)" "$body" >> "$ZGPT_FAKE_POST_LOG"
        return 0
    fi
    if [[ -n "${ZGPT_FAKE_NOTES_FILE:-}" ]]; then
        local id tmp
        id="$(date +%s%N)"
        tmp="${ZGPT_FAKE_NOTES_FILE}.tmp.$$"
        jq --arg body "$body" --argjson id "$id" \
            '. + [{id:$id, body:$body, author:{username:"zflow-bot", bot:true}, system:false}]' \
            "$ZGPT_FAKE_NOTES_FILE" > "$tmp" && mv "$tmp" "$ZGPT_FAKE_NOTES_FILE"
        return
    fi
    result="$("$GLAB_CMD" api --hostname "$INTERNAL_HOST" -X POST \
        "projects/$(encoded_project "$mr_url")/merge_requests/$(mr_iid "$mr_url")/notes" \
        --field "body=$body" 2>&1)" || rc=$?
    if ((rc != 0)); then
        printf 'GitLab MR note post failed (%d): %s\n' "$rc" "$result" >&2
        return "$rc"
    fi
}

post_final() {
    local kind="$2" detail="$3"
    post_note "$1" "$MARKER **${kind}** — ${detail}. Done; stopping review checks."
}

finish_with_note() {
    local mr_url="$1" cwd="$2" status="$3" kind="$4" detail="$5" cleanup_fn="${6:-}"
    if post_final "$mr_url" "$kind" "$detail"; then
        # Run any terminal-path cleanup (e.g. owned-worktree removal) before the
        # status file is published, so a poller observing the terminal status
        # never sees stale on-disk state (e.g. a worktree that should be gone).
        # Cleanup is best-effort and deliberately non-fatal: the MR really did
        # reach this terminal state, so a refused or failed cleanup must not
        # suppress the status. Note that being on the right-hand side of ||
        # also disables errexit here, which is why the failure is logged
        # explicitly rather than left silent.
        if [[ -n "$cleanup_fn" ]] && ! "$cleanup_fn" "$mr_url" "$cwd"; then
            log "terminal cleanup ${cleanup_fn} failed; publishing status=${status} anyway"
        fi
        printf '%s\n' "$status" > "$(status_file "$mr_url" "$cwd")"
        return 0
    fi
    printf 'blocked_post\n' > "$(status_file "$mr_url" "$cwd")"
    return 1
}

positive_text() {
    local normalized
    normalized="$(printf '%s' "$1" | tr '[:upper:]' '[:lower:]' | tr '\n\r\t' '   ' | sed 's/[[:space:]]\+/ /g; s/^ //; s/ $//')"
    [[ "$normalized" =~ (^|[^[:alnum:]])(not|isn.t|isnt|no)[[:space:]]+(lgtm|approved|looks[[:space:]]+good) ]] && return 1
    [[ "$normalized" =~ (lgtm|approved|looks[[:space:]]+good).*(but|except|however|yet|once|after|when) ]] && return 1
    [[ "$normalized" =~ (^|[^[:alnum:]])lgtm([^[:alnum:]]|$) ]] ||
        [[ "$normalized" =~ (^|[^[:alnum:]])looks[[:space:]]+good[[:space:]]+to[[:space:]]+me([^[:alnum:]]|$) ]] ||
        [[ "$normalized" =~ (^|[^[:alnum:]])approved([^[:alnum:]]|$) ]] ||
        [[ "$normalized" =~ ^/?approve[.![:space:]]*$ ]]
}

eligible_note_lines() {
    local notes_json="$1" mode="$2"
    # TRUSTED_REVIEWERS gating: empty = default-deny (no one triggers a fix worker).
    # Non-empty = comma-separated case-insensitive allowlist with whitespace trimmed.
    # TRUST_BOT_SELF_REVIEW adds an opt-in exception: yg-bot's own auto-review
    # note ("## AI Code Review (yg-bot)" with a findings table, no approval
    # conclusion) is actionable without a trusted human reviewer. The merge
    # gate (has_positive_signal / API approval) is NOT affected by this flag.
    if [[ "$mode" == discussions ]]; then
        jq -c --arg self "$SELF_USERNAME" --arg trusted "$TRUSTED_REVIEWERS" --arg trust_bot "$TRUST_BOT_SELF_REVIEW" --arg bot_author "$BOT_REVIEW_AUTHOR" '
          def eligible($self):
            (.system // false) != true and
            (.author.bot // false) != true and
            ((.author.username // "") != "zflow-bot") and
            ($self == "" or (.author.username // "") != $self) and
            (((.author.username // "") | test("(^|[-_])bot$|\\[bot\\]$"; "i")) | not) and
            (((.body // "") | test("\\[zflow-review-loop\\]|\\[zflow-skip\\]"; "i")) | not);
          def trusted($list):
            if $list == "" then false
            else (.author.username // "") | ascii_downcase as $author |
              ($list | ascii_downcase | gsub("\\s+";"") | split(",")) as $arr |
              any($arr[]; . == $author)
            end;
          def bot_self_review($trust_bot; $bot_author):
            ($trust_bot == "true") and
            ($bot_author != "") and
            (((.author.username // "") | ascii_downcase) == ($bot_author | ascii_downcase)) and
            ((.body // "") | contains("## AI Code Review")) and
            ((.body // "") | contains("严重度")) and
            (((.body // "") | test("批准合入|LGTM"; "i")) | not);
          .[] | select(.resolved != true) | select((.notes // []) | length > 0) | . as $discussion |
          [$discussion.notes[] | select(eligible($self) and (trusted($trusted) or bot_self_review($trust_bot; $bot_author))) | select(.resolved != true)] | last // empty |
          {identity:($discussion.id // .id | tostring), note_id:(.id|tostring),
           body:(.body // ""), path:(.position.new_path // .position.old_path // ""),
           line:((.position.new_line // .position.old_line // 0)|tostring)}
        ' <<< "$notes_json"
    else
        jq -c --arg self "$SELF_USERNAME" --arg trusted "$TRUSTED_REVIEWERS" --arg trust_bot "$TRUST_BOT_SELF_REVIEW" --arg bot_author "$BOT_REVIEW_AUTHOR" '
          def eligible($self):
            (.system // false) != true and
            (.author.bot // false) != true and
            ((.author.username // "") != "zflow-bot") and
            ($self == "" or (.author.username // "") != $self) and
            (((.author.username // "") | test("(^|[-_])bot$|\\[bot\\]$"; "i")) | not) and
            (((.body // "") | test("\\[zflow-review-loop\\]|\\[zflow-skip\\]"; "i")) | not);
          def trusted($list):
            if $list == "" then false
            else (.author.username // "") | ascii_downcase as $author |
              ($list | ascii_downcase | gsub("\\s+";"") | split(",")) as $arr |
              any($arr[]; . == $author)
            end;
          def bot_self_review($trust_bot; $bot_author):
            ($trust_bot == "true") and
            ($bot_author != "") and
            (((.author.username // "") | ascii_downcase) == ($bot_author | ascii_downcase)) and
            ((.body // "") | contains("## AI Code Review")) and
            ((.body // "") | contains("严重度")) and
            (((.body // "") | test("批准合入|LGTM"; "i")) | not);
          .[] | select(eligible($self) and (trusted($trusted) or bot_self_review($trust_bot; $bot_author))) |
          select((.type // "") != "DiffNote" and .position == null) |
          {identity:(.id|tostring), note_id:(.id|tostring), body:(.body // ""), path:"", line:"0"}
        ' <<< "$notes_json"
    fi
}

# Trusted-reviewer gating: when ZGPT_REVIEW_LOOP_TRUSTED_REVIEWERS is non-empty,
# only those usernames (comma-separated, case-insensitive) are eligible for
# text-based positive signals (LGTM, looks good, approve text). API approval
# always counts regardless. When TRUSTED_REVIEWERS is empty (default), no one's
# text triggers a terminal positive signal — only GitLab API approval can.
has_positive_signal() {
    local notes="$1" discussions="$2" body
    # Pass TRUSTED_REVIEWERS; empty means default-deny for text signals
    while IFS= read -r body; do positive_text "$body" && return 0; done < <(
        jq -r --arg self "$SELF_USERNAME" --arg trusted "$TRUSTED_REVIEWERS" '
          def eligible($self):
            (.system // false) != true and (.author.bot // false) != true and
            ((.author.username // "") != "zflow-bot") and
            ($self == "" or (.author.username // "") != $self) and
            (((.author.username // "") | test("(^|[-_])bot$|\\[bot\\]$"; "i")) | not) and
            (((.body // "") | test("\\[zflow-review-loop\\]|\\[zflow-skip\\]"; "i")) | not);
          def trusted($list):
            if $list == "" then false
            else (.author.username // "") | ascii_downcase as $author |
              ($list | ascii_downcase | gsub("\\s+";"") | split(",")) as $arr |
              any($arr[]; . == $author)
            end;
          .[] | select(.resolved != true) |
          select((.type // "") != "DiffNote" and .position == null) |
          select(eligible($self) and trusted($trusted)) | .body // empty
        ' <<< "$notes"
        jq -r --arg self "$SELF_USERNAME" --arg trusted "$TRUSTED_REVIEWERS" '
          def eligible($self):
            (.system // false) != true and (.author.bot // false) != true and
            ((.author.username // "") != "zflow-bot") and
            ($self == "" or (.author.username // "") != $self) and
            (((.author.username // "") | test("(^|[-_])bot$|\\[bot\\]$"; "i")) | not) and
            (((.body // "") | test("\\[zflow-review-loop\\]|\\[zflow-skip\\]"; "i")) | not);
          def trusted($list):
            if $list == "" then false
            else (.author.username // "") | ascii_downcase as $author |
              ($list | ascii_downcase | gsub("\\s+";"") | split(",")) as $arr |
              any($arr[]; . == $author)
            end;
          .[] | select(.resolved != true) | .notes[]? | select(.resolved != true) |
          select(eligible($self) and trusted($trusted)) | .body // empty
        ' <<< "$discussions"
    )
    return 1
}

validate_fix_target() {
    [[ -n "${ZGPT_FAKE_RUN_WORKER:-}" ]] && return 0
    local mr_json="$1" worktree="$2" branch source remote project expected remote_host remote_path rest
    branch="$(git -C "$worktree" branch --show-current)" || return 1
    source="$(jq -r '.source_branch // empty' <<< "$mr_json")"
    [[ -n "$branch" && "$branch" == "$source" ]] || {
        printf 'checked-out branch %s does not match MR source branch %s\n' "$branch" "$source" >&2; return 1;
    }
    [[ ! "$branch" =~ ^(main|master|dev|test|release($|[-/])) ]] || {
        printf 'refusing protected source branch: %s\n' "$branch" >&2; return 1;
    }
    remote="$(git -C "$worktree" remote get-url origin)" || return 1
    project="$(mr_field "${3}" project_path)"
    expected="${ZGPT_REVIEW_LOOP_SOURCE_PROJECT:-$project}"
    remote="${remote%.git}"
    if [[ "$remote" == *://* ]]; then
        rest="${remote#*://}"; rest="${rest#*@}"
        remote_host="${rest%%/*}"; remote_host="${remote_host%%:*}"
        remote_path="${rest#*/}"
    elif [[ "$remote" == *@*:* ]]; then
        rest="${remote#*@}"; remote_host="${rest%%:*}"; remote_path="${rest#*:}"
    elif [[ "$remote" == *:* ]]; then
        remote_host="${remote%%:*}"; remote_path="${remote#*:}"
    else
        printf 'unsupported origin URL: %s\n' "$remote" >&2; return 1
    fi
    [[ "$remote_host" == "$INTERNAL_HOST" || "$remote_host" == "$INTERNAL_SSH_KEY" ]] || {
        printf 'origin host must be %s/%s, got %s\n' "$INTERNAL_SSH_KEY" "$INTERNAL_HOST" "$remote_host" >&2; return 1;
    }
    [[ "$remote_path" == "$expected" ]] || {
        printf 'origin does not match MR source project %s: %s\n' "$expected" "$remote" >&2; return 1;
    }
}

build_fix_prompt() {
    cat <<EOF
Fix GitLab MR review item $2 on <$1> (attempt $6 of $MAX_ATTEMPTS).

Review feedback:
$3

Location: $4:$5

Write your deliverable artifact with this exact header format:
First line: schema=zflow.review_loop.worker_result.v1
Then one line: status=<status> where status is fixed, not_actionable, or failed
If status=fixed, include exactly one line: commit_sha=<full 40-char sha>
If status=not_actionable or status=failed, do not include commit_sha.

Work only in the assigned worktree. Decide whether this is actionable. If it is
not actionable, report status=not_actionable without editing. Otherwise apply
the smallest safe fix, verify it, create a normal new commit, and push only the
current MR source branch. Never amend, rebase, force-push, merge, or push a
protected branch. End with status=fixed or status=failed; include commit_sha=<sha>
only with status=fixed after the push is verified.
EOF
}

run_fix_worker() {
    local mr_url="$1" identity="$2" body="$3" path="$4" line="$5" attempt="$6" cwd="$7" worktree="$8" worker_cmd="$9" name="${10}"
    if [[ -n "${ZGPT_FAKE_RUN_WORKER:-}" ]]; then
        if [[ -n "${ZGPT_FAKE_WORKER_ADVANCE_TIME_TO:-}" && -n "${ZGPT_FAKE_TIME_FILE:-}" ]]; then
            printf '%s\n' "$ZGPT_FAKE_WORKER_ADVANCE_TIME_TO" > "$ZGPT_FAKE_TIME_FILE"
        fi
        printf 'status=%s\n' "${ZGPT_FAKE_WORKER_STATUS:-fixed}"
        [[ "${ZGPT_FAKE_WORKER_STATUS:-fixed}" == fixed ]] && printf 'commit_sha=fakeabc123\n'
        return "${ZGPT_FAKE_WORKER_RC:-0}"
    fi
    local prompt token output rc=0 args supervisor_pane artifact_dir artifact safe_identity artifact_status artifact_commit resolved_commit head_commit upstream_commit
    prompt="$(build_fix_prompt "$mr_url" "$identity" "$body" "$path" "$line" "$attempt")"
    token="fix-${identity}-$(date +%s)"
    supervisor_pane="$(cat "$(pane_file "$mr_url" "$cwd")" 2>/dev/null || true)"
    safe_identity="$(printf '%s' "$identity" | tr -c 'A-Za-z0-9._-' '_')"
    artifact_dir="$(review_loop_state_dir "$mr_url" "$cwd")/worker-results"
    artifact="$artifact_dir/${safe_identity}-attempt-${attempt}.txt"
    mkdir -p "$artifact_dir"
    rm -f "$artifact"
    args=(--name "${name}-${identity}" --cwd "$worktree" --route implement --report-mode full
          --timeout 300 --max-timeout 300 --token "$token" --artifact "$artifact" --close --task "$prompt")
    [[ -n "$worker_cmd" ]] && args=(--command "$worker_cmd" "${args[@]}")
    if [[ -n "$supervisor_pane" ]]; then
        output="$(ZGPT_MANAGER_PANE_ID="$supervisor_pane" ZJ_PANE_ID="$supervisor_pane" "$run_worker" "${args[@]}" 2>&1)" || rc=$?
    else
        output="$("$run_worker" "${args[@]}" 2>&1)" || rc=$?
    fi
    if [[ -s "$artifact" ]]; then
        # Schema enforcement: always strict. First line must be the schema header.
        local schema_line schema_count status_count commit_count
        schema_line="$(sed -n '1p' "$artifact")"
        schema_count="$(grep -c '^schema=' "$artifact" || true)"
        if [[ "$schema_line" != "schema=zflow.review_loop.worker_result.v1" ]] || ((schema_count != 1)); then
            printf 'artifact missing schema=zflow.review_loop.worker_result.v1 (got: %s)\n' "$schema_line" >&2
            return 1
        fi
        status_count="$(grep -c '^status=' "$artifact" || true)"
        if ((status_count != 1)); then
            printf 'artifact must have exactly one status= line (found %d)\n' "$status_count" >&2
            return 1
        fi
        commit_count="$(grep -c '^commit_sha=' "$artifact" || true)"
        artifact_status="$(sed -n 's/^status=//p' "$artifact" | tail -1)"
        artifact_commit="$(sed -n 's/^commit_sha=//p' "$artifact" | tail -1)"
        case "$artifact_status" in
            not_actionable)
                if ((commit_count != 0)); then
                    printf 'not_actionable artifact must not contain commit_sha=\n' >&2
                    return 1
                fi
                cat "$artifact"
                return 0
                ;;
            failed)
                if ((commit_count != 0)); then
                    printf 'failed artifact must not contain commit_sha=\n' >&2
                    return 1
                fi
                return 1
                ;;
            fixed)
                if ((commit_count != 1)); then
                    printf 'fixed artifact must contain exactly one commit_sha= line\n' >&2
                    return 1
                fi
                if ! [[ "$artifact_commit" =~ ^[0-9a-f]{40}$ ]]; then
                    printf 'fixed artifact commit_sha must be 40 hex chars (got: %s)\n' "$artifact_commit" >&2
                    return 1
                fi
                # ZGPT_FAKE_SKIP_COMMIT_VERIFY skips only git commit/upstream lookup, not schema
                if [[ -z "${ZGPT_FAKE_SKIP_COMMIT_VERIFY:-}" ]]; then
                    resolved_commit="$(git -C "$worktree" rev-parse "${artifact_commit}^{commit}" 2>/dev/null)" || { printf 'commit_sha %s not found in worktree\n' "$artifact_commit" >&2; return 1; }
                    head_commit="$(git -C "$worktree" rev-parse 'HEAD^{commit}' 2>/dev/null)" || return 1
                    upstream_commit="$(git -C "$worktree" rev-parse '@{upstream}^{commit}' 2>/dev/null)" || return 1
                    [[ "$resolved_commit" == "$head_commit" && "$resolved_commit" == "$upstream_commit" ]] || { printf 'commit_sha %s does not match both HEAD and upstream\n' "$artifact_commit" >&2; return 1; }
                fi
                cat "$artifact"
                ((rc == 0)) || printf 'runner exited %d after writing a verified fixed artifact\n' "$rc" >&2
                return 0
                ;;
            *)
                return 1
                ;;
        esac
    fi
    printf 'runner_output=%s\n' "$output" >&2
    return 1
}

process_item() {
    local mr_url="$1" identity="$2" note_id="$3" body="$4" path="$5" line="$6" cwd="$7" worktree="$8" worker_cmd="$9" name="${10}" mr_json="${11}"
    local seen attempts next output rc=0 status commit=''
    seen="$(last_seen "$mr_url" "$identity" "$cwd")"
    [[ "$seen" != "$note_id" ]] || return 0
    attempts="$(attempt_count "$mr_url" "$identity" "$cwd")"
    if ((attempts >= MAX_ATTEMPTS)); then
        mark_seen "$mr_url" "$identity" "$cwd" "$note_id"
        post_note "$mr_url" "$MARKER **Manual review required** — item \`$identity\` has reached its $MAX_ATTEMPTS-fix limit."
        return 0
    fi
    # Allow-push gate: when false (default), do not launch editing worker;
    # post manager authorization required and mark seen without consuming attempt.
    if [[ "$ALLOW_PUSH" != true && "$ALLOW_PUSH" != 1 ]]; then
        mark_seen "$mr_url" "$identity" "$cwd" "$note_id"
        post_note "$mr_url" "$MARKER **Push authorization required** — item \`$identity\`: a manager must authorize push for this MR (set ZGPT_REVIEW_LOOP_ALLOW_PUSH=true) before fixes can be submitted. Marked as seen without consuming a fix attempt."
        return 0
    fi
    validate_fix_target "$mr_json" "$worktree" "$mr_url" || return 1
    next=$((attempts + 1))
    output="$(run_fix_worker "$mr_url" "$identity" "$body" "$path" "$line" "$next" "$cwd" "$worktree" "$worker_cmd" "$name")" || rc=$?
    status="$(sed -n 's/^status=//p' <<< "$output" | tail -1)"
    if [[ "$status" == not_actionable ]]; then
        mark_seen "$mr_url" "$identity" "$cwd" "$note_id"
        return 0
    fi
    attempts="$(increment_attempt "$mr_url" "$identity" "$cwd")"
    mark_seen "$mr_url" "$identity" "$cwd" "$note_id"
    commit="$(sed -n 's/^commit_sha=//p' <<< "$output" | tail -1)"
    if ((rc == 0)) && [[ "$status" == fixed ]]; then
        post_note "$mr_url" "$MARKER **Fix submitted** — item \`$identity\`, attempt $attempts/$MAX_ATTEMPTS; verification passed${commit:+; commit \`$commit\`}."
    else
        post_note "$mr_url" "$MARKER **Fix attempt failed** — item \`$identity\`, attempt $attempts/$MAX_ATTEMPTS; verification or worker execution failed."
    fi
}

cleanup_owned_worktree() {
    local mr_url="$1" cwd="$2" record path branch root common_dir
    record="$(owned_worktree_file "$mr_url" "$cwd")"
    [[ -f "$record" ]] || return 0
    IFS=$'\t' read -r path branch < "$record"
    [[ -n "$path" && -n "$branch" && -d "$path" ]] || return 0
    common_dir="$(git -C "$path" rev-parse --path-format=absolute --git-common-dir)" || return 1
    root="$(dirname "$common_dir")"
    case "$path" in "$root"/.worktrees/*|/tmp/zflow/*/worktrees/*) ;; *) log "refusing unowned cleanup path: $path"; return 1;; esac
    git -C "$root" worktree remove "$path"
    git -C "$root" branch -D "$branch"
    rm -f "$record"
}

supervisor_loop() {
    local mr_url="$1" cwd="$2" worker_cmd="$3" worktree="$4" name="$5"
    # The supervise subcommand receives these values explicitly, then assigns
    # them to the globals used by the loop. This preserves caller env overrides
    # through the visible-pane launcher instead of depending on ambient state.
    local started polls=0 now elapsed mr_json state notes discussions discussion_note_ids standalone_notes approvals approved line identity note_id body path file_line had_item
    if ! resolve_self_username; then
        finish_with_note "$mr_url" "$cwd" blocked_api Blocked "failed to identify the authenticated GitLab user" || true
        return 1
    fi
    started="$(current_secs)"
    printf 'active\n' > "$(status_file "$mr_url" "$cwd")"
    while true; do
        polls=$((polls + 1)); now="$(current_secs)"; elapsed=$((now - started))
        if ((elapsed >= MAX_RUNTIME)); then
            if finish_with_note "$mr_url" "$cwd" timeout Timeout "the ${MAX_RUNTIME}-second observation window ended"; then return 0; else return 1; fi
        fi
        if ((MAX_POLLS > 0 && polls > MAX_POLLS)); then
            if finish_with_note "$mr_url" "$cwd" poll_limit Done "the configured polling window ended"; then return 0; else return 1; fi
        fi
        if ! mr_json="$(fetch_mr "$mr_url")"; then
            finish_with_note "$mr_url" "$cwd" blocked_api Blocked "failed to read MR state" || true
            return 1
        fi
        state="$(jq -r '.state // empty' <<< "$mr_json")"
        if [[ "$state" == merged ]]; then
            finish_with_note "$mr_url" "$cwd" merged Done "the MR is merged" cleanup_owned_worktree || return 1
            return 0
        elif [[ "$state" == closed ]]; then
            if finish_with_note "$mr_url" "$cwd" closed Done "the MR is closed"; then return 0; else return 1; fi
        fi
        if ! notes="$(fetch_notes "$mr_url")" || ! discussions="$(fetch_discussions "$mr_url")" || ! approvals="$(fetch_approvals "$mr_url")"; then
            finish_with_note "$mr_url" "$cwd" blocked_api Blocked "a GitLab review API request failed" || true
            return 1
        fi
        approved="$(jq -r '.approved // false' <<< "$approvals")"
        if [[ "$approved" == true ]] || has_positive_signal "$notes" "$discussions"; then
            if finish_with_note "$mr_url" "$cwd" approved Done "LGTM or approval was received"; then return 0; else return 1; fi
        fi
        discussion_note_ids="$(jq '[.[] | .notes[]? | .id]' <<< "$discussions")"
        standalone_notes="$(jq --argjson ids "$discussion_note_ids" '[.[] | select(.id as $id | ($ids | index($id)) == null)]' <<< "$notes")"
        had_item=false
        while IFS= read -r line; do
            [[ -n "$line" ]] || continue
            identity="$(jq -r '.identity' <<< "$line")"
            note_id="$(jq -r '.note_id' <<< "$line")"
            body="$(jq -r '.body' <<< "$line")"
            path="$(jq -r '.path' <<< "$line")"
            file_line="$(jq -r '.line' <<< "$line")"
            [[ -n "$identity" && "$identity" != null ]] || continue
            had_item=true
            process_item "$mr_url" "$identity" "$note_id" "$body" "$path" "$file_line" "$cwd" "$worktree" "$worker_cmd" "$name" "$mr_json" || {
                finish_with_note "$mr_url" "$cwd" blocked_fix Blocked "item $identity could not be processed or reported" || true
                return 1
            }
        done < <(eligible_note_lines "$discussions" discussions; eligible_note_lines "$standalone_notes" standalone)
        [[ "$had_item" == true ]] || log "no new actionable review items"
        maybe_sleep "$POLL_INTERVAL"
    done
}

record_final_status() {
    local mr_url="$1" cwd="$2" rc="$3" current
    current="$(cat "$(status_file "$mr_url" "$cwd")" 2>/dev/null || true)"
    if [[ -z "$current" || "$current" == active ]]; then
        if ((rc == 0)); then
            printf 'done\n' > "$(status_file "$mr_url" "$cwd")"
        else
            printf 'failed\n' > "$(status_file "$mr_url" "$cwd")"
        fi
    fi
}

close_own_pane() {
    local mr_url="$1" cwd="$2" pane
    pane="$(cat "$(pane_file "$mr_url" "$cwd")" 2>/dev/null || true)"
    [[ -n "$pane" ]] || return 0
    command -v herdr >/dev/null 2>&1 || return 0
    { herdr pane close "$pane" >/dev/null 2>&1 || true; } &
}

cmd_supervise() {
    local mr_url='' cwd='' name='' worker_cmd='' worktree='' poll_interval='' max_runtime='' max_attempts='' max_polls='' glab_cmd='' self_username='' trusted_reviewers='' allow_push='' trust_bot_self_review='' bot_review_author='' pane_id=''
    while (($#)); do
        case "$1" in
            --cwd) cwd="${2:?}"; shift 2;;
            --name) name="${2:?}"; shift 2;;
            --command) worker_cmd="${2:?}"; shift 2;;
            --worktree) worktree="${2:?}"; shift 2;;
            --poll-interval) poll_interval="${2:?}"; shift 2;;
            --max-runtime) max_runtime="${2:?}"; shift 2;;
            --max-attempts) max_attempts="${2:?}"; shift 2;;
            --max-polls) max_polls="${2:?}"; shift 2;;
            --glab-cmd) glab_cmd="${2:?}"; shift 2;;
            --self-username) self_username="${2:?}"; shift 2;;
            --trusted-reviewers) trusted_reviewers="${2:?}"; shift 2;;
            --allow-push) allow_push="${2:?}"; shift 2;;
            --trust-bot-self-review) trust_bot_self_review="${2:?}"; shift 2;;
            --bot-review-author) bot_review_author="${2:?}"; shift 2;;
            --pane-id) pane_id="${2:?}"; shift 2;;
            -h|--help) usage; return;;
            *) [[ -z "$mr_url" ]] || die "unknown argument: $1"; mr_url="$1"; shift;;
        esac
    done
    [[ "$mr_url" =~ ^https?://[^[:space:]]+$ ]] || die "valid MR URL required"
    [[ -n "$cwd" && -n "$worktree" && -n "$name" ]] || die "supervise requires --cwd, --worktree, and --name"
    [[ -n "$poll_interval" && -n "$max_runtime" && -n "$max_attempts" && -n "$max_polls" && -n "$glab_cmd" ]] || die "supervise requires explicit loop config and glab command"
    POLL_INTERVAL="$poll_interval"
    MAX_RUNTIME="$max_runtime"
    MAX_ATTEMPTS="$max_attempts"
    MAX_POLLS="$max_polls"
    GLAB_CMD="$glab_cmd"
    SELF_USERNAME="$self_username"
    TRUSTED_REVIEWERS="$trusted_reviewers"
    ALLOW_PUSH="${allow_push:-$ALLOW_PUSH}"
    [[ -n "$trust_bot_self_review" ]] && TRUST_BOT_SELF_REVIEW="$trust_bot_self_review"
    [[ -n "$bot_review_author" ]] && BOT_REVIEW_AUTHOR="$bot_review_author"
    # Author-bind the bot-self-review marker. Resolve via the GitLab API when
    # not provided; if it cannot be resolved, fail closed (disable the feature).
    if [[ "$TRUST_BOT_SELF_REVIEW" == "true" && -z "$BOT_REVIEW_AUTHOR" ]]; then
        BOT_REVIEW_AUTHOR="$("$GLAB_CMD" api user 2>/dev/null | jq -r '.username // empty' 2>/dev/null)"
        [[ -n "$BOT_REVIEW_AUTHOR" ]] || log "trust-bot-self-review enabled but cannot resolve bot GitLab author; failing closed"
    fi
    [[ "$TRUST_BOT_SELF_REVIEW" == "true" && -z "$BOT_REVIEW_AUTHOR" ]] && TRUST_BOT_SELF_REVIEW="false"
    [[ -n "$pane_id" ]] || pane_id="${ZGPT_MANAGER_PANE_ID:-${ZJ_PANE_ID:-}}"
    init_state "$mr_url" "$cwd"
    printf '%s\n' "$$" > "$(pid_file "$mr_url" "$cwd")"
    [[ -n "$pane_id" ]] && printf '%s\n' "$pane_id" > "$(pane_file "$mr_url" "$cwd")"
    local rc=0
    trap 'printf "cancelled\n" > "$(status_file "$mr_url" "$cwd")"; release_lock "$mr_url" "$cwd"; close_own_pane "$mr_url" "$cwd"; exit 143' TERM INT
    supervisor_loop "$mr_url" "$cwd" "$worker_cmd" "$worktree" "$name" || rc=$?
    record_final_status "$mr_url" "$cwd" "$rc"
    release_lock "$mr_url" "$cwd"
    close_own_pane "$mr_url" "$cwd"
    return "$rc"
}

start_background_supervisor() {
    local mr_url="$1" cwd="$2" worker_cmd="$3" worktree="$4" name="$5" logfile="$6" pid
    (
        trap '' HUP
        trap 'release_lock "$mr_url" "$cwd"' EXIT
        trap 'printf "cancelled\n" > "$(status_file "$mr_url" "$cwd")"; exit 143' TERM INT
        supervisor_loop "$mr_url" "$cwd" "$worker_cmd" "$worktree" "$name"
    ) >> "$logfile" 2>&1 < /dev/null &
    pid=$!
    printf '%s\n' "$pid" > "$(pid_file "$mr_url" "$cwd")"
    printf 'supervisor_pid=%s\n' "$pid"
}

start_pane_supervisor() {
    local mr_url="$1" cwd="$2" worker_cmd="$3" worktree="$4" name="$5" logfile="$6" output pane_id supervise_cmd
    supervise_cmd="$script_dir/zgpt-review-loop.sh"
    local args=(
        --name "$name" --cwd "$cwd" --mode print --log "$logfile"
        --command "$supervise_cmd"
        --command-arg supervise
        --command-arg "$mr_url"
        --command-arg --cwd --command-arg "$cwd"
        --command-arg --name --command-arg "$name"
        --command-arg --worktree --command-arg "$worktree"
        --command-arg --poll-interval --command-arg "$POLL_INTERVAL"
        --command-arg --max-runtime --command-arg "$MAX_RUNTIME"
        --command-arg --max-attempts --command-arg "$MAX_ATTEMPTS"
        --command-arg --max-polls --command-arg "$MAX_POLLS"
        --command-arg --glab-cmd --command-arg "$GLAB_CMD"
        --close-on-exit
    )
    [[ -n "$SELF_USERNAME" ]] && args+=(--command-arg --self-username --command-arg "$SELF_USERNAME")
    [[ -n "$worker_cmd" ]] && args+=(--command-arg --command --command-arg "$worker_cmd")
    args+=(--command-arg --allow-push --command-arg "$ALLOW_PUSH")
    [[ -n "$TRUSTED_REVIEWERS" ]] && args+=(--command-arg --trusted-reviewers --command-arg "$TRUSTED_REVIEWERS")
    args+=(--command-arg --trust-bot-self-review --command-arg "$TRUST_BOT_SELF_REVIEW")
    [[ -n "$BOT_REVIEW_AUTHOR" ]] && args+=(--command-arg --bot-review-author --command-arg "$BOT_REVIEW_AUTHOR")
    output="$("$pane_helper" "${args[@]}" 2>&1)" || {
        printf '%s\n' "$output" >> "$logfile"
        return 1
    }
    printf '%s\n' "$output" >> "$logfile"
    pane_id="$(sed -n 's/^pane_id=//p' <<< "$output" | tail -1)"
    [[ -n "$pane_id" ]] || die "pane helper did not report pane_id"
    printf '%s\n' "$pane_id" > "$(pane_file "$mr_url" "$cwd")"
    # The helper's generated runner exports its own pane as ZGPT_MANAGER_PANE_ID;
    # cmd_supervise records that same pane, while start records it immediately so
    # status/stop/dedupe work even before the runner begins.
    printf 'supervisor_pane=%s\n' "$pane_id"
}

cmd_start() {
    local mr_url='' cwd="$PWD" name='' worker_cmd='' worktree='' owned='' trusted_reviewers='' allow_push='' trust_bot_self_review='' bot_review_author=''
    while (($#)); do
        case "$1" in
            --cwd) cwd="${2:?}"; shift 2;;
            --name) name="${2:?}"; shift 2;;
            --command) worker_cmd="${2:?}"; shift 2;;
            --worktree) worktree="${2:?}"; shift 2;;
            --owned-worktree) owned="${2:?}"; worktree="$owned"; shift 2;;
            --trusted-reviewers) trusted_reviewers="${2:?}"; shift 2;;
            --allow-push) allow_push="${2:?}"; shift 2;;
            --trust-bot-self-review) trust_bot_self_review="${2:?}"; shift 2;;
            --bot-review-author) bot_review_author="${2:?}"; shift 2;;
            -h|--help) usage; return;;
            *) [[ -z "$mr_url" ]] || die "unknown argument: $1"; mr_url="$1"; shift;;
        esac
    done
    # Apply override values when passed as CLI args (env defaults still apply otherwise)
    [[ -n "$trusted_reviewers" ]] && TRUSTED_REVIEWERS="$trusted_reviewers"
    [[ -n "$allow_push" ]] && ALLOW_PUSH="$allow_push"
    [[ -n "$trust_bot_self_review" ]] && TRUST_BOT_SELF_REVIEW="$trust_bot_self_review"
    [[ -n "$bot_review_author" ]] && BOT_REVIEW_AUTHOR="$bot_review_author"
    [[ "$mr_url" =~ ^https?://[^[:space:]]+$ ]] || die "valid MR URL required"
    require_jq
    if ! acquire_lock "$mr_url" "$cwd"; then
        printf 'status=already_active\nidentity=%s\nmr_url=%s\n' "$(mr_identity "$mr_url")" "$mr_url"
        return 0
    fi
    init_state "$mr_url" "$cwd"
    [[ -n "$worktree" ]] || worktree="$(git -C "$cwd" rev-parse --show-toplevel 2>/dev/null || printf '%s' "$cwd")"
    [[ -n "$name" ]] || name="review-loop-$(mr_identity "$mr_url")"
    if [[ -z "$owned" && "$worktree" == /tmp/zflow/*/worktrees/* ]]; then
        local detected_branch
        detected_branch="$(git -C "$worktree" branch --show-current 2>/dev/null || true)"
        [[ "$detected_branch" == zgpt/* ]] && owned="$worktree"
    fi
    if [[ -n "$owned" ]]; then
        printf '%s\t%s\n' "$owned" "$(git -C "$owned" branch --show-current)" > "$(owned_worktree_file "$mr_url" "$cwd")"
    fi
    local logfile launch_meta rc=0 backend
    logfile="$(log_file "$mr_url" "$cwd")"
    backend="${ZGPT_REVIEW_LOOP_LAUNCH_BACKEND:-herdr}"
    case "$backend" in
        background) launch_meta="$(start_background_supervisor "$mr_url" "$cwd" "$worker_cmd" "$worktree" "$name" "$logfile")" || rc=$?;;
        herdr) launch_meta="$(start_pane_supervisor "$mr_url" "$cwd" "$worker_cmd" "$worktree" "$name" "$logfile")" || rc=$?;;
        *) release_lock "$mr_url" "$cwd"; die "unknown ZGPT_REVIEW_LOOP_LAUNCH_BACKEND: $backend";;
    esac
    if ((rc != 0)); then
        release_lock "$mr_url" "$cwd"
        return "$rc"
    fi
    printf 'status=started\nidentity=%s\nmr_url=%s\nstate_dir=%s\nlog=%s\n%s\n' \
        "$(mr_identity "$mr_url")" "$mr_url" "$(review_loop_state_dir "$mr_url" "$cwd")" "$logfile" "$launch_meta"
}

cmd_status() {
    local mr_url="${1:-}" dir pid pane status='unknown'
    [[ -n "$mr_url" ]] || die "MR URL required"
    dir="$(review_loop_state_dir "$mr_url")"
    pid="$(cat "$dir/supervisor.pid" 2>/dev/null || true)"
    pane="$(cat "$dir/supervisor.pane" 2>/dev/null || true)"
    if [[ -d "$dir/lock" ]] && is_live_pane "$pane"; then status=active
    elif [[ -d "$dir/lock" && "$pid" =~ ^[0-9]+$ ]] && kill -0 "$pid" 2>/dev/null; then status=active
    elif [[ -f "$dir/status" ]]; then status="$(cat "$dir/status")"
    elif [[ -d "$dir/lock" ]]; then status=stale_lock
    elif [[ -d "$dir" ]]; then status=stopped; fi
    printf 'identity=%s\nmr_url=%s\nstate_dir=%s\nstatus=%s\n' "$(mr_identity "$mr_url")" "$mr_url" "$dir" "$status"
    [[ -n "$pid" ]] && printf 'supervisor_pid=%s\n' "$pid"
    [[ -n "$pane" ]] && printf 'supervisor_pane=%s\n' "$pane"
    return 0
}

cmd_stop() {
    local mr_url="${1:-}" pid pane post_rc=0 stopped=false
    [[ -n "$mr_url" ]] || die "MR URL required"
    pid="$(cat "$(pid_file "$mr_url")" 2>/dev/null || true)"
    pane="$(cat "$(pane_file "$mr_url")" 2>/dev/null || true)"
    if [[ "$pid" =~ ^[0-9]+$ ]] && kill -0 "$pid" 2>/dev/null; then
        post_final "$mr_url" Done "the review loop was cancelled" || post_rc=$?
        kill_tree "$pid"
        stopped=true
    elif is_live_pane "$pane"; then
        post_final "$mr_url" Done "the review loop was cancelled" || post_rc=$?
        herdr pane close "$pane" >/dev/null 2>&1 || true
        stopped=true
    fi
    maybe_sleep 1
    release_lock "$mr_url"
    if [[ "$stopped" == true ]]; then
        printf 'stopped\n' > "$(status_file "$mr_url")"
        printf 'status=stopped\nidentity=%s\n' "$(mr_identity "$mr_url")"
        return "$post_rc"
    fi
    printf 'status=not_running\nidentity=%s\n' "$(mr_identity "$mr_url")"
}
cmd_list() {
    local base loops d pid pane status
    base="${ZGPT_STATE_DIR_OVERRIDE:-$(zgpt_state_root)}"; loops="$base/review-loops"
    [[ -d "$loops" ]] || { printf '(no review loops registered)\n'; return; }
    for d in "$loops"/*; do
        [[ -d "$d" ]] || continue
        pid="$(cat "$d/supervisor.pid" 2>/dev/null || true)"
        pane="$(cat "$d/supervisor.pane" 2>/dev/null || true)"
        status=stopped
        if is_live_pane "$pane"; then
            status="active (pane=$pane)"
        elif [[ "$pid" =~ ^[0-9]+$ ]] && kill -0 "$pid" 2>/dev/null; then
            status="active (pid=$pid)"
        fi
        printf '%-55s %s\n' "$(basename "$d")" "$status"
    done
}

case "${1:-}" in
    start) shift; cmd_start "$@";;
    status) shift; cmd_status "$@";;
    stop) shift; cmd_stop "$@";;
    supervise) shift; cmd_supervise "$@";;
    list) shift; cmd_list "$@";;
    config) printf 'poll_interval=%s\nmax_runtime=%s\nmax_attempts=%s\ntrusted_reviewers=%s\nallow_push=%s\n' "$POLL_INTERVAL" "$MAX_RUNTIME" "$MAX_ATTEMPTS" "$TRUSTED_REVIEWERS" "$ALLOW_PUSH";;
    -h|--help) usage;;
    *) die "use start, status, stop, list, supervise, or config";;
esac
