#!/usr/bin/env bash
set -euo pipefail

usage() {
    cat <<'USAGE'
Usage: zgpt-review-prompt.sh --artifact <path> [options]

Emit a bounded correctness-review worker prompt with explicit stop conditions.

Options:
  --artifact <path>         Required review report path the worker must write.
  --subject <text>          Short review subject/title. Default: Review assigned change.
  --target <text>           Files, branch, diff, PR, or artifact to review. Default: the assigned change.
  --max-commands <n>        Shell command ceiling. Default: 8.
  --minutes <n>             Wall-clock time ceiling. Default: 15.
  --worker <name>           Worker role name. Default: worker-review.
  -h, --help                Show this help.
USAGE
}

die() { printf 'error: %s\n' "$*" >&2; exit 2; }

artifact=""
subject="Review assigned change"
target="the assigned change"
max_commands=8
minutes=15
worker="worker-review"

while [[ $# -gt 0 ]]; do
    case "$1" in
        --artifact) artifact="${2:?}"; shift 2;;
        --subject) subject="${2:?}"; shift 2;;
        --target) target="${2:?}"; shift 2;;
        --max-commands) max_commands="${2:?}"; shift 2;;
        --minutes) minutes="${2:?}"; shift 2;;
        --worker) worker="${2:?}"; shift 2;;
        -h|--help) usage; exit 0;;
        *) die "unknown argument: $1";;
    esac
done

[[ -n "$artifact" ]] || die "--artifact is required"
[[ "$max_commands" =~ ^[0-9]+$ ]] || die "--max-commands must be an integer"
[[ "$minutes" =~ ^[0-9]+$ ]] || die "--minutes must be an integer"

cat <<PROMPT
Role:
You are $worker.

Goal:
$subject

Target:
$target

Review scope:
- Correctness only: find defects that would break behavior, tests, data safety, or the requested acceptance criteria.
- Do not comment on style, naming, formatting, or speculative improvements unless they cause a correctness bug.
- Do not edit files, commit, push, or redesign the implementation.

Bounds:
- Run at most $max_commands shell commands total.
- Spend at most $minutes minutes wall-clock.
- Start with an initial sweep of the diff/relevant files and any named artifact.
- If the initial sweep reveals no high-confidence correctness issue, approve and stop. Do not reconstruct history or keep diffing for extra assurance.
- If evidence is insufficient for a high-confidence finding within the bounds, say so, approve, and stop.

Report:
Write $artifact with exactly:
1. Verdict: APPROVE or REQUEST_CHANGES
2. High-confidence correctness findings only, each with file/line/evidence; or "None"
3. Commands run
4. Notes on any skipped investigation due to the bounds

Completion:
After writing $artifact, stop. If used with zgpt-run-worker.sh, it will append the artifact path and split completion marker.
PROMPT
