#!/usr/bin/env bash
set -euo pipefail

# zgpt-watch-managers.sh — quiet, low-rate, delta-only safety net over REGISTERED
# keep-alive manager panes.
#
# L1 of the manager→super channel is the manager's own artifact + greppable
# `MANAGER_STATUS:` line and the super's zgpt-wait-manager.sh (report-agent is
# broken on herdr 0.8.0, so the artifact/line are the primary signal). This
# script is the L2 safety net: when a manager misses its status line, the super
# keeps a small registry of the panes it cares about and polls just those (never
# the whole fleet), printing ONLY state transitions (deltas). No news → no
# output. The super decides whether to surface an event to the human.
#
# Registry: one line per pane, TAB-separated:
#   pane_id \t workstream \t expect_artifact \t last_status \t last_artifact_mtime
# Default path: <zgpt state dir>/manager-registry.tsv (override with
# ZGPT_MANAGER_REGISTRY or --registry). last_status is one of
# - | working | idle | done | blocked ; last_artifact_mtime is epoch or -.

usage() {
    cat <<'EOF'
Usage: zgpt-watch-managers.sh <command> [args]

Quiet delta-only poll over REGISTERED keep-alive manager panes (L2 safety net).
Prints nothing when nothing changed; prints one `event=` line per delta.

Commands:
  register <pane-id> [--workstream <name>] [--artifact <path>]
                              Add a manager pane to the watch registry. The next
                              `once` reports its current state (first delta).
                              Accepts --registry before or after the command.
  unregister <pane-id>        Remove a manager pane from the registry.
                              Accepts --registry before or after the command.
  list                        Print the registry (pane, workstream, artifact, last state).
  once [--deliver-to-pane <id>] [--deliver-events <csv>]
                              Poll each registered pane once; print ONLY deltas:
                                event=idle_for_steer|blocked|working|gone pane=... [artifact=...]
                              A registered pane that no longer exists is dropped
                              automatically and reported as event=gone.
                              exit 0 even when news is printed (no news => no output).
                              With --deliver-to-pane, also inject matching deltas into
                              the super pane as a new user turn (see Deliver below).
  watch [--interval <secs>] [--max-runtime <secs>] [--registry <path>]
        [--exit-on-delta] [--deliver-to-pane <id>] [--deliver-events <csv>]
                              Loop `once` every --interval seconds (default 240;
                              180-300 recommended: 3-5m active wait, 10-15m for
                              idle keep-alives). Stops after --max-runtime secs
                              (default: forever). Silent while there is no delta.
                              With --exit-on-delta, print the first delta and exit
                              0 immediately: the loop becomes a one-shot wake-up
                              job whose exit IS the state-change signal.
                              With --deliver-to-pane, push matching deltas into the
                              super chat so ring-0 auto-receives without manual poll.
  ensure-watch [--registry <path>] [--deliver-to-pane <id>] [--interval <secs>]
                              Ensure a durable watch is running for this registry,
                              delivering matching deltas to the super pane. Prints
                              watch=started|running|none deliver_to=<id>. The watcher
                              is detached from the launching shell (nohup + disown)
                              and tracked by a pidfile next to the registry
                              (<registry dir>/manager-watch.pid), so it survives the
                              ephemeral launcher. Reuses a live watcher when one is
                              already running. Deliver target resolution:
                              --deliver-to-pane > $ZGPT_SUPER_PANE_ID/
                              $ZFLOW_SUPER_PANE_ID > unique supermanager: pane.

Options:
  --registry <path>           Registry file (default: <zgpt state dir>/manager-registry.tsv,
                              or $ZGPT_MANAGER_REGISTRY). Accepted both before the
                              command and inline after `watch` / `once` / `register` /
                              `ensure-watch`.
  --exit-on-delta             Watch once, and on the first delta print it and exit 0
                              (default: keep polling). Pairs with --interval /
                              --max-runtime / --registry.
  --deliver-to-pane <id>      Deliver matching deltas into this herdr pane (the
                              supermanager chat). Matching deltas are queued to
                              <registry dir>/manager-deliver-pending.log and
                              flushed once per poll round through a gate: nothing
                              is injected while the target pane is `working`.
                              Default target when omitted:
                              $ZGPT_SUPER_PANE_ID or $ZFLOW_SUPER_PANE_ID if set;
                              otherwise the unique pane whose label starts with
                              "supermanager:". If several match, delivery is skipped
                              and a warn: line explains on stderr.
  --deliver-events <csv>      Which event names to queue for delivery (default:
                              idle_for_steer,blocked). `working` and `gone` are
                              excluded by default to avoid noise.
  --deliver-settle <secs>     Pause before the inject's (second) Enter (default: 1).
  --session <name>            herdr session name (or export ZGPT_HERDR_SESSION).
  -h, --help                  Show this help.

Deliver (super inbox):
  herdr has no native "manager DONE → super chat" subscription. --deliver-to-pane
  closes that gap: matching deltas are appended to a pending file
  (<registry dir>/manager-deliver-pending.log), then once per poll round the whole
  queue is injected into the super pane as one `[zflow-manager] ...` turn. The gate
  never interrupts a working super: the queue waits, reported as deferred_to=, and
  is delivered whole when the super is idle. Per-event delivered_to= lines on stdout
  remain the durable log signal.

Notes:
  - idle alone is not completion: with an --artifact expectation, idle_for_steer
    reports artifact_state=present|missing, so a manager idling before its artifact
    is written is still surfaced.
  - Only registered panes are polled — never the whole fleet.
  - Without --deliver-to-pane, this is still not a chat bus: it only prints
    machine-readable event lines for the process that launched the watcher.
EOF
}

die() { printf 'error: %s\n' "$*" >&2; exit 2; }
positive_integer() { [[ "${1:-}" =~ ^[1-9][0-9]*$ ]]; }

script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$script_dir/zgpt-common.sh"

state_dir="$(zgpt_state_dir "$PWD")"
registry="${ZGPT_MANAGER_REGISTRY:-$state_dir/manager-registry.tsv}"
interval=240
max_runtime=""
exit_on_delta=0
once_events=0
# Super-inbox deliver: optional push of matching deltas into the ring-0 pane.
# Env defaults let a long-lived super session set ZGPT_SUPER_PANE_ID once.
deliver_to_pane="${ZGPT_SUPER_PANE_ID:-${ZFLOW_SUPER_PANE_ID:-}}"
deliver_events="idle_for_steer,blocked"
deliver_settle=1

file_mtime() {
    local f="$1"
    stat -c %Y "$f" 2>/dev/null || stat -f %m "$f" 2>/dev/null || printf '0'
}

# True when $1 is one of the comma-separated event names in deliver_events.
event_should_deliver() {
    local event="$1" item
    local IFS=','
    for item in $deliver_events; do
        [[ "$item" == "$event" ]] && return 0
    done
    return 1
}

# Pending-delivery queue path: <registry dir>/manager-deliver-pending.log. A file,
# so a watcher restart never loses undelivered events.
deliver_pending_file() {
    printf '%s/manager-deliver-pending.log\n' "$(dirname "$registry")"
}

# Queue one greppable event line for delivery to the super pane. The actual
# injection is a single flush at the end of `once` (flush_pending_deliveries), so
# the super is never interrupted mid-turn. Matching is unchanged from the old
# direct-inject path; enqueue itself prints nothing.
deliver_event_to_super() {
    local event_line="$1"
    local event
    [[ -n "$deliver_to_pane" ]] || return 0
    event="${event_line#event=}"
    event="${event%% *}"
    event_should_deliver "$event" || return 0
    local pending
    pending="$(deliver_pending_file)"
    mkdir -p "$(dirname "$pending")"
    printf '%s\n' "$event_line" >>"$pending"
}

# Flush the pending deliver queue into the super pane once per `once` round.
# Gate: while the target pane is `working`, nothing is injected — the queue is
# left intact and each queued event is reported as deferred_to= on stdout. On any
# other target state (idle/done/blocked/empty/unknown) the whole queue is injected
# as one `[zflow-manager] ...` turn and cleared; each event then prints
# delivered_to=. A failed inject keeps the queue for the next round.
flush_pending_deliveries() {
    [[ -n "$deliver_to_pane" ]] || return 0
    local pending
    pending="$(deliver_pending_file)"
    [[ -s "$pending" ]] || return 0
    local status line event msg="" first=1
    status="$(zgpt_herdr_agent_status "$deliver_to_pane" 2>/dev/null || true)"
    if [[ "$status" == "working" ]]; then
        while IFS= read -r line; do
            [[ -z "$line" ]] && continue
            event="${line#event=}"
            event="${event%% *}"
            printf 'deferred_to=%s event=%s\n' "$deliver_to_pane" "$event"
        done <"$pending"
        return 0
    fi
    while IFS= read -r line; do
        [[ -z "$line" ]] && continue
        if [[ "$first" == "1" ]]; then
            msg="[zflow-manager] $line"
            first=0
        else
            msg+=$'\n'"$line"
        fi
    done <"$pending"
    [[ -n "$msg" ]] || return 0
    if ! zgpt_herdr_prompt_inject "$deliver_to_pane" "$msg" --settle "$deliver_settle" --double-enter large; then
        printf 'warn: deliver to %s failed\n' "$deliver_to_pane" >&2
        return 0   # keep the queue; retried next round
    fi
    while IFS= read -r line; do
        [[ -z "$line" ]] && continue
        event="${line#event=}"
        event="${event%% *}"
        printf 'delivered_to=%s event=%s\n' "$deliver_to_pane" "$event"
    done <"$pending"
    : >"$pending"
}

write_registry() {
    # usage: write_registry <lines...> — atomic replace, preserves empty registry
    local -a lines=("$@")
    if [[ ${#lines[@]} -gt 0 ]]; then
        printf '%s\n' "${lines[@]}" >"$registry.new"
        mv -f "$registry.new" "$registry"
    else
        : >"$registry"
    fi
}

cmd_register() {
    local pane_id="${1:-}"
    [[ -n "$pane_id" ]] || die "register: missing <pane-id>"
    shift || true
    local workstream="" artifact=""
    while [[ $# -gt 0 ]]; do
        case "$1" in
            --workstream) workstream="${2:?--workstream needs a value}"; shift 2 ;;
            --artifact) artifact="${2:?--artifact needs a value}"; shift 2 ;;
            --registry) registry="${2:?--registry needs a value}"; shift 2 ;;
            *) die "register: unknown argument: $1" ;;
        esac
    done
    mkdir -p "$(dirname "$registry")"
    local -a kept=()
    if [[ -f "$registry" ]]; then
        while IFS=$'\t' read -r p ws a ls lm; do
            [[ "$p" == "$pane_id" ]] && continue
            kept+=("$p"$'\t'"$ws"$'\t'"$a"$'\t'"$ls"$'\t'"$lm")
        done <"$registry"
    fi
    # last_status='-' so the first `once` reports the manager's current state.
    kept+=("$pane_id"$'\t'"$workstream"$'\t'"$artifact"$'\t'"-"$'\t'"-")
    write_registry ${kept[@]+"${kept[@]}"}
    printf 'registered=%s workstream=%s artifact=%s\n' "$pane_id" "${workstream:-}" "${artifact:-}"
}

cmd_unregister() {
    local pane_id=""
    while [[ $# -gt 0 ]]; do
        case "$1" in
            --registry) registry="${2:?--registry needs a value}"; shift 2 ;;
            *)
                if [[ -z "$pane_id" ]]; then
                    pane_id="$1"; shift
                else
                    die "unregister: unknown argument: $1"
                fi
                ;;
        esac
    done
    [[ -n "$pane_id" ]] || die "unregister: missing <pane-id>"
    [[ -f "$registry" ]] || { printf 'not_registered=%s\n' "$pane_id"; exit 0; }
    local -a kept=()
    while IFS=$'\t' read -r p ws a ls lm; do
        [[ "$p" == "$pane_id" ]] && continue
        kept+=("$p"$'\t'"$ws"$'\t'"$a"$'\t'"$ls"$'\t'"$lm")
    done <"$registry"
    # ${arr[@]+...} guard: under set -u an empty array is "unbound"; on
    # unregister-last, kept is empty and write_registry must still empty the file.
    write_registry ${kept[@]+"${kept[@]}"}
    printf 'unregistered=%s\n' "$pane_id"
}

cmd_list() {
    printf 'pane_id\tworkstream\texpect_artifact\tlast_status\tlast_artifact_mtime\n'
    [[ -f "$registry" ]] && cat "$registry" || true
}

cmd_once() {
    zgpt_herdr_require
    zgpt_herdr_resolve_session
    once_events=0
    [[ -f "$registry" ]] || return 0
    local -a next=()
    while IFS=$'\t' read -r pane_id workstream expect_artifact last_status last_mtime; do
        [[ -z "$pane_id" || "$pane_id" == \#* ]] && continue
        local cur_status cur_mtime="-" event=""
        # Auto-cleanup: a registered pane that no longer exists is dropped from
        # the registry and reported as a `gone` delta, so the super learns a
        # manager pane died instead of polling a dead registration forever.
        if ! zgpt_herdr_pane_exists "$pane_id"; then
            printf 'event=gone pane=%s\n' "$pane_id"
            once_events=$(( once_events + 1 ))
            deliver_event_to_super "event=gone pane=$pane_id"
            continue
        fi
        cur_status="$(zgpt_herdr_agent_status "$pane_id")"
        if [[ -n "$expect_artifact" && -f "$expect_artifact" ]]; then
            cur_mtime="$(file_mtime "$expect_artifact")"
        fi
        case "$cur_status" in
            idle|done)
                # idle_for_steer on the transition into idle/done, and again
                # whenever a registered artifact appears or its mtime changes.
                # A steady idle (same state, same artifact) stays silent.
                if [[ "$last_status" != "idle" && "$last_status" != "done" ]]; then
                    event="idle_for_steer"
                elif [[ -n "$expect_artifact" && -f "$expect_artifact" && "$cur_mtime" != "$last_mtime" ]]; then
                    event="idle_for_steer"
                fi
                ;;
            blocked)
                [[ "$last_status" != "blocked" ]] && event="blocked"
                ;;
            working)
                [[ "$last_status" != "working" ]] && event="working"
                ;;
        esac
        if [[ -n "$event" ]]; then
            local event_line
            event_line="event=$event pane=$pane_id"
            [[ -n "$workstream" ]] && event_line+=" workstream=$workstream"
            if [[ -n "$expect_artifact" ]]; then
                if [[ -f "$expect_artifact" ]]; then
                    event_line+=" artifact=$expect_artifact artifact_state=present artifact_mtime=$cur_mtime"
                else
                    event_line+=" artifact=$expect_artifact artifact_state=missing"
                fi
            fi
            printf '%s\n' "$event_line"
            once_events=$(( once_events + 1 ))
            deliver_event_to_super "$event_line"
        fi
        # Preserve last status when the pane is unreachable (no event, no churn).
        if [[ -n "$cur_status" ]]; then
            next+=("$pane_id"$'\t'"$workstream"$'\t'"$expect_artifact"$'\t'"$cur_status"$'\t'"$cur_mtime")
        else
            next+=("$pane_id"$'\t'"$workstream"$'\t'"$expect_artifact"$'\t'"${last_status:--}"$'\t'"${last_mtime:--}")
        fi
    done <"$registry"
    # Guard against an empty registry (all panes auto-unregistered as gone).
    write_registry ${next[@]+"${next[@]}"}
    # One delivery flush per round: never interrupt a working super mid-turn.
    flush_pending_deliveries
    return 0
}

# Shared flag parser for once/watch (and leading global flags).
parse_watch_flags() {
    while [[ $# -gt 0 ]]; do
        case "$1" in
            --interval) interval="${2:?--interval needs a value}"; shift 2 ;;
            --max-runtime) max_runtime="${2:?--max-runtime needs a value}"; shift 2 ;;
            --registry) registry="${2:?--registry needs a value}"; shift 2 ;;
            --exit-on-delta) exit_on_delta=1; shift ;;
            --deliver-to-pane) deliver_to_pane="${2:?--deliver-to-pane needs a value}"; shift 2 ;;
            --deliver-events) deliver_events="${2:?--deliver-events needs a value}"; shift 2 ;;
            --deliver-settle) deliver_settle="${2:?--deliver-settle needs a value}"; shift 2 ;;
            *)
                # Leave remaining args for the caller via REPLY array pattern:
                # store unparsed tail and return.
                parse_watch_flags_rest=("$@")
                return 0
                ;;
        esac
    done
    parse_watch_flags_rest=()
}

cmd_once_with_flags() {
    parse_watch_flags_rest=()
    parse_watch_flags "$@"
    if [[ ${#parse_watch_flags_rest[@]} -gt 0 ]]; then
        die "once: unknown argument: ${parse_watch_flags_rest[0]}"
    fi
    if [[ -n "$deliver_settle" ]]; then
        # allow 0 for tests; otherwise positive integer
        [[ "$deliver_settle" =~ ^[0-9]+$ ]] || die "--deliver-settle must be a non-negative integer"
    fi
    resolve_deliver_pane
    cmd_once
}

cmd_watch() {
    local max_ms=""
    parse_watch_flags_rest=()
    parse_watch_flags "$@"
    if [[ ${#parse_watch_flags_rest[@]} -gt 0 ]]; then
        die "watch: unknown argument: ${parse_watch_flags_rest[0]}"
    fi
    positive_integer "$interval" || die "--interval must be a positive integer"
    [[ "$deliver_settle" =~ ^[0-9]+$ ]] || die "--deliver-settle must be a non-negative integer"
    if [[ -n "$max_runtime" ]]; then
        positive_integer "$max_runtime" || die "--max-runtime must be a positive integer"
        max_ms=$(( max_runtime * 1000 ))
    fi
    resolve_deliver_pane
    local start_ms now_ms
    start_ms=$(( $(date +%s) * 1000 ))
    while true; do
        cmd_once
        # --exit-on-delta: the first delta printed IS the result. Exiting lets a
        # background Bash task treat completion as the state-change wake-up signal.
        if [[ "$exit_on_delta" == "1" && "$once_events" -gt 0 ]]; then
            return 0
        fi
        if [[ -n "$max_ms" ]]; then
            now_ms=$(( $(date +%s) * 1000 ))
            (( now_ms - start_ms >= max_ms )) && break
        fi
        sleep "$interval"
    done
    return 0
}

# Super-inbox deliver target: explicit --deliver-to-pane or the env default are
# already in deliver_to_pane at parse time. When still empty, fall back to
# self-discovery of the unique supermanager: pane (see
# zgpt_herdr_discover_super_pane). Zero matches => no delivery; several matches
# => no delivery with a warn: on stderr. Called once per invocation so the
# discovery cost is not paid on every `once` poll inside a `watch` loop.
resolve_deliver_pane() {
    [[ -n "$deliver_to_pane" ]] && return 0
    local found
    found="$(zgpt_herdr_discover_super_pane)" || true
    [[ -n "$found" ]] && deliver_to_pane="$found"
    return 0
}

# Start a durable watcher detached from the ephemeral launcher shell:
#   - nohup: SIGHUP on the launching shell/pane exit is ignored
#   - disown: the job is removed from the shell's job table (no wait, no HUP)
#   - bash -c 'exec "$0" "$@"': the wrapper is replaced by the script, so $!
#     below is the watcher's own PID
# stdin from /dev/null and stdout/stderr to <log> keep it from holding the
# terminal. Writes <pidfile> so a later `ensure-watch` can detect and reuse it.
start_durable_watch() {
    local pidfile="$1" log="$2"
    nohup bash -c 'exec "$0" "$@"' "$script_dir/zgpt-watch-managers.sh" watch \
        --registry "$registry" --deliver-to-pane "$deliver_to_pane" --interval "$interval" \
        >>"$log" 2>&1 < /dev/null &
    disown 2>/dev/null || true
    printf '%s\n' "$!" >"$pidfile"
}

cmd_ensure_watch() {
    parse_watch_flags_rest=()
    parse_watch_flags "$@"
    if [[ ${#parse_watch_flags_rest[@]} -gt 0 ]]; then
        die "ensure-watch: unknown argument: ${parse_watch_flags_rest[0]}"
    fi
    positive_integer "$interval" || die "--interval must be a positive integer"
    [[ "$deliver_settle" =~ ^[0-9]+$ ]] || die "--deliver-settle must be a non-negative integer"
    resolve_deliver_pane
    if [[ -z "$deliver_to_pane" ]]; then
        # No deliver target (no env, no unique supermanager pane): a log-only
        # durable watch is not the contract here — nothing would be delivered.
        printf 'watch=none deliver_to=\n'
        return 0
    fi
    local logdir pidfile log old_pid
    logdir="$(dirname "$registry")"
    mkdir -p "$logdir"
    pidfile="$logdir/manager-watch.pid"
    log="$logdir/manager-watch.log"
    if [[ -f "$pidfile" ]]; then
        old_pid="$(head -n1 "$pidfile" 2>/dev/null | tr -d '[:space:]')"
        if [[ -n "$old_pid" ]] && kill -0 "$old_pid" 2>/dev/null; then
            printf 'watch=running deliver_to=%s\n' "$deliver_to_pane"
            return 0
        fi
        rm -f "$pidfile"
    fi
    start_durable_watch "$pidfile" "$log"
    printf 'watch=started deliver_to=%s\n' "$deliver_to_pane"
}

cmd="${1:-}"
# Leading global flags (before the subcommand).
while [[ "$cmd" == --* ]]; do
    case "$cmd" in
        --registry)
            registry="${2:?--registry needs a value}"
            shift 2
            ;;
        --deliver-to-pane)
            deliver_to_pane="${2:?--deliver-to-pane needs a value}"
            shift 2
            ;;
        --deliver-events)
            deliver_events="${2:?--deliver-events needs a value}"
            shift 2
            ;;
        --deliver-settle)
            deliver_settle="${2:?--deliver-settle needs a value}"
            shift 2
            ;;
        -h|--help)
            usage; exit 0
            ;;
        *)
            die "unknown flag before command: $cmd (see --help)"
            ;;
    esac
    cmd="${1:-}"
done
shift || true
case "$cmd" in
    register) cmd_register "$@" ;;
    unregister) cmd_unregister "$@" ;;
    list) cmd_list ;;
    once) cmd_once_with_flags "$@" ;;
    watch) cmd_watch "$@" ;;
    ensure-watch) cmd_ensure_watch "$@" ;;
    -h|--help|"") usage; [[ -n "$cmd" ]] && exit 0; die "missing command (see --help)" ;;
    *) die "unknown command: $cmd (see --help)" ;;
esac
