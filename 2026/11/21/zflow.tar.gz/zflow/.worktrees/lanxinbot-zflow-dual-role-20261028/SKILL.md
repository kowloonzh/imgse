---
name: zflow-workers
description: Dispatch execution work (writing code, writing tests, running cases, collecting evidence) to visible AI worker agents in herdr panes. Use ONLY when the user explicitly asks for zflow / workers to execute subtasks (e.g. "用 zflow", "派 worker", "$zflow-workers"); never self-invoke because a task looks large, long or parallelisable. Keep design, proposals, review and decisions in the main session.
---

# zflow Workers

**Explicit opt-in only.** This skill applies only when the user explicitly says to use zflow or
workers for subtasks. Without that, do the work directly in this session — do not launch workers,
and none of the manager/worker rules below apply. The opt-in covers the task it was given for; it
does not carry over to later, unrelated tasks.

Two roles, nothing else. **You** (the session reading this) are the manager. Each **worker** is a
real interactive CLI running in its own herdr pane, launched and driven through
`scripts/zgpt-run-worker.sh`.

| Role | Who | Job |
|---|---|---|
| **manager** | this session | analyse, design, decide, decompose, write prompts, dispatch, monitor, review, integrate, report. No extra configuration. |
| **worker** | a herdr pane | do one unit of work and stop. |

The manager does not execute; the manager does all the thinking. Workers exist to absorb execution
*volume*, not to absorb judgement.

## What goes where

**Delegate execution, not judgment.** This split is what keeps this session's token cost down:
execution volume — many files, long test runs, big logs — burns tokens in the worker pane instead
of in this context. Reasoning stays here, because that is the part worth spending this context on.

| Stays in this session (judgement) | Goes to a worker (execution volume) |
|---|---|
| requirements analysis, design, technical choices | writing the actual code |
| proposals, notes, design documents | writing test cases |
| reading diffs, review, decisions, acceptance | running tests / builds / deploys |
| decomposition, prompt design, talking to the user | evidence collection, mechanical batch edits, scanning long logs |

**Do not delegate judgment.** Semantics-dense code — admission/webhook rules, reconcile ordering,
protocol/compatibility decisions — is manager work. Decide it here and specify it branch-by-branch
in the prompt, or simply write it here when specifying it would cost more than doing it.

**Cost test before dispatching.** Delegation pays off when the work is *volume*. It costs twice when
the work is *judgement*: you pay once to write a precise spec and again to review the output. If
writing the prompt precisely would cost about as much as doing the work, do the work here.

**Do not launch a worker merely to review.** Day-to-day verification of ordinary implement work is
the manager's job, from the artifact and the diff. Reach for a separate reviewer only when the user
asks, or when the change is high-blast-radius and genuinely needs an independent pass.

## Configuration

One environment variable, set once per machine:

| Env | Role | Default when unset |
|---|---|---|
| `ZFLOW_WORKER_CMD` | the worker CLI | legacy `GPT_WORKER_CMD`, then `startomni-alice` |

`--command <cmd>` overrides it for a single launch. Hosts that want a wrapper with baked-in flags
(e.g. `claude --dangerously-skip-permissions`) point `ZFLOW_WORKER_CMD` at the wrapper script —
the launcher resolves the command by name, so the value must be a single executable, not a
command line.

## Manager loop

This loop is for **execution** work only. A unit that is reasoning — design, a proposal, a decision,
a review — does not enter the loop; do it in this session and skip to the result.

1. **Decompose.** Split the execution request into units. One worker if one worker can do it; split
   only when the units can progress independently (disjoint files/slices, independent collectors,
   non-overlapping worktrees). Prefer the fewest workers that cover the goal and say why you chose
   the count.
2. **Write each prompt.** State, for every worker: its working directory, the necessary context,
   the deliverable, how it will be checked, what it may change, and what it must never touch.
   - **Never write "follow the pattern in X."** That outsources the judgement of which parts of X
     are load-bearing. Give the exact structure and the reason for each condition; let the worker
     fill in the body.
   - Bound the scope and effort in the prompt ("run no more than N commands", "write the file and
     stop").
3. **Dispatch.** One `zgpt-run-worker.sh` call per unit. Run independent units in parallel with
   `scripts/zgpt-fanout.sh` (bounded) or background `&` + `wait`; run sequentially when a later
   step needs an earlier artifact, or when shared mutable state would collide.
4. **Monitor.** `herdr agent list` for state; `herdr agent read <pane>` to see output;
   `herdr agent wait <pane> --until idle` to block for completion. Do not block the conversation
   while a worker runs — dispatch, then keep talking.
5. **Review.** Read the worker's artifact, then the actual diff / screenshots / real artifacts.
   **A completion message is not verification.** When two sources disagree on a fact, settle it
   with a test or other verifiable evidence, not by argument.
6. **Integrate and release.** Accepted work lands in one place. Finished one-shot workers close
   themselves (`--close`); keep a pane open only when you will steer it again.

## Worker entry point

```bash
bash scripts/zgpt-run-worker.sh \
  --name dev --cwd <worktree> \
  --artifact <run_dir>/report.md --close \
  --route implement --report-mode compact \
  --task "<the unit of work>"
```

Key options:

| Option | Meaning |
|---|---|
| `--command <cmd>` | worker CLI for this launch (default `ZFLOW_WORKER_CMD`) |
| `--cwd <dir>` | working directory (a worktree for writable workers) |
| `--route implement\|inspect\|verify` | task gate; `inspect`/`verify` add a report-only, no-edit default. Default `implement` |
| `--report-mode compact\|full\|none` | append a report contract to the prompt |
| `--artifact <path>` | ask the worker to write this file; `artifact=<path>` is printed on completion |
| `--close` | graceful exit + close the pane when the run finishes |
| `--ready-pattern <str>` | readiness glyph; required for CLIs with no auto glyph (see Notes) |
| `--timeout` / `--max-timeout` | inactivity window (default 900s) / absolute ceiling (default 21600s). `--max-timeout 0` removes the cap |
| `--command-arg <arg>` | extra arg for the worker CLI (repeatable) |
| `--effort <level>` | effort level for Claude/Grok-family workers (default `high`) |
| `--allow-nested` | bypass the worker-depth guard (deliberate nested fan-out only) |

Completion is signalled by a `WORKER_DONE:<token>` marker the runner watches for in the pane
transcript; the wait is an **inactivity window** that slides forward while the pane keeps producing
output, so a long healthy task is never killed while a stuck one is reaped after `--timeout`.

## Isolation: one writer per checkout

Two writers must never share a checkout. Give every writable worker its own worktree:

```bash
bash scripts/zgpt-worktree.sh <repo> <task-id>     # prints the worktree path
```

Read-only workers (`--route inspect|verify`) may use an existing checkout; they must not write to
it. Never point a writable worker at a primary clone.

## Monitoring and steering

```bash
herdr agent list                                  # every agent pane and its state
herdr agent read <pane>                           # live pane output
herdr agent wait <pane> --until idle              # block until it is done/idle
herdr agent prompt <pane> "<instruction>"         # steer a running worker
herdr pane read <pane> --source visible --lines 40
herdr pane close <pane>
```

If a worker is `blocked` (an approval or question prompt), `herdr agent explain <pane>` says why,
`herdr agent read <pane>` shows what it is waiting on, then `herdr agent prompt` answers it.

## Notes

- **CLIs without a readiness glyph need `--ready-pattern`.** Claude (`❯`) and codex (`›`) are
  auto-detected. `opencode` is family `generic` and never prints `❯`; launch it with
  `--ready-pattern "Ask anything"` or the run ends in `ready_timeout` (it fails safe — no task is
  injected).
- **`--close` is the default posture for one-shot workers.** Omit it only when you intend to keep
  steering the same pane.
- **Depth guard.** A worker inherits `ZFLOW_WORKER_DEPTH`; `zgpt-run-worker.sh` refuses to start
  above `ZFLOW_MAX_WORKER_DEPTH` (default 0) unless `--allow-nested` is passed, so a worker cannot
  silently recurse into a chain of sub-workers. The route gate also tells the worker it is the
  terminal executor.
- **Outward actions stay gated.** Pushes, releases, deploys, production changes and anything sent
  to an external service wait for explicit human authorisation.
- **Keep worker output out of the main conversation** — read the artifact and the diff, not the
  full pane log.

## Optional: block edits to a primary clone

Prose does not hold at 300k+ context; a hook does. `zgpt-primary-clone-guard.sh` is a Claude Code
`PreToolUse` hook that blocks `Edit`/`Write`/`MultiEdit`/`NotebookEdit` inside a *primary* clone
while allowing the same path inside a linked worktree. It fails open on any internal error and
fails closed only on a confident primary-clone hit. Disable with `ZFLOW_GUARD=off`.

Register it in `~/.claude/settings.json` (point `command` at wherever this skill is checked out):

```json
{
  "hooks": {
    "PreToolUse": [
      {
        "matcher": "Edit|Write|MultiEdit|NotebookEdit",
        "hooks": [
          { "type": "command", "command": "$HOME/.claude/skills/zflow-workers/scripts/zgpt-primary-clone-guard.sh" }
        ]
      }
    ]
  }
}
```

## Layout

| Path | Role |
|---|---|
| `SKILL.md` | this contract |
| `scripts/zgpt-run-worker.sh` | the worker entry point (launch → inject → wait → collect) |
| `scripts/zgpt-worker-pane.sh` | pane launcher used by the runner |
| `scripts/zgpt-worktree.sh` | isolated worktrees for writable workers |
| `scripts/zgpt-fanout.sh` | bounded parallel dispatch |
| `scripts/zgpt-common.sh`, `scripts/zgpt-cli-adapter.sh` | shared helpers / CLI-family capabilities |
| `scripts/zgpt-primary-clone-guard.sh` | optional PreToolUse hook: block edits to a primary clone |
| `hooks/herdr-pane-label.sh` | labels the human session's pane `human:<repo> · <title>` |
| `tests/` | offline smoke suites (`bash tests/run-all.sh`) |
