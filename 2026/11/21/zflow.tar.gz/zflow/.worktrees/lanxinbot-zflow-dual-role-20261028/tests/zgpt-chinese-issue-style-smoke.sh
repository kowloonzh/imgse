#!/usr/bin/env bash
set -euo pipefail

# Offline smoke for --chinese-issue-style / ZFLOW_CHINESE_ISSUE_STYLE.
# Never launches a real pane: real zgpt-run-worker.sh + stub launcher + herdr that
# becomes ready immediately and emits WORKER_DONE on first recent-unwrapped read.
# Captures the injected prompt via pane send-text / agent prompt stubs.

unset ZFLOW_WORKER_DEPTH ZFLOW_MAX_WORKER_DEPTH ZFLOW_CHINESE_ISSUE_STYLE 2>/dev/null || true

scripts="$(cd "$(dirname "${BASH_SOURCE[0]}")/../scripts" && pwd)"
# shellcheck source=/dev/null
source "$scripts/zgpt-common.sh"

passed=0
failed=0
pass() { printf 'PASS: %s\n' "$1"; passed=$((passed + 1)); }
fail() { printf 'FAIL: %s\n' "$1" >&2; failed=$((failed + 1)); }

tmp="$(mktemp -d "${TMPDIR:-/tmp}/zgpt-chinese-issue-style-smoke.XXXXXX")"
trap 'rm -rf "$tmp"' EXIT

stub_dir="$tmp/scripts"
mkdir -p "$stub_dir" "$tmp/bin"
ln -s "$scripts/zgpt-run-worker.sh" "$stub_dir/zgpt-run-worker.sh"
ln -s "$scripts/zgpt-common.sh" "$stub_dir/zgpt-common.sh"
ln -s "$scripts/zgpt-cli-adapter.sh" "$stub_dir/zgpt-cli-adapter.sh"
run_worker="$stub_dir/zgpt-run-worker.sh"

cat >"$stub_dir/zgpt-worker-pane.sh" <<'STUB'
#!/usr/bin/env bash
printf 'launcher_called\n' >>"${ZGPT_LAUNCH_CALLED:?}"
printf 'pane_id=fake:p1\n'
printf 'family=generic\n'
STUB
chmod +x "$stub_dir/zgpt-worker-pane.sh"

cat >"$tmp/bin/herdr" <<'STUB'
#!/usr/bin/env bash
set -euo pipefail
if [[ "${1:-}" == --session ]]; then shift 2; fi
cmd="${1:-} ${2:-}"
case "$cmd" in
  "pane read")
    source_name=""
    for ((i=3; i<=$#; i++)); do
      if [[ "${!i:-}" == "--source" ]]; then
        j=$((i + 1)); source_name="${!j:-}"; break
      fi
    done
    if [[ "$source_name" == "visible" ]]; then
      printf '❯\n'
      exit 0
    fi
    printf 'WORKER_DONE:testtoken\n'
    exit 0
    ;;
  "pane send-text")
    # Capture injected text (args after send-text: pane id + full prompt).
    printf '%s\n' "$@" >>"${ZGPT_CAPTURE:?}"
    exit 0
    ;;
  "agent prompt")
    # Newer herdr path: capture the prompt body after flags/pane id.
    printf '%s\n' "$@" >>"${ZGPT_CAPTURE:?}"
    exit 0
    ;;
  "pane get"|"pane send-keys"|"pane close"|"agent wait"|"agent get")
    exit 0
    ;;
  "pane wait-output")
    exit 1
    ;;
  *) exit 0 ;;
esac
STUB
chmod +x "$tmp/bin/herdr"

capture="$tmp/prompt.capture"
launch_called="$tmp/launch.called"

run_launch() {
    local out_file="$1"; shift
    : >"$capture"
    : >"$launch_called"
    PATH="$tmp/bin:$PATH" HERDR_SESSION=test-session ZFLOW_LEDGER=off \
        ZGPT_CAPTURE="$capture" ZGPT_LAUNCH_CALLED="$launch_called" \
        "$run_worker" --name t --command fakecli --token testtoken \
        --ready-timeout 5 --poll 1 --timeout 30 --max-timeout 30 \
        --task 'write a note about 预留 concurrency' "$@" >"$out_file" 2>&1 &
    local pid=$! waited=0
    while kill -0 "$pid" 2>/dev/null && (( waited < 15 )); do
        sleep 1; waited=$((waited + 1))
    done
    if kill -0 "$pid" 2>/dev/null; then
        kill "$pid" 2>/dev/null || true
        wait "$pid" 2>/dev/null || true
        return 124
    fi
    wait "$pid"
    return $?
}

# ── 1. Default off: no Chinese contract in injected prompt ───────────────────
out="$tmp/off.out"
set +e
run_launch "$out"
rc=$?
set -e
if [[ "$rc" == 0 ]] && grep -q '^status=ok$' "$out"; then
    pass 'default: reaches status=ok'
else
    fail "default: expected status=ok (rc=$rc)"; sed 's/^/  /' "$out"
fi
if grep -q '^chinese_issue_style=off$' "$out"; then
    pass 'default: metadata chinese_issue_style=off'
else
    fail 'default: missing chinese_issue_style=off metadata'; sed 's/^/  /' "$out"
fi
if grep -q 'Chinese technical-issue writing contract' "$capture"; then
    fail 'default: contract must NOT be injected'
else
    pass 'default: contract not injected'
fi

# ── 2. Flag on: contract prepended + metadata on ────────────────────────────
out="$tmp/flag.out"
set +e
run_launch "$out" --chinese-issue-style
rc=$?
set -e
if [[ "$rc" == 0 ]] && grep -q '^status=ok$' "$out"; then
    pass 'flag: reaches status=ok'
else
    fail "flag: expected status=ok (rc=$rc)"; sed 's/^/  /' "$out"
fi
if grep -q '^chinese_issue_style=on$' "$out"; then
    pass 'flag: metadata chinese_issue_style=on'
else
    fail 'flag: missing chinese_issue_style=on metadata'; sed 's/^/  /' "$out"
fi
if grep -q 'Chinese technical-issue writing contract' "$capture"; then
    pass 'flag: contract injected into prompt'
else
    fail 'flag: contract missing from captured prompt'; sed 's/^/  /' "$capture"
fi
if grep -q '根因 1 / 根因 2' "$capture" && grep -q 'never invent rc1/rc2' "$capture"; then
    pass 'flag: forbids rc1/rc2 abbreviation'
else
    fail 'flag: missing 根因/rc forbid clause'
fi
if grep -q '现象 → 根因编号 → 已修复 → 仍开放 → 复现 → 验收' "$capture"; then
    pass 'flag: structure order present'
else
    fail 'flag: missing structure order'
fi
# Contract must appear before the task substance.
if awk '
  /Chinese technical-issue writing contract/ { c=NR }
  /write a note about/ { t=NR }
  END { exit !(c && t && c < t) }
' "$capture"; then
    pass 'flag: contract precedes task text'
else
    fail 'flag: contract must prepend task'
fi

# ── 3. Env on: ZFLOW_CHINESE_ISSUE_STYLE=1 ───────────────────────────────────
out="$tmp/env.out"
set +e
ZFLOW_CHINESE_ISSUE_STYLE=1 run_launch "$out"
rc=$?
set -e
if [[ "$rc" == 0 ]] && grep -q '^chinese_issue_style=on$' "$out"; then
    pass 'env=1: metadata chinese_issue_style=on'
else
    fail "env=1: expected on metadata (rc=$rc)"; sed 's/^/  /' "$out"
fi
if grep -q 'Chinese technical-issue writing contract' "$capture"; then
    pass 'env=1: contract injected'
else
    fail 'env=1: contract missing'
fi

# ── 4. Env off-ish values do not enable ──────────────────────────────────────
out="$tmp/envoff.out"
set +e
ZFLOW_CHINESE_ISSUE_STYLE=0 run_launch "$out"
rc=$?
set -e
if grep -q '^chinese_issue_style=off$' "$out"; then
    pass 'env=0: metadata stays off'
else
    fail 'env=0: should stay off'; sed 's/^/  /' "$out"
fi
if grep -q 'Chinese technical-issue writing contract' "$capture"; then
    fail 'env=0: must not inject contract'
else
    pass 'env=0: contract not injected'
fi

printf '\n== Summary ==\n'
printf '%d passed, %d failed\n' "$passed" "$failed"
((failed == 0))
