#!/usr/bin/env bash
set -euo pipefail

# zgpt-inject-smoke.sh — deterministic offline tests for
# zgpt_herdr_prompt_inject (zgpt-common.sh).
#
# Stubs `herdr` on PATH with a controllable mock:
#   ZGPT_FAKE_HAS_AGENT_PROMPT  1 (default) | 0  — capability-probe result
#   ZGPT_FAKE_PROMPT_MODE       success | definitive | ambiguous — agent prompt result
# Every herdr invocation is logged to $ZGPT_CALL_LOG; every pane-dance step is
# logged to $ZGPT_PANE_LOG. Exits non-zero on any failure.
#
# Covers (ADR docs/herdr-agent-automation-design.md):
#   - prefers `agent prompt` for detected agent panes
#   - falls back to the pane dance on definitive failure (agent_not_detected …)
#   - does NOT fall back on ambiguous timeout/unknown transport (send-once)
#   - capability gate disables agent prompt when unsupported
#   - double-Enter behavior preserved (always / large / never modes)
#   - `--wait` forwarded only when requested (never used for completion)

script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")/../scripts" && pwd)"
source "$script_dir/zgpt-common.sh"
tmp="$(mktemp -d "${TMPDIR:-/tmp}/zgpt-inject.XXXXXX")"
trap 'rm -rf "$tmp"' EXIT
bin="$tmp/bin"; mkdir -p "$bin"

cat >"$bin/herdr" <<'STUB'
#!/usr/bin/env bash
set -euo pipefail
cmd="${1:-}"; shift || true
{
    printf 'herdr %s' "$cmd"
    [[ $# -gt 0 ]] && printf ' %s' "$@"
    printf '\n'
} >>"$ZGPT_CALL_LOG"
case "$cmd" in
  agent)
    sub="${1:-}"; shift || true
    case "$sub" in
      prompt)
        if [[ "${1:-}" == "--help" ]]; then
          if [[ "${ZGPT_FAKE_HAS_AGENT_PROMPT:-1}" == "1" ]]; then
            printf 'usage: herdr agent prompt TARGET TEXT [--wait] [--timeout MS]\n'
            exit 0
          fi
          printf 'unknown command: prompt\n' >&2
          exit 1
        fi
        case "${ZGPT_FAKE_PROMPT_MODE:-success}" in
          success)
            printf '{"result":{"ok":true}}\n'
            ;;
          definitive)
            printf 'error: agent_not_detected\n' >&2
            exit 1
            ;;
          ambiguous)
            printf 'error: agent_prompt_stalled\n' >&2
            exit 1
            ;;
          *) exit 1 ;;
        esac
        ;;
      *) exit 1 ;;
    esac
    ;;
  pane)
    sub="${1:-}"; shift || true
    case "$sub" in
      send-text) printf 'send-text %s %s\n' "${1:-}" "${2:-}" >>"$ZGPT_PANE_LOG" ;;
      send-keys) printf 'send-keys %s\n' "${1:-}" >>"$ZGPT_PANE_LOG" ;;
      *) exit 1 ;;
    esac
    ;;
  *) exit 1 ;;
esac
STUB
chmod +x "$bin/herdr"
export PATH="$bin:$PATH"
export ZGPT_HERDR_SESSION=""
export ZGPT_CALL_LOG="$tmp/calls.log"
export ZGPT_PANE_LOG="$tmp/pane.log"
: >"$ZGPT_CALL_LOG"; : >"$ZGPT_PANE_LOG"

pass=0; fail=0; fails=()
ok() { pass=$((pass + 1)); printf '  ok: %s\n' "$1"; }
bad() { fail=$((fail + 1)); fails+=("$1"); printf '  FAIL: %s\n' "$1"; }
reset() { unset ZGPT_HERDR_HAS_AGENT_PROMPT; : >"$ZGPT_CALL_LOG"; : >"$ZGPT_PANE_LOG"; }
long_msg="$(printf 'x%.0s' {1..85})"
multi_msg="$(printf 'line1\nline2\nline3\n')"

echo "== prefers agent prompt when available =="
reset
zgpt_herdr_prompt_inject w1:p1 "hello"
grep -q '^herdr agent prompt w1:p1 hello$' "$ZGPT_CALL_LOG" && ok "agent prompt submitted" || bad "no agent prompt: $(cat "$ZGPT_CALL_LOG")"
[[ ! -s "$ZGPT_PANE_LOG" ]] && ok "no pane dance on prompt success" || bad "unexpected pane dance: $(cat "$ZGPT_PANE_LOG")"

echo "== --wait forwards --wait --timeout =="
reset
zgpt_herdr_prompt_inject w1:p1 "hello" --wait --wait-ms 5000
grep -q -- '--wait --timeout 5000' "$ZGPT_CALL_LOG" && ok "--wait forwarded" || bad "no --wait: $(cat "$ZGPT_CALL_LOG")"

echo "== default inject is fire-and-forget (no --wait) =="
reset
zgpt_herdr_prompt_inject w1:p1 "hello"
if grep -q -- '--wait' "$ZGPT_CALL_LOG"; then bad "unexpected --wait in default inject: $(cat "$ZGPT_CALL_LOG")"; else ok "no --wait by default"; fi

echo "== falls back to pane dance on definitive failure =="
reset
export ZGPT_FAKE_PROMPT_MODE=definitive
zgpt_herdr_prompt_inject w1:p1 "hello"
grep -q '^send-text w1:p1 hello$' "$ZGPT_PANE_LOG" && ok "fallback sent text" || bad "no send-text: $(cat "$ZGPT_PANE_LOG")"
grep -q '^send-keys' "$ZGPT_PANE_LOG" && ok "fallback sent Enter" || bad "no send-keys: $(cat "$ZGPT_PANE_LOG")"

echo "== does NOT fall back on ambiguous timeout/unknown =="
reset
export ZGPT_FAKE_PROMPT_MODE=ambiguous
set +e
zgpt_herdr_prompt_inject w1:p1 "hello"
rc=$?
set -e
[[ $rc -ne 0 ]] && ok "ambiguous returns non-zero ($rc)" || bad "ambiguous returned 0"
[[ ! -s "$ZGPT_PANE_LOG" ]] && ok "no fallback after ambiguous" || bad "fell back after ambiguous: $(cat "$ZGPT_PANE_LOG")"

echo "== capability gate disables agent prompt when unsupported =="
reset
export ZGPT_FAKE_HAS_AGENT_PROMPT=0
export ZGPT_FAKE_PROMPT_MODE=success
zgpt_herdr_prompt_inject w1:p1 "hello"
if grep -q '^herdr agent prompt w1:p1 ' "$ZGPT_CALL_LOG"; then bad "agent prompt attempted without capability: $(cat "$ZGPT_CALL_LOG")"; else ok "no behavioral agent prompt when unsupported"; fi
grep -q '^send-text w1:p1 hello$' "$ZGPT_PANE_LOG" && ok "straight to pane dance when unsupported" || bad "no pane dance: $(cat "$ZGPT_PANE_LOG")"

echo "== default run-worker dance double-enters even short text =="
reset
export ZGPT_FAKE_HAS_AGENT_PROMPT=1
export ZGPT_FAKE_PROMPT_MODE=definitive
zgpt_herdr_prompt_inject w1:p1 "hi"
[[ "$(grep -c '^send-keys' "$ZGPT_PANE_LOG")" -ge 2 ]] && ok "always-mode double-entered" || bad "expected >=2 send-keys: $(cat "$ZGPT_PANE_LOG")"

echo "== large mode double-enters only on long/multi-line =="
reset
zgpt_herdr_prompt_inject w1:p1 "$long_msg" --double-enter large
[[ "$(grep -c '^send-keys' "$ZGPT_PANE_LOG")" -ge 2 ]] && ok "large-mode double-entered on long message" || bad "expected >=2 send-keys: $(cat "$ZGPT_PANE_LOG")"
reset
zgpt_herdr_prompt_inject w1:p1 "$multi_msg" --double-enter large
[[ "$(grep -c '^send-keys' "$ZGPT_PANE_LOG")" -ge 2 ]] && ok "large-mode double-entered on multi-line" || bad "expected >=2 send-keys: $(cat "$ZGPT_PANE_LOG")"
reset
zgpt_herdr_prompt_inject w1:p1 "continue" --double-enter large
[[ "$(grep -c '^send-keys' "$ZGPT_PANE_LOG")" == 1 ]] && ok "large-mode single-enter on short message" || bad "expected 1 send-keys: $(cat "$ZGPT_PANE_LOG")"

echo "== never mode single-enters even long text =="
reset
zgpt_herdr_prompt_inject w1:p1 "$long_msg" --double-enter never
[[ "$(grep -c '^send-keys' "$ZGPT_PANE_LOG")" == 1 ]] && ok "never-mode single-enter" || bad "expected 1 send-keys: $(cat "$ZGPT_PANE_LOG")"

echo "== missing args rejected =="
reset
set +e
zgpt_herdr_prompt_inject w1:p1 "" >/dev/null 2>&1
rc=$?
set -e
[[ $rc -ne 0 ]] && ok "empty text rejected" || bad "empty text accepted"

printf '\nSummary: %d/%d passed\n' "$pass" "$((pass + fail))"
[[ ${#fails[@]} -eq 0 ]] || { printf 'Failed: %s\n' "${fails[@]}"; exit 1; }
