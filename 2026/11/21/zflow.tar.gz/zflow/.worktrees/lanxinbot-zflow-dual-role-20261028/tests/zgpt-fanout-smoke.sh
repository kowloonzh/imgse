#!/usr/bin/env bash
set -euo pipefail

script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")/../scripts" && pwd)"
tmp="$(mktemp -d "${TMPDIR:-/tmp}/zgpt-fanout.XXXXXX")"
trap 'rm -rf "$tmp"' EXIT

cat >"$tmp/worker.sh" <<'STUB'
#!/usr/bin/env bash
set -euo pipefail
state="$1"
name="$2"
mkdir -p "$state"
while true; do
  count="$(find "$state" -name '*.lock' -type f | wc -l | tr -d ' ')"
  if (( count >= 2 )); then sleep 0.05; continue; fi
  lock="$state/$name.lock"
  if ( set -C; : >"$lock" ) 2>/dev/null; then break; fi
done
count="$(find "$state" -name '*.lock' -type f | wc -l | tr -d ' ')"
printf '%s\n' "$count" >>"$state/seen"
sleep 0.2
rm -f "$lock"
STUB
chmod +x "$tmp/worker.sh"

printf 'a\nb\nc\nd\n' | "$script_dir/zgpt-fanout.sh" --max-parallel 2 -- "$tmp/worker.sh" "$tmp/state"
[[ "$(sort -nr "$tmp/state/seen" | head -1)" -le 2 ]]

# Regression: stdin lines run through `bash -lc`, which must resolve the sibling
# zgpt-* scripts by bare name even when the caller's PATH lacks the scripts dir
# (install-skill.sh never adds it). Sanitize PATH so the name resolves only if
# zgpt-fanout.sh prepends its own directory before dispatching.
printf 'command -v zgpt-run-worker.sh >/dev/null\n' \
    | env PATH="/usr/bin:/bin" "$script_dir/zgpt-fanout.sh" --max-parallel 1

set +e
printf 'x\n' | "$script_dir/zgpt-fanout.sh" --max-parallel 0 >/tmp/zgpt-fanout.err 2>&1
rc=$?
set -e
[[ "$rc" == 2 ]]
printf 'fanout smoke ok\n'
