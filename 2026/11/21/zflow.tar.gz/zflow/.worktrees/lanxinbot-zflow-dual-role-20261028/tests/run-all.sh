#!/usr/bin/env bash
set -euo pipefail

tests_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

live_suite="zgpt-live-cross-cli-smoke.sh"
run_live="${ZFLOW_RUN_LIVE_TESTS:-0}"

suites=()
while IFS= read -r -d '' suite; do
  base="$(basename "$suite")"
  if [[ "$base" == "$live_suite" && "$run_live" != "1" ]]; then
    continue
  fi
  suites+=("$suite")
done < <(find "$tests_dir" -maxdepth 1 -name '*-smoke.sh' -print0 | sort -z)

pass_count=0
fail_count=0
failed_suites=()

for suite in "${suites[@]}"; do
  name="$(basename "$suite")"
  if bash "$suite" >/tmp/"$name".out 2>&1; then
    printf 'PASS: %s\n' "$name"
    pass_count=$((pass_count + 1))
  else
    printf 'FAIL: %s\n' "$name"
    printf '  --- output ---\n'
    sed 's/^/  /' /tmp/"$name".out
    fail_count=$((fail_count + 1))
    failed_suites+=("$name")
  fi
done

total=$((pass_count + fail_count))
printf '\nSummary: %d/%d suites passed\n' "$pass_count" "$total"

if [[ "$run_live" != "1" ]]; then
  printf '(live suite %s skipped; set ZFLOW_RUN_LIVE_TESTS=1 to include it)\n' "$live_suite"
fi

if (( fail_count > 0 )); then
  printf 'Failed suites: %s\n' "${failed_suites[*]}"
  exit 1
fi

exit 0
