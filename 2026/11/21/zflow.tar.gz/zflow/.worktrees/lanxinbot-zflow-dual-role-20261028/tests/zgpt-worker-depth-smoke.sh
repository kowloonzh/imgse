#!/usr/bin/env bash
set -euo pipefail

# Offline smoke suite for the worker-depth guard (FIX for accidental
# worker-to-worker recursion). Never launches a real pane and never requires a
# live herdr session. The real zgpt-run-worker.sh is run against a stubbed
# zgpt-worker-pane.sh launcher and a herdr stub whose visible read answers
# immediately with the ready glyph and whose recent-unwrapped read answers
# immediately with the completion marker, so a launch either reaches
# status=ok in about a second or is refused by the depth guard before the
# launcher is even called.
#
#   - depth 0 (manager, unset) launches
#   - depth 1 (a worker spawning a sub-worker) is refused before launch
#   - depth 2 (a worker-of-worker) is refused before launch
#   - --allow-nested and ZFLOW_MAX_WORKER_DEPTH are explicit escape hatches
#     that each permit depth 1
#   - the route-gate text reaches the injected prompt for implement and for a
#     report-only route, including the terminal-executor / no-sub-worker clause

# The suite must be hermetic: running it inside a zflow worker (which exports
# ZFLOW_WORKER_DEPTH) must not make the "depth 0 / unset" cases look like nested
# launches. Clear both depth vars so the unset case really is unset; the depth-1
# / depth-2 cases below set their own value explicitly.
unset ZFLOW_WORKER_DEPTH ZFLOW_MAX_WORKER_DEPTH 2>/dev/null || true

scripts="$(cd "$(dirname "${BASH_SOURCE[0]}")/../scripts" && pwd)"
# shellcheck source=/dev/null
source "$scripts/zgpt-common.sh"

passed=0
failed=0
pass() { printf 'PASS: %s\n' "$1"; passed=$((passed + 1)); }
fail() { printf 'FAIL: %s\n' "$1" >&2; failed=$((failed + 1)); }
assert_eq() { if [[ "$1" == "$2" ]]; then pass "$3"; else fail "$3 (got=$1 expected=$2)"; fi; }
assert_contains() { if grep -q -- "$2" <<<"$1"; then pass "$3"; else fail "$3 (output did not contain: $2)"; fi; }
assert_fail() { local label="$1"; shift; if ! "$@" >/dev/null 2>&1; then pass "$label"; else fail "$label (expected failure)"; fi; }

tmp="$(mktemp -d "${TMPDIR:-/tmp}/zgpt-depth-smoke.XXXXXX")"
trap 'rm -rf "$tmp"' EXIT

# ── Stub harness ─────────────────────────────────────────────────────────────
# Real run-worker.sh + common.sh + cli-adapter.sh (symlinked so `source
# "$script_dir/..."` resolves), a fake zgpt-worker-pane.sh launcher that records
# being called and reports a fake pane_id, and a herdr stub that becomes ready
# on the first visible read and emits the completion marker on the first
# recent-unwrapped read. The injected prompt is captured by the send-text stub.
stub_dir="$tmp/scripts"
mkdir -p "$stub_dir" "$tmp/bin"
ln -s "$scripts/zgpt-run-worker.sh" "$stub_dir/zgpt-run-worker.sh"
ln -s "$scripts/zgpt-common.sh" "$stub_dir/zgpt-common.sh"
ln -s "$scripts/zgpt-cli-adapter.sh" "$stub_dir/zgpt-cli-adapter.sh"
run_worker="$stub_dir/zgpt-run-worker.sh"

cat >"$stub_dir/zgpt-worker-pane.sh" <<'STUB'
#!/usr/bin/env bash
printf 'launcher_called\n' >>"${ZGPT_LAUNCH_CALLED:?}"
printf 'pane_id=fake:p1\n'
printf 'family=generic\n'
STUB
chmod +x "$stub_dir/zgpt-worker-pane.sh"

cat >"$tmp/bin/herdr" <<'STUB'
#!/usr/bin/env bash
set -euo pipefail
if [[ "${1:-}" == --session ]]; then shift 2; fi
cmd="${1:-} ${2:-}"
case "$cmd" in
  "pane read")
    source_name=""
    for ((i=3; i<=$#; i++)); do
      if [[ "${!i:-}" == "--source" ]]; then
        j=$((i + 1)); source_name="${!j:-}"; break
      fi
    done
    if [[ "$source_name" == "visible" ]]; then
      # Readiness glyph + absence of the not-logged-in phrase.
      printf '❯\n'
      exit 0
    fi
    # recent-unwrapped: emit the completion marker on the first read so a
    # permitted launch reaches status=ok immediately.
    printf 'WORKER_DONE:testtoken\n'
    exit 0
    ;;
  "pane send-text")
    # Capture the injected prompt (all args: pane id + full text).
    printf '%s\n' "$@" >>"${ZGPT_CAPTURE:?}"
    exit 0
    ;;
  "agent prompt")
    # Capability probe: --help confirms herdr 0.8.0 supports agent prompt.
    if [[ "${3:-}" == "--help" ]]; then
      exit 0
    fi
    # Inject path now prefers agent prompt; capture target + full text the same
    # way the send-text stub did.
    shift 2  # drop "agent prompt"
    printf '%s\n' "$@" >>"${ZGPT_CAPTURE:?}"
    exit 0
    ;;
  "pane get"|"pane send-keys"|"pane close"|"agent wait"|"agent get")
    exit 0
    ;;
  "pane wait-output")
    # Unsupported waits return immediately; the loop then falls back to reads.
    exit 1
    ;;
  *) exit 0 ;;
esac
STUB
chmod +x "$tmp/bin/herdr"

capture="$tmp/prompt.capture"
launch_called="$tmp/launch.called"

# Runs the real script against the stub harness in a background subshell so the
# test can bound a hang. A permitted launch reaches status=ok in ~1-2s; a
# refused launch exits immediately (die, rc=2). Returns the worker's exit code,
# or 124 if it had to be killed at the 15s guard.
run_launch() {
    local out_file="$1"; shift
    : >"$capture"
    : >"$launch_called"
    PATH="$tmp/bin:$PATH" HERDR_SESSION=test-session ZFLOW_LEDGER=off \
        ZGPT_CAPTURE="$capture" ZGPT_LAUNCH_CALLED="$launch_called" \
        "$run_worker" --name t --command fakecli --token testtoken \
        --ready-timeout 5 --poll 1 --timeout 30 --max-timeout 30 \
        --task 'benign' "$@" >"$out_file" 2>&1 &
    local pid=$! waited=0
    while kill -0 "$pid" 2>/dev/null && (( waited < 15 )); do
        sleep 1; waited=$((waited + 1))
    done
    if kill -0 "$pid" 2>/dev/null; then
        kill "$pid" 2>/dev/null || true
        wait "$pid" 2>/dev/null || true
        return 124
    fi
    wait "$pid"
    return $?
}

# ── 1. Depth 0 (manager, env unset) launches ────────────────────────────────
out="$tmp/d0.out"
set +e
run_launch "$out"
rc=$?
set -e
if [[ "$rc" == 0 ]] && grep -q '^status=ok$' "$out"; then
    pass 'depth 0 (manager): launches and reaches status=ok'
else
    fail "depth 0: expected status=ok (rc=$rc, output below)"
    sed 's/^/  /' "$out"
fi
if grep -q 'refusing to launch' "$out"; then
    fail 'depth 0: must not hit the depth guard'
else
    pass 'depth 0: no depth-refusal error'
fi

# ── 1b. Depth 0 explicit still launches (numeric 0 is allowed; managers prefer unset) ─
out="$tmp/d0explicit.out"
set +e
ZFLOW_WORKER_DEPTH=0 run_launch "$out"
rc=$?
set -e
if [[ "$rc" == 0 ]] && grep -q '^status=ok$' "$out"; then
    pass 'depth 0 explicit: launches and reaches status=ok'
else
    fail "depth 0 explicit: expected status=ok (rc=$rc, output below)"
    sed 's/^/  /' "$out"
fi

# ── 2. Depth 1 (a worker spawning a sub-worker) is refused before launch ────
out="$tmp/d1.out"
set +e
ZFLOW_WORKER_DEPTH=1 run_launch "$out"
rc=$?
set -e
if [[ "$rc" != 0 ]] && grep -q 'refusing to launch a nested worker' "$out"; then
    pass 'depth 1: refuses to launch with a clear error'
else
    fail "depth 1: expected a hard refusal (rc=$rc, output below)"
    sed 's/^/  /' "$out"
fi
if grep -q -- '--allow-nested' "$out"; then
    pass 'depth 1: refusal names the --allow-nested opt-in'
else
    fail 'depth 1: refusal must name the escape hatch'
fi
if [[ -s "$launch_called" ]]; then
    fail 'depth 1: the launcher must not be invoked on refusal'
else
    pass 'depth 1: launcher not invoked'
fi

# ── 3. Escape hatch: --allow-nested permits depth 1 ─────────────────────────
out="$tmp/d1allow.out"
set +e
ZFLOW_WORKER_DEPTH=1 run_launch "$out" --allow-nested
rc=$?
set -e
if [[ "$rc" == 0 ]] && grep -q '^status=ok$' "$out"; then
    pass 'depth 1 + --allow-nested: escape hatch permits the launch'
else
    fail "depth 1 + --allow-nested: expected status=ok (rc=$rc, output below)"
    sed 's/^/  /' "$out"
fi

# ── 4. Escape hatch: ZFLOW_MAX_WORKER_DEPTH=1 permits depth 1 ────────────────
out="$tmp/d1max.out"
set +e
ZFLOW_WORKER_DEPTH=1 ZFLOW_MAX_WORKER_DEPTH=1 run_launch "$out"
rc=$?
set -e
if [[ "$rc" == 0 ]] && grep -q '^status=ok$' "$out"; then
    pass 'depth 1 + ZFLOW_MAX_WORKER_DEPTH=1: escape hatch permits the launch'
else
    fail "depth 1 + ZFLOW_MAX_WORKER_DEPTH=1: expected status=ok (rc=$rc, output below)"
    sed 's/^/  /' "$out"
fi

# ── 5. Depth 2 (worker-of-worker) is refused before launch ──────────────────
out="$tmp/d2.out"
set +e
ZFLOW_WORKER_DEPTH=2 run_launch "$out"
rc=$?
set -e
if [[ "$rc" != 0 ]] && grep -q 'refusing to launch a nested worker' "$out"; then
    pass 'depth 2: refuses to launch with a clear error'
else
    fail "depth 2: expected a hard refusal (rc=$rc, output below)"
    sed 's/^/  /' "$out"
fi
if grep -q -- '--allow-nested' "$out"; then
    pass 'depth 2: refusal names the --allow-nested opt-in'
else
    fail 'depth 2: refusal must name the escape hatch'
fi
if [[ -s "$launch_called" ]]; then
    fail 'depth 2: the launcher must not be invoked on refusal'
else
    pass 'depth 2: launcher not invoked'
fi

# ── 6. Escape hatch: --allow-nested permits depth 2 ─────────────────────────
out="$tmp/d2allow.out"
set +e
ZFLOW_WORKER_DEPTH=2 run_launch "$out" --allow-nested
rc=$?
set -e
if [[ "$rc" == 0 ]] && grep -q '^status=ok$' "$out"; then
    pass 'depth 2 + --allow-nested: escape hatch permits the launch'
else
    fail "depth 2 + --allow-nested: expected status=ok (rc=$rc, output below)"
    sed 's/^/  /' "$out"
fi

# ── 7. Escape hatch: ZFLOW_MAX_WORKER_DEPTH=2 permits depth 2 ───────────────
out="$tmp/d2max.out"
set +e
ZFLOW_WORKER_DEPTH=2 ZFLOW_MAX_WORKER_DEPTH=2 run_launch "$out"
rc=$?
set -e
if [[ "$rc" == 0 ]] && grep -q '^status=ok$' "$out"; then
    pass 'depth 2 + ZFLOW_MAX_WORKER_DEPTH=2: escape hatch permits the launch'
else
    fail "depth 2 + ZFLOW_MAX_WORKER_DEPTH=2: expected status=ok (rc=$rc, output below)"
    sed 's/^/  /' "$out"
fi

# ── 8. Route-gate text reaches the injected prompt: implement ───────────────
out="$tmp/impl.out"
set +e
run_launch "$out" --route implement
rc=$?
set -e
prompt="$(cat "$capture")"
assert_contains "$prompt" 'Route gate: implementation is allowed only within' 'implement gate keeps the scope/writable-paths clause'
assert_contains "$prompt" 'terminal executor' 'implement gate states this worker is the terminal executor'
assert_contains "$prompt" 'zgpt-run-worker.sh' 'implement gate names the nested-worker scripts'
assert_contains "$prompt" 'sub-worker' 'implement gate forbids delegating the edit to a sub-worker'

# ── 9. Route-gate text reaches the injected prompt: report-only route ───────
out="$tmp/report.out"
set +e
run_launch "$out" --route inspect
rc=$?
set -e
prompt="$(cat "$capture")"
assert_contains "$prompt" 'Route gate: report-only' 'report gate keeps the no-edit default'
assert_contains "$prompt" 'terminal executor' 'report gate carries the terminal-executor clause'
assert_contains "$prompt" 'zgpt-fanout.sh' 'report gate names the nested-worker scripts'
assert_contains "$prompt" 'not an acceptable substitute' 'report gate says reviewing a sub-worker is no substitute'

# ── 10. Help + validation ───────────────────────────────────────────────────
help_out="$("$run_worker" --help 2>&1)"
assert_contains "$help_out" '--allow-nested' '--help documents --allow-nested'
assert_contains "$help_out" 'ZFLOW_WORKER_DEPTH' '--help documents the depth guard'
assert_fail 'invalid ZFLOW_MAX_WORKER_DEPTH is rejected' env ZFLOW_MAX_WORKER_DEPTH=abc \
    "$run_worker" --name t --task x

# ── 11. Generated runner increments depth (offline, no live herdr) ──────────
# Run the REAL zgpt-worker-pane.sh against a herdr stub that answers placement
# queries with a fake repo tab and dumps the generated runner (the last arg of
# `pane run`) to a capture file. Every launch is a worker, so the runner must
# increment depth. Both the print-mode and interactive-mode runner blocks are
# exercised so neither can silently regress.
gen_bin="$tmp/bin-gen"
mkdir -p "$gen_bin"
cat >"$gen_bin/herdr" <<'GENSTUB'
#!/usr/bin/env bash
set -euo pipefail
if [[ "${1:-}" == --session ]]; then shift 2; fi
cmd="${1:-} ${2:-}"
case "$cmd" in
  "tab list")
    printf '{}\n'; exit 0
    ;;
  "tab get")
    printf '{"result":{"tab":{"label":"agents:x"}}}\n'; exit 0
    ;;
  "tab rename"|"pane rename"|"pane report-metadata"|"pane send-keys"|"pane close"|"agent wait"|"agent get")
    exit 0
    ;;
  "tab create")
    printf '{"result":{"tab":{"tab_id":"w1:t9"},"root_pane":{"pane_id":"w1:p0"}}}\n'; exit 0
    ;;
  "pane current"|"pane process-info")
    printf '\n'; exit 0
    ;;
  "pane get")
    printf '{"result":{"pane":{"tab_id":"w1:t9"}}}\n'; exit 0
    ;;
  "pane list")
    printf '{"result":{"panes":[]}}\n'; exit 0
    ;;
  "pane split")
    printf '{"result":{"pane":{"pane_id":"w1:p8"}}}\n'; exit 0
    ;;
  "pane run")
    # Last arg is the generated runner path; dump it for inspection.
    cat "${@: -1}" >>"${ZGPT_RUNNER_CAPTURE:?}"
    exit 0
    ;;
  *) exit 0 ;;
esac
GENSTUB
chmod +x "$gen_bin/herdr"

gen_dir="$tmp/gen"
mkdir -p "$gen_dir/cwd" "$gen_dir/state"
gen_runner() {
    local role="$1" mode="$2" cap="$3" out="$4"
    local tmpdir="$gen_dir/tmp-$role-$mode"
    mkdir -p "$tmpdir"
    : >"$cap"
    set +e
    TMPDIR="$tmpdir" PATH="$gen_bin:$PATH" HERDR_SESSION=test-session \
        ZFLOW_STATE_ROOT="$gen_dir/state" ZGPT_RUNNER_CAPTURE="$cap" \
        "$scripts/zgpt-worker-pane.sh" --name gen --role "$role" --mode "$mode" \
        --command true --cwd "$gen_dir/cwd" >"$out" 2>&1
    local rc=$?
    set -e
    return "$rc"
}

for mode in print interactive; do
    cap="$gen_dir/worker-$mode.runner"
    if gen_runner worker "$mode" "$cap" "$gen_dir/worker-$mode.out"; then
        if grep -qF 'export ZFLOW_WORKER_DEPTH=$(( ${ZFLOW_WORKER_DEPTH:-0} + 1 ))' "$cap" \
            && ! grep -q 'unset ZFLOW_WORKER_DEPTH' "$cap" \
            && ! grep -qE 'export ZFLOW_WORKER_DEPTH=0' "$cap"; then
            pass "worker/$mode runner: still increments depth"
        else
            fail "worker/$mode runner: expected a guarded depth increment (no unset / depth-0 export)"
        fi
    else
        fail "worker/$mode runner: generation failed; output below"
        sed 's/^/  /' "$gen_dir/worker-$mode.out"
    fi
done

printf '\n== Summary ==\n'
printf '%d passed, %d failed\n' "$passed" "$failed"
((failed == 0))
