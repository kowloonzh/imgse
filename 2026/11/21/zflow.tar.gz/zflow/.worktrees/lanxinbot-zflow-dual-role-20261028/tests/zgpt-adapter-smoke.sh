#!/usr/bin/env bash
set -euo pipefail

# Offline smoke suite for zgpt-cli-adapter.sh: CLI-family classification and
# per-family capability selection. Pure function calls only -- no herdr
# session, no pane, runs in well under a second.

scripts="$(cd "$(dirname "${BASH_SOURCE[0]}")/../scripts" && pwd)"
# shellcheck source=/dev/null
source "$scripts/zgpt-cli-adapter.sh"

passed=0
failed=0
pass() { printf 'PASS: %s\n' "$1"; passed=$((passed + 1)); }
fail() { printf 'FAIL: %s\n' "$1" >&2; failed=$((failed + 1)); }
assert_eq() { if [[ "$1" == "$2" ]]; then pass "$3"; else fail "$3 (got=$1 expected=$2)"; fi; }
assert_ok() { local label="$1"; shift; if "$@" >/dev/null 2>&1; then pass "$label"; else fail "$label (expected success)"; fi; }
assert_fail() { local label="$1"; shift; if ! "$@" >/dev/null 2>&1; then pass "$label"; else fail "$label (expected failure)"; fi; }

family() { zgpt_cli_family "$1" "${2:-}"; }

printf '\n== Family classification: bare names per family ==\n'
assert_eq "$(family claude)" claude 'claude family: bare "claude"'
assert_eq "$(family codex)" codex 'codex family: bare "codex"'
assert_eq "$(family pi)" pi 'pi family: bare "pi"'
assert_eq "$(family grok)" grok 'grok family: bare "grok"'
assert_eq "$(family bash)" generic 'generic family: bare "bash"'
assert_eq "$(family some-unrecognized-tool)" generic 'generic family: unrecognized name'

printf '\n== Family classification: deliberate special cases ==\n'
assert_eq "$(family startcccodex)" claude 'startcccodex is Claude family despite containing "codex"'
assert_eq "$(family startbridge)" claude 'startbridge is Claude family'
assert_eq "$(family startds)" claude 'startds is Claude family'
assert_eq "$(family startdsf)" claude 'startdsf is Claude family'
assert_eq "$(family startbridge-grok)" claude 'startbridge-grok is Claude family despite containing "grok"'
assert_eq "$(family startbridge-grok-mini)" claude 'startbridge-grok-mini is Claude family (wildcard still Claude)'
assert_eq "$(family grok)" grok 'native grok is Grok family'
assert_eq "$(family startgrok)" grok 'startgrok is Grok family'
assert_eq "$(family startgrok-build)" grok 'startgrok-build is Grok family (wildcard)'

printf '\n== Family classification: other startX conventions ==\n'
assert_eq "$(family startclaude)" claude 'startclaude is Claude family'
assert_eq "$(family startcodex)" codex 'startcodex is Codex family'
assert_eq "$(family startcodex-mini)" codex 'startcodex-mini is Codex family (wildcard)'
assert_eq "$(family startpi)" pi 'startpi is Pi family'
assert_eq "$(family startpi-fast)" pi 'startpi-fast is Pi family (wildcard)'
assert_eq "$(family startomni-spark)" claude 'startomni-spark is Claude family'
assert_eq "$(family startspark)" claude 'startspark is Claude family'
assert_eq "$(family gpt)" claude 'gpt is Claude family (wire-compatible wrapper)'
assert_eq "$(family glm)" claude 'glm is Claude family (wire-compatible wrapper)'

printf '\n== Absolute paths and wrapper basenames classify the same as bare names ==\n'
assert_eq "$(family /usr/local/bin/startclaude)" claude 'absolute path to startclaude is Claude family'
assert_eq "$(family /opt/tools/startcccodex)" claude 'absolute path to startcccodex keeps the special case'
assert_eq "$(family /usr/local/bin/codex)" codex 'absolute path to codex is Codex family'
assert_eq "$(family /usr/local/bin/startgrok-build)" grok 'absolute path to startgrok-build is Grok family'
assert_eq "$(family ./startbridge-grok)" claude 'relative path to startbridge-grok is Claude family'

printf '\n== --family / override wins over name-based classification ==\n'
assert_eq "$(family codex claude)" claude 'explicit override claude wins over codex-looking name'
assert_eq "$(family claude grok)" grok 'explicit override grok wins over claude-looking name'
assert_eq "$(family startcccodex codex)" codex 'explicit override codex wins over the startcccodex special case'
assert_eq "$(family claude bogus-family)" generic 'unrecognized override value falls back to generic'
assert_eq "$(ZGPT_CLI_FAMILY=grok family claude)" grok 'ZGPT_CLI_FAMILY env var overrides name-based classification'
assert_eq "$(ZGPT_CLI_FAMILY=grok zgpt_cli_family claude pi)" pi 'explicit override arg wins over ZGPT_CLI_FAMILY env var'

printf '\n== Readiness pattern/regex selection per family ==\n'
assert_eq "$(zgpt_cli_ready_pattern claude)" '❯' 'claude ready pattern is ❯'
assert_eq "$(zgpt_cli_ready_pattern grok)" '❯' 'grok ready pattern is ❯ (Claude-like prompt)'
assert_eq "$(zgpt_cli_ready_pattern codex)" '›' 'codex ready pattern is ›'
assert_eq "$(zgpt_cli_ready_regex pi)" '^─{8,}[[:space:]]*$' 'pi has its own bordered-editor ready regex'
assert_eq "$(zgpt_cli_ready_regex claude)" '' 'claude has no ready regex (uses ready pattern instead)'
assert_eq "$(zgpt_cli_ready_regex codex)" '' 'codex has no ready regex (uses ready pattern instead)'
border_line="$(printf '\xe2\x94\x80%.0s' $(seq 1 10))"
if printf '%s\n' "$border_line" | grep -Eq -- "$(zgpt_cli_ready_regex pi)"; then
    pass 'pi ready regex matches a real bordered editor line'
else
    fail 'pi ready regex matches a real bordered editor line'
fi
if printf 'not a border\n' | grep -Eq -- "$(zgpt_cli_ready_regex pi)"; then
    fail 'pi ready regex does not match plain text'
else
    pass 'pi ready regex does not match plain text'
fi

printf '\n== Codex composer readiness ==\n'
codex_ready() { zgpt_cli_visible_output_ready codex '' "$1" '›' ''; }
# Codex 0.163 idle screen: placeholder composer, then status bar and footer.
codex_idle_new=$'  >_ OpenAI Codex\n\n› Ask Codex to do anything\n\n  DeepSeek V4 Flash · fab max · ~/w · Context 0% used\n  ? for shortcuts                       ⚠ 2 warnings · f2 to view'
assert_ok 'codex 0.16x placeholder composer with footer is ready' codex_ready "$codex_idle_new"
assert_ok 'codex bare composer as last line is ready' codex_ready $'  >_ OpenAI Codex\n\n›'
assert_fail 'codex trust menu is not ready' codex_ready $'Do you trust this folder?\n\n› 1. Yes, continue\n  2. No, quit\n\n  Press enter to continue'
assert_fail 'codex running turn is not ready' codex_ready $'• Working (3s • esc to interrupt)\n\n› Ask Codex to do anything\n\n  ? for shortcuts'
assert_fail 'codex still starting MCP servers is not ready' codex_ready $'• Starting MCP servers (1/3)\n\n› Ask Codex to do anything\n\n  ? for shortcuts'
assert_fail 'codex screen without composer is not ready' codex_ready $'  >_ OpenAI Codex\n  loading...'
assert_fail 'codex composer buried above a long transcript is not ready' codex_ready $'› old prompt\na\nb\nc\nd\ne'

printf '\n== Exit prompt per family ==\n'
assert_eq "$(zgpt_cli_exit_prompt claude)" '/exit' 'claude exit prompt is /exit'
assert_eq "$(zgpt_cli_exit_prompt codex)" '/exit' 'codex exit prompt is /exit'
assert_eq "$(zgpt_cli_exit_prompt pi)" '/exit' 'pi exit prompt is /exit'
assert_eq "$(zgpt_cli_exit_prompt grok)" '/exit' 'grok exit prompt is /exit'
assert_eq "$(zgpt_cli_exit_prompt bash)" 'exit' 'generic exit prompt is exit'

printf '\n== Startup capability differences per family ==\n'
export ANTHROPIC_API_KEY=sk-test-key
assert_ok 'claude gets --bare when ANTHROPIC_API_KEY is set' zgpt_cli_startup_bare claude
assert_fail 'codex never gets --bare, even with ANTHROPIC_API_KEY set' zgpt_cli_startup_bare codex
unset ANTHROPIC_API_KEY
assert_fail 'claude does not get --bare without ANTHROPIC_API_KEY' zgpt_cli_startup_bare claude
assert_fail 'codex never gets --bare' zgpt_cli_startup_bare codex
assert_fail 'pi never gets --bare' zgpt_cli_startup_bare pi
assert_fail 'grok never gets --bare' zgpt_cli_startup_bare grok

assert_eq "$(zgpt_cli_approve_flag pi)" '--approve' 'pi gets --approve'
assert_eq "$(zgpt_cli_approve_flag grok)" '--always-approve' 'grok gets --always-approve'
assert_eq "$(zgpt_cli_approve_flag claude)" '' 'claude has no approve flag'
assert_eq "$(zgpt_cli_approve_flag codex)" '' 'codex has no approve flag'

assert_ok 'codex disables apps by default' zgpt_cli_startup_disable_apps codex
assert_fail 'claude does not disable apps' zgpt_cli_startup_disable_apps claude
assert_fail 'pi does not disable apps' zgpt_cli_startup_disable_apps pi
assert_fail 'grok does not disable apps' zgpt_cli_startup_disable_apps grok

assert_ok 'claude auto-injects effort' zgpt_cli_startup_effort claude
assert_ok 'grok auto-injects effort' zgpt_cli_startup_effort grok
assert_fail 'codex does not auto-inject effort' zgpt_cli_startup_effort codex
assert_fail 'pi does not auto-inject effort' zgpt_cli_startup_effort pi
assert_fail 'generic does not auto-inject effort' zgpt_cli_startup_effort bash

printf '\n== Summary ==\n'
printf '%d passed, %d failed\n' "$passed" "$failed"
((failed == 0))
