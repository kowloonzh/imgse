#!/usr/bin/env bash
# zgpt-primary-clone-guard-smoke.sh — offline smoke test for the PreToolUse guard.
set -uo pipefail

script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")/../scripts" && pwd)"
guard="$script_dir/zgpt-primary-clone-guard.sh"

tmp="$(mktemp -d "${TMPDIR:-/tmp}/zgpt-clone-guard.XXXXXX")"
trap 'rm -rf "$tmp"' EXIT

# ---------------------------------------------------------------------------
# Build a temp repo with one commit, plus a linked worktree.
# $tmp/repo        → primary clone
# $tmp/repo-wt     → linked worktree
# $tmp/nogit       → not a repo at all
# ---------------------------------------------------------------------------
repo="$tmp/repo"
wt="$tmp/repo-wt"
nogit="$tmp/nogit"
mkdir -p "$repo" "$nogit"

git -C "$repo" init -q
git -C "$repo" config user.email t@t
git -C "$repo" config user.name t
git -C "$repo" commit -q --allow-empty -m init
# Use the default branch name as base for the worktree branch.
base="$(git -C "$repo" rev-parse --abbrev-ref HEAD)"
git -C "$repo" worktree add -q -b wt-branch "$wt" "$base"

# Helper: feed a JSON payload to the guard; capture rc + stdout + stderr.
run_guard() {
  ZFLOW_GUARD_ALLOW="$ZFLOW_GUARD_ALLOW" ZFLOW_GUARD="$ZFLOW_GUARD" \
    bash "$guard" <<<"$1" >/tmp/zgpt-cg.out 2>/tmp/zgpt-cg.err
  rc=$?
  out="$(cat /tmp/zgpt-cg.out)"
  err="$(cat /tmp/zgpt-cg.err)"
}

pass=0
fail=0
ok() { printf 'PASS: %s\n' "$1"; pass=$((pass+1)); }
bad() { printf 'FAIL: %s\n' "$1"; printf '  rc=%s\n  stderr=%s\n  stdout=%s\n' "$rc" "$err" "$out"; fail=$((fail+1)); }

# Default allowlist must not include our temp repo, so we override it to the
# bare minimum (/tmp would match $tmp, so we use only $HOME/.claude-ish paths).
export ZFLOW_GUARD_ALLOW="$HOME/.claude-not-a-real-dir"
export ZFLOW_GUARD=""

# Case 1: Edit in the primary checkout → exit 2, stderr names path, JSON deny.
payload1='{"tool_name":"Edit","tool_input":{"file_path":"'"$repo"'/app/foo.go","old_string":"a","new_string":"b"}}'
run_guard "$payload1"
c1=1
[[ "$rc" == 2 ]] || { bad "case1 rc (got $rc, want 2)"; c1=0; }
if [[ "$c1" == 1 ]]; then printf '%s\n' "$err" | grep -q "$repo" || { bad "case1 stderr must name path"; c1=0; }; fi
if [[ "$c1" == 1 ]]; then printf '%s\n' "$out" | jq -e '.hookSpecificOutput.permissionDecision == "deny"' >/dev/null 2>&1 || { bad "case1 stdout JSON must have deny"; c1=0; }; fi
[[ "$c1" == 1 ]] && ok "case1: edit in primary clone denied"

# Case 2: Edit in the linked worktree → exit 0, no deny.
payload2='{"tool_name":"Edit","tool_input":{"file_path":"'"$wt"'/app/foo.go","old_string":"a","new_string":"b"}}'
run_guard "$payload2"
[[ "$rc" == 0 ]] && ! printf '%s\n' "$out" | grep -q '"deny"' || { bad "case2"; rc=-99; }
[[ "${rc:-0}" == 0 ]] && ok "case2: edit in linked worktree allowed"

# Case 3: Edit under /tmp and $HOME/.claude → exit 0.
export ZFLOW_GUARD_ALLOW="$HOME/.claude:/tmp:$HOME/.config"
payload3a='{"tool_name":"Edit","tool_input":{"file_path":"/tmp/whatever.go","old_string":"a","new_string":"b"}}'
run_guard "$payload3a"
[[ "$rc" == 0 ]] || { bad "case3 /tmp"; rc=-99; }
mkdir -p "$HOME/.claude" 2>/dev/null || true
payload3b='{"tool_name":"Edit","tool_input":{"file_path":"'"$HOME/.claude/x.go"'","old_string":"a","new_string":"b"}}'
run_guard "$payload3b"
[[ "$rc" == 0 ]] || { bad "case3 \$HOME/.claude"; rc=-99; }
[[ "${rc:-0}" == 0 ]] && ok "case3: allowlisted paths allowed"
export ZFLOW_GUARD_ALLOW="$HOME/.claude-not-a-real-dir"  # restore strict

# Case 4: path in no git repo at all → exit 0.
payload4='{"tool_name":"Edit","tool_input":{"file_path":"'"$nogit"'/foo.go","old_string":"a","new_string":"b"}}'
run_guard "$payload4"
[[ "$rc" == 0 ]] || { bad "case4"; rc=-99; }
[[ "${rc:-0}" == 0 ]] && ok "case4: non-repo path allowed"

# Case 5: tool_name Bash with a primary-clone path → exit 0 (not our business).
payload5='{"tool_name":"Bash","tool_input":{"command":"echo","file_path":"'"$repo"'/x"}}'
run_guard "$payload5"
[[ "$rc" == 0 ]] || { bad "case5"; rc=-99; }
[[ "${rc:-0}" == 0 ]] && ok "case5: Bash tool ignored"

# Case 6: malformed payload (not json; and valid json with no file_path) → exit 0, no hang.
run_guard 'not json at all'
[[ "$rc" == 0 ]] || { bad "case6a not-json"; rc=-99; }
run_guard '{"tool_name":"Edit","tool_input":{"old_string":"a"}}'
[[ "$rc" == 0 ]] || { bad "case6b no file_path"; rc=-99; }
[[ "${rc:-0}" == 0 ]] && ok "case6: malformed payloads allowed"

# Case 7: ZFLOW_GUARD=off with case-1 payload → exit 0.
export ZFLOW_GUARD="off"
run_guard "$payload1"
[[ "$rc" == 0 ]] || { bad "case7"; rc=-99; }
[[ "${rc:-0}" == 0 ]] && ok "case7: ZFLOW_GUARD=off disables guard"
export ZFLOW_GUARD=""

# Case 8: ZFLOW_GUARD_ALLOW set to the temp primary repo → exit 0 for case-1 payload.
export ZFLOW_GUARD_ALLOW="$repo"
run_guard "$payload1"
[[ "$rc" == 0 ]] || { bad "case8"; rc=-99; }
[[ "${rc:-0}" == 0 ]] && ok "case8: allowlisting the repo itself passes"
export ZFLOW_GUARD_ALLOW="$HOME/.claude-not-a-real-dir"

# Case 9: a path whose file does not exist yet but whose parent dir is in the
# primary clone (Write-a-new-file) → exit 2.
newfile="$repo/deep/nested/never-created.go"
payload9='{"tool_name":"Write","tool_input":{"file_path":"'"$newfile"'","content":"x"}}'
run_guard "$payload9"
c9=1
[[ "$rc" == 2 ]] || { bad "case9 rc (got $rc, want 2)"; c9=0; }
if [[ "$c9" == 1 ]]; then printf '%s\n' "$out" | jq -e '.hookSpecificOutput.permissionDecision == "deny"' >/dev/null 2>&1 || { bad "case9 stdout JSON must have deny"; c9=0; }; fi
[[ "$c9" == 1 ]] && ok "case9: new file under primary clone denied"

# Case 10: a directory under an allowlisted root is symlinked into the temp
# primary repo; an Edit addressed *through* the symlink must be DENIED (rc 2).
# This is the regression for the raw-path allowlist bypass: before the fix the
# symlinked path matched the allow prefix and was silently allowed, never
# reaching the git verdict that would have flagged the primary clone.
allowroot="$tmp/allowroot"
mkdir -p "$allowroot"
# Link $allowroot/symlinked-skills -> $repo so an address under the symlink
# resolves physically into the primary clone.
ln -s "$repo" "$allowroot/symlinked-skills"
export ZFLOW_GUARD_ALLOW="$allowroot"
symlinked_file="$allowroot/symlinked-skills/app/foo.go"
payload10='{"tool_name":"Edit","tool_input":{"file_path":"'"$symlinked_file"'","old_string":"a","new_string":"b"}}'
run_guard "$payload10"
c10=1
[[ "$rc" == 2 ]] || { bad "case10 rc (got $rc, want 2)"; c10=0; }
if [[ "$c10" == 1 ]]; then printf '%s\n' "$out" | jq -e '.hookSpecificOutput.permissionDecision == "deny"' >/dev/null 2>&1 || { bad "case10 stdout JSON must have deny"; c10=0; }; fi
# The deny reason must name what the agent actually typed (the symlink path).
if [[ "$c10" == 1 ]]; then printf '%s\n' "$err" | grep -q "$symlinked_file" || { bad "case10 stderr must name the raw symlink path"; c10=0; }; fi
[[ "$c10" == 1 ]] && ok "case10: symlink-into-primary-clone under allowlisted root denied"
export ZFLOW_GUARD_ALLOW="$HOME/.claude-not-a-real-dir"  # restore strict

# Case 11: a real, non-symlinked file directly under the allowlisted root must
# still be ALLOWED (rc 0) — the fix must not over-block genuinely-allowlisted
# paths.
real_allow_file="$allowroot/real.go"
mkdir -p "$allowroot"
export ZFLOW_GUARD_ALLOW="$allowroot"
payload11='{"tool_name":"Edit","tool_input":{"file_path":"'"$real_allow_file"'","old_string":"a","new_string":"b"}}'
run_guard "$payload11"
[[ "$rc" == 0 ]] && ! printf '%s\n' "$out" | grep -q '"deny"' || { bad "case11"; rc=-99; }
[[ "${rc:-0}" == 0 ]] && ok "case11: real non-symlinked file under allowlisted root allowed"
export ZFLOW_GUARD_ALLOW="$HOME/.claude-not-a-real-dir"  # restore strict

total=$((pass+fail))
printf '\nSummary: %d/%d\n' "$pass" "$total"
(( fail == 0 ))
