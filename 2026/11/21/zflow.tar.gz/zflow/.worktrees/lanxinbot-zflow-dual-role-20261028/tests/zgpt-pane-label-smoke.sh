#!/usr/bin/env bash
set -euo pipefail

# Offline smoke suite for zgpt_pane_label in zgpt-common.sh. Pure function calls
# against real git fixtures only -- no herdr session, no pane, no network.

scripts="$(cd "$(dirname "${BASH_SOURCE[0]}")/../scripts" && pwd)"
# shellcheck source=/dev/null
source "$scripts/zgpt-common.sh"

passed=0
failed=0
pass() { printf 'PASS: %s\n' "$1"; passed=$((passed + 1)); }
fail() { printf 'FAIL: %s\n' "$1" >&2; failed=$((failed + 1)); }
assert_eq() { if [[ "$1" == "$2" ]]; then pass "$3"; else fail "$3 (got=$1 expected=$2)"; fi; }
assert_contains() { if grep -qF -- "$2" <<<"$1"; then pass "$3"; else fail "$3 (output did not contain: $2)"; fi; }
assert_not_contains() { if grep -qF -- "$2" <<<"$1"; then fail "$3 (output unexpectedly contained: $2)"; else pass "$3"; fi; }

tmp="$(mktemp -d "${TMPDIR:-/tmp}/zgpt-pane-label-smoke.XXXXXX")"
trap 'rm -rf "$tmp"' EXIT

printf '\n== zgpt_pane_label: --role is defensive against a bad direct caller ==\n'
assert_eq "$(zgpt_pane_label bogus-role somename /nonexistent-dir-xyz)" 'worker:somename' 'unrecognized role falls back to worker'

printf '\n== Fixtures: a repo, a linked worktree, and a detached-HEAD checkout ==\n'
repo="$tmp/repo"
mkdir -p "$repo"
git init -q "$repo"
git -C "$repo" config user.name smoke
git -C "$repo" config user.email smoke@example.invalid
printf 'base\n' >"$repo/file.txt"
git -C "$repo" add file.txt
git -C "$repo" commit -qm init
git -C "$repo" branch -M main
git -C "$repo" checkout -qb feature/label-test
wt="$tmp/worktrees/wt1"
mkdir -p "$(dirname "$wt")"
git -C "$repo" worktree add -q "$wt" main >/dev/null
sha="$(git -C "$repo" rev-parse HEAD)"
detached="$tmp/detached"
git clone -q "$repo" "$detached" >/dev/null
git -C "$detached" checkout -q "$sha"
pass 'fixtures created: repo, linked worktree, detached-HEAD clone'

printf '\n== Label format: role, name, and repo@branch ==\n'
out="$(zgpt_pane_label worker auth-fix "$repo")"
assert_eq "$out" 'worker:auth-fix · repo@feature/label-test' 'worker role, on the feature branch, in the main repo checkout'

printf '\n== Repo resolution through a git worktree (worktree-aware via git common dir) ==\n'
out="$(zgpt_pane_label worker wt-worker "$wt")"
assert_eq "$out" 'worker:wt-worker · repo@main' 'linked worktree resolves repo name from the main checkout, branch from the worktree HEAD'

printf '\n== Detached HEAD falls back to a short sha ==\n'
out="$(zgpt_pane_label worker det "$detached")"
short_sha="$(git -C "$detached" rev-parse --short HEAD)"
assert_eq "$out" "worker:det · detached@$short_sha" "detached HEAD label uses short sha ($short_sha), not the literal word HEAD"
assert_not_contains "$out" '@HEAD' 'detached HEAD label never contains the literal @HEAD'

printf '\n== cwd that is not a git repo omits the whole @<branch> segment ==\n'
plain="$tmp/plain-dir"
mkdir -p "$plain"
out="$(zgpt_pane_label worker plainworker "$plain")"
assert_eq "$out" 'worker:plainworker' 'non-repo cwd produces role:name only, no separator or repo@branch'
assert_not_contains "$out" '·' 'non-repo cwd label has no middle-dot separator'

printf '\n== A cwd that does not exist at all also omits @<branch> ==\n'
out="$(zgpt_pane_label worker ghost "$tmp/does-not-exist")"
assert_eq "$out" 'worker:ghost' 'nonexistent cwd produces role:name only'

printf '\n== Sanitization: control chars, newlines, tabs, and repeated spaces collapse ==\n'
dirty_name="$(printf 'foo\n\tbar\x01\x02  baz   qux')"
out="$(zgpt_pane_label worker "$dirty_name" "$plain")"
assert_eq "$out" 'worker:foo bar baz qux' 'newlines/tabs become spaces, control bytes are stripped, runs of spaces collapse to one'
assert_eq "$(printf '%s' "$out" | wc -l | tr -d ' ')" 0 'sanitized label is a single line (no embedded newline)'
assert_not_contains "$out" $'\t' 'sanitized label contains no literal tab'

printf '\n== Length truncation: NAME is truncated first so repo@branch survives ==\n'
long_name="$(printf 'x%.0s' $(seq 1 200))"
out="$(zgpt_pane_label worker "$long_name" "$repo")"
out_len=${#out}
if (( out_len <= 70 )); then
    pass "long name truncates the overall label to roughly the ~64-char cap (got ${out_len} chars)"
else
    fail "long name truncates the overall label to roughly the ~64-char cap (got ${out_len} chars, expected <= 70)"
fi
assert_contains "$out" 'repo@feature/label-test' 'repo@branch segment survives truncation intact'
assert_contains "$out" 'worker:x' 'truncated label still starts with the role prefix and part of the name'

printf '\n== Summary ==\n'
printf '%d passed, %d failed\n' "$passed" "$failed"
((failed == 0))
