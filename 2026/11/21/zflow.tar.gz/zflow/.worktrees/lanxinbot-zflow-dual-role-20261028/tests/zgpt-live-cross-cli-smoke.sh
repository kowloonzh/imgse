#!/usr/bin/env bash
set -euo pipefail

script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")/../scripts" && pwd)"
source "$script_dir/zgpt-common.sh"
source "$script_dir/zgpt-cli-adapter.sh"

# Disabled by default: this creates real herdr panes and invokes real CLIs.
# Keep the dependency checks above the skip so the default smoke path catches
# missing shared helpers instead of masking them.
if [[ "${ZFLOW_RUN_LIVE_SMOKE:-false}" != true ]]; then
    printf 'live cross-cli smoke skipped (set ZFLOW_RUN_LIVE_SMOKE=true to enable)\n'
    exit 0
fi

run_worker="$script_dir/zgpt-run-worker.sh"
run_dir="$(zgpt_state_dir "$PWD")/runs/live-cross-cli-$(date +%Y%m%d-%H%M%S)"
mkdir -p "$run_dir"

commands="${ZFLOW_LIVE_COMMANDS:-claude,startcodex-luna,startpi}"
old_ifs="$IFS"; IFS=','
for command in $commands; do
    IFS="$old_ifs"
    if ! command -v "$command" >/dev/null 2>&1; then
        printf 'live skip: %s not installed\n' "$command"
        IFS=','
        continue
    fi
    safe="$(printf '%s' "$command" | tr -c 'A-Za-z0-9_.-' '-')"
    resolved="$(command -v "$command")"
    family="$(zgpt_cli_family "$command")"
    printf 'live attempt: command=%s path=%s family=%s\n' "$command" "$resolved" "$family"
    set +e
    runner_output="$("$run_worker" --name "live-$safe" --command "$command" --cwd "$PWD" \
        --artifact "$run_dir/$safe.md" --close --timeout "${ZFLOW_LIVE_TIMEOUT:-120}" \
        --task "Write a one-line live lifecycle smoke result to the requested artifact, then finish." \
        --no-effort-note 2>&1)"
    rc=$?
    set -e
    printf '%s\n' "$runner_output"
    if [[ "$rc" != 0 ]]; then
        printf 'live failure: command=%s rc=%s; inspect authentication, trust, and pane output above\n' "$command" "$rc" >&2
        exit "$rc"
    fi
    if ! printf '%s\n' "$runner_output" | grep -q '^status=ok$'; then
        printf 'live failure: command=%s did not reach exact status=ok\n' "$command" >&2
        exit 1
    fi
    if [[ ! -s "$run_dir/$safe.md" ]]; then
        printf 'live failure: command=%s artifact missing or empty: %s\n' "$command" "$run_dir/$safe.md" >&2
        exit 1
    fi
    IFS=','
done
IFS="$old_ifs"
printf 'live cross-cli smoke ok\n'
