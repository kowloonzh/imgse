#!/usr/bin/env bash
set -euo pipefail

# Offline smoke suite for worker pane placement geometry in
# zgpt-worker-pane.sh / zgpt-common.sh. Everything is stubbed: no live herdr
# server, no pane, no network. The pure geometry / ratio functions run
# directly; the herdr-backed helpers run against a fake `herdr` binary on PATH
# that serves canned pane list / layout / tab fixtures.
#
# Rules under test (see SKILL.md):
#   1. Anchor = roomiest pane by live geometry; human: panes are never anchors.
#   2. Direction follows the long edge (width > 2*height => right, else down).
#   3. A tab with >= 6 live panes -- or no splittable pane at all -- overflows
#      to the next agents:<repo>-N tab, or a freshly created one.
#   4. The split --ratio gives the new pane a fair share (area/(n+1)) capped at
#      half the anchor, so max/min stays <= 2 (binary trees can't tile 3 or 5
#      equal panes).
#   5. Liveness is judged by `pane layout`, not `pane list`: a ghost listed by
#      pane list but absent from layout is never an anchor and never counts.

scripts="$(cd "$(dirname "${BASH_SOURCE[0]}")/../scripts" && pwd)"
# shellcheck source=/dev/null
source "$scripts/zgpt-common.sh"

passed=0
failed=0
pass() { printf 'PASS: %s\n' "$1"; passed=$((passed + 1)); }
fail() { printf 'FAIL: %s\n' "$1" >&2; failed=$((failed + 1)); }
assert_eq() { if [[ "$1" == "$2" ]]; then pass "$3"; else fail "$3 (got=$1 expected=$2)"; fi; }
assert_contains() { if grep -qF -- "$2" <<<"$1"; then pass "$3"; else fail "$3 (output did not contain: $2)"; fi; }
assert_not_contains() { if grep -qF -- "$2" <<<"$1"; then fail "$3 (output unexpectedly contained: $2)"; else pass "$3"; fi; }

tmp="$(mktemp -d "${TMPDIR:-/tmp}/zgpt-pane-placement-smoke.XXXXXX")"
trap 'rm -rf "$tmp"' EXIT

# Hermetic: never inherit a session/anchor env that would change herdr calls.
unset ZGPT_HERDR_SESSION ZGPT_TAB_ID ZJ_TAB_ID ZGPT_MANAGER_PANE_ID ZJ_PANE_ID 2>/dev/null || true

# --- fake herdr ------------------------------------------------------------------
fakebin="$tmp/bin"
mkdir -p "$fakebin"
cat >"$fakebin/herdr" <<'FAKE'
#!/usr/bin/env bash
d="${FAKE_DIR:?FAKE_DIR not set}"
case "${1:-}" in
  tab)
    case "${2:-}" in
      list)   cat "$d/tabs.json" 2>/dev/null || printf '{"result":{"tabs":[]}}\n' ;;
      create) cat "$d/create.json" 2>/dev/null || { printf 'error: no create fixture\n' >&2; exit 1; } ;;
      get)    printf '{"result":{"tab":{"label":"agents:proj"}}}\n' ;;
    esac
    ;;
  pane)
    case "${2:-}" in
      # both `pane list --workspace W` and `pane layout --pane P` carry their
      # value as the 4th argument (after the flag word)
      list)   cat "$d/panes_${4}.json" 2>/dev/null || printf '{"result":{"panes":[]}}\n' ;;
      layout) cat "$d/layout_${4}.json" 2>/dev/null || printf '{"error":"pane_not_found","result":{}}\n' ;;
    esac
    ;;
esac
FAKE
chmod +x "$fakebin/herdr"
# The helpers reach herdr through `hd` -> `herdr` on PATH; the fake must win.
export PATH="$fakebin:$PATH"

# --- fixture generators ----------------------------------------------------------
# mk_layout <tab_id> <area_w> <area_h> <"pane_id w h" ...>
#   emits the JSON body `herdr pane layout --pane` returns for a tab.
mk_layout() {
    local tab="$1" aw="$2" ah="$3"; shift 3
    local panes_json="" sep="" p w h
    while (( $# > 0 )); do
        p="$1"; w="$2"; h="$3"; shift 3
        panes_json+="${sep}{\"pane_id\":\"$p\",\"focused\":false,\"rect\":{\"x\":0,\"y\":0,\"width\":$w,\"height\":$h}}"
        sep=","
    done
    printf '{"result":{"layout":{"area":{"width":%s,"height":%s,"x":0,"y":0},"focused_pane_id":"","panes":[%s],"splits":[],"tab_id":"%s","workspace_id":"%s","zoomed":false}}}' \
        "$aw" "$ah" "$panes_json" "$tab" "${tab%%:*}"
}

# mk_panes <"pane_id tab_id label_json" ...>
#   emits `herdr pane list --workspace <ws>` JSON. label_json is already JSON
#   (a quoted string or null).
mk_panes() {
    local arr="" sep="" p t lbl
    while (( $# > 0 )); do
        p="$1"; t="$2"; lbl="$3"; shift 3
        arr+="${sep}{\"pane_id\":\"$p\",\"tab_id\":\"$t\",\"label\":$lbl,\"terminal_title_stripped\":\"\"}"
        sep=","
    done
    printf '{"result":{"panes":[%s]}}' "$arr"
}

# scenario <name> — print a fresh fixture dir (the caller must export FAKE_DIR,
# because a `$(...)` subshell cannot propagate the export back).
scenario() {
    local dir="$tmp/fx/$1"
    rm -rf "$dir"; mkdir -p "$dir"
    printf '%s\n' "$dir"
}

# --- git repo fixture (for repo tab naming) --------------------------------------
repo="$tmp/proj"
mkdir -p "$repo"
git init -q "$repo"
git -C "$repo" config user.name smoke
git -C "$repo" config user.email smoke@example.invalid
printf 'base\n' >"$repo/file.txt"
git -C "$repo" add file.txt
git -C "$repo" commit -qm init
git -C "$repo" branch -M main
pass 'fixtures created: fake herdr + git repo (agents:proj)'

# ── 2. Direction: split along the long edge ────────────────────────────────────
printf '\n== zgpt_split_direction_for_rect: split along the long edge ==\n'
assert_eq "$(zgpt_split_direction_for_rect 200 40)" right 'wide rect (200x40, width > 2*height) splits right'
assert_eq "$(zgpt_split_direction_for_rect 100 60)" down 'tall rect (100x60) splits down'
assert_eq "$(zgpt_split_direction_for_rect 200 100)" down 'square-ish boundary (width == 2*height) splits down'
assert_eq "$(zgpt_split_direction_for_rect 300 100)" right 'wide rect (300x100) splits right'
assert_eq "$(zgpt_split_direction_for_rect 10 90)" down 'narrow tall rect splits down'

# ── 3. Split ratio: fair share capped at half the anchor ────────────────────────
printf '\n== zgpt_split_ratio_for_equal_share: fair share with a 2x cap ==\n'
# Trace the real evolution of a 100x100 tab (T=10000): each split takes the
# roomiest pane, and the function must keep every pane within 2x of the
# smallest. ratio_trace_case <n> <anchor_w> <anchor_h> <tab_w> <tab_h> \
#                              <"other pane areas..."> <label>
ratio_trace_case() {
    local n="$1" aw="$2" ah="$3" tw="$4" th="$5" others="$6" label="$7"
    local ratio verdict
    ratio="$(zgpt_split_ratio_for_equal_share "$aw" "$ah" "$tw" "$th" "$n" down)"
    verdict="$(awk -v r="$ratio" -v aw="$aw" -v ah="$ah" -v tw="$tw" -v th="$th" -v n="$n" -v others="$others" '
        BEGIN {
            aa = aw*ah; ta = tw*th;
            newp = (1-r)*aa; rem = aa - newp;
            target = int(ta/(n+1)); half = int(aa/2);
            exp_new = (target > half) ? half : target;
            diff = newp - exp_new; if (diff < 0) diff = -diff;
            nres = (diff <= 2) ? "new=ok" : "new=BAD(" diff ")";
            # post-split layout: the two pieces of the anchor + the n-1 other
            # panes that were already in the tab
            minp = newp; maxp = newp;
            if (rem < minp) minp = rem; if (rem > maxp) maxp = rem;
            split(others, o, " ");
            for (i = 1; i <= length(o); i++) { a = o[i]+0; if (a < minp) minp = a; if (a > maxp) maxp = a; }
            mm = maxp/minp;
            mres = (mm <= 2.0001) ? "mm=ok(" sprintf("%.2f", mm) ")" : "mm=BAD(" sprintf("%.2f", mm) ")";
            printf "%s %s", nres, mres;
        }')"
    assert_contains "$verdict" "new=ok" "$label: new pane area matches the target"
    assert_contains "$verdict" "mm=ok" "$label: simulated max/min ratio <= 2"
}
ratio_trace_case 1 100 100 100 100 ""      'n=1 -> exact halves (equal)'
ratio_trace_case 2 50 100  100 100 "5000"  'n=2 -> half/quarter/quarter (2x bound)'
ratio_trace_case 3 50 100  100 100 "2500 2500" 'n=3 -> exact quarters (equal)'
ratio_trace_case 4 50 50   100 100 "2500 2500 2500" 'n=4 -> quarters + eighths (2x bound)'
ratio_trace_case 5 50 50   100 100 "2500 2500 1250 1250" 'n=5 -> three quarters + three eighths (2x bound)'

# Fair-share branch: the roomiest pane is well above the mean, so the new pane
# gets the exact fair share (10000/4 = 2500) instead of the half cap.
r="$(zgpt_split_ratio_for_equal_share 100 100 100 100 3 down)"
assert_eq "$r" "0.7500" 'anchor = whole tab, n=3: fair share 2500/10000 -> ratio 0.75'
new_area="$(awk -v r="$r" 'BEGIN { printf "%.0f", (1-r)*10000 }')"
assert_eq "$new_area" "2500" 'fair branch gives the new pane exactly area/4'

# Degenerate input never yields a ratio herdr would reject.
assert_eq "$(zgpt_split_ratio_for_equal_share 0 10 100 100 2 down)" "0.5" 'zero-size anchor falls back to 0.5'

# ── 4. Anchor selection: roomiest splittable pane, human never ─────────────────
printf '\n== zgpt_herdr_anchor_for_tab: geometric anchor, human excluded ==\n'
d="$(scenario anchor)"; export FAKE_DIR="$d"
# w1:t1: the human pane is the largest AND the first — a naive first-pane or
# raw-largest pick would land on it. It must be skipped.
mk_layout w1:t1 247 69 \
    w1:p1 247 30 \
    w1:p2 247 25 \
    w1:p3 120 50 \
    w1:p4 247 20 >"$d/layout_w1:p1.json"
mk_panes \
    'w1:p1' 'w1:t1' '"human:zflow · Debug pane event handling"' \
    'w1:p2' 'w1:t1' '"human:zflow-2 · Another human pane"' \
    'w1:p3' 'w1:t1' '"worker:alpha · proj@main"' \
    'w1:p4' 'w1:t1' '"worker:beta · proj@main"' >"$d/panes_w1.json"
out="$(zgpt_herdr_anchor_for_tab w1:t1 || true)"
assert_contains "$out" 'anchor_pane_id=w1:p3' 'roomiest non-human pane is chosen (both human panes excluded)'
assert_contains "$out" 'pane_count=4' 'pane count reflects all 4 live panes'
assert_not_contains "$out" 'w1:p1' 'human pane is never the anchor'
assert_not_contains "$out" 'w1:p2' 'second human pane is never the anchor'
assert_eq "$(printf '%s\n' "$out" | sed -n 's/^anchor_width=//p' | sed -n '1p')" 120 'anchor rect width is reported for direction/ratio math'

# Tie-break: equal area picks the wider pane, then the lexicographically
# smaller pane id.
d="$(scenario tie)"; export FAKE_DIR="$d"
mk_layout w1:t1 247 69 \
    w1:pA 100 20 \
    w1:pB 100 20 \
    w1:pC 50 40 >"$d/layout_w1:pA.json"
mk_panes \
    'w1:pA' 'w1:t1' '"worker:aa"' \
    'w1:pB' 'w1:t1' '"worker:bb"' \
    'w1:pC' 'w1:t1' '"worker:cc"' >"$d/panes_w1.json"
out="$(zgpt_herdr_anchor_for_tab w1:t1 || true)"
assert_contains "$out" 'anchor_pane_id=w1:pA' 'tie on area: wider pane wins (2000 area each, pA/pB wider than pC)'

# ── 5. Ghost panes: liveness judged by layout, not pane list ───────────────────
printf '\n== Ghost panes: pane list lags layout, ghosts never anchor/count ==\n'
d="$(scenario ghost)"; export FAKE_DIR="$d"
# pane list carries a "ghost" w1:p2 (first listed, would win a naive pick) that
# pane layout does not know about. Live panes are w1:p1 and w1:p3 only.
mk_layout w1:t1 247 69 \
    w1:p1 200 30 \
    w1:p3 100 20 >"$d/layout_w1:p1.json"
mk_panes \
    'w1:p2' 'w1:t1' '"worker:ghost · proj@main"' \
    'w1:p1' 'w1:t1' '"worker:one · proj@main"' \
    'w1:p3' 'w1:t1' '"worker:three · proj@main"' >"$d/panes_w1.json"
out="$(zgpt_herdr_anchor_for_tab w1:t1 || true)"
assert_contains "$out" 'anchor_pane_id=w1:p1' 'ghost pane (list-only) is never chosen as anchor'
assert_contains "$out" 'pane_count=2' 'ghost pane does not count toward the 6-pane cap'
assert_not_contains "$out" 'w1:p2' 'ghost pane id never appears in anchor output'

# ── 6. 6-pane cap + all-super/human overflow ───────────────────────────────────
printf '\n== 6-pane cap: full tab overflows to the next repo tab ==\n'
d="$(scenario full6)"; export FAKE_DIR="$d"
mk_layout w1:t1 247 69 \
    w1:p1 124 35 w1:p2 123 34 w1:p3 124 35 \
    w1:p4 123 34 w1:p5 124 35 w1:p6 123 34 >"$d/layout_w1:p1.json"
mk_panes \
    'w1:p1' 'w1:t1' '"worker:one"' 'w1:p2' 'w1:t1' '"worker:two"' \
    'w1:p3' 'w1:t1' '"worker:three"' 'w1:p4' 'w1:t1' '"worker:four"' \
    'w1:p5' 'w1:t1' '"worker:five"' 'w1:p6' 'w1:t1' '"worker:six"' >"$d/panes_w1.json"
# agents:proj is full (6 panes); agents:proj-2 has one worker pane and is suitable.
printf '{"result":{"tabs":[{"tab_id":"w1:t1","label":"agents:proj"},{"tab_id":"w2:t1","label":"agents:proj-2"}]}}\n' >"$d/tabs.json"
mk_layout w2:t1 247 69 w2:p1 247 69 >"$d/layout_w2:p1.json"
mk_panes 'w2:p1' 'w2:t1' '"worker:later · proj@main"' >"$d/panes_w2.json"

if zgpt_herdr_anchor_for_tab w1:t1 >/dev/null; then
    fail 'tab with 6 live panes must not yield an anchor'
else
    pass 'tab with 6 live panes yields no anchor (overflow)'
fi
out="$(zgpt_herdr_ensure_repo_tab "$repo")"
assert_contains "$out" 'target_tab_id=w2:t1' '6-pane agents:proj is skipped; agents:proj-2 is reused'
assert_eq "$(printf '%s\n' "$out" | sed -n 's/^created_tab_id=//p' | sed -n '1p')" '' 'reused tab reports empty created_tab_id'

# Both agents:proj and agents:proj-2 full -> create agents:proj-3.
printf '{"result":{"tabs":[{"tab_id":"w1:t1","label":"agents:proj"},{"tab_id":"w2:t1","label":"agents:proj-2"}]}}\n' >"$d/tabs.json"
mk_panes \
    'w2:p1' 'w2:t1' '"worker:one"' 'w2:p2' 'w2:t1' '"worker:two"' \
    'w2:p3' 'w2:t1' '"worker:three"' 'w2:p4' 'w2:t1' '"worker:four"' \
    'w2:p5' 'w2:t1' '"worker:five"' 'w2:p6' 'w2:t1' '"worker:six"' >"$d/panes_w2.json"
mk_layout w2:t1 247 69 \
    w2:p1 124 35 w2:p2 123 34 w2:p3 124 35 \
    w2:p4 123 34 w2:p5 124 35 w2:p6 123 34 >"$d/layout_w2:p1.json"
printf '{"result":{"tab":{"tab_id":"w3:t1"},"root_pane":{"pane_id":"w3:p1"}}}\n' >"$d/create.json"
out="$(zgpt_herdr_ensure_repo_tab "$repo")"
assert_contains "$out" 'target_tab_id=w3:t1' 'both suffixes full -> a fresh agents:proj-3 tab is created'
assert_contains "$out" 'created_tab_id=w3:t1' 'fresh tab reports created_tab_id'
assert_contains "$out" 'root_pane_id=w3:p1' 'fresh tab reports the bootstrap root pane for reuse'

printf '\n== Human-only tab (even 1 pane) overflows, never split ==\n'
d="$(scenario humanonly)"; export FAKE_DIR="$d"
mk_layout w1:t1 247 69 w1:p1 247 69 >"$d/layout_w1:p1.json"
mk_panes 'w1:p1' 'w1:t1' '"human:zflow · Debug pane event handling"' >"$d/panes_w1.json"
printf '{"result":{"tabs":[{"tab_id":"w1:t1","label":"agents:proj"}]}}\n' >"$d/tabs.json"
printf '{"result":{"tab":{"tab_id":"w2:t1"},"root_pane":{"pane_id":"w2:p1"}}}\n' >"$d/create.json"
if zgpt_herdr_anchor_for_tab w1:t1 >/dev/null; then
    fail 'human-only tab must not yield an anchor'
else
    pass 'human-only tab (1 pane) yields no anchor (overflow)'
fi
out="$(zgpt_herdr_ensure_repo_tab "$repo")"
assert_contains "$out" 'target_tab_id=w2:t1' 'human-only agents:proj is skipped; a fresh agents:proj-2 is created'
assert_not_contains "$out" 'w1:t1' 'the human pane tab is never reused for a worker'

# find_suitable_repo_tab: no suitable existing repo tab -> empty (fall through).
d="$(scenario nosuitable)"; export FAKE_DIR="$d"
mk_layout w1:t1 247 69 w1:p1 247 69 >"$d/layout_w1:p1.json"
mk_panes 'w1:p1' 'w1:t1' '"human:zflow · Debug pane event handling"' >"$d/panes_w1.json"
printf '{"result":{"tabs":[{"tab_id":"w1:t1","label":"agents:proj"}]}}\n' >"$d/tabs.json"
found="$(zgpt_herdr_find_suitable_repo_tab "$repo" || true)"
assert_eq "$found" '' 'find_suitable_repo_tab returns nothing when the only repo tab is human-only'

d="$(scenario notabs)"; export FAKE_DIR="$d"
printf '{"result":{"tabs":[]}}\n' >"$d/tabs.json"
found="$(zgpt_herdr_find_suitable_repo_tab "$repo" || true)"
assert_eq "$found" '' 'find_suitable_repo_tab returns nothing when no repo tab exists yet'

printf '\n== Summary ==\n'
printf '%d passed, %d failed\n' "$passed" "$failed"
((failed == 0))
