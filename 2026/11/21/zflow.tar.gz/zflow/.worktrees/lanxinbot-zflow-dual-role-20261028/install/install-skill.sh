#!/usr/bin/env bash
set -euo pipefail

# install-skill.sh — make the zflow-workers skill usable from ANY repo and
# by multiple agents, by symlinking it into each agent's skills home:
#   ~/.claude/skills   (Claude Code)
#   ~/.agents/skills   (Codex and other agents via the shared skills home)
# Edits stay in this repo (single source of truth); each agent discovers the
# skill everywhere, and the documented .../scripts/... paths resolve.
#
# Idempotent: re-running when the correct symlink already exists is a no-op.
#
#   scripts/install-skill.sh              # install into all known homes
#   scripts/install-skill.sh --claude     # only ~/.claude/skills
#   scripts/install-skill.sh --codex      # only ~/.agents/skills
#   scripts/install-skill.sh --force      # replace an existing non-matching target
#   scripts/install-skill.sh --uninstall  # remove the symlinks

die() { printf 'error: %s\n' "$*" >&2; exit 1; }

repo_root="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
skill_name="zflow-workers"
legacy_skill_name="zflow-gpt""-workers"
src="$repo_root/.claude/skills/$skill_name"

claude_home="$HOME/.claude/skills"
codex_home="$HOME/.agents/skills"

force=false
uninstall=false
want_claude=false
want_codex=false
for a in "$@"; do
    case "$a" in
        --force) force=true;;
        --uninstall) uninstall=true;;
        --claude) want_claude=true;;
        --codex) want_codex=true;;
        -h|--help) sed -n '3,17p' "${BASH_SOURCE[0]}" | sed 's/^# \{0,1\}//'; exit 0;;
        *) die "unknown argument: $a";;
    esac
done
# Default: both homes unless a specific one was requested.
if [[ "$want_claude" == false && "$want_codex" == false ]]; then
    want_claude=true; want_codex=true
fi

[[ -d "$src" ]] || die "skill source not found: $src"

# Prefer a symlink target relative to $HOME (portable across machines / moves),
# matching the existing ~/.claude/skills convention. Both skills homes are two
# levels below $HOME (~/.claude/skills, ~/.agents/skills), so "../.." reaches
# $HOME. Fall back to an absolute target only if the repo is not under $HOME.
if [[ "$src" == "$HOME/"* ]]; then
    link_target="../../${src#$HOME/}"      # e.g. ../../github/me/zflow/.claude/skills/zflow-workers
else
    link_target="$src"
fi

# Real path a symlink resolves to (portable; avoids BSD `readlink -f`).
resolve() { (cd "$1" 2>/dev/null && pwd -P); }
src_real="$(resolve "$src")"

targets=()
[[ "$want_claude" == true ]] && targets+=("$claude_home")
[[ "$want_codex" == true ]] && targets+=("$codex_home")

link_one() {
    local dest_dir="$1" dest="$1/$skill_name"
    local legacy_dest="$1/$legacy_skill_name"
    if [[ "$uninstall" == true ]]; then
        if [[ -L "$dest" ]]; then
            rm -- "$dest"; printf 'uninstalled: %s\n' "$dest"
        else
            printf 'skip (not a symlink or absent): %s\n' "$dest"
        fi
        if [[ -L "$legacy_dest" ]]; then
            rm -- "$legacy_dest"; printf 'uninstalled legacy: %s\n' "$legacy_dest"
        fi
        return 0
    fi
    mkdir -p "$dest_dir"
    if [[ -L "$legacy_dest" ]]; then
        rm -- "$legacy_dest"
        printf 'removed legacy symlink: %s\n' "$legacy_dest"
    fi
    if [[ -L "$dest" ]]; then
        local current; current="$(readlink "$dest")"
        if [[ "$current" == "$link_target" ]]; then
            printf 'already installed: %s -> %s\n' "$dest" "$link_target"; return 0
        fi
        if [[ "$(resolve "$dest")" == "$src_real" ]]; then
            # Ours already, but a different literal form (e.g. old absolute) — migrate to relative.
            rm -- "$dest"; ln -s "$link_target" "$dest"
            printf 'relinked (relative): %s -> %s\n' "$dest" "$link_target"; return 0
        fi
        [[ "$force" == true ]] || die "$dest already links elsewhere ($current); re-run with --force"
        rm -- "$dest"
    elif [[ -e "$dest" ]]; then
        [[ "$force" == true ]] || die "$dest exists and is not a symlink; re-run with --force"
        rm -rf -- "$dest"
    fi
    ln -s "$link_target" "$dest"
    printf 'installed: %s -> %s\n' "$dest" "$link_target"
}

for t in "${targets[@]}"; do
    link_one "$t"
done

if [[ "$uninstall" != true ]]; then
    printf 'verify: for d in %s; do ls "$d/%s/scripts" >/dev/null && echo "$d ok"; done\n' \
        "${targets[*]}" "$skill_name"
fi
