#!/usr/bin/env bash
set -euo pipefail

# install-skill-package.sh — symlink THIS package (skills/zflow layout) into
#   ~/.claude/skills/zflow-workers
#   ~/.agents/skills/zflow-workers
#
#   install/install-skill-package.sh
#   install/install-skill-package.sh --claude | --codex
#   install/install-skill-package.sh --force
#   install/install-skill-package.sh --uninstall

die() { printf 'error: %s\n' "$*" >&2; exit 1; }

pkg_root="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
skill_name="zflow-workers"
src="$pkg_root"

claude_home="$HOME/.claude/skills"
codex_home="$HOME/.agents/skills"

force=false
uninstall=false
want_claude=false
want_codex=false
for a in "$@"; do
    case "$a" in
        --force) force=true;;
        --uninstall) uninstall=true;;
        --claude) want_claude=true;;
        --codex) want_codex=true;;
        -h|--help)
            sed -n '3,12p' "${BASH_SOURCE[0]}" | sed 's/^# \{0,1\}//'
            exit 0
            ;;
        *) die "unknown argument: $a";;
    esac
done
if [[ "$want_claude" == false && "$want_codex" == false ]]; then
    want_claude=true; want_codex=true
fi

[[ -f "$src/SKILL.md" ]] || die "skill source not found: $src/SKILL.md"
[[ -d "$src/scripts" ]] || die "scripts/ missing under $src"

if [[ "$src" == "$HOME/"* ]]; then
    # both skill homes are $HOME/.<agent>/skills — two levels down
    link_target="../../${src#$HOME/}"
else
    link_target="$src"
fi

resolve() { (cd "$1" 2>/dev/null && pwd -P); }
src_real="$(resolve "$src")"

link_one() {
    local dest_dir="$1" dest="$1/$skill_name"
    if [[ "$uninstall" == true ]]; then
        if [[ -L "$dest" ]]; then
            rm -- "$dest"; printf 'uninstalled: %s\n' "$dest"
        else
            printf 'skip (not a symlink or absent): %s\n' "$dest"
        fi
        return 0
    fi
    mkdir -p "$dest_dir"
    if [[ -L "$dest" ]]; then
        local current; current="$(readlink "$dest")"
        if [[ "$current" == "$link_target" ]] || [[ "$(resolve "$dest")" == "$src_real" ]]; then
            if [[ "$current" != "$link_target" ]]; then
                rm -- "$dest"; ln -s "$link_target" "$dest"
                printf 'relinked: %s -> %s\n' "$dest" "$link_target"
            else
                printf 'already installed: %s -> %s\n' "$dest" "$link_target"
            fi
            return 0
        fi
        [[ "$force" == true ]] || die "$dest already links elsewhere ($current); re-run with --force"
        rm -- "$dest"
    elif [[ -e "$dest" ]]; then
        [[ "$force" == true ]] || die "$dest exists and is not a symlink; re-run with --force"
        rm -rf -- "$dest"
    fi
    ln -s "$link_target" "$dest"
    printf 'installed: %s -> %s\n' "$dest" "$link_target"
}

[[ "$want_claude" == true ]] && link_one "$claude_home"
[[ "$want_codex" == true ]] && link_one "$codex_home"
