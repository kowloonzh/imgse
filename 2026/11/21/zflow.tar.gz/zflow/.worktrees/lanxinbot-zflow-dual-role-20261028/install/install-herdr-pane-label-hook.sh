#!/usr/bin/env bash
set -euo pipefail

# install-herdr-pane-label-hook.sh — wire the herdr pane-label hook into a
# Claude Code settings.json, so a hand-started Claude session gets a
# "human:<repo> · <title>" label on its herdr pane border instead of the
# generic "claude" agent label.
#
# The hook lives at hooks/herdr-pane-label.sh inside the zflow-workers skill,
# which scripts/install-skill.sh symlinks into ~/.claude/skills/zflow-workers —
# so the path written into settings.json is stable and tracks `git pull` with no
# file copying. Run install-skill.sh first (or `make install-herdr-hook`, which
# depends on it).
#
# Idempotent: re-running registers nothing twice; --uninstall removes only the
# entries this installer added and leaves every other settings key untouched.
# The file is merged with jq (never overwritten), backed up to settings.json.bak
# before the first modification, and rewritten only when the merge changed it.
#
#   scripts/install-herdr-pane-label-hook.sh                      # register into ~/.claude/settings.json
#   scripts/install-herdr-pane-label-hook.sh --uninstall          # remove the hook entries
#   scripts/install-herdr-pane-label-hook.sh --settings FILE      # operate on FILE instead (tests)
#
# Caveat: herdr only renders pane borders on tabs with 2+ panes, so a single-pane
# tab shows no title regardless. See docs/herdr-single-pane-title-finding.md.

die() { printf 'error: %s\n' "$*" >&2; exit 1; }

settings="${HOME}/.claude/settings.json"
uninstall=false
while (( $# > 0 )); do
    case "$1" in
        --uninstall) uninstall=true; shift;;
        --settings) (( $# >= 2 )) || die "--settings requires a file path argument"; settings="$2"; shift 2;;
        --settings=*) settings="${1#--settings=}"; shift;;
        -h|--help) sed -n '3,25p' "${BASH_SOURCE[0]}" | sed 's/^# \{0,1\}//'; exit 0;;
        *) die "unknown argument: $1";;
    esac
done

command -v jq >/dev/null 2>&1 \
    || die "jq is required to merge $settings (brew install jq); nothing was modified"

hook_path="${HOME}/.claude/skills/zflow-workers/hooks/herdr-pane-label.sh"
[[ -f "$hook_path" ]] \
    || die "hook not found at $hook_path — run 'scripts/install-skill.sh --claude' first (it symlinks the skill; the hook lives inside it); nothing was modified"

# Shell-quote the path so the hook still runs if $HOME contains a quote.
hook_cmd="bash '$(printf '%s' "$hook_path" | sed "s/'/'\\\\''/g")'"

settings_dir="$(dirname "$settings")"
mkdir -p "$settings_dir"
new_file="${settings}.new"
trap 'rm -f -- "$new_file"' EXIT

install_jq='
def has_cmd(arr; c):
  ((arr // []) | any(.[]? | .hooks[]?; (.type == "command") and (.command == c)));

.hooks.SessionStart =
  (if has_cmd(.hooks.SessionStart; $cmd)
   then (.hooks.SessionStart // [])
   else ((.hooks.SessionStart // []) + [{hooks:[{type:"command",command:$cmd,timeout:10}]}])
   end)
|
.hooks.Stop =
  (if has_cmd(.hooks.Stop; $cmd)
   then (.hooks.Stop // [])
   else ((.hooks.Stop // []) + [{hooks:[{type:"command",command:$cmd,timeout:10,async:true}]}])
   end)
'

uninstall_jq='
def has_cmd(arr; c):
  ((arr // []) | any(.[]? | .hooks[]?; (.type == "command") and (.command == c)));

.hooks.SessionStart = [(.hooks.SessionStart // [])[]? | select((has_cmd([.]; $cmd)) | not)] |
.hooks.Stop = [(.hooks.Stop // [])[]? | select((has_cmd([.]; $cmd)) | not)] |
if ((.hooks.SessionStart // []) | length) == 0 then del(.hooks.SessionStart) else . end |
if ((.hooks.Stop // []) | length) == 0 then del(.hooks.Stop) else . end |
if ((.hooks // {}) | length) == 0 then del(.hooks) else . end
'

prog="$install_jq"
verb="install"
if [[ "$uninstall" == true ]]; then
    prog="$uninstall_jq"
    verb="uninstall"
fi

if [[ -f "$settings" ]]; then
    jq "$prog" --arg cmd "$hook_cmd" "$settings" > "${settings}.new"
else
    jq "$prog" --arg cmd "$hook_cmd" -n '{}' > "${settings}.new"
fi

if [[ -f "$settings" ]] && cmp -s "$settings" "${settings}.new"; then
    rm -f -- "${settings}.new"
    printf '%s: already up to date (no change): %s\n' "$verb" "$settings"
else
    if [[ -f "$settings" ]]; then
        cp -- "$settings" "$settings.bak"
        printf 'backed up: %s -> %s.bak\n' "$settings" "$settings"
    fi
    mv -- "${settings}.new" "$settings"
    printf '%s: %s\n' "$verb" "$settings"
fi
