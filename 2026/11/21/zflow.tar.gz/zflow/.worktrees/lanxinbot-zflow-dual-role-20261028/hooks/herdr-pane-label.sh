#!/usr/bin/env bash
# Label this session's herdr pane as "human:<repo> · <session title>".
#
# Hand-started Claude sessions have no manual pane label, so herdr falls back to
# the detected agent label and every pane reads "claude". zflow workers already
# get a "worker:<name> · <repo>@<branch>" label from zgpt-worker-pane.sh, so this
# skips them: a worker is often a Claude session too, and relabelling it would
# destroy the orchestrator's own naming. In the two-role model the only other
# pane is the human's own session, which this labels human:<repo>.
#
# Installed copy: this file lives inside the zflow-workers skill, which
# scripts/install-skill.sh symlinks to ~/.claude/skills/zflow-workers, so the
# path is stable and tracks `git pull`. Wire it into settings.json with
# scripts/install-herdr-pane-label-hook.sh (registers on SessionStart and Stop,
# Stop async). Runs on SessionStart (initial label) and Stop (refresh once the
# conversation has a title). Always exits 0 — a labelling failure must never
# break a session.

set -u

# Not running under herdr: nothing to label.
[ -n "${HERDR_PANE_ID:-}" ] || exit 0

# zflow worker: the manager owns this pane's label.
[ -z "${ZFLOW_WORKER_DEPTH:-}" ] || exit 0

command -v herdr >/dev/null 2>&1 || exit 0
command -v jq >/dev/null 2>&1 || exit 0

pane_json="$(herdr pane get "$HERDR_PANE_ID" 2>/dev/null)" || exit 0
[ -n "$pane_json" ] || exit 0

current_label="$(printf '%s' "$pane_json" | jq -r '.result.pane.label // ""' 2>/dev/null)"

# Second guard: a pane zflow labelled directly, even if the env var didn't reach us.
# worker: panes are preserved — only an unlabelled hand-started session becomes human:.
case "$current_label" in
    worker:*) exit 0 ;;
esac

repo="$(git rev-parse --show-toplevel 2>/dev/null)"
if [ -n "$repo" ]; then
    repo="$(basename "$repo")"
else
    repo="$(basename "$PWD")"
fi

title="$(printf '%s' "$pane_json" | jq -r '.result.pane.terminal_title_stripped // ""' 2>/dev/null)"

# "Claude Code" is the placeholder title before the conversation has a topic.
if [ -n "$title" ] && [ "$title" != "Claude Code" ]; then
    label="human:${repo} · ${title}"
else
    label="human:${repo}"
fi

herdr pane rename "$HERDR_PANE_ID" "$label" >/dev/null 2>&1 || true
exit 0
