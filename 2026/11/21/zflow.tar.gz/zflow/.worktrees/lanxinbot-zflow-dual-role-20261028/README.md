# zflow

Agent skill for visible, model-agnostic **AI worker runtime on top of [herdr](https://herdr.dev/)**.

Two roles. The session you are in is the **manager** — it analyses, designs, decides, decomposes,
writes each worker's prompt, dispatches, monitors, reviews and integrates. Each **worker** is a real
interactive CLI in its own herdr pane, so you can watch and steer live processes instead of hidden
subagents. Only one environment variable is needed: `ZFLOW_WORKER_CMD`.

The split is **delegate execution, not judgement**: code, tests and test runs go to a worker;
design, proposals, review and decisions stay in the manager session. That is what keeps the
manager's token cost down — execution volume burns tokens in the worker pane, not in the main
context.

This package is the installable skill extract of the
[AliceOrg/zflow](https://github.com/AliceOrg/zflow) project
(`.claude/skills/zflow-workers/`).

## Layout

| Path | Role |
|---|---|
| `SKILL.md` | Skill contract: the two roles, the manager loop, worker entry point |
| `scripts/` | `zgpt-*.sh` worker launcher / pane / worktree / fan-out helpers |
| `hooks/` | herdr pane-label SessionStart/Stop hook |
| `agents/` | Agent metadata (`openai.yaml`) |
| `tests/` | Offline smoke suites |
| `install/` | Symlink / hook installers |

## Install

From this checkout:

```bash
# Symlink into Claude + Codex skill homes (idempotent)
bash install/install-skill.sh
# Optional: herdr pane label hook
bash install/install-herdr-pane-label-hook.sh
```

`install-skill.sh` expects the skill at `.claude/skills/zflow-workers` relative to a zflow
repo root. For this package layout, either:

```bash
# Option A — install from the full zflow repo (recommended)
git clone https://github.com/AliceOrg/zflow.git && cd zflow && make install

# Option B — point skill homes at this package directly
ln -sfn "$(pwd)" ~/.claude/skills/zflow-workers
ln -sfn "$(pwd)" ~/.agents/skills/zflow-workers
```

## Quick use

```bash
export ZFLOW_WORKER_CMD=<your worker CLI>     # once per machine
source scripts/zgpt-common.sh
run_dir="$(zgpt_state_dir "$PWD")/runs/demo-$(date +%Y%m%d-%H%M%S)"; mkdir -p "$run_dir"
scripts/zgpt-run-worker.sh \
  --name worker-do --cwd "$PWD" \
  --artifact "$run_dir/summary.md" --close \
  --task "Write a 5-bullet summary of this repo."
```

## Source of truth

Development continues in [AliceOrg/zflow](https://github.com/AliceOrg/zflow). This repo mirrors
the skill + scripts for internal skill-catalog install (`cloud_platform/xcloud/skills/zflow`).

## Test

```bash
bash tests/run-all.sh
```
