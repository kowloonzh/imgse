#!/usr/bin/env bash
set -euo pipefail

# zgpt-worktree.sh — manage isolated git worktrees for writable workers.
#
# Migration- and multi-lane scenarios need each writable worker in its own
# checkout so parallel edits never collide. This wraps `git worktree` with a
# namespaced branch/path convention so the manager can hand a clean --cwd to a
# worker, then integrate and clean up.
#
#   create  --name <slice> [--base <ref>] [--path <dir>]   branch zgpt/<slice> + worktree, prints path=
#   path    --name <slice>                                  print the worktree path (if it exists)
#   list                                                    list zgpt-managed worktrees
#   remove  --name <slice> [--delete-branch] [--force]      remove the worktree (and optionally its branch)
#
# Worktrees default to <state_dir>/worktrees/<slice> under /tmp/zflow (or
# $ZFLOW_STATE_ROOT), on branch zgpt/<slice>.

script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$script_dir/zgpt-common.sh"

usage() { sed -n '3,20p' "${BASH_SOURCE[0]}" | sed 's/^# \{0,1\}//'; }
die() { printf 'error: %s\n' "$*" >&2; exit 2; }

command -v git >/dev/null || die "git not found"
repo_root="$(git rev-parse --show-toplevel 2>/dev/null)" || die "not inside a git repository"

sub="${1:-}"
[[ -n "$sub" ]] || { usage; exit 2; }
shift || true

name=""
base=""
path=""
delete_branch=false
force=false
while [[ $# -gt 0 ]]; do
    case "$1" in
        --name) name="${2:?}"; shift 2;;
        --base) base="${2:?}"; shift 2;;
        --path) path="${2:?}"; shift 2;;
        --delete-branch) delete_branch=true; shift;;
        --force) force=true; shift;;
        -h|--help) usage; exit 0;;
        *) die "unknown argument: $1";;
    esac
done

branch_for() { printf 'zgpt/%s' "$1"; }
default_path_for() { printf '%s/worktrees/%s' "$(zgpt_state_dir "$repo_root")" "$1"; }

case "$sub" in
    create)
        [[ -n "$name" ]] || die "create: --name is required"
        [[ -n "$path" ]] || path="$(default_path_for "$name")"
        branch="$(branch_for "$name")"
        if git -C "$repo_root" worktree list --porcelain | grep -qxF "worktree $path"; then
            printf 'path=%s\n' "$path"
            printf 'status=exists\n'
            exit 0
        fi
        mkdir -p "$(dirname "$path")"
        if git -C "$repo_root" show-ref --verify --quiet "refs/heads/$branch"; then
            # Branch already exists — attach a worktree to it.
            git -C "$repo_root" worktree add "$path" "$branch" >&2
        else
            [[ -n "$base" ]] || base="$(git -C "$repo_root" rev-parse --abbrev-ref HEAD)"
            git -C "$repo_root" worktree add -b "$branch" "$path" "$base" >&2
        fi
        printf 'path=%s\n' "$path"
        printf 'branch=%s\n' "$branch"
        printf 'status=created\n'
        ;;
    path)
        [[ -n "$name" ]] || die "path: --name is required"
        [[ -n "$path" ]] || path="$(default_path_for "$name")"
        if git -C "$repo_root" worktree list --porcelain | grep -qxF "worktree $path"; then
            printf '%s\n' "$path"
        else
            die "no worktree for $name at $path"
        fi
        ;;
    list)
        # Show only worktrees under our managed root.
        state_root_worktrees="$(zgpt_state_dir "$repo_root")/worktrees/"
        git -C "$repo_root" worktree list | awk -v root="$state_root_worktrees" '$1 ~ root || NR==1'
        ;;
    remove)
        [[ -n "$name" ]] || die "remove: --name is required"
        [[ -n "$path" ]] || path="$(default_path_for "$name")"
        branch="$(branch_for "$name")"
        rm_args=(worktree remove "$path")
        [[ "$force" == true ]] && rm_args+=(--force)
        git -C "$repo_root" "${rm_args[@]}"
        printf 'removed=%s\n' "$path"
        if [[ "$delete_branch" == true ]]; then
            if [[ "$force" == true ]]; then
                git -C "$repo_root" branch -D "$branch" >&2 && printf 'branch_deleted=%s\n' "$branch"
            else
                git -C "$repo_root" branch -d "$branch" >&2 && printf 'branch_deleted=%s\n' "$branch"
            fi
        fi
        ;;
    -h|--help) usage;;
    *) die "unknown subcommand: $sub (use create|path|list|remove)";;
esac
