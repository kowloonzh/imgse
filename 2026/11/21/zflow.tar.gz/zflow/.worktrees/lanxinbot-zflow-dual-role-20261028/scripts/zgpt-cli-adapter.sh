#!/usr/bin/env bash
# CLI-family capabilities shared by the worker launcher and runner.
# Keep this file Bash 3.2 compatible: it is sourced by macOS system Bash.

zgpt_cli_basename() {
    local cmd="${1:-}"
    basename "$cmd"
}

zgpt_cli_family() {
    local cmd="${1:-}" override="${2:-${ZGPT_CLI_FAMILY:-}}" base
    if [[ -n "$override" ]]; then
        case "$override" in
            claude|codex|pi|grok|generic) printf '%s\n' "$override"; return 0 ;;
            *) printf 'generic\n'; return 0 ;;
        esac
    fi
    base="$(zgpt_cli_basename "$cmd" | tr '[:upper:]' '[:lower:]')"
    case "$base" in
        # Bridge/omni Claude wrappers first so startbridge-grok* stays Claude-family.
        startcccodex|claude|startclaude|*claude*|startomni-*|*startomni*|startspark*|startbridge|startbridge-*|startds|startdsf|gpt|glm)
            printf 'claude\n' ;;
        codex|startcodex|startcodex-*|*codex*)
            printf 'codex\n' ;;
        pi|startpi|startpi-*|pi-*)
            printf 'pi\n' ;;
        # Native Grok Build CLI and its startgrok* model wrappers (not startbridge-grok*).
        grok|startgrok|startgrok*)
            printf 'grok\n' ;;
        *)
            printf 'generic\n' ;;
    esac
}

zgpt_cli_ready_pattern() {
    case "$(zgpt_cli_family "${1:-}" "${2:-}")" in
        claude) printf '❯\n' ;;
        codex) printf '›\n' ;;
        pi) printf '›\n' ;;
        # Grok Build uses a Claude-like prompt prefix character.
        grok) printf '❯\n' ;;
        *) printf '❯\n' ;;
    esac
}

zgpt_cli_ready_regex() {
    case "$(zgpt_cli_family "${1:-}" "${2:-}")" in
        # Pi's editor is a blank bordered input area, not a Codex-style glyph.
        # The trust dialog is bypassed by the managed --approve capability.
        pi) printf '^─{8,}[[:space:]]*$\n' ;;
        *) printf '\n' ;;
    esac
}

zgpt_cli_ready_blocker_regex() {
    case "$(zgpt_cli_family "${1:-}" "${2:-}")" in
        codex) printf 'Starting MCP servers\n' ;;
        *) printf '\n' ;;
    esac
}

zgpt_cli_ready_settle_secs() {
    case "$(zgpt_cli_family "${1:-}" "${2:-}")" in
        codex) printf '1\n' ;;
        *) printf '0\n' ;;
    esac
}

zgpt_cli_visible_output_blocked() {
    local cmd="${1:-}" override="${2:-}" screen="${3:-}" line current total
    [[ "$(zgpt_cli_family "$cmd" "$override")" == codex ]] || return 1
    while IFS= read -r line; do
        case "$line" in
            *"Starting MCP servers"*)
                if [[ "$line" =~ Starting[[:space:]]MCP[[:space:]]servers[[:space:]]\(([0-9]+)/([0-9]+)\) ]]; then
                    current="${BASH_REMATCH[1]}"
                    total="${BASH_REMATCH[2]}"
                    if (( current < total )); then
                        return 0
                    fi
                else
                    return 0
                fi
                ;;
        esac
    done <<EOF
$screen
EOF
    return 1
}

# Codex's composer is the last line that starts with `›`. Older builds show it
# bare as the final line; newer ones (0.16x) fill it with a dim placeholder
# ("› Ask Codex to do anything") and draw a status bar and "? for shortcuts"
# footer below it. Accept both, but only when at most a short footer follows
# the composer, and reject numbered selection menus ("› 1. Yes, continue" in
# trust/update dialogs) and a running turn ("esc to interrupt").
zgpt_cli_codex_visible_output_ready() {
    local screen="${1:-}" line composer="" after=0
    while IFS= read -r line; do
        [[ "$line" =~ [^[:space:]] ]] || continue
        if [[ "$line" =~ ^[[:space:]]*›([[:space:]]|$) ]]; then
            composer="$line"
            after=0
        elif [[ -n "$composer" ]]; then
            after=$((after + 1))
        fi
    done <<EOF
$screen
EOF
    [[ -n "$composer" ]] || return 1
    [[ "$composer" =~ ^[[:space:]]*›[[:space:]]*[0-9]+\. ]] && return 1
    [[ "$screen" == *"esc to interrupt"* ]] && return 1
    (( after <= 3 ))
}

zgpt_cli_visible_output_ready() {
    local cmd="${1:-}" override="${2:-}" screen="${3:-}" ready_pattern="${4:-}" ready_regex="${5:-}"
    if zgpt_cli_visible_output_blocked "$cmd" "$override" "$screen"; then
        return 1
    fi
    if [[ -n "$ready_pattern" ]]; then
        if [[ "$(zgpt_cli_family "$cmd" "$override")" == codex && "$ready_pattern" == "›" ]]; then
            zgpt_cli_codex_visible_output_ready "$screen"
        else
            printf '%s\n' "$screen" | grep -qF "$ready_pattern"
        fi
    elif [[ -n "$ready_regex" ]]; then
        printf '%s\n' "$screen" | grep -Eq -- "$ready_regex"
    else
        return 1
    fi
}

# These are deliberately separate capabilities. Callers can opt into explicit
# flags without coupling readiness or print-mode behavior to startup policy.
#
# --bare is a startup-speed optimization, but it also makes Anthropic auth
# "strictly ANTHROPIC_API_KEY or apiKeyHelper" -- OAuth and the keychain are
# never read. So on an OAuth login (a claude.ai Pro/Max subscription) with no
# API key in the environment, every --bare worker comes up unauthenticated and
# answers its first request with "Not logged in · Please run /login", while
# `claude auth status` still reports loggedIn:true. Verified directly:
#   claude -p "..."         -> ok
#   claude --bare -p "..."  -> Not logged in · Please run /login
#
# Only add it when the credential --bare can actually see is present. An
# explicit --bare still forces it, so an API-key user keeps the faster startup.
zgpt_cli_startup_bare() {
    [[ "$(zgpt_cli_family "${1:-}" "${2:-}")" == claude ]] || return 1
    [[ -n "${ANTHROPIC_API_KEY:-}" ]]
}

zgpt_cli_startup_effort() {
    case "$(zgpt_cli_family "${1:-}" "${2:-}")" in
        claude|grok) return 0 ;;
        *) return 1 ;;
    esac
}

# Codex starts app-provided MCP servers unless apps are disabled. Managed
# interactive workers disable apps by default to avoid slow/noisy app MCP
# startup; callers can append --enable apps later to override this default.
zgpt_cli_startup_disable_apps() {
    [[ "$(zgpt_cli_family "${1:-}" "${2:-}")" == codex ]]
}

zgpt_effort_valid() {
    case "${1:-}" in
        low|medium|high|xhigh|max) return 0 ;;
        *) return 1 ;;
    esac
}

# Return the managed auto-approve flag for a family, or empty when none applies.
# Callers should only append this when zgpt_cli_startup_approve returns success.
zgpt_cli_approve_flag() {
    case "$(zgpt_cli_family "${1:-}" "${2:-}")" in
        pi) printf '%s\n' '--approve' ;;
        grok) printf '%s\n' '--always-approve' ;;
        *) printf '\n' ;;
    esac
}

# Pi asks for project trust on first launch. Grok defaults to permission prompts
# unless always-approve is set. Managed workers auto-approve only when the
# caller did not supply an explicit approve/permission policy.
zgpt_cli_startup_approve() {
    local family arg
    family="$(zgpt_cli_family "${1:-}" "${2:-}")"
    case "$family" in
        pi)
            shift 2 || true
            for arg in "$@"; do
                case "$arg" in
                    --approve|-a|--no-approve|-na) return 1 ;;
                esac
            done
            return 0
            ;;
        grok)
            shift 2 || true
            for arg in "$@"; do
                case "$arg" in
                    --always-approve|--permission-mode|--permission-mode=*) return 1 ;;
                esac
            done
            return 0
            ;;
        *)
            return 1
            ;;
    esac
}

zgpt_cli_requires_visible_editor() {
    case "$(zgpt_cli_family "${1:-}" "${2:-}")" in
        claude|codex|pi|grok) return 0 ;;
        *) return 1 ;;
    esac
}

zgpt_cli_print_style() {
    case "$(zgpt_cli_family "${1:-}" "${2:-}")" in
        claude) printf 'claude\n' ;;
        codex) printf 'codex\n' ;;
        pi) printf 'pi\n' ;;
        # Grok headless uses -p / --single (Claude-compatible form).
        grok) printf 'claude\n' ;;
        *) printf 'generic\n' ;;
    esac
}

zgpt_cli_exit_prompt() {
    case "$(zgpt_cli_family "${1:-}" "${2:-}")" in
        claude|codex|pi|grok) printf '/exit\n' ;;
        *) printf 'exit\n' ;;
    esac
}

# Emit a command invocation suitable for a generated print-mode runner. The
# caller has already assigned worker_cmd, prompt, and worker_args as globals
# before sourcing/invoking this function (see zgpt-worker-pane.sh).
# shellcheck disable=SC2154 # worker_args/prompt: caller-scoped globals, not local to this file
zgpt_cli_run_print() {
    local family
    family="$(zgpt_cli_print_style "${worker_cmd:-}" "${worker_family:-}")"
    case "$family" in
        claude) "$worker_cmd" "${worker_args[@]+${worker_args[@]}}" -p "$prompt" ;;
        codex) "$worker_cmd" "${worker_args[@]+${worker_args[@]}}" exec "$prompt" ;;
        pi) "$worker_cmd" "${worker_args[@]+${worker_args[@]}}" --print "$prompt" ;;
        *) "$worker_cmd" "${worker_args[@]+${worker_args[@]}}" "$prompt" ;;
    esac
}
