#!/usr/bin/env bash
set -euo pipefail

# Dispatched commands — the direct-exec form and `bash -lc` stdin lines — must
# resolve the sibling zgpt-* scripts by bare name, as the docs show. install-skill.sh
# only symlinks the skill into skills homes; it never puts the scripts on PATH. Prepend
# this script's own directory (which holds every zgpt-* sibling) so bare names resolve
# regardless of the caller's login-shell PATH.
script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
export PATH="$script_dir:$PATH"

usage() {
    cat <<'USAGE'
Usage: zgpt-fanout.sh --max-parallel <n> [--] <command> [args...]
       printf '%s\n' '<cmd1>' '<cmd2>' | zgpt-fanout.sh --max-parallel <n>

Run independent worker launches with bounded parallelism. With a command and
args, stdin lines are appended as the final argument to that command. Without a
command, each non-empty stdin line is executed with bash -lc.
USAGE
}

die() { printf 'error: %s\n' "$*" >&2; exit 2; }
posint() { [[ "${1:-}" =~ ^[1-9][0-9]*$ ]]; }

max_parallel=""
while [[ $# -gt 0 ]]; do
    case "$1" in
        --max-parallel|-j) max_parallel="${2:?}"; shift 2;;
        --help|-h) usage; exit 0;;
        --) shift; break;;
        *) break;;
    esac
done
[[ -n "$max_parallel" ]] || die "--max-parallel is required"
posint "$max_parallel" || die "--max-parallel must be a positive integer"

active=0
fail=0
pids=()
reap_one() {
    local pid="${pids[0]}"
    pids=("${pids[@]:1}")
    if ! wait "$pid"; then fail=1; fi
    active=$((active - 1))
}

while IFS= read -r line || [[ -n "$line" ]]; do
    [[ -n "$line" ]] || continue
    while (( active >= max_parallel )); do reap_one; done
    if (( $# > 0 )); then
        ( "$@" "$line" ) &
    else
        ( bash -lc "$line" ) &
    fi
    pids+=("$!")
    active=$((active + 1))
done
while (( active > 0 )); do reap_one; done
exit "$fail"
