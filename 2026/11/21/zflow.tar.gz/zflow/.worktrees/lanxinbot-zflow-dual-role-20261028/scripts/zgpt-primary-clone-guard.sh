#!/usr/bin/env bash
# zgpt-primary-clone-guard.sh — PreToolUse hook for Claude Code.
#
# Blocks Edit/Write/MultiEdit/NotebookEdit against paths inside a *primary*
# git clone. Feature work must happen in an isolated linked worktree; the
# primary checkout is for reading and for landing reviewed results only.
#
# Wiring lives in SKILL.md (settings.json snippet). Fail open on any
# internal error; fail closed only on a confident primary-clone hit.
#
# Env:
#   ZFLOW_GUARD=off           → disable the guard entirely (escape hatch)
#   ZFLOW_GUARD_ALLOW=p:a     → colon-separated path prefixes to allow
#                               (default: $HOME/.claude:/tmp:$HOME/.config)
#
# Dependencies: bash, jq, git.

set -uo pipefail

# ---------------------------------------------------------------------------
# Escape hatch: one knob, deliberately inconvenient to set by accident.
# ---------------------------------------------------------------------------
if [[ "${ZFLOW_GUARD:-}" == "off" ]]; then
  exit 0
fi

# ---------------------------------------------------------------------------
# Allowlist (manager-owned config/instruction/scratch paths are not feature work).
# ---------------------------------------------------------------------------
default_allow="$HOME/.claude:/tmp:$HOME/.config"
allow_raw="${ZFLOW_GUARD_ALLOW:-$default_allow}"

is_allowed() {
  # $1 = path (may be non-existent). Returns 0 if it matches an allow prefix.
  local p="$1"
  local IFS=':'
  local prefix
  for prefix in $allow_raw; do
    [[ -z "$prefix" ]] && continue
    # Normalize the prefix so a trailing-slash mismatch does not defeat us.
    case "$p/" in
      "${prefix%/}/"*) return 0 ;;
    esac
  done
  return 1
}

# ---------------------------------------------------------------------------
# Per-directory git verdict cache (process-lifetime; no on-disk cache).
# Verdicts: "linked" (worktree) or "primary" (primary clone). Not-in-a-repo
# and errors short-circuit before caching.
# ---------------------------------------------------------------------------
declare -A DIR_VERDICT

# Resolve a path to its nearest *existing* ancestor directory, then run git
# there. A path whose file does not yet exist (Write-a-new-file) must still be
# attributed to the right repo via its parent dir.
nearest_existing_dir() {
  local p="$1"
  local d
  # realpath -m tolerates non-existent tail segments; -e would fail.
  d="$(realpath -m "$p" 2>/dev/null)" || d="$p"
  # If it is (or would resolve to) a file, step up to the directory.
  while [[ -n "$d" && ! -d "$d" ]]; do
    d="${d%/*}"
  done
  if [[ -z "$d" ]]; then
    d="."
  fi
  printf '%s\n' "$d"
}

git_verdict() {
  # $1 = an existing directory inside (presumably) a git repo.
  # Prints "linked" or "primary". Caller must treat any non-match as allow.
  local d="$1"
  if [[ -n "${DIR_VERDICT[$d]+x}" ]]; then
    printf '%s\n' "${DIR_VERDICT[$d]}"
    return 0
  fi

  local common_dir toplevel
  # Bail out fast: not a git repo at all → caller allows.
  if ! common_dir="$(git -C "$d" rev-parse --git-common-dir 2>/dev/null)"; then
    return 1
  fi
  # Resolve to absolute for a stable comparison.
  common_dir="$(cd "$d" && cd "$common_dir" 2>/dev/null && pwd 2>/dev/null)" || common_dir="$(realpath -m "$common_dir" 2>/dev/null)"
  toplevel="$(git -C "$d" rev-parse --show-toplevel 2>/dev/null)" || return 1
  toplevel="$(realpath -m "$toplevel" 2>/dev/null)" || toplevel="$toplevel"

  local verdict
  # In a linked worktree, --git-common-dir points at the primary's .git (i.e.
  # outside this checkout's own top level). In a primary clone it points at
  # <toplevel>/.git — inside the top level.
  case "$common_dir/" in
    "${toplevel}/"*)
      # common dir is inside this checkout's top level → primary clone.
      verdict="primary"
      ;;
    *)
      # common dir lives elsewhere → linked worktree.
      verdict="linked"
      ;;
  esac

  DIR_VERDICT["$d"]="$verdict"
  printf '%s\n' "$verdict"
  return 0
}

deny() {
  # $1 = actionable reason. Exit code 2 feeds the reason back to the model;
  # also emit the structured form on stdout so either contract is satisfied.
  local reason="$1"
  printf '%s\n' "$reason" >&2
  jq -nc --arg r "$reason" \
    '{hookSpecificOutput:{hookEventName:"PreToolUse",permissionDecision:"deny",permissionDecisionReason:$r}}'
  exit 2
}

# ---------------------------------------------------------------------------
# Main: read stdin once (not re-readable).
# ---------------------------------------------------------------------------
payload="$(cat)"

# Tool gate: only mutate-tools are our business.
tool_name="$(printf '%s' "$payload" | jq -r '.tool_name // empty' 2>/dev/null)" || {
  # jq itself failed → malformed input → fail open.
  printf 'zgpt-primary-clone-guard: could not parse payload, allowing\n' >&2
  exit 0
}
case "$tool_name" in
  Edit|Write|MultiEdit|NotebookEdit) : ;;
  *) exit 0 ;;
esac

# Extract target path (file_path, falling back to notebook_path).
target="$(printf '%s' "$payload" | jq -r '.tool_input.file_path // .tool_input.notebook_path // empty' 2>/dev/null)" || {
  printf 'zgpt-primary-clone-guard: jq failed reading file_path, allowing\n' >&2
  exit 0
}
if [[ -z "$target" ]]; then
  # No path extractable → fail open (never wedge the session on a malformed payload).
  exit 0
fi

# Resolve the target to its physical path before any verdict: a path addressed
# through a symlink (e.g. ~/.claude/skills/zflow-workers -> <repo>/.claude/...)
# must be judged by where it actually lands, not by the symlink's name. realpath
# -m tolerates a non-existent tail (Write-a-new-file) and resolves symlinks in
# the existing leading components. If realpath is unavailable or fails, fall
# back to the raw path and continue (fail open on tooling error, as elsewhere).
resolved="$(realpath -m "$target" 2>/dev/null)" || resolved="$target"

# Allowlist: check the resolved path so a symlink into a repo is not whitelisted
# by a prefix that only matches the symlink's name. A genuinely-under-allowlist
# path that resolves to itself is still allowed. $target (the raw path) is kept
# for the deny message so the reason names what the agent actually typed.
if is_allowed "$resolved"; then
  exit 0
fi

# Find the nearest existing ancestor directory (of the resolved path).
dir="$(nearest_existing_dir "$resolved")"

# Ask git for a verdict; any failure → allow with a warning.
verdict="$(git_verdict "$dir")" || {
  printf 'zgpt-primary-clone-guard: no git repo at %s, allowing\n' "$dir" >&2
  exit 0
}

if [[ "$verdict" == "primary" ]]; then
  # Recover the repo top level for an actionable message.
  repo="$(git -C "$dir" rev-parse --show-toplevel 2>/dev/null)" || repo="$dir"
  base="$(git -C "$dir" rev-parse --abbrev-ref HEAD 2>/dev/null)" || base="main"
  # Suggest a branch name derived from the session's purpose when we can't do better.
  branch="work/$(basename "$repo")-$(date +%s 2>/dev/null || echo handoff)"
  deny "${target} is inside the primary clone ${repo}. Create a worktree first: git -C ${repo} worktree add ${repo}/.worktrees/${branch} -b ${branch} ${base}, then edit there. (Set ZFLOW_GUARD=off only if this is genuinely manager-owned coordination.)"
fi

# Linked worktree, or verdict was something we did not recognise → allow.
exit 0
