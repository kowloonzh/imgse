#!/usr/bin/env bash
set -euo pipefail

# zgpt-run-worker.sh — launch an interactive AI worker, inject a task, and block
# until the pane transcript contains the WORKER_DONE:<token> completion marker.
#
# Two-role model: the session you talk to is the manager (it decomposes the task
# and writes the prompt); this script is the single worker entry point. There are
# no difficulty tiers, no advisor/fleet/manager command classes, and no routing
# telemetry — one worker command, configured once via ZFLOW_WORKER_CMD.
#
# Encodes the conventions learned from running these workers by hand:
#   - --bare startup (fast; ~4s vs ~12s) unless --no-bare
#   - launch WITHOUT a prompt, wait until the CLI shows its prompt, THEN inject
#     by sending text and pressing Enter (a prompt passed as a CLI arg only
#     pre-fills and never auto-submits in an interactive TUI)
#   - append a split completion marker so the echoed prompt can't false-positive
#     a pane monitor, plus an effort/scope bound so the worker doesn't run away
#   - detect completion by grepping the pane for WORKER_DONE:<token> (read via
#     herdr recent-unwrapped to reconstruct hard-wrapped lines, fall back to
#     visible); --artifact is optional — when provided the worker is asked to
#     write it, and artifact=<path> is printed
#   - the marker wait is an inactivity window, not a fixed wall-clock: each
#     observed change in the pane transcript slides the deadline forward, capped
#     by --max-timeout, so a healthy long task survives while a stuck worker
#     (no output) is still reaped after --timeout
#   - optional graceful exit + close-pane on completion (--close)
#
# It composes: run several in the background (`&`) for parallel fan-out and
# `wait` for a barrier; run sequentially for a pipeline.

usage() {
    cat <<'EOF'
Usage: zgpt-run-worker.sh --name <n> [--command <cmd>] (--task <text> | --task-file <path>) [options]

Launch an interactive worker, inject a task, and wait for the WORKER_DONE:<token>
marker to appear in the pane transcript (read via herdr recent-unwrapped, falling
back to visible).

Required:
  --name <name>             Worker/pane name.
  --task <text>             Task prompt (substance only; marker + effort footer are appended).
  --task-file <path>        Read the task prompt from a file instead of --task.

Options:
  --command <cmd>           Worker CLI. Default: ZFLOW_WORKER_CMD, then legacy
                            GPT_WORKER_CMD, then startomni-alice.
  --artifact <path>         Optional: file the worker is asked to write. When provided, the
                            task prompt includes file-write instructions and artifact=<path>
                            is printed on completion. Completion is detected via the
                            WORKER_DONE:<token> marker — not by file presence.
  --route <route>           Task routing gate: implement|inspect|verify. Default: implement.
  --report-mode <mode>      Append report contract: compact|full|none. Default: none.
  --chinese-issue-style     Prepend the Chinese technical-issue writing contract to the
                            injected prompt (natural short Chinese, fixed terms, structure
                            现象→根因编号→已修复→仍开放→复现→验收, ≤4 lines/paragraph,
                            self-check for translationese). Default: off. Also enabled when
                            ZFLOW_CHINESE_ISSUE_STYLE is 1/true/on/yes. Use for GitLab
                            issue/investigation notes written for colleagues; do not enable
                            for pure code/implement tasks.
  --verify-budget <text>    Append a per-task verification budget/command limit note.
  --max-commands <n>        Append a concrete max-command budget for the worker.
  --time-budget <text>      Append an approximate wall-clock budget note.
  --cwd <dir>               Working directory. Default: current directory.
  --direction <dir>         Pane split direction: right|down|left|up. Default: right.
  --tab-id <id>             Target this herdr tab id explicitly.
  --command-arg <arg>       Extra arg for the worker CLI (repeatable). Codex-family
                            workers receive --disable apps before these values by default;
                            append --command-arg --enable --command-arg apps to re-enable.
  --family <family>         Override CLI family: claude|codex|pi|grok|generic.
  --bare / --no-bare        Force adding / not adding --command-arg --bare. Default: auto — add it
                            for Claude-family CLIs ONLY when ANTHROPIC_API_KEY is set, skip
                            otherwise. --bare makes Anthropic auth strictly
                            ANTHROPIC_API_KEY/apiKeyHelper (OAuth and keychain are never read),
                            so on a claude.ai subscription login it produces a worker that
                            looks ready and then answers "Not logged in · Please run /login".
                            NOTE: codex has no --bare flag, so codex-family workers never get it.
  --effort <level>          Worker effort level. Default: high (env ZFLOW_WORKER_EFFORT).
                            Claude-family and Grok-family workers get --effort <level>
                            automatically. Allowed: low|medium|high|xhigh|max.
  --no-effort-flag          Do not inject effort CLI flags at all; rely on the worker CLI's
                            own default/inherited effort.
  --token <token>           Completion marker token. Default: derived from --name.
  --ready-pattern <str>     Prompt glyph that means "ready to inject". Default: auto — ❯ for
                            Claude-family and Grok-family CLIs, › for codex-family. Family
                            "generic" CLIs (e.g. opencode) have no reliable auto glyph and
                            must set this explicitly or the run ends in ready_timeout.
  --ready-regex <regex>     Regex used for readiness when --ready-pattern is absent. Pi defaults
                            to its horizontal editor border.
  --ready-timeout <secs>    Max wait for the worker prompt. Default: 90.
  --timeout <secs>          Max INACTIVITY wait for the WORKER_DONE marker: the
                            deadline slides forward while the pane keeps producing
                            output, so a healthy long task is never killed mid-run.
                            Default: 900.
  --max-timeout <secs>      Absolute ceiling on the marker wait from launch,
                            regardless of pane activity (bounds a runaway worker
                            that keeps printing). 0 disables the cap. Default: 21600
                            (6h). Env: ZGPT_RUN_WORKER_MAX_TIMEOUT.
  --poll <secs>             Marker poll interval. Default: 3.
  --log <path>              Launcher log path (passed through to zgpt-worker-pane.sh).
  --no-restore-focus        Leave focus on the new worker pane instead of restoring the manager pane.
  --no-effort-note          Do not append the effort/scope bound to the task.
  --close                   Graceful exit + close-pane after the marker appears.
  --allow-nested            Bypass the worker-depth guard: permit this launch even when
                            ZFLOW_WORKER_DEPTH already exceeds the nesting limit. Reserved for
                            deliberate worker-to-worker fan-out; accidental recursion is the
                            default failure the guard exists to stop.
  -h, --help                Show this help.

Depth guard:
  A worker inherits ZFLOW_WORKER_DEPTH incremented by the runner it executes in
  (depth 1 for a manager-launched worker), and this launcher refuses to start
  above ZFLOW_MAX_WORKER_DEPTH (default 0) unless --allow-nested is passed, so a
  worker can no longer silently recurse into a chain of nested workers. Raise
  ZFLOW_MAX_WORKER_DEPTH (or pass --allow-nested) only for deliberate nested
  fan-out.

Output (key=value lines):
  pane_id=<id>
  pane_label=<label>   "worker:<name> · <repo>@<branch>" applied via `herdr pane rename`.
                       Best-effort; omitted if the launcher could not produce one.
  placement_source=<source>
  target_tab_id=<id>
  status=ok|artifact_ok|ready_timeout|marker_timeout|not_logged_in
  artifact=<path>    (only when --artifact was provided)

not_logged_in:
  The worker CLI answered with "Not logged in · Please run /login". This is
  reported at the first API call, not at startup, so the pane looks ready and
  accepts the task before failing. The stored credential is typically still
  valid (`claude auth status` returns loggedIn:true before and after) and it is
  not version-specific. Serializing launches does not prevent it, so the run
  fails fast with this status instead of hanging for the full --timeout; the
  root cause is in the worker CLI, not in this script.

Exit status: 0 on status=ok or status=artifact_ok, non-zero otherwise.

Artifact-idle fallback (per LORE-131):
  The marker remains the primary completion signal. Only after the marker
  timeout elapses, if --artifact was provided, the artifact file exists, and
  the worker pane is idle/done (via herdr agent wait --until idle|done, or
  herdr agent get agent_status), the run is treated as complete: status=artifact_ok
  is emitted, artifact=<path> is still printed, and the worker pane is closed
  when --close is set. Missing artifact, missing idle/done state, or an active
  pane keeps status=marker_timeout.
EOF
}

die() { printf 'error: %s\n' "$*" >&2; exit 2; }
current_secs() { date +%s; }
positive_integer() { [[ "${1:-}" =~ ^[1-9][0-9]*$ ]]; }

script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
launcher="$script_dir/zgpt-worker-pane.sh"
source "$script_dir/zgpt-common.sh"
source "$script_dir/zgpt-cli-adapter.sh"

name=""
worker_default_cmd="${ZFLOW_WORKER_CMD:-${GPT_WORKER_CMD:-startomni-alice}}"
command_cmd=""
command_explicit=false
artifact=""
task=""
task_file=""
cwd="$PWD"
direction="right"
worker_args=()
family_override="${ZGPT_CLI_FAMILY:-}"
bare=auto
effort="${ZFLOW_WORKER_EFFORT:-high}"
effort_explicit=false
effort_flag=auto
selected_effort=""
effort_style="none"
token=""
ready_pattern=""   # empty = auto-pick by command family (see below)
ready_regex=""      # empty = auto-pick; literal ready_pattern has precedence
ready_timeout=90
timeout=900
max_timeout="${ZGPT_RUN_WORKER_MAX_TIMEOUT:-21600}"
poll=3
log_path=""
route="implement"
report_mode="none"
# Optional Chinese technical-issue writing contract. Off by default so pure code
# workers are not polluted; turn it on for issue/investigation notes.
# Env ZFLOW_CHINESE_ISSUE_STYLE=1|true|on|yes also enables (same effect as the flag).
chinese_issue_style=false
case "${ZFLOW_CHINESE_ISSUE_STYLE:-}" in
    1|true|TRUE|on|ON|yes|YES) chinese_issue_style=true ;;
esac
verify_budget=""
max_commands=""
time_budget=""
restore_focus=true
effort_note=true
close=false
allow_nested=false
tab_id=""
agent_name=""
family=""
cleanup_done=false
interrupted=false

while [[ $# -gt 0 ]]; do
    case "$1" in
        --name) name="${2:?}"; shift 2;;
        --command) command_cmd="${2:?}"; command_explicit=true; shift 2;;
        --artifact) artifact="${2:?}"; shift 2;;
        --task) task="${2:?}"; shift 2;;
        --task-file) task_file="${2:?}"; shift 2;;
        --cwd) cwd="${2:?}"; shift 2;;
        --direction) direction="${2:?}"; shift 2;;
        --tab-id) tab_id="${2:?}"; shift 2;;
        --command-arg) worker_args+=("${2:?}"); shift 2;;
        --family) family_override="${2:?}"; shift 2;;
        --bare) bare=on; shift;;
        --no-bare) bare=off; shift;;
        --effort) effort="${2:?}"; effort_explicit=true; effort_flag=on; shift 2;;
        --no-effort-flag) effort_flag=off; shift;;
        --session) export ZGPT_HERDR_SESSION="${2:?}"; shift 2;;
        --token) token="${2:?}"; shift 2;;
        --ready-pattern) ready_pattern="${2:?}"; shift 2;;
        --ready-regex) ready_regex="${2:?}"; shift 2;;
        --ready-timeout) ready_timeout="${2:?}"; shift 2;;
        --timeout) timeout="${2:?}"; shift 2;;
        --max-timeout) max_timeout="${2:?}"; shift 2;;
        --poll) poll="${2:?}"; shift 2;;
        --log) log_path="${2:?}"; shift 2;;
        --route) route="${2:?}"; shift 2;;
        --report-mode) report_mode="${2:?}"; shift 2;;
        --chinese-issue-style) chinese_issue_style=true; shift;;
        --verify-budget|--verification-budget) verify_budget="${2:?}"; shift 2;;
        --max-commands) max_commands="${2:?}"; shift 2;;
        --time-budget) time_budget="${2:?}"; shift 2;;
        --no-restore-focus) restore_focus=false; shift;;
        --no-effort-note) effort_note=false; shift;;
        --close) close=true; shift;;
        --allow-nested) allow_nested=true; shift;;
        -h|--help) usage; exit 0;;
        *) die "unknown argument: $1";;
    esac
done

[[ -n "$name" ]] || die "--name is required"
if [[ -n "$task_file" ]]; then
    [[ -f "$task_file" ]] || die "task file not found: $task_file"
    task="$(<"$task_file")"
fi
[[ -n "$task" ]] || die "provide --task or --task-file"
positive_integer "$ready_timeout" || die "--ready-timeout must be a positive integer"
positive_integer "$timeout" || die "--timeout must be a positive integer"
positive_integer "$poll" || die "--poll must be a positive integer"
{ positive_integer "$max_timeout" || [[ "$max_timeout" == "0" ]]; } || die "--max-timeout must be a positive integer or 0 (unlimited)"
case "$route" in
    implement|inspect|verify) ;;
    *) die "--route must be one of: implement, inspect, verify" ;;
esac
case "$report_mode" in
    none|compact|full) ;;
    *) die "--report-mode must be one of: none, compact, full" ;;
esac

# Worker command resolution. --command is highest precedence; otherwise the
# single configured worker command (ZFLOW_WORKER_CMD, then legacy GPT_WORKER_CMD,
# then startomni-alice).
[[ -n "$command_cmd" ]] || command_cmd="$worker_default_cmd"
[[ -n "$command_cmd" ]] || die "no worker command: pass --command <cmd> or set ZFLOW_WORKER_CMD (legacy GPT_WORKER_CMD is also honored)"

# Worker-depth guard. This MUST be a hard failure, not advisory telemetry:
# a worker that recurses today can burn hours under the sliding inactivity
# deadline, so a nested launch past the limit stops here with the opt-in spelled
# out rather than quietly continuing.
worker_depth="${ZFLOW_WORKER_DEPTH:-0}"
[[ "$worker_depth" =~ ^[0-9]+$ ]] || die "ZFLOW_WORKER_DEPTH must be a non-negative integer, got: '$ZFLOW_WORKER_DEPTH'"
depth_limit="${ZFLOW_MAX_WORKER_DEPTH:-0}"
[[ "$depth_limit" =~ ^[0-9]+$ ]] || die "ZFLOW_MAX_WORKER_DEPTH must be a non-negative integer, got: '$ZFLOW_MAX_WORKER_DEPTH'"
if [[ "$allow_nested" != true && "$worker_depth" -gt "$depth_limit" ]]; then
    die "worker depth $worker_depth exceeds the nesting limit (ZFLOW_MAX_WORKER_DEPTH=$depth_limit, default 0): refusing to launch a nested worker. This guard stops accidental worker-to-worker recursion. For deliberate nested fan-out, rerun with --allow-nested or raise ZFLOW_MAX_WORKER_DEPTH."
fi
zgpt_herdr_require        # herdr + jq must be available
zgpt_herdr_resolve_session  # sets/exports ZGPT_HERDR_SESSION (empty = default session)
[[ -x "$launcher" ]] || die "launcher not found: $launcher"

if [[ -z "$token" ]]; then
    safe="$(printf '%s' "$name" | tr -c 'A-Za-z0-9_.-' '-')"
    token="$safe-$(date +%Y%m%d-%H%M%S)"
fi

# Build the injected prompt: task substance + effort bound + split completion marker.
# The marker prefix and token are described with words between them so the echoed
# prompt never contains the literal "WORKER_DONE:<token>" (which a pane monitor,
# including one that rejoins wrapped lines, would otherwise match prematurely).
# When --artifact is provided, include file-write instructions; otherwise omit them.
prompt=""
if [[ "$chinese_issue_style" == true ]]; then
    # Prepend: GitLab issue/investigation notes for Chinese colleagues. Opt-in
    # only — pure implement workers must not get this. One-shot workers produce
    # the full structured body in one pass, following the section order.
    prompt+=$'Chinese technical-issue writing contract (mandatory for this task):\n'
    prompt+=$'- Write natural short Chinese for colleagues. No translationese, no long sentences.\n'
    prompt+=$'- Fixed terms only: 预留 (SchedulingReservation), 请求键 (requestKey), 首次试算 (firstDryRun), 标准节点资源过滤 (NodeResourcesFit). Write 根因 1 / 根因 2 in full — never invent rc1/rc2.\n'
    prompt+=$'- Structure the deliverable as: 现象 → 根因编号 → 已修复 → 仍开放 → 复现 → 验收.\n'
    prompt+=$'- At most 4 lines per paragraph; one assertion per sentence.\n'
    prompt+=$'- Keep English only for error strings, API/code identifiers, and commit/MR numbers; concepts in Chinese.\n'
    prompt+=$'- Forbidden translationese: 「对 X 不可见」「不感知」「由 X 消费」「落盘」(when meaning schedule).\n'
    prompt+=$'- Before finishing, self-check for translationese, inconsistent terms, invented abbreviations, and English-word piles in one sentence; fix them first.\n'
    prompt+=$'- If the model is deepseek-v4-flash, do not sign the note with a model name.\n'
    prompt+=$'- Interactive outline confirmation is only for live manager turns. One-shot workers write the full structured body once, still using the section order above.\n\n'
fi
prompt+="$task"
if [[ "$effort_note" == true ]]; then
    prompt+=$'\n\n'"Keep it efficient: do not run more than a handful of commands; produce the required file and stop rather than exploring further."
fi
prompt+=$'\n\n'"Worker route: $route."
case "$route" in
    inspect|verify)
        prompt+=$'\n'"Route gate: report-only. Do not edit repository files unless the task explicitly grants writable paths. This worker is the terminal executor — do not launch any nested worker (zgpt-run-worker.sh, zgpt-worker-pane.sh, zgpt-fanout.sh), do not spawn subagents, and do not use Task/Agent delegation tools. Delegating the work to a sub-worker and then reviewing its output is not an acceptable substitute for doing the work yourself."
        ;;
    implement)
        prompt+=$'\n'"Route gate: implementation is allowed only within the task's stated scope and writable paths. This worker is the terminal executor — make the edits yourself. Do not launch any worker (zgpt-run-worker.sh, zgpt-worker-pane.sh, zgpt-fanout.sh), do not spawn subagents, and do not use Task/Agent delegation tools. Delegating the edit to a sub-worker and then reviewing its diff is not an acceptable substitute for doing the work; if the task needs more than one worker, report that need and stop instead of recursing."
        ;;
esac
case "$report_mode" in
    compact)
        prompt+=$'\n'"Report mode: compact. Final report should be short: summary, commands/tests, changed files, risks."
        ;;
    full)
        prompt+=$'\n'"Report mode: full. Final report should include summary, commands, files read/changed, verification, compatibility notes, and risks."
        ;;
esac
if [[ -n "$verify_budget" || -n "$max_commands" || -n "$time_budget" ]]; then
    prompt+=$'\n'"Verification budget:"
    [[ -z "$verify_budget" ]] || prompt+=$'\n'"- $verify_budget"
    [[ -z "$max_commands" ]] || prompt+=$'\n'"- Run no more than $max_commands shell commands unless blocked."
    [[ -z "$time_budget" ]] || prompt+=$'\n'"- Target wall-clock budget: $time_budget."
fi
if [[ -n "$artifact" ]]; then
    prompt+=$'\n\n'"Write your deliverable to the file: $artifact"
    prompt+=$'\n'"Write that file as your very last action, the instant the work is done — including immediately after any git commit and push. Do not pause, wait, re-review, or look for more to do before writing it: the manager is blocked polling for this file and cannot see your progress until it appears. Writing the file, then printing the done marker below, is how you finish."
fi
prompt+=$'\n'"When finished, print on its own line the word WORKER immediately followed by _DONE: immediately followed by this exact id with no spaces: $token"

family="$(zgpt_cli_family "$command_cmd" "$family_override")"

# Resolve startup capabilities centrally. Classification uses the executable
# basename, so absolute paths and wrappers have the same behavior.
add_bare=false
case "$bare" in
    on) add_bare=true;;
    off) add_bare=false;;
    auto) zgpt_cli_startup_bare "$command_cmd" "$family_override" && add_bare=true;;
esac

# Resolve effort flags. Default is high (or ZFLOW_WORKER_EFFORT / --effort), and
# auto injection applies to Claude-family and Grok-family CLIs.
add_effort=false
selected_effort="$effort"
effort_style="claude"
case "$effort_flag" in
    on) add_effort=true;;
    off) add_effort=false;;
    auto) zgpt_cli_startup_effort "$command_cmd" "$family_override" && add_effort=true;;
esac

# Auto-pick the ready glyph by CLI family if the caller did not set --ready-pattern.
# Claude's TUI prompt is ❯; codex's is ›. Generic CLIs have no reliable glyph.
if [[ -z "$ready_pattern" && -z "$ready_regex" ]]; then
    ready_regex="$(zgpt_cli_ready_regex "$command_cmd" "$family_override")"
    if [[ -z "$ready_regex" ]]; then
        ready_pattern="$(zgpt_cli_ready_pattern "$command_cmd" "$family_override")"
    fi
fi

# 1. Launch the worker WITHOUT a prompt (interactive), so we can inject after ready.
launch_args=(--name "$name" --cwd "$cwd" --direction "$direction" --command "$command_cmd")
if [[ -n "$family_override" ]]; then
    launch_args+=(--family "$family_override")
fi
if [[ -n "$ready_pattern" ]]; then
    launch_args+=(--ready-pattern "$ready_pattern")
elif [[ -n "$ready_regex" ]]; then
    launch_args+=(--ready-regex "$ready_regex")
fi
if [[ -n "$tab_id" ]]; then
    launch_args+=(--tab-id "$tab_id")
fi
if [[ "$add_bare" == true ]]; then
    launch_args+=(--command-arg --bare)
fi
if zgpt_cli_startup_disable_apps "$command_cmd" "$family_override"; then
    launch_args+=(--command-arg --disable --command-arg apps)
fi
if [[ "$add_effort" == true ]]; then
    case "$effort_style" in
        claude)
            launch_args+=(--command-arg --effort --command-arg "$selected_effort") ;;
        *) ;;
    esac
fi
for a in ${worker_args[@]+"${worker_args[@]}"}; do
    launch_args+=(--command-arg "$a")
done
if [[ -n "$log_path" ]]; then
    launch_args+=(--log "$log_path")
fi
if [[ "$restore_focus" != true ]]; then
    launch_args+=(--no-restore-focus)
fi

launch_args+=(--print-created-tab-id)
pane_output="$("$launcher" "${launch_args[@]}")"
pane_id="$(printf '%s\n' "$pane_output" | sed -n 's/^pane_id=//p' | sed -n '1p')"
pane_label="$(printf '%s\n' "$pane_output" | sed -n 's/^pane_label=//p' | sed -n '1p')"
placement_source="$(printf '%s\n' "$pane_output" | sed -n 's/^placement_source=//p' | sed -n '1p')"
target_tab_id="$(printf '%s\n' "$pane_output" | sed -n 's/^target_tab_id=//p' | sed -n '1p')"
family="$(printf '%s\n' "$pane_output" | sed -n 's/^family=//p' | sed -n '1p')"
agent_name="$(printf '%s\n' "$pane_output" | sed -n 's/^agent_name=//p' | sed -n '1p')"
logical_name="$(printf '%s\n' "$pane_output" | sed -n 's/^name=//p' | sed -n '1p')"
[[ -n "$pane_id" ]] || die "could not parse pane_id from launcher output: $pane_output"
printf 'pane_id=%s\n' "$pane_id"
[[ -n "$pane_label" ]] && printf 'pane_label=%s\n' "$pane_label"
[[ -n "$logical_name" ]] && printf 'name=%s\n' "$logical_name"
[[ -n "$family" ]] && printf 'family=%s\n' "$family"
[[ -n "$agent_name" ]] && printf 'agent_name=%s\n' "$agent_name"
[[ -n "$placement_source" ]] && printf 'placement_source=%s\n' "$placement_source"
[[ -n "$target_tab_id" ]] && printf 'target_tab_id=%s\n' "$target_tab_id"
printf 'route=%s\n' "$route"
printf 'report_mode=%s\n' "$report_mode"
if [[ "$chinese_issue_style" == true ]]; then
    printf 'chinese_issue_style=on\n'
else
    printf 'chinese_issue_style=off\n'
fi

worker_closed=false
rebind_worker_pane() {
    local rebound=""
    if hd pane get "$pane_id" >/dev/null 2>&1; then
        return 0
    fi
    [[ -n "$agent_name" ]] || return 1
    rebound="$(zgpt_herdr_agent_pane_for_name "$agent_name" || true)"
    [[ -n "$rebound" ]] || return 1
    pane_id="$rebound"
}

close_worker_pane() {
    [[ "$close" == true || "$interrupted" == true ]] || return 0
    [[ "$worker_closed" == true ]] && return 0
    worker_closed=true
    rebind_worker_pane || true
    exit_prompt="$(zgpt_cli_exit_prompt "$command_cmd" "$family_override")"
    # pane-scoped `pane send-text` needs no agent registration (we never call
    # `agent start` for this pane), and `agent wait --until` is the current form.
    hd pane send-text "$pane_id" "$exit_prompt" >/dev/null 2>&1 || true
    rebind_worker_pane || true
    hd pane send-keys "$pane_id" Enter >/dev/null 2>&1 || true
    hd agent wait "$pane_id" --until idle --timeout 3000 >/dev/null 2>&1 || \
        hd agent wait "$pane_id" --until "done" --timeout 3000 >/dev/null 2>&1 || true
    hd pane close "$pane_id" >/dev/null 2>&1 || true
}

close_created_tab_if_owned() {
    [[ "$close" == true || "$interrupted" == true ]] || return 0
    [[ -n "${target_tab_id:-}" ]] || return 0
    local owned_tab_marker
    owned_tab_marker="$(zgpt_state_dir "$cwd")/owned-tabs/$target_tab_id"
    [[ -f "$owned_tab_marker" ]] || return 0
    # A repo tab can be shared by workers launched after this one.  Close it
    # only after our pane has gone and it contains no remaining panes.
    local workspace_id pane_count
    workspace_id="${target_tab_id%%:*}"
    pane_count="$(hd pane list --workspace "$workspace_id" 2>/dev/null \
        | jq -r --arg tab "$target_tab_id" '[.result.panes[]? | select(.tab_id == $tab)] | length' 2>/dev/null)"
    [[ "$pane_count" == "0" ]] || return 0
    rm -f "$owned_tab_marker"
    hd tab close "$target_tab_id" >/dev/null 2>&1 || true
}

cleanup_worker() {
    local rc=$?
    [[ "$cleanup_done" == true ]] && return "$rc"
    cleanup_done=true
    close_worker_pane
    close_created_tab_if_owned
    return "$rc"
}
trap 'interrupted=true; exit 130' INT TERM
trap 'cleanup_worker' EXIT

emit_and_exit() {
    local status="$1"
    if [[ "$status" == "ok" || "$status" == "artifact_ok" ]]; then
        close_created_tab_if_owned
    fi
    printf 'status=%s\n' "$status"
    [[ -n "$artifact" ]] && printf 'artifact=%s\n' "$artifact"
    [[ "$status" == "ok" || "$status" == "artifact_ok" ]] && exit 0 || exit 1
}

# 2. Wait until the worker CLI is ready to receive input. Known interactive
# families require the visible editor glyph; native idle is never sufficient.
# There is one absolute readiness deadline shared by output wait and the poll
# fallback. An immediate unsupported/error result is a fallback signal, not a
# second timeout budget.
ready_timeout_ms=$(( ready_timeout * 1000 ))
ready=false
ready_deadline=$(( $(current_secs) + ready_timeout ))
ready_settle_secs="$(zgpt_cli_ready_settle_secs "$command_cmd" "$family_override")"
positive_integer "$ready_settle_secs" || ready_settle_secs=0

read_ready_screen() {
    local screen="" rebound=""
    if ! screen="$(hd pane read "$pane_id" --source visible 2>/dev/null)"; then
        if [[ -n "$agent_name" ]]; then
            rebound="$(zgpt_herdr_agent_pane_for_name "$agent_name" || true)"
            [[ -n "$rebound" ]] && pane_id="$rebound"
        fi
        screen="$(hd pane read "$pane_id" --source visible 2>/dev/null || true)"
    fi
    printf '%s\n' "$screen"
}

maybe_settle_ready() {
    local screen="${1:-}" now remaining_secs settle_secs
    zgpt_cli_visible_output_ready "$command_cmd" "$family_override" "$screen" "$ready_pattern" "$ready_regex" || return 1
    settle_secs="$ready_settle_secs"
    if (( settle_secs > 0 )); then
        now="$(current_secs)"
        (( now < ready_deadline )) || return 1
        remaining_secs=$(( ready_deadline - now ))
        if (( settle_secs > remaining_secs )); then
            settle_secs="$remaining_secs"
        fi
        if (( settle_secs > 0 )); then
            sleep "$settle_secs"
        fi
        screen="$(read_ready_screen)"
        zgpt_cli_visible_output_ready "$command_cmd" "$family_override" "$screen" "$ready_pattern" "$ready_regex" || return 1
    fi
    return 0
}

# herdr >=0.7.5 moved top-level `wait output` under `pane wait-output`.
ready_wait_args=(pane wait-output "$pane_id" --source visible --timeout "$ready_timeout_ms")
if [[ -n "$ready_pattern" ]]; then
    ready_wait_args+=(--match "$ready_pattern")
else
    ready_wait_args+=(--regex "$ready_regex")
fi
if hd "${ready_wait_args[@]}" >/dev/null 2>&1; then
    if maybe_settle_ready "$(read_ready_screen)"; then
        ready=true
    fi
fi
while [[ "$ready" != true ]]; do
    now="$(current_secs)"
    if (( now >= ready_deadline )); then
        break
    fi
    # Re-resolve only after a pane read fails. This keeps normal pane-id mode
    # cheap while allowing a herdr pane replacement to recover by identity.
    screen="$(read_ready_screen)"
    if maybe_settle_ready "$screen"; then
        ready=true
        break
    fi
    now="$(current_secs)"
    if (( now < ready_deadline )); then
        sleep_secs="$poll"
        remaining_secs=$(( ready_deadline - now ))
        if (( sleep_secs > remaining_secs )); then
            sleep_secs="$remaining_secs"
        fi
        if (( sleep_secs < 1 )); then
            sleep_secs=1
        fi
        sleep "$sleep_secs"
    fi
done

if [[ "$ready" != true ]]; then
    printf 'zgpt-run-worker: %s not ready after %ss\n' "$name" "$ready_timeout" >&2
    emit_and_exit ready_timeout
fi

# 3. Inject the task and submit.
# Preferred path: `herdr agent prompt` (bracketed paste + auto-Enter) for
# detected agent panes. It falls back to the pane send-text + Enter dance for
# non-agent/unknown panes, herdr without `agent prompt`, and definitive prompt
# failures. Send-once semantics are preserved: an ambiguous timeout/unknown
# transport result never falls back or resends — the text may already have
# reached the TUI, and the completion loop below is the arbiter.
zgpt_herdr_prompt_inject "$pane_id" "$prompt" --rebind-fn rebind_worker_pane || true

# 4. Block until the pane transcript contains the assembled WORKER_DONE:<token> marker.
#    Build the marker at runtime by concatenating two literals so this script file
#    itself never contains the assembled string (which would cause a false positive
#    if this file's own source were ever scanned).
done_marker="WORKER""_DONE:$token"
compact_done_marker="$(printf '%s' "$done_marker" | tr -d '[:space:]')"

# read_worker_pane_lines: shared fallback logic lives in zgpt-common.sh's
# zgpt_pane_read_fallback. Rebinds by agent identity and retries once on
# failure, swallowing any further failure.
read_worker_pane_lines() {
    zgpt_pane_read_fallback rebind_worker_pane --format text
}

# text may be passed in to avoid a second pane read (the completion loop reads
# once per poll and reuses the transcript for both marker and activity checks).
worker_pane_has_done_marker() {
    local text="${1:-}" compact_text
    [[ -n "$text" ]] || text="$(read_worker_pane_lines)"
    compact_text="$(printf '%s' "$text" | tr -d '[:space:]')"
    [[ "$compact_text" == *"$compact_done_marker"* ]]
}

# worker_pane_reports_not_logged_in: a newly started Claude Code session can
# answer its first request with "Not logged in · Please run /login" while the
# stored credential is perfectly valid. It surfaces at the first API call, NOT
# at startup: the pane shows a clean ready prompt, accepts the injected task,
# and only then reports it — so this is checked during the completion wait.
worker_pane_reports_not_logged_in() {
    local text
    text="$(read_worker_pane_visible_lines)"
    [[ "$text" == *"Not logged in"* ]]
}

read_worker_pane_visible_lines() {
    local text=""
    if ! text="$(hd pane read "$pane_id" --source visible --lines 80 --format text 2>/dev/null)"; then
        rebind_worker_pane || true
        text="$(hd pane read "$pane_id" --source visible --lines 80 --format text 2>/dev/null || true)"
    fi
    printf '%s\n' "$text"
}

worker_pane_has_active_shell() {
    local text
    text="$(read_worker_pane_visible_lines)"
    printf '%s\n' "$text" | grep -qiE '[1-9][0-9]*[[:space:]]+shells?[[:space:]]+still[[:space:]]+running'
}

# worker_pane_idle_or_done: returns 0 if the worker pane's native agent state
# is idle or done and the UI does not report an active background shell;
# non-zero otherwise. Tries `herdr agent wait --until idle|done` with a short
# timeout first, then falls back to a non-blocking `herdr agent get` +
# agent_status parse.
worker_pane_idle_or_done() {
    local probe_ms=2000
    rebind_worker_pane || true
    if hd agent wait "$pane_id" --until idle --timeout "$probe_ms" >/dev/null 2>&1; then
        ! worker_pane_has_active_shell
        return
    fi
    if hd agent wait "$pane_id" --until "done" --timeout "$probe_ms" >/dev/null 2>&1; then
        ! worker_pane_has_active_shell
        return
    fi
    local agent_json native_status=""
    agent_json="$(hd agent get "$pane_id" 2>/dev/null)" || agent_json=""
    if [[ -n "$agent_json" ]]; then
        native_status="$(printf '%s\n' "$agent_json" | \
            jq -r '.result.agent.agent_status // empty' 2>/dev/null)" || native_status=""
    fi
    [[ ( "$native_status" == "idle" || "$native_status" == "done" ) ]] || return 1
    ! worker_pane_has_active_shell
}

# maybe_artifact_ok: marker-timeout fallback per LORE-131. Returns 0 and emits
# artifact_ok when all of: --artifact was provided, the artifact file exists,
# and the worker pane is idle/done. Returns non-zero otherwise (no artifact,
# missing file, or pane still active) - caller should keep status=marker_timeout.
maybe_artifact_ok() {
    [[ -n "$artifact" ]] || return 1
    [[ -f "$artifact" ]] || return 1
    if worker_pane_idle_or_done; then
        close_worker_pane
        emit_and_exit artifact_ok
    fi
    return 1
}

completion_start_secs="$(current_secs)"
# The marker deadline is an inactivity window, not a fixed wall-clock: it is
# recomputed from the last observed pane activity, so a healthy worker on a long
# task (e.g. an e2e that outlives --timeout) is never killed while it keeps
# producing output. --timeout is the inactivity window; --max-timeout is the
# absolute ceiling from launch (0 = no ceiling).
last_activity_secs="$completion_start_secs"
last_pane_text=""
while true; do
    pane_text="$(read_worker_pane_lines)"
    if worker_pane_has_done_marker "$pane_text"; then
        close_worker_pane
        emit_and_exit ok
    fi
    # Checked after the marker so a worker that legitimately finished is never
    # reclassified as a login failure just because the phrase appears earlier
    # in its scrollback.
    if worker_pane_reports_not_logged_in; then
        printf 'zgpt-run-worker: %s reported "Not logged in" — the worker CLI cannot reach the API\n' "$name" >&2
        close_worker_pane
        emit_and_exit not_logged_in
    fi
    now="$(current_secs)"
    # Activity = transcript changed since the last observation. Content-based
    # inequality is deliberately conservative: any change (append, truncation,
    # resync) counts as progress, which only ever errs toward NOT killing a live
    # worker. The first read only establishes the baseline.
    if [[ -n "$last_pane_text" && "$pane_text" != "$last_pane_text" ]]; then
        last_activity_secs="$now"
    fi
    [[ -n "$pane_text" ]] && last_pane_text="$pane_text"
    completion_deadline="$(zgpt_sliding_deadline "$last_activity_secs" "$timeout" "$completion_start_secs" "$max_timeout")"
    if (( now >= completion_deadline )); then
        break
    fi
    remaining_secs=$(( completion_deadline - now ))
    wait_chunk_secs="$poll"
    if (( wait_chunk_secs < 1 )); then
        wait_chunk_secs=1
    fi
    if (( wait_chunk_secs > remaining_secs )); then
        wait_chunk_secs="$remaining_secs"
    fi
    wait_chunk_ms=$(( wait_chunk_secs * 1000 ))
    if hd pane wait-output "$pane_id" --match "$done_marker" --source recent-unwrapped --lines 99999 \
        --timeout "$wait_chunk_ms" >/dev/null 2>&1; then
        close_worker_pane
        emit_and_exit ok
    fi
    # Unsupported waits return immediately; keep the same sliding deadline while
    # avoiding a busy loop before the next normalized pane read. Output produced
    # during the wait is credited on the next iteration via the activity check.
    now="$(current_secs)"
    if (( now < completion_deadline )); then
        sleep_secs="$poll"
        remaining_secs=$(( completion_deadline - now ))
        if (( sleep_secs > remaining_secs )); then
            sleep_secs="$remaining_secs"
        fi
        if (( sleep_secs < 1 )); then
            sleep_secs=1
        fi
        sleep "$sleep_secs"
    fi
done

printf 'zgpt-run-worker: %s marker not seen after %ss of inactivity (absolute cap %ss, token: %s)\n' "$name" "$timeout" "$max_timeout" "$token" >&2
maybe_artifact_ok || emit_and_exit marker_timeout
