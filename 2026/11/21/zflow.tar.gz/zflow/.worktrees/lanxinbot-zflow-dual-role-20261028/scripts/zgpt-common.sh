#!/usr/bin/env bash
# Shared helpers for the zgpt-* scripts. Source near the top of each script:
#   source "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/zgpt-common.sh"

zgpt_repo_name_for_cwd() {
    local cwd="${1:-$PWD}"
    local common_dir repo_dir superproject
    if command -v git >/dev/null && superproject="$(git -C "$cwd" rev-parse --show-superproject-working-tree 2>/dev/null)" && [[ -n "$superproject" ]]; then
        repo_dir="$(git -C "$cwd" rev-parse --show-toplevel 2>/dev/null || true)"
        [[ -n "$repo_dir" ]] && { basename "$repo_dir"; return 0; }
    fi
    if command -v git >/dev/null && common_dir="$(git -C "$cwd" rev-parse --path-format=absolute --git-common-dir 2>/dev/null)"; then
        case "$common_dir" in
            */.git) repo_dir="${common_dir%/.git}" ;;
            *) repo_dir="$(git -C "$cwd" rev-parse --path-format=absolute --show-toplevel 2>/dev/null || true)" ;;
        esac
        if [[ -n "${repo_dir:-}" && -d "$repo_dir" ]]; then
            basename "$repo_dir"
            return 0
        fi
    fi
    basename "$cwd"
}

zgpt_repo_tab_name() {
    local cwd="${1:-$PWD}"
    printf 'agents:%s\n' "$(zgpt_repo_name_for_cwd "$cwd")"
}

# Choose a pane split direction from a pane's live rect. Terminal character
# cells are about 2:1 tall:wide, so a pane whose width exceeds twice its
# height is "wide" — split it vertically (right) along its long edge; a tall
# pane splits horizontally (down). width == 2*height is square-ish in cell
# units and falls back to down (herdr's default-friendly axis).
zgpt_split_direction_for_rect() {
    local w="${1:-0}" h="${2:-0}"
    if [[ "$w" =~ ^[0-9]+$ && "$h" =~ ^[0-9]+$ ]] && (( w > h * 2 )); then
        printf 'right\n'
    else
        printf 'down\n'
    fi
}

# Compute the herdr `pane split --ratio` that gives a fresh worker pane a fair
# share of its tab. `herdr pane split --ratio R` keeps R of the split axis with
# the ORIGINAL pane and gives the new pane (1-R) of it (verified live against
# herdr 0.8.0), so new pane area == anchor_area * (1 - R).
#
# Args: <anchor_w> <anchor_h> <tab_w> <tab_h> <n> <direction>
#   n is the number of panes already in the tab (the new pane makes n+1).
#   direction is accepted for signature completeness; the area math is the same
#   for right and down splits (the new pane spans the anchor's full short axis
#   either way), so the ratio is axis-independent.
#
# Target: new pane area == tab_area / (n+1) (equal shares). A binary split tree
# cannot tile every n into exact equal rectangles — 3 and 5 equal panes are
# impossible, only powers of two tile exactly — and splitting the roomiest pane
# at the exact fair share leaves a sliver when the anchor is barely above the
# mean. Cap the new pane at half the anchor instead: splitting the largest pane
# into two near-equal pieces keeps every pane in the tab within 2x of the
# smallest (max/min ratio <= 2), which is the acceptance bound we can actually
# guarantee. In a balanced layout the cap is what fires, so the ratio comes out
# 0.5 — split the roomiest pane in half along its long edge. The clamp keeps a
# degenerate input from producing a ratio herdr would reject.
zgpt_split_ratio_for_equal_share() {
    # shellcheck disable=SC2034 # direction kept for signature parity; ratio is axis-independent
    local anchor_w="${1:-0}" anchor_h="${2:-0}" tab_w="${3:-0}" tab_h="${4:-0}" n="${5:-1}" direction="${6:-down}"
    local anchor_area tab_area target new_pane
    anchor_area=$((anchor_w * anchor_h))
    tab_area=$((tab_w * tab_h))
    if (( anchor_area <= 0 )) || (( tab_area <= 0 )) || [[ ! "$n" =~ ^[0-9]+$ ]]; then
        printf '0.5\n'
        return 0
    fi
    target=$((tab_area / (n + 1)))
    if (( target > anchor_area / 2 )); then
        new_pane=$((anchor_area / 2))
    else
        new_pane="$target"
    fi
    awk -v a="$anchor_area" -v x="$new_pane" 'BEGIN { r = 1 - x / a; if (r < 0.05) r = 0.05; if (r > 0.95) r = 0.95; printf "%.4f\n", r }'
}

# Strip control chars/newlines and collapse whitespace to single spaces.
zgpt__pane_label_sanitize() {
    local s="${1-}"
    s="$(printf '%s' "$s" | tr -d '\000-\010\013\014\016-\037\177')"
    s="$(printf '%s' "$s" | tr '\n\r\t' '   ')"
    s="$(printf '%s' "$s" | tr -s ' ')"
    s="${s#"${s%%[![:space:]]*}"}"
    s="${s%"${s##*[![:space:]]}"}"
    printf '%s' "$s"
}

# Build the pane label: "<role>:<name> · <repo>@<branch>".
# role     worker (the two-role model has only managers-as-sessions and workers;
#          the only pane role is "worker").
# name     free-form worker name; sanitized and truncated first when the
#          overall label would exceed the length cap.
# cwd      working directory the worker runs in; used to resolve repo/branch.
#
# repo comes from zgpt_repo_name_for_cwd (worktree-aware via git common dir).
# branch is `git rev-parse --abbrev-ref HEAD`; detached HEAD falls back to a
# short sha. The whole "@<branch>" segment is omitted when git is unavailable
# or cwd is not a repo, so a label never claims a branch that doesn't exist.
zgpt_pane_label() {
    local role="${1:-worker}" name="${2:-}" cwd="${3:-$PWD}"
    local cap=64
    local sep=$'\xc2\xb7' # U+00B7 MIDDLE DOT, UTF-8
    case "$role" in
        worker) ;;
        *) role="worker" ;;
    esac

    name="$(zgpt__pane_label_sanitize "$name")"

    local repo_branch=""
    if command -v git >/dev/null && [[ -d "$cwd" ]] && git -C "$cwd" rev-parse --is-inside-work-tree >/dev/null 2>&1; then
        local repo branch
        repo="$(zgpt_repo_name_for_cwd "$cwd")"
        branch="$(git -C "$cwd" rev-parse --abbrev-ref HEAD 2>/dev/null || true)"
        if [[ "$branch" == "HEAD" || -z "$branch" ]]; then
            branch="$(git -C "$cwd" rev-parse --short HEAD 2>/dev/null || true)"
        fi
        if [[ -n "$repo" && -n "$branch" ]]; then
            repo_branch="$(zgpt__pane_label_sanitize "$repo")@$(zgpt__pane_label_sanitize "$branch")"
        fi
    fi

    local prefix="${role}:"
    local suffix=""
    [[ -n "$repo_branch" ]] && suffix=" ${sep} ${repo_branch}"

    # Truncate the NAME segment first so "repo@branch" survives when the
    # combined label would exceed the length cap.
    local fixed_len=$(( ${#prefix} + ${#suffix} ))
    local max_name_len=$(( cap - fixed_len ))
    if (( max_name_len < 0 )); then
        max_name_len=0
    fi
    if (( ${#name} > max_name_len )); then
        name="${name:0:max_name_len}"
    fi

    printf '%s%s%s' "$prefix" "$name" "$suffix"
}

zgpt_git_common_dir_for_cwd() {
    local cwd="${1:-$PWD}"
    local common_dir
    [[ -d "$cwd" ]] || return 1
    command -v git >/dev/null || return 1
    common_dir="$(git -C "$cwd" rev-parse --path-format=absolute --git-common-dir 2>/dev/null)" || return 1
    [[ -n "$common_dir" ]] || return 1
    (cd "$common_dir" 2>/dev/null && pwd -P)
}

zgpt_cwd_belongs_to_repo() {
    local target_cwd="${1:-}"
    local candidate_cwd="${2:-}"
    local target_common candidate_common target_real candidate_real

    [[ -n "$target_cwd" && -d "$target_cwd" ]] || return 1
    [[ -n "$candidate_cwd" && -d "$candidate_cwd" ]] || return 1

    if target_common="$(zgpt_git_common_dir_for_cwd "$target_cwd")"; then
        candidate_common="$(zgpt_git_common_dir_for_cwd "$candidate_cwd")" || return 1
        [[ "$candidate_common" == "$target_common" ]]
        return $?
    fi

    target_real="$(cd "$target_cwd" 2>/dev/null && pwd -P)" || return 1
    candidate_real="$(cd "$candidate_cwd" 2>/dev/null && pwd -P)" || return 1
    [[ "$candidate_real" == "$target_real" || "$candidate_real" == "$target_real"/* ]]
}

# ── Runtime state directory helpers ──────────────────────────────────────────
# All generated .agent-style run data, worker logs, and managed worker worktrees
# default under /tmp/zflow (override with ZFLOW_STATE_ROOT).  The path
# distinguishes repo and worktree so parallel checkouts never collide.

# Default root for all runtime state.  Override with ZFLOW_STATE_ROOT.
zgpt_state_root() {
    printf '%s' "${ZFLOW_STATE_ROOT:-/tmp/zflow}"
}

# Per-checkout state directory: <root>/<repo>/<worktree_id>
# - main worktree  → "main"
# - linked worktree → worktree basename (safe deterministic identifier)
zgpt_state_dir() {
    local cwd="${1:-$PWD}"
    local root repo_name git_dir wt_id
    root="$(zgpt_state_root)"
    if command -v git >/dev/null; then
        repo_name="$(zgpt_repo_name_for_cwd "$cwd")"
        git_dir="$(git -C "$cwd" rev-parse --git-dir 2>/dev/null)" || git_dir=""
        case "$git_dir" in
            */.git/worktrees/*)
                wt_id="$(basename "$git_dir")" ;;
            *)
                wt_id="main" ;;
        esac
        printf '%s/%s/%s' "$root" "$repo_name" "$wt_id"
    else
        printf '%s/unknown/%s' "$root" "$(basename "$cwd")"
    fi
}

# ── Marker-wait deadline helpers ─────────────────────────────────────────────
# zgpt-run-worker.sh waits for a WORKER_DONE marker. The wait is an inactivity
# window rather than a fixed wall-clock: the deadline slides forward whenever
# the pane produces new output, so a healthy long task (e.g. an e2e that
# outlives --timeout) is never killed mid-run. --max-timeout is an absolute
# ceiling from launch that bounds a runaway worker that keeps printing.

# Pure arithmetic: deadline = last_activity + inactivity, capped at
# (start + max_timeout) when max_timeout > 0. max_timeout == 0 means no cap.
zgpt_sliding_deadline() {
    local last_activity="${1:-}" inactivity="${2:-}" start="${3:-}" max_timeout="${4:-}"
    local d=$(( last_activity + inactivity ))
    if (( max_timeout > 0 )); then
        local ceiling=$(( start + max_timeout ))
        (( d > ceiling )) && d="$ceiling"
    fi
    printf '%s' "$d"
}

# Herdr helpers.

# Require herdr and jq are available; exit 1 with a message if not.
zgpt_herdr_require() {
    command -v herdr >/dev/null || { printf 'error: herdr not found\n' >&2; exit 1; }
    command -v jq >/dev/null || { printf 'error: jq is required for herdr helpers\n' >&2; exit 1; }
}

# Resolve the herdr session to drive. Exports ZGPT_HERDR_SESSION (empty = use
# herdr's implicit default, i.e. no --session flag needed).
# Precedence:
#   1. ZGPT_HERDR_SESSION already set.
#   2. HERDR_SESSION env var.
#   3. The sole running non-default session (rare: multi-session).
#   4. "" (empty) → herdr's default session (most common case).
zgpt_herdr_resolve_session() {
    if [[ -n "${ZGPT_HERDR_SESSION:-}" ]]; then
        export ZGPT_HERDR_SESSION
        return 0
    fi
    if [[ -n "${HERDR_SESSION:-}" ]]; then
        ZGPT_HERDR_SESSION="$HERDR_SESSION"
        export ZGPT_HERDR_SESSION
        return 0
    fi
    local json running_count sname
    json="$(herdr session list --json 2>/dev/null)" || json=''
    running_count="$(printf '%s\n' "$json" | jq -r '[.sessions[] | select(.running == true)] | length' 2>/dev/null)" || running_count=0
    if [[ "$running_count" == "1" ]]; then
        sname="$(printf '%s\n' "$json" | jq -r '[.sessions[] | select(.running == true)][0].name' 2>/dev/null)"
        # Only set --session when name is non-default (default session needs no flag)
        if [[ -n "$sname" && "$sname" != "default" ]]; then
            ZGPT_HERDR_SESSION="$sname"
        else
            ZGPT_HERDR_SESSION=""
        fi
    else
        ZGPT_HERDR_SESSION=""
    fi
    export ZGPT_HERDR_SESSION
    return 0
}

# Run herdr against the resolved session (works with or without a named session).
hd() {
    if [[ -n "${ZGPT_HERDR_SESSION:-}" ]]; then
        herdr --session "$ZGPT_HERDR_SESSION" "$@"
    else
        herdr "$@"
    fi
}

# Return 0 when the installed herdr supports `herdr agent prompt` (first
# available in 0.8.0). Probes the subcommand once per process and caches the
# result in ZGPT_HERDR_HAS_AGENT_PROMPT (1=yes, 0=no); parsing `herdr --version`
# is fragile across output formats, so probing the subcommand is the gate. When
# absent, zgpt_herdr_prompt_inject no-ops straight to the pane dance.
zgpt_herdr_has_agent_prompt() {
    if [[ -n "${ZGPT_HERDR_HAS_AGENT_PROMPT:-}" ]]; then
        [[ "$ZGPT_HERDR_HAS_AGENT_PROMPT" == "1" ]]
        return
    fi
    local cap=0
    if hd agent prompt --help >/dev/null 2>&1; then
        cap=1
    fi
    ZGPT_HERDR_HAS_AGENT_PROMPT="$cap"
    [[ "$cap" == "1" ]]
}

# Preferred task/steer injection: `herdr agent prompt` (bracketed paste +
# auto-Enter) for detected agent panes, falling back to the pane send-text +
# send-keys Enter dance for non-agent/unknown panes, herdr without `agent
# prompt`, and definitive prompt failures.
#
# Send-once doctrine (preserved from the pane dance): a *definitive* `agent
# prompt` failure (agent_not_running / agent_not_detected / unknown command /
# socket refused) means nothing reached the TUI, so falling back is safe. An
# ambiguous outcome (stalled/timeout, or any unclassified error) may mean the
# text already reached the editor before the socket failed — do NOT fall back
# or resend; return the prompt's exit status and let the caller's completion
# loop (WORKER_DONE marker / artifact) decide.
#
# Args: <pane_id> <text> [opts...]
#   --settle <secs>    fallback-path settle before the (second) Enter. Default 2.
#   --double-enter <always|large|never>
#                      always  -> run-worker dance: send-text, Enter (retry once
#                                  w/ rebind), sleep, Enter — the delayed second
#                                  Enter is not cosmetic (zgpt-run-worker.sh).
#                                  Default.
#                      large   -> steer dance: sleep, Enter, then a second Enter
#                                  only for >80-char / multi-line text.
#                      never   -> single Enter, no second.
#   --wait             pass --wait --timeout to agent prompt (bounded acceptance
#                      ack for steering). Default fire-and-forget: completion
#                      stays with the marker/artifact loop, never `agent wait`.
#   --wait-ms <ms>     timeout for --wait. Default 120000.
#   --rebind-fn <fn>   zero-arg function to re-resolve $pane_id on a pane-dance
#                      failure (pane moves); must reassign the caller's pane_id.
zgpt_herdr_prompt_inject() {
    local pane_id="${1:-}" text="${2:-}"
    shift 2 || true
    [[ -n "$pane_id" && -n "$text" ]] || return 1
    local settle="2" double_mode="always" wait_flag=0 wait_ms="120000" rebind_fn=""
    while [[ $# -gt 0 ]]; do
        case "$1" in
            --settle) settle="${2:-2}"; shift 2 ;;
            --double-enter) double_mode="${2:-always}"; shift 2 ;;
            --wait) wait_flag=1; shift ;;
            --wait-ms) wait_ms="${2:-120000}"; shift 2 ;;
            --rebind-fn) rebind_fn="${2:-}"; shift 2 ;;
            *) break ;;
        esac
    done

    if zgpt_herdr_has_agent_prompt; then
        local args=(agent prompt "$pane_id" "$text")
        if [[ "$wait_flag" == "1" ]]; then
            args+=(--wait --timeout "$wait_ms")
        fi
        local out="" rc=0
        out="$(hd "${args[@]}" 2>&1)" && rc=0 || rc=$?
        if [[ "$rc" == "0" ]]; then
            return 0
        fi
        # Ambiguous outcomes: the text may have landed — never fall back/resend.
        case "$out" in
            *stalled*|*timeout*|*timed*out*|*timed-out*)
                return "$rc" ;;
        esac
        # Definitive failures fall through to the pane dance below.
        case "$out" in
            *agent_not_running*|*agent_not_detected*|*not*detected*|*no*agent*|*unknown*command*|*command*not*found*|*socket*refused*|*not*supported*|*does*not*support*) ;;
            *) return "$rc" ;;
        esac
    fi

    # Fallback pane dance. Send-once doctrine applies here too: pane
    # send/read failures are swallowed, never retried as a fresh paste.
    if [[ "$double_mode" == "always" ]]; then
        hd pane send-text "$pane_id" "$text" >/dev/null 2>&1 || true
        if [[ -n "$rebind_fn" ]]; then "$rebind_fn" || true; fi
        hd pane send-keys "$pane_id" Enter >/dev/null 2>&1 || {
            if [[ -n "$rebind_fn" ]]; then "$rebind_fn" || true; fi
            hd pane send-keys "$pane_id" Enter >/dev/null 2>&1 || true
        }
        sleep "$settle"
        if [[ -n "$rebind_fn" ]]; then "$rebind_fn" || true; fi
        hd pane send-keys "$pane_id" Enter >/dev/null 2>&1 || true
    else
        hd pane send-text "$pane_id" "$text" >/dev/null 2>&1 || true
        sleep "$settle"
        hd pane send-keys "$pane_id" Enter >/dev/null 2>&1 || true
        if [[ "$double_mode" == "large" && ( "${#text}" -gt 80 || "$text" == *$'\n'* ) ]]; then
            sleep "$settle"
            hd pane send-keys "$pane_id" Enter >/dev/null 2>&1 || true
        fi
    fi
    return 0
}

# Return the native herdr agent_status of a pane (idle|working|blocked|done|...)
# or empty when unknown. Non-blocking: one `herdr agent get` call.
zgpt_herdr_agent_status() {
    local pane_id="${1:-}"
    [[ -n "$pane_id" ]] || return 1
    hd agent get "$pane_id" 2>/dev/null |
        jq -r '.result.agent.agent_status // empty' |
        sed -n '1p'
}

# Return 0 when the pane_id resolves to a live herdr pane, 1 otherwise.
# `pane get` is the authoritative existence probe (distinct from agent state:
# a pane may exist with no agent).
zgpt_herdr_pane_exists() {
    local pane_id="${1:-}" json
    [[ -n "$pane_id" ]] || return 1
    json="$(hd pane get "$pane_id" 2>/dev/null || true)"
    [[ -n "$json" ]] || return 1
    printf '%s' "$json" | jq -e '.result.pane.pane_id != null' >/dev/null 2>&1
}

# Map a herdr pane_id (e.g. "w1:p5") to its owning tab_id via `herdr pane get`.
zgpt_herdr_tab_id_for_pane() {
    local pane_id="${1:-}"
    [[ -n "$pane_id" ]] || return 1
    hd pane get "$pane_id" 2>/dev/null |
        jq -r '.result.pane.tab_id // empty' |
        sed -n '1p'
}

# Find a tab_id by its label. Returns the first match.
zgpt_herdr_tab_id_for_label() {
    local label="${1:-}"
    [[ -n "$label" ]] || return 1
    hd tab list 2>/dev/null |
        jq -r --arg lbl "$label" '.result.tabs[] | select(.label == $lbl) | .tab_id' |
        sed -n '1p'
}

# Get a tab's label by tab_id.
zgpt_herdr_tab_label_for_id() {
    local tab_id="${1:-}"
    [[ -n "$tab_id" ]] || return 1
    hd tab get "$tab_id" 2>/dev/null |
        jq -r '.result.tab.label // empty' |
        sed -n '1p'
}

# Choose the pane to split in a tab using live geometry, never pane order.
# Excludes panes whose label (from `herdr pane list`) starts with human: —
# the human pane is not splittable land.
# Among the rest picks the pane with the largest rect area (width * height);
# ties break on width, then on the lexicographically smaller pane id.
#
# Live pane count and geometry come from `herdr pane layout --pane <id>` for a
# pane id known to exist in the tab, NOT from `herdr pane list`, which lags the
# layout and can list ghost panes herdr has already reaped: a ghost is never a
# candidate and never counts toward the 6-pane cap. Labels only come from
# `pane list` (layout carries none).
#
# Prints key=value lines:
#   anchor_pane_id=<id> anchor_width=<w> anchor_height=<h>
#   tab_width=<w> tab_height=<h> pane_count=<n>
# and returns 0. Returns 1 when the tab already has >= 6 live panes, or holds
# no splittable pane at all (only the human pane, or no layout data).
zgpt_herdr_anchor_for_tab() {
    local tab_id="${1:-}"
    [[ -n "$tab_id" ]] || return 1
    local ws="${tab_id%%:*}"
    local list_json layout count
    list_json="$(hd pane list --workspace "$ws" 2>/dev/null || true)"
    # Probe panes listed in the tab until one yields a real layout: `pane list`
    # lags the layout, so the first listed pane may already be a ghost that
    # `pane layout` no longer knows about. Only a layout whose .result.layout
    # actually carries a panes array counts.
    local probe_pane cand
    layout=""
    while IFS= read -r probe_pane; do
        [[ -n "$probe_pane" ]] || continue
        cand="$(hd pane layout --pane "$probe_pane" 2>/dev/null || true)"
        [[ -n "$cand" ]] || continue
        if printf '%s\n' "$cand" | jq -e '(.result.layout.panes | type) == "array"' >/dev/null 2>&1; then
            layout="$cand"
            break
        fi
    done < <(printf '%s\n' "$list_json" | jq -r --arg t "$tab_id" '.result.panes[]? | select(.tab_id == $t) | .pane_id')
    [[ -n "$layout" ]] || return 1
    count="$(printf '%s\n' "$layout" | jq '[.result.layout.panes[]?] | length' 2>/dev/null)"
    [[ "$count" =~ ^[0-9]+$ ]] || return 1
    (( count >= 6 )) && return 1

    local area_w area_h
    area_w="$(printf '%s\n' "$layout" | jq -r '.result.layout.area.width' 2>/dev/null)"
    area_h="$(printf '%s\n' "$layout" | jq -r '.result.layout.area.height' 2>/dev/null)"
    [[ "$area_w" =~ ^[0-9]+$ ]] || area_w=0
    [[ "$area_h" =~ ^[0-9]+$ ]] || area_h=0

    local pane_id w h area lbl
    local best_id="" best_area=-1 best_w=-1 best_h=0
    while IFS= read -r pane_id; do
        [[ -n "$pane_id" ]] || continue
        w="$(printf '%s\n' "$layout" | jq -r --arg p "$pane_id" '.result.layout.panes[]? | select(.pane_id == $p) | .rect.width' 2>/dev/null)"
        h="$(printf '%s\n' "$layout" | jq -r --arg p "$pane_id" '.result.layout.panes[]? | select(.pane_id == $p) | .rect.height' 2>/dev/null)"
        [[ "$w" =~ ^[0-9]+$ && "$h" =~ ^[0-9]+$ ]] || continue
        lbl="$(printf '%s\n' "$list_json" | jq -r --arg p "$pane_id" '[.result.panes[]? | select(.pane_id == $p) | .label // null][0] // ""' 2>/dev/null)"
        case "$lbl" in
            human:*) continue ;;
        esac
        area=$((w * h))
        if (( area > best_area )) \
            || { (( area == best_area )) && (( w > best_w )); } \
            || { (( area == best_area )) && (( w == best_w )) && [[ -n "$best_id" ]] && [[ "$pane_id" < "$best_id" ]]; }; then
            best_area="$area"; best_w="$w"; best_h="$h"; best_id="$pane_id"
        fi
    done < <(printf '%s\n' "$layout" | jq -r '.result.layout.panes[]? | .pane_id')
    [[ -n "$best_id" ]] || return 1

    printf 'anchor_pane_id=%s\n' "$best_id"
    printf 'anchor_width=%s\n' "$best_w"
    printf 'anchor_height=%s\n' "$best_h"
    printf 'tab_width=%s\n' "$area_w"
    printf 'tab_height=%s\n' "$area_h"
    printf 'pane_count=%s\n' "$count"
    return 0
}

# Return 0 if the pane_id looks like a valid herdr pane id (e.g. "w1:p5" or "wB:p5"),
# return 1 if it is a legacy bare integer (e.g. "65") or some other format
# herdr would reject.
zgpt_herdr_is_herdr_pane_id() {
    local pid="${1:-}"
    # herdr pane ids match "w<alnum>:p<alnum>" (workspace:pane).
    [[ "$pid" =~ ^w[0-9A-Za-z]+:p[0-9A-Za-z]+$ ]]
}

# Resolve a live pane through the unique herdr agent identity. This is used
# only after a pane operation fails; callers retain pane-id mode when no agent
# name was supplied.
zgpt_herdr_agent_pane_for_name() {
    local agent_name="${1:-}" json pane_id
    [[ -n "$agent_name" ]] || return 1
    json="$(hd agent get "$agent_name" 2>/dev/null || true)"
    pane_id="$(printf '%s\n' "$json" | jq -r '.result.agent.pane_id // empty' 2>/dev/null | sed -n '1p')"
    if [[ -n "$pane_id" ]]; then
        printf '%s\n' "$pane_id"
        return 0
    fi
    json="$(hd agent list 2>/dev/null || true)"
    pane_id="$(printf '%s\n' "$json" | jq -r --arg n "$agent_name" '
        .result.agents[]? | select((.name // .agent_name // .id) == $n) | .pane_id // .pane.pane_id // empty' 2>/dev/null | sed -n '1p')"
    [[ -n "$pane_id" ]] || return 1
    printf '%s\n' "$pane_id"
}

# Used by zgpt-run-worker.sh to poll a herdr pane's transcript: prefer the
# recent-unwrapped source (it reconstructs hard-wrapped markers) and fall back
# to the visible buffer when recent-unwrapped comes back empty.
#
# Deliberately operates on the caller's global $pane_id instead of taking it
# as a parameter: a rebind_fn that reassigns $pane_id must be visible to the
# retry read below without a bash 4.3+ nameref (this file stays Bash 3.2
# compatible), and both current callers already maintain $pane_id at file
# scope the same way the original per-file implementations did.
#
# Args: <rebind_fn> [format_args...]
#   rebind_fn    Name of a zero-arg function to call (and retry once) when a
#                read fails, swallowing any further failure so this always
#                returns 0 -- e.g. run-worker's rebind_worker_pane. Pass ""
#                to propagate a read failure immediately (return 1) instead,
#                for callers (e.g. watch-pane) that rebind and retry
#                themselves.
#   format_args  Extra args forwarded to `hd pane read`, e.g. --format text.
# shellcheck disable=SC2154 # pane_id: caller-scoped global, see above
zgpt_pane_read_fallback() {
    local rebind_fn="${1:-}"
    shift || true
    local text=""
    if ! text="$(hd pane read "$pane_id" --source recent-unwrapped --lines 99999 "$@" 2>/dev/null)"; then
        if [[ -n "$rebind_fn" ]]; then
            "$rebind_fn" || true
            text="$(hd pane read "$pane_id" --source recent-unwrapped --lines 99999 "$@" 2>/dev/null || true)"
        else
            return 1
        fi
    fi
    if [[ -z "$text" ]]; then
        if ! text="$(hd pane read "$pane_id" --source visible --lines 99999 "$@" 2>/dev/null)"; then
            if [[ -n "$rebind_fn" ]]; then
                "$rebind_fn" || true
                text="$(hd pane read "$pane_id" --source visible --lines 99999 "$@" 2>/dev/null || true)"
            else
                return 1
            fi
        fi
    fi
    printf '%s\n' "$text"
}

# Resolve target placement metadata using herdr primitives. Prints key=value
# lines suitable for logs and CLI output.
#
# Precedence:
#   1. explicit --tab-id
#   2. ZGPT_TAB_ID / ZJ_TAB_ID
#   3. ZGPT_MANAGER_PANE_ID / ZJ_PANE_ID
#   4. herdr pane current
#   5. herdr pane process-info --current + pane get
#   6. repo-tab fallback
zgpt_herdr_resolve_target_placement() {
    local explicit_tab_id="${1:-}"
    local cwd="${2:-$PWD}"

    local placement_source=""
    local target_tab_id=""
    local manager_pane_id=""
    local placement_reason=""
    local created_tab_id=""

    # A managed repo tab is a stable destination.  Prefer it over incidental
    # current-pane state inherited from an earlier worker in that tab.  Only a
    # repo tab that can actually host another worker counts: fewer than 6 live
    # panes and at least one non-human pane to split from.  A tab whose only
    # pane is the human pane is skipped, so a worker never splits the human's
    # pane (which lives in agents:<repo>).
    local managed_repo_tab_id=""
    managed_repo_tab_id="$(zgpt_herdr_find_suitable_repo_tab "$cwd" || true)"

    if [[ -n "$explicit_tab_id" ]]; then
        placement_source="explicit-tab-id"
        target_tab_id="$explicit_tab_id"
    elif [[ -n "${ZGPT_TAB_ID:-${ZJ_TAB_ID:-}}" ]]; then
        placement_source="env-tab-id"
        target_tab_id="${ZGPT_TAB_ID:-${ZJ_TAB_ID:-}}"
    elif [[ -n "${ZGPT_MANAGER_PANE_ID:-${ZJ_PANE_ID:-}}" ]]; then
        manager_pane_id="${ZGPT_MANAGER_PANE_ID:-${ZJ_PANE_ID:-}}"
        if zgpt_herdr_is_herdr_pane_id "$manager_pane_id"; then
            placement_source="env-manager-pane"
            target_tab_id="$(zgpt_herdr_tab_id_for_pane "$manager_pane_id")"
            [[ -n "$target_tab_id" ]] || {
                printf 'error: no tab found for manager pane id: %s\n' "$manager_pane_id" >&2
                return 2
            }
        fi
    fi

    if [[ -z "$target_tab_id" && -n "$managed_repo_tab_id" ]]; then
        placement_source="managed-repo-tab"
        target_tab_id="$managed_repo_tab_id"
    fi

    if [[ -z "$target_tab_id" ]]; then
        local probe pane_id tab_id pane_cwd
        probe="$(hd pane current 2>/dev/null || true)"
        if [[ -n "$probe" ]]; then
            pane_id="$(printf '%s\n' "$probe" | jq -r '.result.pane.pane_id // empty' 2>/dev/null | sed -n '1p')"
            tab_id="$(printf '%s\n' "$probe" | jq -r '.result.pane.tab_id // empty' 2>/dev/null | sed -n '1p')"
            pane_cwd="$(printf '%s\n' "$probe" | jq -r '.result.pane.foreground_cwd // .result.pane.cwd // .result.pane.workspace.cwd // .result.workspace.cwd // empty' 2>/dev/null | sed -n '1p')"
            if [[ -n "$tab_id" && -n "$pane_cwd" ]]; then
                if zgpt_cwd_belongs_to_repo "$cwd" "$pane_cwd"; then
                    placement_source="herdr-pane-current"
                    manager_pane_id="$pane_id"
                    target_tab_id="$tab_id"
                else
                    placement_reason="current pane cwd is outside target repo"
                fi
            elif [[ -n "$tab_id" ]]; then
                placement_reason="current pane cwd unavailable"
            fi
        fi
    fi

    if [[ -z "$target_tab_id" ]]; then
        local current_json current_pane_id current_cwd
        current_json="$(hd pane process-info --current 2>/dev/null || true)"
        if [[ -n "$current_json" ]]; then
            current_pane_id="$(printf '%s\n' "$current_json" | jq -r '.result.process_info.pane_id // empty' 2>/dev/null | sed -n '1p')"
            current_cwd="$(printf '%s\n' "$current_json" | jq -r '.result.process_info.foreground_cwd // ([.result.process_info.foreground_processes[]?.cwd // empty] | last) // empty' 2>/dev/null | sed -n '1p')"
            if [[ -n "$current_pane_id" && -n "$current_cwd" ]]; then
                if zgpt_cwd_belongs_to_repo "$cwd" "$current_cwd"; then
                    target_tab_id="$(zgpt_herdr_tab_id_for_pane "$current_pane_id")"
                    [[ -n "$target_tab_id" ]] || {
                        printf 'error: could not resolve tab for manager pane id: %s\n' "$current_pane_id" >&2
                        return 2
                    }
                    placement_source="herdr-process-info-current"
                    manager_pane_id="$current_pane_id"
                else
                    placement_reason="current process cwd is outside target repo"
                fi
            elif [[ -n "$current_pane_id" ]]; then
                placement_reason="current process cwd unavailable"
            fi
        fi
    fi

    local root_pane_id=""
    if [[ -z "$target_tab_id" ]]; then
        local repo_tab_info
        repo_tab_info="$(zgpt_herdr_ensure_repo_tab "$cwd")"
        target_tab_id="$(printf '%s\n' "$repo_tab_info" | sed -n 's/^target_tab_id=//p' | sed -n '1p')"
        created_tab_id="$(printf '%s\n' "$repo_tab_info" | sed -n 's/^created_tab_id=//p' | sed -n '1p')"
        root_pane_id="$(printf '%s\n' "$repo_tab_info" | sed -n 's/^root_pane_id=//p' | sed -n '1p')"
        placement_source="repo-tab-fallback"
        [[ -n "$placement_reason" ]] || placement_reason="could not detect current pane/tab"
    fi

    [[ -n "$target_tab_id" ]] || return 1
    printf 'placement_source=%s\n' "$placement_source"
    printf 'target_tab_id=%s\n' "$target_tab_id"
    [[ -n "$manager_pane_id" ]] && printf 'manager_pane_id=%s\n' "$manager_pane_id" || true
    [[ -n "$placement_reason" ]] && printf 'placement_reason=%s\n' "$placement_reason" || true
    [[ -n "$created_tab_id" ]] && printf 'created_tab_id=%s\n' "$created_tab_id" || true
    [[ -n "$root_pane_id" ]] && printf 'root_pane_id=%s\n' "$root_pane_id" || true
    return 0
}

# Resolve worker target tab id using herdr primitives.
# Same precedence as zgpt_resolve_target_tab_id but for herdr tab ids (strings
# like "w1:t3", not bare integers).
#
# NOTE: legacy bare integer pane ids are ignored here. Callers that run inside
# herdr should set ZGPT_MANAGER_PANE_ID to a herdr pane id.
#
# Returns 0 with tab_id printed, 1 if no anchor found (caller should create a
# repo tab), or 2 on error.
zgpt_herdr_resolve_target_tab_id() {
    local meta target_tab_id
    meta="$(zgpt_herdr_resolve_target_placement "${1:-}" "$PWD")" || return $?
    target_tab_id="$(printf '%s\n' "$meta" | sed -n 's/^target_tab_id=//p' | sed -n '1p')"
    [[ -n "$target_tab_id" ]] || return 1
    printf '%s\n' "$target_tab_id"
}

# Print the tab_id of the first repo-named tab (agents:<repo>, agents:<repo>-2,
# ...) that can host a new worker pane: fewer than 6 live panes and at least
# one non-human pane to split from. Prints nothing and returns 1
# when no existing repo tab is suitable — the caller then falls through to
# creating the next unused suffix (zgpt_herdr_ensure_repo_tab) or to the
# pane-current anchors. Stops at the first gap in the suffix sequence: labels
# are created sequentially, so nothing beyond a missing suffix is used yet.
zgpt_herdr_find_suitable_repo_tab() {
    local cwd="${1:-$PWD}"
    local base i tab_label existing
    base="$(zgpt_repo_tab_name "$cwd")"
    i=1
    while (( i <= 64 )); do
        if (( i == 1 )); then
            tab_label="$base"
        else
            tab_label="${base}-${i}"
        fi
        existing="$(zgpt_herdr_tab_id_for_label "$tab_label" || true)"
        if [[ -n "$existing" ]]; then
            if zgpt_herdr_anchor_for_tab "$existing" >/dev/null; then
                printf '%s\n' "$existing"
                return 0
            fi
        else
            return 1
        fi
        i=$((i + 1))
    done
    return 1
}

# Find or create the repo-named tab used when a detached manager has no stable
# pane anchor. Repo tabs are named agents:<repo>, agents:<repo>-2, agents:<repo>-3,
# ...; the first one that exists and can host another worker is reused, and a
# fresh tab is created only once every existing suffix is full or holds no
# splittable pane. Uses herdr tab create/list. Prints two key=value lines:
# target_tab_id=... and created_tab_id=... (created_tab_id is empty when an
# existing tab was reused), plus root_pane_id=... for a freshly created tab.
zgpt_herdr_ensure_repo_tab() {
    local cwd="${1:-$PWD}"
    local base i tab_label existing
    base="$(zgpt_repo_tab_name "$cwd")"
    i=1
    while (( i <= 64 )); do
        if (( i == 1 )); then
            tab_label="$base"
        else
            tab_label="${base}-${i}"
        fi
        existing="$(zgpt_herdr_tab_id_for_label "$tab_label" || true)"
        if [[ -n "$existing" ]]; then
            if zgpt_herdr_anchor_for_tab "$existing" >/dev/null; then
                printf 'target_tab_id=%s\n' "$existing"
                printf 'created_tab_id=\n'
                return 0
            fi
        else
            break
        fi
        i=$((i + 1))
    done

    local result created_tab_id root_pane_id
    result="$(hd tab create --cwd "$cwd" --label "$tab_label" --no-focus 2>&1)"
    created_tab_id="$(printf '%s\n' "$result" | jq -r '.result.tab.tab_id // empty' 2>/dev/null)"
    [[ -n "$created_tab_id" ]] || {
        printf 'error: could not create repo tab %q; herdr returned: %s\n' "$tab_label" "$result" >&2
        return 2
    }
    # herdr >=0.7.5 returns the tab's bootstrap pane as result.root_pane; the
    # caller reuses it directly as the worker pane instead of splitting off a
    # throwaway extra pane and closing it afterward.
    root_pane_id="$(printf '%s\n' "$result" | jq -r '.result.root_pane.pane_id // empty' 2>/dev/null)"
    printf 'target_tab_id=%s\n' "$created_tab_id"
    printf 'created_tab_id=%s\n' "$created_tab_id"
    [[ -n "$root_pane_id" ]] && printf 'root_pane_id=%s\n' "$root_pane_id" || true
}
